#ifndef __XAI_NEWS_FILTER_MQH__
#define __XAI_NEWS_FILTER_MQH__

class CXAINewsFilter
{
private:
   int  m_before_minutes;
   int  m_after_minutes;
   bool m_fail_closed;
   bool m_last_blocked;
   datetime m_last_event_time;
   string m_last_event_name;

   bool IsUSDHighImpact(const MqlCalendarEvent &event) const
   {
      // MT5 calendar importance: CALENDAR_IMPORTANCE_HIGH is the blocking tier.
      return event.importance==CALENDAR_IMPORTANCE_HIGH;
   }

public:
   CXAINewsFilter()
   {
      m_before_minutes=30;
      m_after_minutes=30;
      m_fail_closed=true;
      m_last_blocked=false;
      m_last_event_time=0;
      m_last_event_name="";
   }

   void Configure(const int before_minutes,
                  const int after_minutes,
                  const bool fail_closed)
   {
      m_before_minutes=before_minutes;
      m_after_minutes=after_minutes;
      m_fail_closed=fail_closed;
   }

   bool Refresh()
   {
      m_last_blocked=false;
      m_last_event_time=0;
      m_last_event_name="";

      MqlCalendarValue values[];
      datetime from_time=TimeGMT()-m_after_minutes*60;
      datetime to_time=TimeGMT()+m_before_minutes*60;

      ResetLastError();
      const int count=CalendarValueHistory(values,from_time,to_time,NULL,NULL);

      if(count<0)
         return !m_fail_closed;

      for(int i=0;i<count;i++)
      {
         MqlCalendarEvent event;
         ResetLastError();

         if(!CalendarEventById(values[i].event_id,event))
         {
            if(m_fail_closed)
               return false;
            continue;
         }

         if(event.currency!="USD")
            continue;

         if(!IsUSDHighImpact(event))
            continue;

         m_last_blocked=true;
         m_last_event_time=values[i].time;
         m_last_event_name=event.name;
         return true;
      }

      return true;
   }

   bool HasBlockingNews() const
   {
      return m_last_blocked;
   }

   datetime LastEventTime() const
   {
      return m_last_event_time;
   }

   string LastEventName() const
   {
      return m_last_event_name;
   }

   bool IsReady() const
   {
      return true;
   }
};

#endif
