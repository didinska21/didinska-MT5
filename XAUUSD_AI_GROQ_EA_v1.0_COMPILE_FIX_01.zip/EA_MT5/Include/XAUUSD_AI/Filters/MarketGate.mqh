#ifndef __XAI_MARKET_GATE_MQH__
#define __XAI_MARKET_GATE_MQH__

struct XAIEnvironmentDecision
{
   bool session_allowed;
   bool news_blocked;
   bool spread_allowed;
   bool volatility_allowed;
   bool pass;
   string reason;
};

class CXAIMarketGate
{
public:
   bool Evaluate(const bool session_allowed,
                 const bool news_blocked,
                 const bool spread_allowed,
                 const bool volatility_allowed,
                 XAIEnvironmentDecision &out) const
   {
      out.session_allowed=session_allowed;
      out.news_blocked=news_blocked;
      out.spread_allowed=spread_allowed;
      out.volatility_allowed=volatility_allowed;
      out.pass=false;
      out.reason="";

      if(!session_allowed)
      {
         out.reason="SESSION_BLOCKED";
         return false;
      }

      if(news_blocked)
      {
         out.reason="NEWS_BLOCKED";
         return false;
      }

      if(!spread_allowed)
      {
         out.reason="SPREAD_HIGH";
         return false;
      }

      if(!volatility_allowed)
      {
         out.reason="VOLATILITY_EXTREME";
         return false;
      }

      out.pass=true;
      out.reason="PASS";
      return true;
   }
};

#endif
