#ifndef __XAI_SESSION_FILTER_MQH__
#define __XAI_SESSION_FILTER_MQH__

enum XAISession
{
   XAI_SESSION_CLOSED = 0,
   XAI_SESSION_LONDON,
   XAI_SESSION_NEW_YORK,
   XAI_SESSION_OVERLAP
};

class CXAISessionFilter
{
private:
   int  m_london_start_hour;
   int  m_london_end_hour;
   int  m_ny_start_hour;
   int  m_ny_end_hour;
   bool m_allow_london;
   bool m_allow_new_york;
   bool m_allow_overlap;

   bool InWindow(const int hour,const int start_hour,const int end_hour) const
   {
      if(start_hour==end_hour) return true;
      if(start_hour<end_hour)
         return hour>=start_hour && hour<end_hour;
      return hour>=start_hour || hour<end_hour;
   }

public:
   CXAISessionFilter()
   {
      m_london_start_hour=7;
      m_london_end_hour=12;
      m_ny_start_hour=12;
      m_ny_end_hour=17;
      m_allow_london=true;
      m_allow_new_york=true;
      m_allow_overlap=true;
   }

   void Configure(const int london_start_utc,
                  const int london_end_utc,
                  const int new_york_start_utc,
                  const int new_york_end_utc,
                  const bool allow_london,
                  const bool allow_new_york,
                  const bool allow_overlap)
   {
      m_london_start_hour=london_start_utc;
      m_london_end_hour=london_end_utc;
      m_ny_start_hour=new_york_start_utc;
      m_ny_end_hour=new_york_end_utc;
      m_allow_london=allow_london;
      m_allow_new_york=allow_new_york;
      m_allow_overlap=allow_overlap;
   }

   XAISession CurrentSessionUTC(const datetime utc_time) const
   {
      MqlDateTime dt;
      TimeToStruct(utc_time,dt);

      const bool london=InWindow(dt.hour,m_london_start_hour,m_london_end_hour);
      const bool ny=InWindow(dt.hour,m_ny_start_hour,m_ny_end_hour);

      if(london && ny) return XAI_SESSION_OVERLAP;
      if(london) return XAI_SESSION_LONDON;
      if(ny) return XAI_SESSION_NEW_YORK;
      return XAI_SESSION_CLOSED;
   }

   bool IsAllowedUTC(const datetime utc_time) const
   {
      const XAISession session=CurrentSessionUTC(utc_time);

      if(session==XAI_SESSION_OVERLAP)
         return m_allow_overlap && (m_allow_london || m_allow_new_york);

      if(session==XAI_SESSION_LONDON)
         return m_allow_london;

      if(session==XAI_SESSION_NEW_YORK)
         return m_allow_new_york;

      return false;
   }

   XAISession CurrentSession() const
   {
      return CurrentSessionUTC(TimeGMT());
   }

   bool IsAllowed() const
   {
      return IsAllowedUTC(TimeGMT());
   }
};

#endif
