#ifndef __XAI_ENGINE_GUARD_MQH__
#define __XAI_ENGINE_GUARD_MQH__

class CXAIEngineGuard
{
private:
   bool m_execution_lock;
   bool m_recovery_complete;
   bool m_fatal_error;

public:
   CXAIEngineGuard()
   {
      m_execution_lock=false;
      m_recovery_complete=false;
      m_fatal_error=false;
   }

   void SetRecoveryComplete(const bool value) { m_recovery_complete=value; }
   void SetExecutionLock(const bool value) { m_execution_lock=value; }
   void SetFatalError(const bool value) { m_fatal_error=value; }

   bool CanScan() const
   {
      return m_recovery_complete && !m_fatal_error;
   }

   bool CanOpenNewTrade() const
   {
      return m_recovery_complete && !m_execution_lock && !m_fatal_error;
   }

   bool IsLocked() const { return m_execution_lock || m_fatal_error; }
};

#endif
