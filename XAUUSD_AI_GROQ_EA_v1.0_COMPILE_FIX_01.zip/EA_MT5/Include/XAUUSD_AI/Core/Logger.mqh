#ifndef XAUUSD_AI_LOGGER_MQH
#define XAUUSD_AI_LOGGER_MQH

class CXAILogger {
public:
   void Info(string msg) { Print("[XAI][INFO] ", msg); }
   void Warning(string msg) { Print("[XAI][WARN] ", msg); }
   void Error(string msg) { Print("[XAI][ERROR] ", msg); }
   void Trade(string msg) { Print("[XAI][TRADE] ", msg); }
   void Risk(string msg) { Print("[XAI][RISK] ", msg); }
   void AI(string msg) { Print("[XAI][AI] ", msg); }
};

#endif
