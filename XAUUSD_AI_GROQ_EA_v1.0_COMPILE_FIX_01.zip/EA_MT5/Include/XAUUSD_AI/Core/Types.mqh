#ifndef XAUUSD_AI_TYPES_MQH
#define XAUUSD_AI_TYPES_MQH

enum ENUM_XAI_DIRECTION { XAI_DIR_NONE=0, XAI_DIR_BUY=1, XAI_DIR_SELL=2 };
enum ENUM_XAI_STRUCTURE { XAI_STRUCT_UNKNOWN=0, XAI_STRUCT_BULLISH=1, XAI_STRUCT_BEARISH=2, XAI_STRUCT_RANGING=3, XAI_STRUCT_CONFLICT=4 };
enum ENUM_XAI_SETUP { XAI_SETUP_NONE=0, XAI_SETUP_CONTINUATION=1, XAI_SETUP_REVERSAL=2 };
enum ENUM_XAI_LIQUIDITY_TYPE { XAI_LIQ_SWING_HIGH=0, XAI_LIQ_SWING_LOW, XAI_LIQ_EQUAL_HIGH, XAI_LIQ_EQUAL_LOW, XAI_LIQ_SESSION_HIGH, XAI_LIQ_SESSION_LOW, XAI_LIQ_PREVIOUS_DAY_HIGH, XAI_LIQ_PREVIOUS_DAY_LOW };

enum ENUM_XAI_VOLATILITY { XAI_VOL_UNKNOWN=0, XAI_VOL_LOW=1, XAI_VOL_NORMAL=2, XAI_VOL_HIGH=3, XAI_VOL_EXTREME=4 };
enum ENUM_XAI_AI_DECISION { XAI_AI_WAIT=0, XAI_AI_BUY=1, XAI_AI_SELL=2 };
enum ENUM_XAI_TRADE_STATE { XAI_TRADE_IDLE=0, XAI_TRADE_SIGNAL_CREATED, XAI_TRADE_RISK_APPROVED, XAI_TRADE_ORDER_READY, XAI_TRADE_ORDER_SENT, XAI_TRADE_ORDER_CONFIRMED, XAI_TRADE_POSITION_ACTIVE, XAI_TRADE_POSITION_CLOSED, XAI_TRADE_EXECUTION_FAILED, XAI_TRADE_CANCELLED };

struct SXAISwingPoint {
   datetime time;
   int index;
   double price;
   bool is_high;
   bool confirmed;
   double strength;
};


struct SXAILiquidityLevel {
   ulong id;
   double price;
   datetime time;
   ENUM_XAI_LIQUIDITY_TYPE type;
   double strength;
   bool active;
};

struct XAIStructureSnapshot {
   ENUM_XAI_STRUCTURE state;
   double last_higher_high;
   double last_higher_low;
   double last_lower_high;
   double last_lower_low;
   double last_bos_price;
   datetime last_bos_time;
   double last_choch_price;
   datetime last_choch_time;
   double score;
};

struct XAISetupCandidate {
   string setup_id;
   ENUM_XAI_DIRECTION direction;
   ENUM_XAI_SETUP setup_type;
   datetime created_at;
   double entry_zone_low;
   double entry_zone_high;
   double invalidation_price;
   double proposed_entry;
   double proposed_sl;
   double proposed_tp;
   double technical_score;
   double trend_score;
   double structure_score;
   double liquidity_score;
   double confirmation_score;
   double momentum_score;
   double volatility_score;
   double rr_score;
   ENUM_XAI_STRUCTURE structure;
   bool valid;
};

struct XAIRiskDecision {
   bool approved;
   double risk_percent;
   double risk_money;
   double calculated_lot;
   double entry;
   double sl;
   double tp;
   double rr;
   string reason_code;
};

#endif
