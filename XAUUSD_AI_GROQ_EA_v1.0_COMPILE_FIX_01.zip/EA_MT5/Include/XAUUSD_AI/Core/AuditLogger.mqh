#ifndef __XAI_AUDIT_LOGGER_MQH__
#define __XAI_AUDIT_LOGGER_MQH__

enum XAIAuditLevel
{
   XAI_LOG_INFO = 0,
   XAI_LOG_WARN,
   XAI_LOG_ERROR,
   XAI_LOG_TRADE
};

class CXAIAuditLogger
{
private:
   int    m_handle;
   string m_file_name;

   string EscapeCsv(const string value) const
   {
      string x=value;
      StringReplace(x,"\"","\"\"");
      return "\""+x+"\"";
   }

   string LevelName(const XAIAuditLevel level) const
   {
      if(level==XAI_LOG_WARN)  return "WARN";
      if(level==XAI_LOG_ERROR) return "ERROR";
      if(level==XAI_LOG_TRADE) return "TRADE";
      return "INFO";
   }

public:
   CXAIAuditLogger()
   {
      m_handle=INVALID_HANDLE;
      m_file_name="";
   }

   bool Initialize(const string file_name="XAI_AUDIT.csv")
   {
      m_file_name=file_name;
      m_handle=FileOpen(m_file_name,
                        FILE_READ|FILE_WRITE|FILE_CSV|FILE_SHARE_READ|FILE_SHARE_WRITE,
                        ',');
      if(m_handle==INVALID_HANDLE)
         return false;

      if(FileSize(m_handle)==0)
      {
         FileWrite(m_handle,
                   "timestamp_utc",
                   "level",
                   "event",
                   "state",
                   "request_id",
                   "setup_id",
                   "symbol",
                   "direction",
                   "technical_score",
                   "ai_decision",
                   "ai_confidence",
                   "risk_assessment",
                   "entry",
                   "sl",
                   "tp",
                   "rr",
                   "volume",
                   "ticket",
                   "retcode",
                   "message");
      }
      FileSeek(m_handle,0,SEEK_END);
      return true;
   }

   void Write(const XAIAuditLevel level,
              const string event,
              const string state,
              const string request_id,
              const string setup_id,
              const string symbol,
              const string direction,
              const double technical_score,
              const string ai_decision,
              const double ai_confidence,
              const string risk_assessment,
              const double entry,
              const double sl,
              const double tp,
              const double rr,
              const double volume,
              const ulong ticket,
              const uint retcode,
              const string message)
   {
      if(m_handle==INVALID_HANDLE)
         return;

      FileSeek(m_handle,0,SEEK_END);
      FileWrite(m_handle,
                TimeToString(TimeGMT(),TIME_DATE|TIME_SECONDS),
                LevelName(level),
                event,
                state,
                request_id,
                setup_id,
                symbol,
                direction,
                DoubleToString(technical_score,4),
                ai_decision,
                DoubleToString(ai_confidence,4),
                risk_assessment,
                DoubleToString(entry,_Digits),
                DoubleToString(sl,_Digits),
                DoubleToString(tp,_Digits),
                DoubleToString(rr,4),
                DoubleToString(volume,2),
                (string)ticket,
                (string)retcode,
                message);
      FileFlush(m_handle);
   }

   void Close()
   {
      if(m_handle!=INVALID_HANDLE)
      {
         FileFlush(m_handle);
         FileClose(m_handle);
         m_handle=INVALID_HANDLE;
      }
   }

   ~CXAIAuditLogger()
   {
      Close();
   }
};

#endif
