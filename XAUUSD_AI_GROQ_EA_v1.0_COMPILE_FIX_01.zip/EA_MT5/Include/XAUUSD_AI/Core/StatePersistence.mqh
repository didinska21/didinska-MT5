#ifndef __XAI_STATE_PERSISTENCE_MQH__
#define __XAI_STATE_PERSISTENCE_MQH__

class CXAIStatePersistence
{
private:
   string Key(const string suffix) const
   {
      return "XAI_STATE_"+IntegerToString((long)AccountInfoInteger(ACCOUNT_LOGIN))+
             "_"+_Symbol+"_"+suffix;
   }

public:
   void Save(const int state,const string request_id,const string setup_id)
   {
      GlobalVariableSet(Key("STATE"),(double)state);
      GlobalVariableSet(Key("UPDATED"),(double)TimeCurrent());
      // String values are persisted through dedicated terminal globals using a
      // deterministic hash; full identifiers remain in the audit log.
      GlobalVariableSet(Key("REQUEST_HASH"),(double)StringGetCharacter(request_id,0));
      GlobalVariableSet(Key("SETUP_HASH"),(double)StringGetCharacter(setup_id,0));
   }

   int LoadState(const int fallback_state) const
   {
      const string key=Key("STATE");
      if(!GlobalVariableCheck(key))
         return fallback_state;
      return (int)GlobalVariableGet(key);
   }

   void Clear()
   {
      GlobalVariableDel(Key("STATE"));
      GlobalVariableDel(Key("UPDATED"));
      GlobalVariableDel(Key("REQUEST_HASH"));
      GlobalVariableDel(Key("SETUP_HASH"));
   }
};

#endif
