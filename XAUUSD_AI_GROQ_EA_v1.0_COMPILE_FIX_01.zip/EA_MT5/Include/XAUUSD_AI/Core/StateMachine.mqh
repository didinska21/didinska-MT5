#ifndef __XAI_STATE_MACHINE_MQH__
#define __XAI_STATE_MACHINE_MQH__

enum XAIState
{
   XAI_STATE_INIT = 0,
   XAI_STATE_RECOVERY,
   XAI_STATE_IDLE,
   XAI_STATE_SCANNING,
   XAI_STATE_CANDIDATE,
   XAI_STATE_PRECHECK,
   XAI_STATE_AI_PENDING,
   XAI_STATE_AI_APPROVED,
   XAI_STATE_EXECUTION_PENDING,
   XAI_STATE_POSITION_ACTIVE,
   XAI_STATE_POSITION_MANAGING,
   XAI_STATE_CLOSING,
   XAI_STATE_COOLDOWN,
   XAI_STATE_ERROR
};

enum XAIEvent
{
   XAI_EVENT_NONE = 0,
   XAI_EVENT_INIT_OK,
   XAI_EVENT_RECOVERY_REQUIRED,
   XAI_EVENT_RECOVERY_DONE,
   XAI_EVENT_NEW_BAR,
   XAI_EVENT_CANDIDATE_FOUND,
   XAI_EVENT_PRECHECK_PASS,
   XAI_EVENT_PRECHECK_FAIL,
   XAI_EVENT_AI_REQUIRED,
   XAI_EVENT_AI_PASS,
   XAI_EVENT_AI_FAIL,
   XAI_EVENT_EXECUTION_START,
   XAI_EVENT_EXECUTION_SUCCESS,
   XAI_EVENT_EXECUTION_FAIL,
   XAI_EVENT_POSITION_FOUND,
   XAI_EVENT_POSITION_CLOSED,
   XAI_EVENT_COOLDOWN_DONE,
   XAI_EVENT_FATAL_ERROR
};

class CXAIStateMachine
{
private:
   XAIState m_state;
   XAIState m_previous;
   string   m_reason;
   ulong    m_transition_count;

   bool IsAllowed(const XAIState from,const XAIEvent event,XAIState &to) const
   {
      to=from;

      if(from==XAI_STATE_INIT && event==XAI_EVENT_RECOVERY_REQUIRED)
      {
         to=XAI_STATE_RECOVERY; return true;
      }
      if(from==XAI_STATE_INIT && event==XAI_EVENT_INIT_OK)
      {
         to=XAI_STATE_IDLE; return true;
      }
      if(from==XAI_STATE_RECOVERY && event==XAI_EVENT_RECOVERY_DONE)
      {
         to=XAI_STATE_IDLE; return true;
      }
      if(from==XAI_STATE_IDLE && event==XAI_EVENT_NEW_BAR)
      {
         to=XAI_STATE_SCANNING; return true;
      }
      if(from==XAI_STATE_SCANNING && event==XAI_EVENT_CANDIDATE_FOUND)
      {
         to=XAI_STATE_CANDIDATE; return true;
      }
      if(from==XAI_STATE_CANDIDATE && event==XAI_EVENT_PRECHECK_PASS)
      {
         to=XAI_STATE_PRECHECK; return true;
      }
      if(from==XAI_STATE_CANDIDATE && event==XAI_EVENT_PRECHECK_FAIL)
      {
         to=XAI_STATE_IDLE; return true;
      }
      if(from==XAI_STATE_PRECHECK && event==XAI_EVENT_AI_REQUIRED)
      {
         to=XAI_STATE_AI_PENDING; return true;
      }
      if(from==XAI_STATE_AI_PENDING && event==XAI_EVENT_AI_PASS)
      {
         to=XAI_STATE_AI_APPROVED; return true;
      }
      if(from==XAI_STATE_AI_PENDING && event==XAI_EVENT_AI_FAIL)
      {
         to=XAI_STATE_IDLE; return true;
      }
      if(from==XAI_STATE_AI_APPROVED && event==XAI_EVENT_EXECUTION_START)
      {
         to=XAI_STATE_EXECUTION_PENDING; return true;
      }
      if(from==XAI_STATE_EXECUTION_PENDING && event==XAI_EVENT_EXECUTION_SUCCESS)
      {
         to=XAI_STATE_POSITION_ACTIVE; return true;
      }
      if(from==XAI_STATE_EXECUTION_PENDING && event==XAI_EVENT_EXECUTION_FAIL)
      {
         to=XAI_STATE_IDLE; return true;
      }
      if(from==XAI_STATE_POSITION_ACTIVE && event==XAI_EVENT_POSITION_FOUND)
      {
         to=XAI_STATE_POSITION_MANAGING; return true;
      }
      if(from==XAI_STATE_POSITION_MANAGING && event==XAI_EVENT_POSITION_CLOSED)
      {
         to=XAI_STATE_COOLDOWN; return true;
      }
      if(from==XAI_STATE_COOLDOWN && event==XAI_EVENT_COOLDOWN_DONE)
      {
         to=XAI_STATE_IDLE; return true;
      }
      if(event==XAI_EVENT_FATAL_ERROR)
      {
         to=XAI_STATE_ERROR; return true;
      }
      return false;
   }

public:
   CXAIStateMachine()
   {
      m_state=XAI_STATE_INIT;
      m_previous=XAI_STATE_INIT;
      m_reason="BOOT";
      m_transition_count=0;
   }

   bool Transition(const XAIEvent event,const string reason)
   {
      XAIState next;
      if(!IsAllowed(m_state,event,next))
         return false;

      m_previous=m_state;
      m_state=next;
      m_reason=reason;
      m_transition_count++;
      return true;
   }

   XAIState State() const { return m_state; }
   XAIState PreviousState() const { return m_previous; }
   string Reason() const { return m_reason; }
   ulong TransitionCount() const { return m_transition_count; }

   bool CanRequestAI() const
   {
      return m_state==XAI_STATE_PRECHECK;
   }

   bool CanExecute() const
   {
      return m_state==XAI_STATE_AI_APPROVED;
   }

   bool IsManagingPosition() const
   {
      return m_state==XAI_STATE_POSITION_ACTIVE ||
             m_state==XAI_STATE_POSITION_MANAGING;
   }

   bool IsSafeToOpenNewTrade() const
   {
      return m_state==XAI_STATE_IDLE;
   }
};

#endif
