#ifndef XAUUSD_AI_RECOVERY_MANAGER_MQH
#define XAUUSD_AI_RECOVERY_MANAGER_MQH

#include <XAUUSD_AI/Core/Types.mqh>
#include <XAUUSD_AI/Core/Config.mqh>

class CXAIRecoveryManager {
private:
   ulong  m_magic;
   string m_symbol;
   bool   m_recovered;
   bool   m_execution_lock;
   int    m_recovered_positions;
   int    m_recovered_orders;
   int    m_recovered_today_entries;

   string GVName(string suffix) const {
      return StringFormat("XAI_%I64u_%s_%s",m_magic,m_symbol,suffix);
   }

   string DayKey() const {
      MqlDateTime dt;
      TimeToStruct(TimeCurrent(),dt);
      return StringFormat("%04d%02d%02d",dt.year,dt.mon,dt.day);
   }

   bool IsManagedPosition(ulong ticket) const {
      if(ticket==0 || !PositionSelectByTicket(ticket)) return false;
      if(PositionGetString(POSITION_SYMBOL)!=m_symbol) return false;
      return ((ulong)PositionGetInteger(POSITION_MAGIC)==m_magic);
   }

   bool IsManagedOrder(ulong ticket) const {
      if(ticket==0 || !OrderSelect(ticket)) return false;
      if(OrderGetString(ORDER_SYMBOL)!=m_symbol) return false;
      return ((ulong)OrderGetInteger(ORDER_MAGIC)==m_magic);
   }

   int CountManagedPositions() const {
      int count=0;
      for(int i=PositionsTotal()-1;i>=0;i--) {
         ulong ticket=PositionGetTicket(i);
         if(IsManagedPosition(ticket)) count++;
      }
      return count;
   }

   int CountManagedOrders() const {
      int count=0;
      for(int i=OrdersTotal()-1;i>=0;i--) {
         ulong ticket=OrderGetTicket(i);
         if(IsManagedOrder(ticket)) count++;
      }
      return count;
   }

   datetime DayStart() const {
      MqlDateTime dt;
      TimeToStruct(TimeCurrent(),dt);
      dt.hour=0; dt.min=0; dt.sec=0;
      return StructToTime(dt);
   }

   int ReconstructTodayEntries() const {
      const datetime from=DayStart();
      const datetime to=TimeCurrent();
      if(!HistorySelect(from,to)) return 0;

      int entries=0;
      const int deals=HistoryDealsTotal();
      for(int i=0;i<deals;i++) {
         ulong deal=HistoryDealGetTicket(i);
         if(deal==0) continue;
         if(HistoryDealGetString(deal,DEAL_SYMBOL)!=m_symbol) continue;
         if((ulong)HistoryDealGetInteger(deal,DEAL_MAGIC)!=m_magic) continue;
         ENUM_DEAL_ENTRY entry=(ENUM_DEAL_ENTRY)HistoryDealGetInteger(deal,DEAL_ENTRY);
         if(entry==DEAL_ENTRY_IN || entry==DEAL_ENTRY_INOUT) entries++;
      }
      return entries;
   }

   bool RebuildDailyCounters() {
      const string day_name=GVName("DAY");
      const string start_name=GVName("START_BALANCE");
      const string trades_name=GVName("DAILY_TRADES");

      const string today=DayKey();
      bool new_day=true;
      if(GlobalVariableCheck(day_name)) {
         const string stored=DoubleToString(GlobalVariableGet(day_name),0);
         new_day=(stored!=today);
      }

      if(new_day || !GlobalVariableCheck(start_name)) {
         GlobalVariableSet(day_name,(double)StringToInteger(today));
         GlobalVariableSet(start_name,AccountInfoDouble(ACCOUNT_BALANCE));
      }

      // If the daily counter is missing/corrupt, reconstruct it from broker history.
      const int history_entries=ReconstructTodayEntries();
      if(!GlobalVariableCheck(trades_name)) {
         GlobalVariableSet(trades_name,(double)history_entries);
      } else {
         double stored=GlobalVariableGet(trades_name);
         if(stored<0.0 || stored>1000000.0) stored=0.0;
         if((int)stored<history_entries) stored=(double)history_entries;
         GlobalVariableSet(trades_name,stored);
      }

      m_recovered_today_entries=(int)GlobalVariableGet(trades_name);
      return true;
   }

   void RebuildPeakEquity() {
      const string peak_name=GVName("PEAK_EQUITY");
      const double equity=AccountInfoDouble(ACCOUNT_EQUITY);
      if(!GlobalVariableCheck(peak_name)) {
         GlobalVariableSet(peak_name,equity);
         return;
      }
      double peak=GlobalVariableGet(peak_name);
      if(peak<=0.0 || equity>peak) GlobalVariableSet(peak_name,equity);
   }

   void RecoverInitialRiskForPosition(ulong ticket) {
      if(ticket==0 || !PositionSelectByTicket(ticket)) return;
      string key=StringFormat("XAI.INITRISK.%I64u",ticket);
      if(GlobalVariableCheck(key) && GlobalVariableGet(key)>0.0) return;

      ENUM_POSITION_TYPE type=(ENUM_POSITION_TYPE)PositionGetInteger(POSITION_TYPE);
      double open_price=PositionGetDouble(POSITION_PRICE_OPEN);
      double sl=PositionGetDouble(POSITION_SL);
      if(open_price<=0.0 || sl<=0.0) return;

      double risk=(type==POSITION_TYPE_BUY ? open_price-sl : sl-open_price);
      if(risk>0.0) GlobalVariableSet(key,risk);
   }

   void RecoverPositions() {
      m_recovered_positions=0;
      for(int i=PositionsTotal()-1;i>=0;i--) {
         ulong ticket=PositionGetTicket(i);
         if(!IsManagedPosition(ticket)) continue;
         m_recovered_positions++;
         RecoverInitialRiskForPosition(ticket);
      }
   }

   void DetectOpenOrders() {
      m_recovered_orders=CountManagedOrders();
      // v1.0 uses market orders only. An existing managed order at startup is
      // therefore treated conservatively as an execution lock; we never resend it.
      m_execution_lock=(m_recovered_orders>0);
   }

public:
   void Configure(ulong magic,string symbol) {
      m_magic=magic;
      m_symbol=symbol;
      m_recovered=false;
      m_execution_lock=false;
      m_recovered_positions=0;
      m_recovered_orders=0;
      m_recovered_today_entries=0;
   }

   bool Recover() {
      if(m_symbol=="" || m_magic==0) return false;

      // Recovery is read-only with respect to broker execution. It reconstructs
      // local state and never sends, modifies, or closes an order/position.
      if(!RebuildDailyCounters()) return false;
      RebuildPeakEquity();
      RecoverPositions();
      DetectOpenOrders();

      m_recovered=true;
      return true;
   }

   bool IsRecovered() const { return m_recovered; }
   bool IsExecutionLocked() const { return m_execution_lock; }
   int RecoveredPositions() const { return m_recovered_positions; }
   int RecoveredOrders() const { return m_recovered_orders; }
   int RecoveredTodayEntries() const { return m_recovered_today_entries; }

   string Status() const {
      return StringFormat("recovered=%s positions=%d orders=%d today_entries=%d execution_lock=%s",
         m_recovered?"true":"false",
         m_recovered_positions,
         m_recovered_orders,
         m_recovered_today_entries,
         m_execution_lock?"true":"false");
   }
};

#endif
