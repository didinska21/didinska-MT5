#ifndef XAUUSD_AI_POSITION_MANAGER_MQH
#define XAUUSD_AI_POSITION_MANAGER_MQH

#include <Trade/Trade.mqh>
#include <XAUUSD_AI/Core/Types.mqh>
#include <XAUUSD_AI/Core/Config.mqh>

class CXAIPositionManager {
private:
   CTrade m_trade;
   ulong m_magic;
   double m_point;
   double m_tick_size;

   string RiskKey(ulong ticket) {
      return StringFormat("XAI.INITRISK.%I64u",ticket);
   }

   bool IsManagedPosition(int index, ulong &ticket) {
      ticket=PositionGetTicket(index);
      if(ticket==0) return false;
      if(!PositionSelectByTicket(ticket)) return false;
      if(InpManageOnlyXAIPositions) {
         if((ulong)PositionGetInteger(POSITION_MAGIC)!=m_magic) return false;
      }
      string symbol=PositionGetString(POSITION_SYMBOL);
      return (symbol==_Symbol);
   }

   double NormalizePrice(double price) {
      double ts=(m_tick_size>0.0 ? m_tick_size : m_point);
      if(ts<=0.0) return NormalizeDouble(price,_Digits);
      return NormalizeDouble(MathRound(price/ts)*ts,_Digits);
   }

   double InitialRisk(ulong ticket, ENUM_POSITION_TYPE type, double open_price, double current_sl) {
      string key=RiskKey(ticket);
      if(GlobalVariableCheck(key)) {
         double r=GlobalVariableGet(key);
         if(r>0.0) return r;
      }
      if(current_sl>0.0) {
         double r=(type==POSITION_TYPE_BUY ? open_price-current_sl : current_sl-open_price);
         if(r>0.0) {
            GlobalVariableSet(key,r);
            return r;
         }
      }
      return 0.0;
   }

   bool BetterSL(ENUM_POSITION_TYPE type,double old_sl,double new_sl) {
      if(new_sl<=0.0) return false;
      if(old_sl<=0.0) return true;
      if(type==POSITION_TYPE_BUY) return new_sl>old_sl+m_point*0.1;
      return new_sl<old_sl-m_point*0.1;
   }

   bool BrokerDistanceValid(ENUM_POSITION_TYPE type,double sl) {
      double bid=SymbolInfoDouble(_Symbol,SYMBOL_BID);
      double ask=SymbolInfoDouble(_Symbol,SYMBOL_ASK);
      int stops=(int)SymbolInfoInteger(_Symbol,SYMBOL_TRADE_STOPS_LEVEL);
      int freeze=(int)SymbolInfoInteger(_Symbol,SYMBOL_TRADE_FREEZE_LEVEL);
      double min_dist=MathMax(stops,freeze)*m_point;
      if(type==POSITION_TYPE_BUY) return (bid-sl)>=min_dist;
      return (sl-ask)>=min_dist;
   }

public:
   void Configure(ulong magic) {
      m_magic=magic;
      m_point=SymbolInfoDouble(_Symbol,SYMBOL_POINT);
      m_tick_size=SymbolInfoDouble(_Symbol,SYMBOL_TRADE_TICK_SIZE);
      m_trade.SetExpertMagicNumber(m_magic);
      m_trade.SetDeviationInPoints(InpMaxDeviationPoints);
   }

   int ManagedPositions() {
      int count=0;
      for(int i=PositionsTotal()-1;i>=0;i--) {
         ulong ticket=0;
         if(IsManagedPosition(i,ticket)) count++;
      }
      return count;
   }

   bool ManagePosition(ulong ticket,double atr,const XAIStructureSnapshot &structure) {
      if(!PositionSelectByTicket(ticket)) return false;
      if(PositionGetString(POSITION_SYMBOL)!=_Symbol) return false;
      if(InpManageOnlyXAIPositions && (ulong)PositionGetInteger(POSITION_MAGIC)!=m_magic) return false;

      ENUM_POSITION_TYPE type=(ENUM_POSITION_TYPE)PositionGetInteger(POSITION_TYPE);
      double open_price=PositionGetDouble(POSITION_PRICE_OPEN);
      double sl=PositionGetDouble(POSITION_SL);
      double tp=PositionGetDouble(POSITION_TP);
      double price=(type==POSITION_TYPE_BUY ? SymbolInfoDouble(_Symbol,SYMBOL_BID) : SymbolInfoDouble(_Symbol,SYMBOL_ASK));
      if(open_price<=0.0 || price<=0.0) return false;

      double risk=InitialRisk(ticket,type,open_price,sl);
      if(risk<=0.0) return false;
      double profit_distance=(type==POSITION_TYPE_BUY ? price-open_price : open_price-price);
      double r_multiple=profit_distance/risk;

      double candidate_sl=sl;
      bool changed=false;

      if(InpEnableBreakEven && r_multiple>=InpBreakEvenTriggerR) {
         double buffer=(atr>0.0 ? atr*InpBreakEvenBufferATR : 0.0);
         double be=(type==POSITION_TYPE_BUY ? open_price+buffer : open_price-buffer);
         be=NormalizePrice(be);
         if(BetterSL(type,candidate_sl,be) && BrokerDistanceValid(type,be)) {
            candidate_sl=be;
            changed=true;
         }
      }

      if(InpEnableStructureTrailing && r_multiple>=InpTrailingStartR && atr>0.0) {
         double buffer=atr*InpTrailingBufferATR;
         double trail=0.0;
         if(type==POSITION_TYPE_BUY && structure.last_higher_low>0.0)
            trail=structure.last_higher_low-buffer;
         else if(type==POSITION_TYPE_SELL && structure.last_lower_high>0.0)
            trail=structure.last_lower_high+buffer;

         if(trail>0.0) {
            trail=NormalizePrice(trail);
            if(BetterSL(type,candidate_sl,trail) && BrokerDistanceValid(type,trail)) {
               candidate_sl=trail;
               changed=true;
            }
         }
      }

      if(!changed) return true;
      if(!m_trade.PositionModify(_Symbol,candidate_sl,tp)) return false;
      uint rc=m_trade.ResultRetcode();
      if(rc!=TRADE_RETCODE_DONE && rc!=TRADE_RETCODE_DONE_PARTIAL) return false;
      return true;
   }

   void ManageAll(double atr,const XAIStructureSnapshot &structure) {
      for(int i=PositionsTotal()-1;i>=0;i--) {
         ulong ticket=0;
         if(IsManagedPosition(i,ticket)) ManagePosition(ticket,atr,structure);
      }
   }

   void CleanupClosedRiskState() {
      // Global variables are deliberately retained for audit/recovery. They are
      // harmless after closure and can be cleaned by a future retention job.
   }
};

#endif
