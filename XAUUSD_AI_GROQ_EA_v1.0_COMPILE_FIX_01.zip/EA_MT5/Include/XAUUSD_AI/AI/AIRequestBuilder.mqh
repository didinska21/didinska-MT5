#ifndef __XAI_AI_REQUEST_BUILDER_MQH__
#define __XAI_AI_REQUEST_BUILDER_MQH__

#include <XAUUSD_AI/AI/AIResponse.mqh>

class CAIRequestBuilder
{
private:
   string Escape(const string value) const
   {
      string x=value;
      StringReplace(x,"\\","\\\\");
      StringReplace(x,"\"","\\\"");
      StringReplace(x,"\r","\\r");
      StringReplace(x,"\n","\\n");
      return x;
   }

   string Num(const double value) const
   {
      return DoubleToString(value,8);
   }

public:
   string Build(const string request_id,
                const string setup_id,
                const string timestamp_utc,
                const string symbol,
                const string signal,
                const double technical_score,
                const double entry,
                const double sl,
                const double tp,
                const double rr,
                const string structure,
                const string regime,
                const double momentum,
                const double volatility,
                const bool news_blocked,
                const bool session_allowed,
                const double spread_points,
                const double equity,
                const double risk_percent) const
   {
      string json="{";
      json+="\"request_id\":\""+Escape(request_id)+"\",";
      json+="\"setup_id\":\""+Escape(setup_id)+"\",";
      json+="\"timestamp_utc\":\""+Escape(timestamp_utc)+"\",";
      json+="\"symbol\":\""+Escape(symbol)+"\",";
      json+="\"signal\":\""+Escape(signal)+"\",";
      json+="\"technical_score\":"+Num(technical_score)+",";
      json+="\"market\":{";
      json+="\"entry\":"+Num(entry)+",";
      json+="\"sl\":"+Num(sl)+",";
      json+="\"tp\":"+Num(tp)+",";
      json+="\"rr\":"+Num(rr)+",";
      json+="\"spread_points\":"+Num(spread_points)+"},";
      json+="\"structure\":{\"state\":\""+Escape(structure)+"\"},";
      json+="\"liquidity\":{},";
      json+="\"momentum\":{\"score\":"+Num(momentum)+"},";
      json+="\"volatility\":{\"score\":"+Num(volatility)+"},";
      json+="\"session\":{\"allowed\":"+(session_allowed ? "true":"false")+"},";
      json+="\"news\":{\"blocked\":"+(news_blocked ? "true":"false")+"},";
      json+="\"risk_context\":{";
      json+="\"equity\":"+Num(equity)+",";
      json+="\"risk_percent\":"+Num(risk_percent)+"}";
      json+="}";
      return json;
   }
};

#endif
