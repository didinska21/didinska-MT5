#ifndef __XAI_AI_RESPONSE_MQH__
#define __XAI_AI_RESPONSE_MQH__

struct AIResponse
{
   string request_id;
   string decision;
   double confidence;
   string market_regime;
   double setup_quality;
   string risk_assessment;
   string reason_code;
   bool   valid;
};

#endif
