#ifndef __XAI_AI_CLIENT_MQH__
#define __XAI_AI_CLIENT_MQH__

#include <XAUUSD_AI/AI/AIResponse.mqh>

class CAIClient
{
private:
   string m_url;
   string m_token;
   int    m_timeout_ms;

   bool ParseResponse(const string body,const string expected_request_id,AIResponse &out)
   {
      if(StringFind(body,"\"status\":\"OK\"")<0) return false;

      string marker="\"request_id\":\"";
      int p=StringFind(body,marker);
      if(p<0) return false;
      p+=StringLen(marker);
      int e=StringFind(body,"\"",p);
      if(e<=p) return false;
      out.request_id=StringSubstr(body,p,e-p);
      if(out.request_id!=expected_request_id) return false;

      marker="\"decision\":\"";
      p=StringFind(body,marker);
      if(p<0) return false;
      p+=StringLen(marker);
      e=StringFind(body,"\"",p);
      if(e<=p) return false;
      out.decision=StringSubstr(body,p,e-p);

      marker="\"confidence\":";
      p=StringFind(body,marker);
      if(p<0) return false;
      p+=StringLen(marker);
      e=p;
      while(e<StringLen(body))
      {
         ushort c=StringGetCharacter(body,e);
         if((c>='0' && c<='9') || c=='.' || c=='-') e++;
         else break;
      }
      out.confidence=StringToDouble(StringSubstr(body,p,e-p));
      out.valid=(out.decision=="BUY" || out.decision=="SELL" || out.decision=="WAIT")
                && out.confidence>=0.0 && out.confidence<=1.0;
      return out.valid;
   }

public:
   bool Initialize(const string url,const string token,const int timeout_ms=5000)
   {
      m_url=url; m_token=token; m_timeout_ms=timeout_ms;
      return StringLen(m_url)>0 && StringLen(m_token)>0;
   }

   bool RequestDecision(const string request_id,const string json_body,AIResponse &response)
   {
      char data[];
      char result[];
      string result_headers;
      string headers="Content-Type: application/json\r\nX-Gateway-Token: "+m_token+"\r\n";
      StringToCharArray(json_body,data,0,StringLen(json_body),CP_UTF8);

      ResetLastError();
      int code=WebRequest("POST",m_url+"/v1/decision",headers,m_timeout_ms,
                          data,result,result_headers);
      if(code!=200) return false;

      string body=CharArrayToString(result,0,-1,CP_UTF8);
      return ParseResponse(body,request_id,response);
   }
};

#endif
