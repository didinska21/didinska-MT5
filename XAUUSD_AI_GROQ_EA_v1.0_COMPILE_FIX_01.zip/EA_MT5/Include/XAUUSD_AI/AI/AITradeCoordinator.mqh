#ifndef __XAI_AI_TRADE_COORDINATOR_MQH__
#define __XAI_AI_TRADE_COORDINATOR_MQH__

#include <XAUUSD_AI/AI/AIClient.mqh>
#include <XAUUSD_AI/AI/AIRequestBuilder.mqh>
#include <XAUUSD_AI/AI/FinalAIGate.mqh>

struct XAITradeCandidate
{
   string request_id;
   string setup_id;
   string direction;
   string timestamp_utc;
   string structure;
   double technical_score;
   double entry;
   double sl;
   double tp;
   double rr;
   double momentum;
   double volatility;
   double spread_points;
   double equity;
   double risk_percent;
   bool news_blocked;
   bool session_allowed;
   bool risk_precheck;
   bool setup_valid;
   bool price_valid;
};

class CAITradeCoordinator
{
private:
   CAIClient        m_client;
   CAIRequestBuilder m_builder;
   CFinalAIGate     m_final_gate;
   double            m_min_ai_confidence;
   double            m_min_technical_score;

public:
   bool Initialize(const string gateway_url,
                   const string gateway_token,
                   const double min_ai_confidence=0.75,
                   const double min_technical_score=0.70,
                   const int timeout_ms=5000)
   {
      m_min_ai_confidence=min_ai_confidence;
      m_min_technical_score=min_technical_score;
      return m_client.Initialize(gateway_url,gateway_token,timeout_ms);
   }

   bool Evaluate(const XAITradeCandidate &candidate, AIResponse &response)
   {
      response.valid=false;

      // AI is not called for candidates that are already invalid locally.
      if(!candidate.setup_valid) return false;
      if(!candidate.risk_precheck) return false;
      if(candidate.news_blocked) return false;
      if(!candidate.session_allowed) return false;
      if(!candidate.price_valid) return false;
      if(candidate.technical_score < m_min_technical_score) return false;
      if(candidate.sl<=0.0 || candidate.tp<=0.0 || candidate.rr<=0.0) return false;

      string payload=m_builder.Build(
         candidate.request_id,
         candidate.setup_id,
         candidate.timestamp_utc,
         "XAUUSD",
         candidate.direction,
         candidate.technical_score,
         candidate.entry,
         candidate.sl,
         candidate.tp,
         candidate.rr,
         candidate.structure,
         candidate.structure,
         candidate.momentum,
         candidate.volatility,
         candidate.news_blocked,
         candidate.session_allowed,
         candidate.spread_points,
         candidate.equity,
         candidate.risk_percent
      );

      if(!m_client.RequestDecision(candidate.request_id,payload,response))
         return false;

      XAIContextGate ctx;
      ctx.risk_precheck=candidate.risk_precheck;
      ctx.news_blocked=candidate.news_blocked;
      ctx.session_allowed=candidate.session_allowed;
      ctx.price_valid=candidate.price_valid;
      ctx.setup_valid=candidate.setup_valid;
      ctx.technical_score=candidate.technical_score;
      ctx.minimum_score=m_min_technical_score;

      return m_final_gate.Approve(
         candidate.direction,
         response,
         ctx,
         m_min_ai_confidence
      );
   }
};

#endif
