#ifndef __XAI_AI_GATE_MQH__
#define __XAI_AI_GATE_MQH__

#include <XAUUSD_AI/AI/AIResponse.mqh>

class CAIGate
{
private:
   double m_min_confidence;

public:
   void Initialize(const double min_confidence)
   {
      m_min_confidence=min_confidence;
   }

   bool Approve(const string technical_direction,const AIResponse &ai)
   {
      if(!ai.valid) return false;
      if(ai.decision!=technical_direction) return false;
      if(ai.confidence<m_min_confidence) return false;
      if(ai.risk_assessment=="HIGH") return false;
      return true;
   }
};

#endif
