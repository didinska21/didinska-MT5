#ifndef __XAI_FINAL_AI_GATE_MQH__
#define __XAI_FINAL_AI_GATE_MQH__

#include <XAUUSD_AI/AI/AIResponse.mqh>

struct XAIContextGate
{
   bool risk_precheck;
   bool news_blocked;
   bool session_allowed;
   bool price_valid;
   bool setup_valid;
   double technical_score;
   double minimum_score;
};

class CFinalAIGate
{
public:
   bool Approve(const string technical_direction,
                const AIResponse &ai,
                const XAIContextGate &ctx,
                const double minimum_ai_confidence) const
   {
      if(!ctx.risk_precheck) return false;
      if(ctx.news_blocked) return false;
      if(!ctx.session_allowed) return false;
      if(!ctx.price_valid) return false;
      if(!ctx.setup_valid) return false;
      if(ctx.technical_score < ctx.minimum_score) return false;

      if(!ai.valid) return false;
      if(ai.decision != technical_direction) return false;
      if(ai.confidence < minimum_ai_confidence) return false;
      if(ai.risk_assessment == "HIGH") return false;

      return true;
   }
};

#endif
