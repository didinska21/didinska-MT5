#ifndef XAUUSD_AI_LIQUIDITY_ENGINE_MQH
#define XAUUSD_AI_LIQUIDITY_ENGINE_MQH

#include <XAUUSD_AI/Core/Types.mqh>

// Phase 3 liquidity map. Detection is deterministic and uses only closed data.
class CXAILiquidityEngine {
private:
   SXAILiquidityLevel m_levels[];
   bool m_bullish_sweep;
   bool m_bearish_sweep;
   datetime m_last_bar;
   double m_equal_tolerance;
   double m_sweep_buffer;
   int m_london_start;
   int m_london_end;
   int m_newyork_start;
   int m_newyork_end;

   void Clear() {
      ArrayResize(m_levels,0);
      m_bullish_sweep=false;
      m_bearish_sweep=false;
   }

   bool SameLevel(const double a,const double b,const double tolerance) const {
      return MathAbs(a-b)<=tolerance;
   }

   void AddLevel(const ENUM_XAI_LIQUIDITY_TYPE type,const double price,const datetime t,const double strength=1.0) {
      if(price<=0.0) return;
      for(int i=0;i<ArraySize(m_levels);i++) {
         if(m_levels[i].type==type && SameLevel(m_levels[i].price,price,m_equal_tolerance*0.5)) {
            if(strength>m_levels[i].strength) m_levels[i].strength=strength;
            m_levels[i].active=true;
            return;
         }
      }
      int n=ArraySize(m_levels);
      ArrayResize(m_levels,n+1);
      m_levels[n].id=(ulong)(n+1);
      m_levels[n].price=price;
      m_levels[n].time=t;
      m_levels[n].type=type;
      m_levels[n].strength=strength;
      m_levels[n].active=true;
   }

   bool IsInWindow(const datetime t,const int start_hour,const int end_hour) const {
      MqlDateTime dt;
      TimeToStruct(t,dt);
      if(start_hour<end_hour) return (dt.hour>=start_hour && dt.hour<end_hour);
      return (dt.hour>=start_hour || dt.hour<end_hour);
   }

   bool GetSessionRange(const MqlRates &rates[],const int start_hour,const int end_hour,
                        double &hi,double &lo,datetime &last_time) const {
      hi=-DBL_MAX;
      lo=DBL_MAX;
      last_time=0;
      bool found=false;
      for(int i=1;i<ArraySize(rates);i++) {
         if(!IsInWindow(rates[i].time,start_hour,end_hour)) continue;
         if(rates[i].high>hi) hi=rates[i].high;
         if(rates[i].low<lo) lo=rates[i].low;
         if(rates[i].time>last_time) last_time=rates[i].time;
         found=true;
      }
      return found;
   }

public:
   CXAILiquidityEngine() : m_bullish_sweep(false),m_bearish_sweep(false),m_last_bar(0),
                           m_equal_tolerance(0.10),m_sweep_buffer(0.02),
                           m_london_start(8),m_london_end(13),m_newyork_start(13),m_newyork_end(18) {}

   void Configure(const double equal_tolerance_price,const double sweep_buffer_price,
                  const int london_start,const int london_end,
                  const int newyork_start,const int newyork_end) {
      m_equal_tolerance=MathMax(0.0,equal_tolerance_price);
      m_sweep_buffer=MathMax(0.0,sweep_buffer_price);
      m_london_start=MathMax(0,MathMin(23,london_start));
      m_london_end=MathMax(0,MathMin(23,london_end));
      m_newyork_start=MathMax(0,MathMin(23,newyork_start));
      m_newyork_end=MathMax(0,MathMin(23,newyork_end));
   }

   bool Update(const MqlRates &rates[],const SXAISwingPoint &highs[],const SXAISwingPoint &lows[]) {
      Clear();
      const int total=ArraySize(rates);
      if(total<10) return false;

      // Previous completed broker-server day high/low.
      MqlDateTime cur;
      TimeToStruct(rates[1].time,cur);
      cur.hour=0; cur.min=0; cur.sec=0;
      datetime day_start=StructToTime(cur);
      datetime prev_start=day_start-86400;
      double pdh=-DBL_MAX,pdl=DBL_MAX;
      datetime pdt=0;
      bool prev_found=false;
      for(int i=1;i<total;i++) {
         if(rates[i].time<prev_start || rates[i].time>=day_start) continue;
         if(rates[i].high>pdh) pdh=rates[i].high;
         if(rates[i].low<pdl) pdl=rates[i].low;
         if(rates[i].time>pdt) pdt=rates[i].time;
         prev_found=true;
      }
      if(prev_found) {
         AddLevel(XAI_LIQ_PREVIOUS_DAY_HIGH,pdh,pdt,1.0);
         AddLevel(XAI_LIQ_PREVIOUS_DAY_LOW,pdl,pdt,1.0);
      }

      // Latest confirmed swing liquidity.
      const int hc=ArraySize(highs);
      const int lc=ArraySize(lows);
      if(hc>0) AddLevel(XAI_LIQ_SWING_HIGH,highs[0].price,highs[0].time,highs[0].strength);
      if(lc>0) AddLevel(XAI_LIQ_SWING_LOW,lows[0].price,lows[0].time,lows[0].strength);

      // Equal highs / lows: nearest pair in confirmed swing arrays.
      for(int i=0;i<hc;i++) {
         for(int j=i+1;j<hc;j++) {
            if(SameLevel(highs[i].price,highs[j].price,m_equal_tolerance)) {
               AddLevel(XAI_LIQ_EQUAL_HIGH,(highs[i].price+highs[j].price)*0.5,highs[i].time,0.90);
               i=hc; break;
            }
         }
      }
      for(int i=0;i<lc;i++) {
         for(int j=i+1;j<lc;j++) {
            if(SameLevel(lows[i].price,lows[j].price,m_equal_tolerance)) {
               AddLevel(XAI_LIQ_EQUAL_LOW,(lows[i].price+lows[j].price)*0.5,lows[i].time,0.90);
               i=lc; break;
            }
         }
      }

      // Session high/low levels. These are broker-server-hour definitions;
      // the dedicated session filter will later own trade-window policy.
      double hi,lo; datetime st;
      if(GetSessionRange(rates,m_london_start,m_london_end,hi,lo,st)) {
         AddLevel(XAI_LIQ_SESSION_HIGH,hi,st,0.80);
         AddLevel(XAI_LIQ_SESSION_LOW,lo,st,0.80);
      }
      if(GetSessionRange(rates,m_newyork_start,m_newyork_end,hi,lo,st)) {
         AddLevel(XAI_LIQ_SESSION_HIGH,hi,st,0.80);
         AddLevel(XAI_LIQ_SESSION_LOW,lo,st,0.80);
      }

      // Sweep is evaluated on the last CLOSED candle only (rates[1]).
      const double h=rates[1].high;
      const double l=rates[1].low;
      const double c=rates[1].close;
      for(int i=0;i<ArraySize(m_levels);i++) {
         const double p=m_levels[i].price;
         if(p<=0.0) continue;
         if(h>p+m_sweep_buffer && c<p) m_bearish_sweep=true; // buy-side liquidity swept, rejection down
         if(l<p-m_sweep_buffer && c>p) m_bullish_sweep=true; // sell-side liquidity swept, rejection up
      }

      m_last_bar=rates[1].time;
      return true;
   }

   int Count() const { return ArraySize(m_levels); }
   SXAILiquidityLevel Level(const int index) const {
      SXAILiquidityLevel x; ZeroMemory(x);
      if(index<0 || index>=ArraySize(m_levels)) return x;
      return m_levels[index];
   }

   bool HasBullishSweep() const { return m_bullish_sweep; }
   bool HasBearishSweep() const { return m_bearish_sweep; }
   datetime LastBar() const { return m_last_bar; }

   bool NearestAbove(const double price,SXAILiquidityLevel &out) const {
      bool found=false; double best=DBL_MAX;
      for(int i=0;i<ArraySize(m_levels);i++) {
         if(!m_levels[i].active || m_levels[i].price<=price) continue;
         double d=m_levels[i].price-price;
         if(d<best) { best=d; out=m_levels[i]; found=true; }
      }
      return found;
   }

   bool NearestBelow(const double price,SXAILiquidityLevel &out) const {
      bool found=false; double best=DBL_MAX;
      for(int i=0;i<ArraySize(m_levels);i++) {
         if(!m_levels[i].active || m_levels[i].price>=price) continue;
         double d=price-m_levels[i].price;
         if(d<best) { best=d; out=m_levels[i]; found=true; }
      }
      return found;
   }
};

#endif
