#ifndef XAUUSD_AI_STRUCTURE_ENGINE_MQH
#define XAUUSD_AI_STRUCTURE_ENGINE_MQH

#include <XAUUSD_AI/Core/Types.mqh>

// Structure engine uses confirmed swing points plus the last CLOSED candle.
// BOS/CHoCH events are edge-triggered per processed bar and never use bar 0.
class CXAIStructureEngine {
private:
   XAIStructureSnapshot m_snapshot;
   ENUM_XAI_STRUCTURE m_previous_state;
   datetime m_last_processed_bar;
   bool m_bullish_bos;
   bool m_bearish_bos;
   bool m_bullish_choch;
   bool m_bearish_choch;

   bool FindLastTwoHighs(const SXAISwingPoint &highs[],SXAISwingPoint &latest,SXAISwingPoint &previous) {
      if(ArraySize(highs)<2) return false;
      latest=highs[0]; previous=highs[1]; return true;
   }
   bool FindLastTwoLows(const SXAISwingPoint &lows[],SXAISwingPoint &latest,SXAISwingPoint &previous) {
      if(ArraySize(lows)<2) return false;
      latest=lows[0]; previous=lows[1]; return true;
   }

public:
   CXAIStructureEngine() { Reset(); }

   void Reset() {
      ZeroMemory(m_snapshot);
      m_snapshot.state=XAI_STRUCT_UNKNOWN;
      m_previous_state=XAI_STRUCT_UNKNOWN;
      m_last_processed_bar=0;
      m_bullish_bos=false; m_bearish_bos=false;
      m_bullish_choch=false; m_bearish_choch=false;
   }

   bool Update(const SXAISwingPoint &highs[],const SXAISwingPoint &lows[],const double close_price,const datetime bar_time) {
      m_bullish_bos=false; m_bearish_bos=false;
      m_bullish_choch=false; m_bearish_choch=false;
      if(bar_time==0 || bar_time==m_last_processed_bar) return true;
      if(ArraySize(highs)<2 || ArraySize(lows)<2) {
         m_snapshot.state=XAI_STRUCT_UNKNOWN;
         m_last_processed_bar=bar_time;
         return false;
      }

      SXAISwingPoint hh,ph,hl,pl;
      if(!FindLastTwoHighs(highs,hh,ph) || !FindLastTwoLows(lows,hl,pl)) return false;

      const ENUM_XAI_STRUCTURE prior=m_snapshot.state;
      m_previous_state=prior;

      m_snapshot.last_higher_high=hh.price;
      m_snapshot.last_higher_low=hl.price;
      m_snapshot.last_lower_high=ph.price;
      m_snapshot.last_lower_low=pl.price;

      const bool bullish_sequence=(hh.price>ph.price && hl.price>pl.price);
      const bool bearish_sequence=(hh.price<ph.price && hl.price<pl.price);

      // A BOS is a closed-candle close through the most recent confirmed
      // structural extreme. The broken swing must predate the closed bar.
      const bool bullish_break=(close_price>hh.price && bar_time>hh.time);
      const bool bearish_break=(close_price<hl.price && bar_time>hl.time);

      if(bullish_break) {
         m_bullish_bos=true;
         m_snapshot.last_bos_price=hh.price;
         m_snapshot.last_bos_time=bar_time;
         if(prior==XAI_STRUCT_BEARISH) {
            m_bullish_choch=true;
            m_snapshot.last_choch_price=hh.price;
            m_snapshot.last_choch_time=bar_time;
         }
      }
      if(bearish_break) {
         m_bearish_bos=true;
         m_snapshot.last_bos_price=hl.price;
         m_snapshot.last_bos_time=bar_time;
         if(prior==XAI_STRUCT_BULLISH) {
            m_bearish_choch=true;
            m_snapshot.last_choch_price=hl.price;
            m_snapshot.last_choch_time=bar_time;
         }
      }

      if(bullish_sequence) m_snapshot.state=XAI_STRUCT_BULLISH;
      else if(bearish_sequence) m_snapshot.state=XAI_STRUCT_BEARISH;
      else m_snapshot.state=XAI_STRUCT_RANGING;

      if(bullish_sequence || bearish_sequence) m_snapshot.score=1.0;
      else m_snapshot.score=0.5;

      m_last_processed_bar=bar_time;
      return true;
   }

   ENUM_XAI_STRUCTURE State() const { return m_snapshot.state; }
   XAIStructureSnapshot Snapshot() const { return m_snapshot; }
   bool IsBullishBOS() const { return m_bullish_bos; }
   bool IsBearishBOS() const { return m_bearish_bos; }
   bool IsBullishCHoCH() const { return m_bullish_choch; }
   bool IsBearishCHoCH() const { return m_bearish_choch; }
   datetime LastProcessedBar() const { return m_last_processed_bar; }
};

#endif
