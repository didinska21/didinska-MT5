#ifndef XAUUSD_AI_MARKET_DATA_MQH
#define XAUUSD_AI_MARKET_DATA_MQH

class CXAIMarketData {
private:
   string m_symbol;
public:
   bool Initialize(string symbol) { m_symbol=symbol; return SymbolSelect(m_symbol,true); }
   bool IsValid() { return (m_symbol!="" && SymbolInfoDouble(m_symbol,SYMBOL_BID)>0.0 && SymbolInfoDouble(m_symbol,SYMBOL_ASK)>0.0); }
   double Bid() { return SymbolInfoDouble(m_symbol,SYMBOL_BID); }
   double Ask() { return SymbolInfoDouble(m_symbol,SYMBOL_ASK); }
   double SpreadPoints() { double p=SymbolInfoDouble(m_symbol,SYMBOL_POINT); if(p<=0) return 0; return (Ask()-Bid())/p; }
   double TickSize() { return SymbolInfoDouble(m_symbol,SYMBOL_TRADE_TICK_SIZE); }
   double TickValue() { return SymbolInfoDouble(m_symbol,SYMBOL_TRADE_TICK_VALUE); }
   double MinVolume() { return SymbolInfoDouble(m_symbol,SYMBOL_VOLUME_MIN); }
   double MaxVolume() { return SymbolInfoDouble(m_symbol,SYMBOL_VOLUME_MAX); }
   double VolumeStep() { return SymbolInfoDouble(m_symbol,SYMBOL_VOLUME_STEP); }
   int StopsLevel() { return (int)SymbolInfoInteger(m_symbol,SYMBOL_TRADE_STOPS_LEVEL); }
   int FreezeLevel() { return (int)SymbolInfoInteger(m_symbol,SYMBOL_TRADE_FREEZE_LEVEL); }
   string Symbol() { return m_symbol; }

   bool GetRates(ENUM_TIMEFRAMES tf,int count,MqlRates &rates[]) {
      ArraySetAsSeries(rates,true);
      return CopyRates(m_symbol,tf,0,count,rates)==count;
   }
};

#endif
