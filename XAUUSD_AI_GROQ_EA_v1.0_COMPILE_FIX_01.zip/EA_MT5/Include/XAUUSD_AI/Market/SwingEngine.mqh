#ifndef XAUUSD_AI_SWING_ENGINE_MQH
#define XAUUSD_AI_SWING_ENGINE_MQH

#include <XAUUSD_AI/Core/Types.mqh>

// Deterministic closed-candle swing detector.
// rates[] is expected to be series-oriented: [0] current, [1] last closed.
class CXAISwingEngine {
private:
   SXAISwingPoint m_highs[];
   SXAISwingPoint m_lows[];
   int m_strength;
   double m_atr;

   bool IsPivotHigh(const MqlRates &rates[], const int index, const int strength) {
      const double p=rates[index].high;
      for(int j=1;j<=strength;j++) {
         if(p<=rates[index-j].high || p<rates[index+j].high) return false;
      }
      return true;
   }

   bool IsPivotLow(const MqlRates &rates[], const int index, const int strength) {
      const double p=rates[index].low;
      for(int j=1;j<=strength;j++) {
         if(p>=rates[index-j].low || p>rates[index+j].low) return false;
      }
      return true;
   }

   double StrengthFromRange(const double distance) {
      if(m_atr<=0.0) return 0.0;
      double s=distance/m_atr;
      if(s>1.0) s=1.0;
      if(s<0.0) s=0.0;
      return s;
   }

public:
   CXAISwingEngine() : m_strength(2), m_atr(0.0) {}

   void Configure(const int strength,const double atr) {
      m_strength=(strength<1 ? 1 : strength);
      m_atr=atr;
   }

   void Clear() {
      ArrayResize(m_highs,0);
      ArrayResize(m_lows,0);
   }

   bool Calculate(const MqlRates &rates[]) {
      Clear();
      const int total=ArraySize(rates);
      if(total < (m_strength*2+4)) return false;

      // Ignore rates[0] because it is the currently forming candle.
      // A pivot is only accepted when all candles on both sides are already known.
      for(int i=total-m_strength-1; i>=m_strength+1; i--) {
         if(IsPivotHigh(rates,i,m_strength)) {
            SXAISwingPoint s;
            s.time=rates[i].time;
            s.index=i;
            s.price=rates[i].high;
            s.is_high=true;
            s.confirmed=true;
            s.strength=StrengthFromRange(rates[i].high-MathMin(rates[i-m_strength].low,rates[i+m_strength].low));
            int n=ArraySize(m_highs);
            ArrayResize(m_highs,n+1);
            m_highs[n]=s;
         }
         if(IsPivotLow(rates,i,m_strength)) {
            SXAISwingPoint s;
            s.time=rates[i].time;
            s.index=i;
            s.price=rates[i].low;
            s.is_high=false;
            s.confirmed=true;
            s.strength=StrengthFromRange(MathMax(rates[i-m_strength].high,rates[i+m_strength].high)-rates[i].low);
            int n=ArraySize(m_lows);
            ArrayResize(m_lows,n+1);
            m_lows[n]=s;
         }
      }
      return (ArraySize(m_highs)>0 || ArraySize(m_lows)>0);
   }

   int HighCount() const { return ArraySize(m_highs); }
   int LowCount() const { return ArraySize(m_lows); }

   SXAISwingPoint High(const int index) const {
      SXAISwingPoint empty;
      ZeroMemory(empty);
      if(index<0 || index>=ArraySize(m_highs)) return empty;
      return m_highs[index];
   }

   SXAISwingPoint Low(const int index) const {
      SXAISwingPoint empty;
      ZeroMemory(empty);
      if(index<0 || index>=ArraySize(m_lows)) return empty;
      return m_lows[index];
   }

   bool LatestHigh(SXAISwingPoint &out) const {
      if(ArraySize(m_highs)<=0) return false;
      out=m_highs[0];
      return true;
   }

   bool LatestLow(SXAISwingPoint &out) const {
      if(ArraySize(m_lows)<=0) return false;
      out=m_lows[0];
      return true;
   }
};

#endif
