#ifndef XAUUSD_AI_EXECUTION_MANAGER_MQH
#define XAUUSD_AI_EXECUTION_MANAGER_MQH
#include <Trade/Trade.mqh>

class CXAIExecutionManager {
private:
   CTrade m_trade;
   ulong m_magic;
   int m_deviation;
public:
   void Configure(ulong magic,int deviation) { m_magic=magic; m_deviation=deviation; m_trade.SetExpertMagicNumber(m_magic); m_trade.SetDeviationInPoints(m_deviation); }

   bool Buy(string symbol,double volume,double sl,double tp,string comment) {
      if(volume<=0) return false;
      return m_trade.Buy(volume,symbol,0.0,sl,tp,comment);
   }
   bool Sell(string symbol,double volume,double sl,double tp,string comment) {
      if(volume<=0) return false;
      return m_trade.Sell(volume,symbol,0.0,sl,tp,comment);
   }
   uint Retcode() { return m_trade.ResultRetcode(); }
   string RetcodeDescription() { return m_trade.ResultRetcodeDescription(); }
};

#endif
