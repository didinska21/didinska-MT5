#ifndef XAUUSD_AI_POSITION_SIZER_MQH
#define XAUUSD_AI_POSITION_SIZER_MQH

class CXAIPositionSizer {
private:
   double NormalizeVolume(string symbol,double volume) {
      double minv=SymbolInfoDouble(symbol,SYMBOL_VOLUME_MIN);
      double maxv=SymbolInfoDouble(symbol,SYMBOL_VOLUME_MAX);
      double step=SymbolInfoDouble(symbol,SYMBOL_VOLUME_STEP);
      if(step<=0.0 || minv<=0.0 || maxv<minv) return 0.0;
      volume=MathFloor(volume/step+1e-9)*step;
      if(volume<minv) return 0.0;
      if(volume>maxv) volume=maxv;
      return NormalizeDouble(volume,8);
   }
public:
   double Normalize(string symbol,double volume) { return NormalizeVolume(symbol,volume); }

   // Risk sizing uses OrderCalcProfit for broker-aware tick/contract behavior.
   // It estimates the monetary loss of one lot if SL is hit.
   double Calculate(string symbol,double equity,double risk_pct,double entry,double sl,ENUM_XAI_DIRECTION direction) {
      if(equity<=0.0 || risk_pct<=0.0 || entry<=0.0 || sl<=0.0) return 0.0;
      if(direction!=XAI_DIR_BUY && direction!=XAI_DIR_SELL) return 0.0;

      ENUM_ORDER_TYPE order_type=(direction==XAI_DIR_BUY ? ORDER_TYPE_BUY : ORDER_TYPE_SELL);
      double one_lot_result=0.0;
      if(!OrderCalcProfit(order_type,symbol,1.0,entry,sl,one_lot_result)) return 0.0;

      double loss_per_lot=MathAbs(one_lot_result);
      if(loss_per_lot<=0.0) return 0.0;

      const double risk_money=equity*risk_pct/100.0;
      return NormalizeVolume(symbol,risk_money/loss_per_lot);
   }
};

#endif
