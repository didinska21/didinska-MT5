#ifndef XAUUSD_AI_RISK_MANAGER_MQH
#define XAUUSD_AI_RISK_MANAGER_MQH

#include <XAUUSD_AI/Core/Types.mqh>
#include <XAUUSD_AI/Core/Config.mqh>
#include <XAUUSD_AI/Risk/PositionSizer.mqh>

class CXAIRiskManager {
private:
   CXAIPositionSizer m_sizer;
   string m_symbol;
   ulong  m_magic;

   string DayKey() const {
      MqlDateTime dt;
      TimeToStruct(TimeCurrent(),dt);
      return StringFormat("%04d%02d%02d",dt.year,dt.mon,dt.day);
   }

   string GVName(string suffix) const {
      return StringFormat("XAI_%I64u_%s_%s",m_magic,m_symbol,suffix);
   }

   double GetOrCreateDouble(string name,double initial_value) const {
      if(!GlobalVariableCheck(name)) GlobalVariableSet(name,initial_value);
      return GlobalVariableGet(name);
   }

   void EnsureDailyState() const {
      const string day=DayKey();
      const string day_name=GVName("DAY");
      if(!GlobalVariableCheck(day_name) || DoubleToString(GlobalVariableGet(day_name),0)!=day) {
         GlobalVariableSet(day_name,(double)StringToInteger(day));
         GlobalVariableSet(GVName("START_BALANCE"),AccountInfoDouble(ACCOUNT_BALANCE));
         GlobalVariableSet(GVName("DAILY_TRADES"),0.0);
      }
   }

   double StartBalance() const {
      EnsureDailyState();
      return GetOrCreateDouble(GVName("START_BALANCE"),AccountInfoDouble(ACCOUNT_BALANCE));
   }

   int ManagedOpenPositions() const {
      int count=0;
      for(int i=PositionsTotal()-1;i>=0;i--) {
         ulong ticket=PositionGetTicket(i);
         if(ticket==0) continue;
         if(!PositionSelectByTicket(ticket)) continue;
         if(PositionGetString(POSITION_SYMBOL)!=m_symbol) continue;
         if((ulong)PositionGetInteger(POSITION_MAGIC)!=m_magic) continue;
         count++;
      }
      return count;
   }

   int TodayEntryCount() const {
      EnsureDailyState();
      return (int)GlobalVariableGet(GVName("DAILY_TRADES"));
   }

   int TodayClosedLossStreak() const {
      MqlDateTime dt;
      TimeToStruct(TimeCurrent(),dt);
      dt.hour=0; dt.min=0; dt.sec=0;
      datetime day_start=StructToTime(dt);
      if(!HistorySelect(day_start,TimeCurrent())) return 0;

      int streak=0;
      const int total=HistoryDealsTotal();
      for(int i=total-1;i>=0;i--) {
         ulong deal=HistoryDealGetTicket(i);
         if(deal==0) continue;
         if(HistoryDealGetString(deal,DEAL_SYMBOL)!=m_symbol) continue;
         if((ulong)HistoryDealGetInteger(deal,DEAL_MAGIC)!=m_magic) continue;
         ENUM_DEAL_ENTRY entry=(ENUM_DEAL_ENTRY)HistoryDealGetInteger(deal,DEAL_ENTRY);
         if(entry!=DEAL_ENTRY_OUT && entry!=DEAL_ENTRY_OUT_BY) continue;

         double net=HistoryDealGetDouble(deal,DEAL_PROFIT)
                   +HistoryDealGetDouble(deal,DEAL_SWAP)
                   +HistoryDealGetDouble(deal,DEAL_COMMISSION);
         if(net<0.0) streak++;
         else if(net>0.0) break;
      }
      return streak;
   }

   double TodayRealizedPnL() const {
      MqlDateTime dt;
      TimeToStruct(TimeCurrent(),dt);
      dt.hour=0; dt.min=0; dt.sec=0;
      datetime day_start=StructToTime(dt);
      if(!HistorySelect(day_start,TimeCurrent())) return 0.0;

      double pnl=0.0;
      const int total=HistoryDealsTotal();
      for(int i=0;i<total;i++) {
         ulong deal=HistoryDealGetTicket(i);
         if(deal==0) continue;
         if(HistoryDealGetString(deal,DEAL_SYMBOL)!=m_symbol) continue;
         if((ulong)HistoryDealGetInteger(deal,DEAL_MAGIC)!=m_magic) continue;
         ENUM_DEAL_ENTRY entry=(ENUM_DEAL_ENTRY)HistoryDealGetInteger(deal,DEAL_ENTRY);
         if(entry!=DEAL_ENTRY_OUT && entry!=DEAL_ENTRY_OUT_BY) continue;
         pnl += HistoryDealGetDouble(deal,DEAL_PROFIT)
             +  HistoryDealGetDouble(deal,DEAL_SWAP)
             +  HistoryDealGetDouble(deal,DEAL_COMMISSION);
      }
      return pnl;
   }

   double FloatingPnL() const {
      double pnl=0.0;
      for(int i=PositionsTotal()-1;i>=0;i--) {
         ulong ticket=PositionGetTicket(i);
         if(ticket==0 || !PositionSelectByTicket(ticket)) continue;
         if(PositionGetString(POSITION_SYMBOL)!=m_symbol) continue;
         if((ulong)PositionGetInteger(POSITION_MAGIC)!=m_magic) continue;
         pnl += PositionGetDouble(POSITION_PROFIT)
             +  PositionGetDouble(POSITION_SWAP);
      }
      return pnl;
   }

   double DailyLossPct() const {
      const double start=StartBalance();
      if(start<=0.0) return 100.0;
      const double pnl=TodayRealizedPnL()+FloatingPnL();
      return (pnl<0.0 ? (-pnl/start)*100.0 : 0.0);
   }

   double UpdatePeakEquity() const {
      const string name=GVName("PEAK_EQUITY");
      const double equity=AccountInfoDouble(ACCOUNT_EQUITY);
      double peak=GetOrCreateDouble(name,equity);
      if(equity>peak) {
         peak=equity;
         GlobalVariableSet(name,peak);
      }
      return peak;
   }

   double DrawdownPct() const {
      const double peak=UpdatePeakEquity();
      const double equity=AccountInfoDouble(ACCOUNT_EQUITY);
      if(peak<=0.0) return 100.0;
      if(equity>=peak) return 0.0;
      return ((peak-equity)/peak)*100.0;
   }

   bool CheckMargin(const XAISetupCandidate &candidate,double volume) const {
      ENUM_ORDER_TYPE type=(candidate.direction==XAI_DIR_BUY ? ORDER_TYPE_BUY : ORDER_TYPE_SELL);
      double margin=0.0;
      if(!OrderCalcMargin(type,m_symbol,volume,candidate.proposed_entry,margin)) return false;
      return (margin>0.0 && margin<=AccountInfoDouble(ACCOUNT_MARGIN_FREE));
   }

public:
   void Configure(string symbol,ulong magic) {
      m_symbol=symbol;
      m_magic=magic;
      EnsureDailyState();
      UpdatePeakEquity();
   }

   XAIRiskDecision Evaluate(const XAISetupCandidate &candidate) {
      XAIRiskDecision r;
      ZeroMemory(r);
      r.entry=candidate.proposed_entry;
      r.sl=candidate.proposed_sl;
      r.tp=candidate.proposed_tp;
      r.rr=candidate.rr_score;
      r.risk_percent=InpRiskPerTradePct;
      r.approved=false;
      r.reason_code="UNINITIALIZED";

      if(m_symbol=="") { r.reason_code="RISK_NOT_CONFIGURED"; return r; }
      if(!candidate.valid) { r.reason_code="CANDIDATE_INVALID"; return r; }
      if(candidate.technical_score<InpMinimumTechnicalScore) { r.reason_code="LOW_TECHNICAL_SCORE"; return r; }
      if(candidate.proposed_entry<=0.0 || candidate.proposed_sl<=0.0 || candidate.proposed_tp<=0.0) { r.reason_code="INVALID_PRICES"; return r; }
      if(candidate.rr_score<InpMinimumRR) { r.reason_code="RR_TOO_LOW"; return r; }
      if(ManagedOpenPositions()>=InpMaxOpenPositions) { r.reason_code="POSITION_LIMIT"; return r; }
      if(TodayEntryCount()>=InpMaxDailyTrades) { r.reason_code="DAILY_TRADE_LIMIT"; return r; }
      if(DailyLossPct()>=InpMaxDailyLossPct) { r.reason_code="DAILY_LOSS_LIMIT"; return r; }
      if(DrawdownPct()>=InpMaxDrawdownPct) { r.reason_code="DRAWDOWN_LIMIT"; return r; }
      if(TodayClosedLossStreak()>=InpMaxConsecutiveLosses) { r.reason_code="CONSECUTIVE_LOSS_LIMIT"; return r; }

      const double equity=AccountInfoDouble(ACCOUNT_EQUITY);
      r.risk_money=equity*InpRiskPerTradePct/100.0;
      r.calculated_lot=m_sizer.Calculate(m_symbol,equity,InpRiskPerTradePct,candidate.proposed_entry,candidate.proposed_sl,candidate.direction);
      if(r.calculated_lot<=0.0) { r.reason_code="LOT_SIZE_INVALID"; return r; }

      if(!CheckMargin(candidate,r.calculated_lot)) { r.reason_code="MARGIN_INVALID"; return r; }

      r.approved=true;
      r.reason_code="RISK_APPROVED";
      return r;
   }

   void RecordEntry() {
      EnsureDailyState();
      const string name=GVName("DAILY_TRADES");
      GlobalVariableSet(name,GlobalVariableGet(name)+1.0);
   }

   double CurrentDailyLossPct() const { return DailyLossPct(); }
   double CurrentDrawdownPct() const { return DrawdownPct(); }
   int CurrentDailyTrades() const { return TodayEntryCount(); }
   int CurrentLossStreak() const { return TodayClosedLossStreak(); }
   int CurrentOpenPositions() const { return ManagedOpenPositions(); }
};

#endif
