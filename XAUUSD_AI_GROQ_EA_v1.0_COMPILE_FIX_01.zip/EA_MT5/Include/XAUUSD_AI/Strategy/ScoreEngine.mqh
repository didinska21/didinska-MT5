#ifndef XAUUSD_AI_SCORE_ENGINE_MQH
#define XAUUSD_AI_SCORE_ENGINE_MQH

#include <XAUUSD_AI/Core/Types.mqh>

// Deterministic technical scoring. This class does not trade and does not
// call AI. All inputs are snapshots available at the closed signal candle.
class CXAIScoreEngine {
private:
   double m_min_score;

   double Clamp01(const double value) const {
      if(value<0.0) return 0.0;
      if(value>1.0) return 1.0;
      return value;
   }

   double SafeRatio(const double numerator,const double denominator) const {
      if(denominator<=0.0) return 0.0;
      return numerator/denominator;
   }

   double CandleConfirmation(const MqlRates &bar) const {
      const double range=bar.high-bar.low;
      if(range<=0.0) return 0.0;
      const double body=MathAbs(bar.close-bar.open);
      return Clamp01(SafeRatio(body,range));
   }

   double MomentumComponent(const MqlRates &bar,const double atr,const ENUM_XAI_DIRECTION direction) const {
      const double range=bar.high-bar.low;
      if(range<=0.0 || atr<=0.0) return 0.0;

      const double body=MathAbs(bar.close-bar.open);
      const double body_ratio=Clamp01(SafeRatio(body,range));
      const double expansion=SafeRatio(range,atr);

      double expansion_score=0.0;
      if(expansion>=0.75 && expansion<=1.75) expansion_score=1.0;
      else if(expansion>=0.50 && expansion<0.75) expansion_score=0.75;
      else if(expansion>1.75 && expansion<=2.25) expansion_score=0.75;
      else if(expansion>2.25 && expansion<=3.0) expansion_score=0.35;

      const bool directional=(direction==XAI_DIR_BUY && bar.close>bar.open) ||
                             (direction==XAI_DIR_SELL && bar.close<bar.open);
      if(!directional) return 0.25*body_ratio;

      return Clamp01(0.55*body_ratio+0.45*expansion_score);
   }

   double VolatilityComponent(const MqlRates &bar,const double atr) const {
      const double range=bar.high-bar.low;
      if(range<=0.0 || atr<=0.0) return 0.0;
      const double ratio=range/atr;

      // Normal expansion receives the highest score. Very small candles and
      // extreme expansion are both penalized.
      if(ratio>=0.75 && ratio<=1.75) return 1.0;
      if(ratio>=0.50 && ratio<0.75) return 0.75;
      if(ratio>1.75 && ratio<=2.25) return 0.75;
      if(ratio>2.25 && ratio<=3.0) return 0.35;
      return 0.0;
   }

   bool FindDirectionalTarget(const XAISetupCandidate &candidate,
                              const SXAILiquidityLevel &levels[],
                              double &target) const {
      bool found=false;
      double best=0.0;

      for(int i=0;i<ArraySize(levels);i++) {
         if(!levels[i].active) continue;
         const double p=levels[i].price;

         if(candidate.direction==XAI_DIR_BUY && p>candidate.proposed_entry) {
            if(!found || p<best) { best=p; found=true; }
         }
         else if(candidate.direction==XAI_DIR_SELL && p<candidate.proposed_entry) {
            if(!found || p>best) { best=p; found=true; }
         }
      }

      if(found) target=best;
      return found;
   }

   double RRComponent(const XAISetupCandidate &candidate,
                      const SXAILiquidityLevel &levels[]) const {
      const double risk=MathAbs(candidate.proposed_entry-candidate.invalidation_price);
      if(risk<=0.0) return 0.0;

      double target=0.0;
      if(!FindDirectionalTarget(candidate,levels,target)) {
         // RR cannot be proven until the later TP engine has an explicit
         // target. Keep a neutral value rather than inventing a target.
         return 0.50;
      }

      const double reward=MathAbs(target-candidate.proposed_entry);
      const double rr=reward/risk;

      if(rr>=2.50) return 1.0;
      if(rr>=2.00) return 0.90;
      if(rr>=1.75) return 0.80;
      if(rr>=1.50) return 0.70;
      if(rr>=1.25) return 0.50;
      if(rr>=1.00) return 0.25;
      return 0.0;
   }

public:
   CXAIScoreEngine() : m_min_score(0.70) {}

   void Configure(const double minimum_score=0.70) {
      m_min_score=Clamp01(minimum_score);
   }

   double MinimumScore() const { return m_min_score; }

   double FinalTechnicalScore(const double trend,
                              const double structure,
                              const double liquidity,
                              const double confirmation,
                              const double momentum,
                              const double volatility,
                              const double rr) const {
      return Clamp01(
         0.20*Clamp01(trend) +
         0.20*Clamp01(structure) +
         0.15*Clamp01(liquidity) +
         0.15*Clamp01(confirmation) +
         0.10*Clamp01(momentum) +
         0.10*Clamp01(volatility) +
         0.10*Clamp01(rr)
      );
   }

   bool Evaluate(XAISetupCandidate &candidate,
                 const MqlRates &rates[],
                 const XAIStructureSnapshot &structure,
                 const SXAILiquidityLevel &levels[],
                 const bool bullish_bos,
                 const bool bearish_bos,
                 const bool bullish_choch,
                 const bool bearish_choch,
                 const bool bullish_sweep,
                 const bool bearish_sweep,
                 const double atr) const {
      if(!candidate.valid || ArraySize(rates)<2 || atr<=0.0) {
         candidate.technical_score=0.0;
         return false;
      }

      const MqlRates bar=rates[1];

      // 1) Trend: direction must agree with the deterministic structure.
      double trend=0.50;
      if(candidate.direction==XAI_DIR_BUY && structure.state==XAI_STRUCT_BULLISH) trend=1.0;
      else if(candidate.direction==XAI_DIR_SELL && structure.state==XAI_STRUCT_BEARISH) trend=1.0;
      else if(structure.state==XAI_STRUCT_RANGING) trend=0.35;
      else trend=0.10;

      // 2) Structure: use the existing structure confidence and reward a
      // fresh structural event relevant to the candidate direction.
      double structure_score=Clamp01(structure.score);
      if(candidate.direction==XAI_DIR_BUY && (bullish_bos || bullish_choch))
         structure_score=MathMax(structure_score,0.95);
      if(candidate.direction==XAI_DIR_SELL && (bearish_bos || bearish_choch))
         structure_score=MathMax(structure_score,0.95);

      // 3) Liquidity: sweep is strongest confirmation; active levels still
      // contribute modestly when a setup is continuation-based.
      double liquidity=0.40;
      if(candidate.direction==XAI_DIR_BUY && bullish_sweep) liquidity=1.0;
      else if(candidate.direction==XAI_DIR_SELL && bearish_sweep) liquidity=1.0;
      else if(ArraySize(levels)>0) liquidity=0.60;

      // 4) Confirmation: candle body quality plus direction agreement.
      const double candle_confirmation=CandleConfirmation(bar);
      const bool directional=(candidate.direction==XAI_DIR_BUY && bar.close>bar.open) ||
                             (candidate.direction==XAI_DIR_SELL && bar.close<bar.open);
      double confirmation=0.70*candle_confirmation + (directional ? 0.30 : 0.0);
      confirmation=Clamp01(confirmation);

      // Reversal candidates already have an explicit CHoCH+sweep requirement;
      // do not double-count it as a free 1.0. The candle still matters.
      if(candidate.setup_type==XAI_SETUP_REVERSAL)
         confirmation=Clamp01(0.50*candle_confirmation + (directional ? 0.20 : 0.0) +
                               ((candidate.direction==XAI_DIR_BUY && bullish_choch) ||
                                (candidate.direction==XAI_DIR_SELL && bearish_choch) ? 0.30 : 0.0));

      // 5) Momentum: directional body + ATR-normalized expansion.
      const double momentum=MomentumComponent(bar,atr,candidate.direction);

      // 6) Volatility: normal expansion preferred, extremes penalized.
      const double volatility=VolatilityComponent(bar,atr);

      // 7) RR proxy: use the nearest favorable liquidity level if available.
      // Final TP/RR validation remains the responsibility of the TP engine.
      const double rr=RRComponent(candidate,levels);

      candidate.trend_score=trend;
      candidate.structure_score=structure_score;
      candidate.liquidity_score=liquidity;
      candidate.confirmation_score=confirmation;
      candidate.momentum_score=momentum;
      candidate.volatility_score=volatility;
      candidate.rr_score=rr;
      candidate.technical_score=FinalTechnicalScore(
         trend,structure_score,liquidity,confirmation,momentum,volatility,rr);

      return (candidate.technical_score>=m_min_score);
   }
};

#endif
