#ifndef XAUUSD_AI_STRATEGY_ENGINE_MQH
#define XAUUSD_AI_STRATEGY_ENGINE_MQH

#include <XAUUSD_AI/Core/Types.mqh>
#include <XAUUSD_AI/Market/SwingEngine.mqh>
#include <XAUUSD_AI/Market/StructureEngine.mqh>
#include <XAUUSD_AI/Market/LiquidityEngine.mqh>

// Phase 4: deterministic setup generation only.
// No scoring, risk, AI, or order execution belongs here.
// All setup triggers are based on the last CLOSED candle.
class CXAIStrategyEngine {
private:
   CXAISwingEngine m_swings;
   CXAIStructureEngine m_structure;
   CXAILiquidityEngine m_liquidity;
   int m_swing_strength;
   double m_last_atr;
   datetime m_last_setup_bar;
   ulong m_setup_sequence;

   string MakeSetupId(const datetime bar_time,const ENUM_XAI_DIRECTION direction) {
      m_setup_sequence++;
      string side=(direction==XAI_DIR_BUY ? "B" : "S");
      return "XAI-"+TimeToString(bar_time,TIME_DATE|TIME_SECONDS)+"-"+side+"-"+IntegerToString((int)m_setup_sequence);
   }

   bool BuildContinuation(const MqlRates &rates[],XAISetupCandidate &candidate) {
      if(ArraySize(rates)<2) return false;

      const double close_price=rates[1].close;
      const double candle_high=rates[1].high;
      const double candle_low=rates[1].low;
      const double body_low=MathMin(rates[1].open,close_price);
      const double body_high=MathMax(rates[1].open,close_price);

      SXAISwingPoint latest_low,latest_high;
      const bool have_low=m_swings.LatestLow(latest_low);
      const bool have_high=m_swings.LatestHigh(latest_high);

      if(m_structure.IsBullishBOS() && m_structure.State()==XAI_STRUCT_BULLISH && have_low) {
         // A bullish continuation requires a bullish BOS on the processed closed bar.
         // An opposite bearish sweep on the same bar invalidates this candidate.
         if(m_liquidity.HasBearishSweep()) return false;

         candidate.direction=XAI_DIR_BUY;
         candidate.setup_type=XAI_SETUP_CONTINUATION;
         candidate.structure=XAI_STRUCT_BULLISH;
         candidate.entry_zone_low=body_low;
         candidate.entry_zone_high=body_high;
         candidate.proposed_entry=close_price;
         candidate.invalidation_price=latest_low.price;
         candidate.proposed_sl=0.0;
         candidate.proposed_tp=0.0;
         candidate.structure_score=m_structure.Snapshot().score;
         candidate.liquidity_score=(m_liquidity.Count()>0 ? 1.0 : 0.0);
         candidate.confirmation_score=1.0;
         candidate.valid=(candidate.proposed_entry>candidate.invalidation_price);
         if(candidate.valid) {
            candidate.created_at=rates[1].time;
            candidate.setup_id=MakeSetupId(candidate.created_at,candidate.direction);
         }
         return candidate.valid;
      }

      if(m_structure.IsBearishBOS() && m_structure.State()==XAI_STRUCT_BEARISH && have_high) {
         if(m_liquidity.HasBullishSweep()) return false;

         candidate.direction=XAI_DIR_SELL;
         candidate.setup_type=XAI_SETUP_CONTINUATION;
         candidate.structure=XAI_STRUCT_BEARISH;
         candidate.entry_zone_low=body_low;
         candidate.entry_zone_high=body_high;
         candidate.proposed_entry=close_price;
         candidate.invalidation_price=latest_high.price;
         candidate.proposed_sl=0.0;
         candidate.proposed_tp=0.0;
         candidate.structure_score=m_structure.Snapshot().score;
         candidate.liquidity_score=(m_liquidity.Count()>0 ? 1.0 : 0.0);
         candidate.confirmation_score=1.0;
         candidate.valid=(candidate.proposed_entry<candidate.invalidation_price);
         if(candidate.valid) {
            candidate.created_at=rates[1].time;
            candidate.setup_id=MakeSetupId(candidate.created_at,candidate.direction);
         }
         return candidate.valid;
      }

      return false;
   }

   bool BuildReversal(const MqlRates &rates[],XAISetupCandidate &candidate) {
      if(ArraySize(rates)<2) return false;

      const double close_price=rates[1].close;
      const double body_low=MathMin(rates[1].open,close_price);
      const double body_high=MathMax(rates[1].open,close_price);

      SXAISwingPoint latest_low,latest_high;
      const bool have_low=m_swings.LatestLow(latest_low);
      const bool have_high=m_swings.LatestHigh(latest_high);

      // Reversal requires both a structure change and a matching liquidity sweep.
      if(m_structure.IsBullishCHoCH() && m_liquidity.HasBullishSweep() && have_low) {
         candidate.direction=XAI_DIR_BUY;
         candidate.setup_type=XAI_SETUP_REVERSAL;
         candidate.structure=XAI_STRUCT_BULLISH;
         candidate.entry_zone_low=body_low;
         candidate.entry_zone_high=body_high;
         candidate.proposed_entry=close_price;
         candidate.invalidation_price=latest_low.price;
         candidate.proposed_sl=0.0;
         candidate.proposed_tp=0.0;
         candidate.structure_score=m_structure.Snapshot().score;
         candidate.liquidity_score=1.0;
         candidate.confirmation_score=1.0;
         candidate.valid=(candidate.proposed_entry>candidate.invalidation_price);
         if(candidate.valid) {
            candidate.created_at=rates[1].time;
            candidate.setup_id=MakeSetupId(candidate.created_at,candidate.direction);
         }
         return candidate.valid;
      }

      if(m_structure.IsBearishCHoCH() && m_liquidity.HasBearishSweep() && have_high) {
         candidate.direction=XAI_DIR_SELL;
         candidate.setup_type=XAI_SETUP_REVERSAL;
         candidate.structure=XAI_STRUCT_BEARISH;
         candidate.entry_zone_low=body_low;
         candidate.entry_zone_high=body_high;
         candidate.proposed_entry=close_price;
         candidate.invalidation_price=latest_high.price;
         candidate.proposed_sl=0.0;
         candidate.proposed_tp=0.0;
         candidate.structure_score=m_structure.Snapshot().score;
         candidate.liquidity_score=1.0;
         candidate.confirmation_score=1.0;
         candidate.valid=(candidate.proposed_entry<candidate.invalidation_price);
         if(candidate.valid) {
            candidate.created_at=rates[1].time;
            candidate.setup_id=MakeSetupId(candidate.created_at,candidate.direction);
         }
         return candidate.valid;
      }

      return false;
   }

public:
   CXAIStrategyEngine() : m_swing_strength(2),m_last_atr(0.0),m_last_setup_bar(0),m_setup_sequence(0) {}

   void Configure(const int swing_strength=2,
                  const double equal_tolerance_price=0.10,
                  const double sweep_buffer_price=0.02,
                  const int london_start=8,const int london_end=13,
                  const int newyork_start=13,const int newyork_end=18) {
      m_swing_strength=(swing_strength<1 ? 1 : swing_strength);
      m_liquidity.Configure(equal_tolerance_price,sweep_buffer_price,
                            london_start,london_end,newyork_start,newyork_end);
   }

   bool BuildStructure(const MqlRates &rates[],const double atr) {
      m_swings.Configure(m_swing_strength,atr);
      m_last_atr=atr;
      if(!m_swings.Calculate(rates)) return false;

      SXAISwingPoint highs[];
      SXAISwingPoint lows[];
      const int hc=m_swings.HighCount();
      const int lc=m_swings.LowCount();
      ArrayResize(highs,hc);
      ArrayResize(lows,lc);
      for(int i=0;i<hc;i++) highs[i]=m_swings.High(i);
      for(int i=0;i<lc;i++) lows[i]=m_swings.Low(i);

      if(!m_structure.Update(highs,lows,rates[1].close,rates[1].time)) return false;
      return m_liquidity.Update(rates,highs,lows);
   }

   XAIStructureSnapshot StructureSnapshot() const { return m_structure.Snapshot(); }
   int SwingHighCount() const { return m_swings.HighCount(); }
   int SwingLowCount() const { return m_swings.LowCount(); }

   bool IsBullishBOS() const { return m_structure.IsBullishBOS(); }
   bool IsBearishBOS() const { return m_structure.IsBearishBOS(); }
   bool IsBullishCHoCH() const { return m_structure.IsBullishCHoCH(); }
   bool IsBearishCHoCH() const { return m_structure.IsBearishCHoCH(); }

   int LiquidityCount() const { return m_liquidity.Count(); }
   SXAILiquidityLevel Liquidity(const int index) const { return m_liquidity.Level(index); }
   bool HasBullishSweep() const { return m_liquidity.HasBullishSweep(); }
   bool HasBearishSweep() const { return m_liquidity.HasBearishSweep(); }

   // Phase 4 canonical scan entry point. The caller supplies the exact closed
   // candle data already used by BuildStructure(), preventing hidden data fetches.
   bool Scan(const MqlRates &rates[],XAISetupCandidate &candidate) {
      ZeroMemory(candidate);
      candidate.valid=false;
      candidate.setup_type=XAI_SETUP_NONE;
      candidate.direction=XAI_DIR_NONE;

      if(ArraySize(rates)<2 || m_structure.LastProcessedBar()!=rates[1].time) return false;
      if(m_last_setup_bar==rates[1].time) return false;

      if(BuildReversal(rates,candidate) || BuildContinuation(rates,candidate)) {
         m_last_setup_bar=rates[1].time;
         return candidate.valid;
      }
      return false;
   }

   double LastATR() const { return m_last_atr; }
};

#endif
