# PHASE 10 — RECOVERY / STATE RECONSTRUCTION ACCEPTANCE TESTS

## REC-001 Fresh startup
- No managed positions.
- No managed orders.
- Recovery succeeds.
- Execution lock is false.
- No order is sent during OnInit.

## REC-002 Existing managed position
- Restart terminal with an existing XAI position.
- Position is discovered by symbol + magic.
- Initial risk is reconstructed from open price and SL if missing.
- No new order is sent.
- Position management remains available.

## REC-003 Existing managed order
- Restart while a managed broker order exists.
- Recovery detects it.
- Execution lock becomes true.
- EA never resends the order.

## REC-004 Daily trade counter missing
- Delete DAILY_TRADES global variable.
- Restart.
- Counter is reconstructed from today's managed entry deals.

## REC-005 Daily trade counter lower than history
- Set DAILY_TRADES below actual entry-deal count.
- Restart.
- Counter is raised to at least the broker-history count.

## REC-006 New broker day
- Change day boundary / simulate next day.
- START_BALANCE and DAILY_TRADES are reset for the new day.

## REC-007 Peak equity recovery
- Existing PEAK_EQUITY survives restart.
- Lower current equity does not lower the stored peak.
- Higher equity updates the peak.

## REC-008 Uncertain execution
- Leave a managed order active during restart.
- Recovery blocks new entries.
- No blind retry occurs.

## REC-009 Gateway unavailable
- Gateway is offline after restart.
- Existing position remains locally manageable.
- New entry remains blocked by later AI/execution gates.

## REC-010 Crash safety
- Force terminal restart after a completed entry.
- Broker position is discovered.
- No duplicate order is generated.

## REC-011 Wrong symbol isolation
- Position with same magic on another symbol exists.
- Recovery ignores it.

## REC-012 Wrong magic isolation
- Position on XAUUSD with another magic exists.
- Recovery ignores it.
