# PHASE 7 — Risk Engine Acceptance Tests

## Scope

Risk approval is local and deterministic. AI is not involved.

## Required tests

- RISK-001: invalid candidate rejected
- RISK-002: technical score below threshold rejected
- RISK-003: invalid entry/SL/TP rejected
- RISK-004: RR below minimum rejected
- RISK-005: max open position enforced
- RISK-006: daily trade limit enforced
- RISK-007: daily loss limit enforced
- RISK-008: maximum drawdown enforced
- RISK-009: consecutive-loss limit enforced
- RISK-010: broker-aware lot sizing using OrderCalcProfit
- RISK-011: volume min/max/step normalization
- RISK-012: insufficient free margin rejected
- RISK-013: approved candidate produces positive risk money and lot
- RISK-014: daily trade counter persists through terminal restart
- RISK-015: peak equity persists through terminal restart

## Safety invariant

Any risk uncertainty or failed broker calculation must return NO TRADE.

## Not enabled yet

Order execution remains disabled in this phase.
