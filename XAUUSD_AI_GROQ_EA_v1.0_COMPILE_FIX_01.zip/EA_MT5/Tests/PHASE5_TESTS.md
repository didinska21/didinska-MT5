# Phase 5 — Technical Scoring Acceptance Tests

## Scope

This phase validates deterministic technical scoring only. No risk, AI, or order execution is enabled.

## Formula

`Score = 0.20 Trend + 0.20 Structure + 0.15 Liquidity + 0.15 Confirmation + 0.10 Momentum + 0.10 Volatility + 0.10 RR`

All components are clamped to `[0,1]` and the final score is clamped to `[0,1]`.

## Required tests

- TS-001: Perfect aligned bullish continuation scores near the upper range.
- TS-002: Perfect aligned bearish continuation scores near the upper range.
- TS-003: Direction/structure conflict is heavily penalized.
- TS-004: Bullish sweep improves bullish liquidity component.
- TS-005: Bearish sweep improves bearish liquidity component.
- TS-006: Weak candle body lowers confirmation.
- TS-007: Directionally opposite candle lowers confirmation/momentum.
- TS-008: Normal ATR expansion scores higher than extreme expansion.
- TS-009: Extreme range is not rewarded as high-quality volatility.
- TS-010: Favorable liquidity target improves RR proxy.
- TS-011: No favorable liquidity target returns neutral RR proxy; it does not invent a target.
- TS-012: Minimum technical score threshold is configurable.
- TS-013: Closed candle only; bar 0 must not influence score inputs.
- TS-014: Invalid candidate returns score 0 and fails.
- TS-015: Zero/invalid ATR returns score 0 and fails.

## Acceptance

A candidate may proceed to Phase 6 only if `technical_score >= InpMinimumTechnicalScore`.

Passing this phase does not authorize trading.
