# PHASE 4 — STRATEGY / SETUP ENGINE TESTS

## Scope

This phase converts closed-candle structure and liquidity events into deterministic setup candidates. It does not calculate final technical score, risk, AI approval, or execute orders.

## Required cases

- P4-001 bullish BOS + bullish structure => BUY continuation candidate.
- P4-002 bearish BOS + bearish structure => SELL continuation candidate.
- P4-003 bullish CHoCH + bullish liquidity sweep => BUY reversal candidate.
- P4-004 bearish CHoCH + bearish liquidity sweep => SELL reversal candidate.
- P4-005 continuation with opposite sweep on same bar => rejected.
- P4-006 CHoCH without matching sweep => rejected.
- P4-007 ranging structure without qualifying event => rejected.
- P4-008 candidate invalidation on wrong side of entry => rejected.
- P4-009 same closed bar scanned twice => only one candidate.
- P4-010 current forming candle (bar 0) must not create a setup.
- P4-011 setup ID must be non-empty and unique within the EA runtime.
- P4-012 no order/AI call may occur in Phase 4.

## Acceptance

Every accepted candidate must contain:

- direction
- setup type
- created_at
- entry zone
- proposed entry
- invalidation price
- structure state
- validity flag

`proposed_sl` and `proposed_tp` remain zero until the dedicated SL/TP phase.
