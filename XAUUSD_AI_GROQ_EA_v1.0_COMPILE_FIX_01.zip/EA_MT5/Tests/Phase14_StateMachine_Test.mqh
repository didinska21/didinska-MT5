#ifndef __XAI_PHASE14_STATE_MACHINE_TEST_MQH__
#define __XAI_PHASE14_STATE_MACHINE_TEST_MQH__

// Acceptance matrix for deterministic state transitions.
//
// INIT -> RECOVERY -> IDLE
// IDLE -> SCANNING -> CANDIDATE -> PRECHECK -> AI_PENDING
// AI_PENDING -> AI_APPROVED -> EXECUTION_PENDING -> POSITION_ACTIVE
// POSITION_ACTIVE -> POSITION_MANAGING -> COOLDOWN -> IDLE
//
// Forbidden transitions must return false.
// Fatal error may transition from any state to ERROR.
// Recovery must complete before opening new trades.
// AI failure returns to IDLE.
// Execution failure returns to IDLE.
// Existing position management remains independent from AI availability.

#endif
