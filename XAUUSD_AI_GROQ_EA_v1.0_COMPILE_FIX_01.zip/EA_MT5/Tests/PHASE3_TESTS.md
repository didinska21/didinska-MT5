# Phase 3 Acceptance Tests

## Structure / BOS / CHoCH
- Closed candle only: bar 0 must never affect BOS/CHoCH.
- Bullish BOS: closed candle closes above latest confirmed structural high.
- Bearish BOS: closed candle closes below latest confirmed structural low.
- Bullish CHoCH: bullish break occurs while prior structure state is bearish.
- Bearish CHoCH: bearish break occurs while prior structure state is bullish.
- BOS/CHoCH flags are edge-triggered and reset each processed bar.
- Historical swing points are never mutated.

## Liquidity
- Previous completed broker-server day high/low are detected.
- Latest confirmed swing high/low are represented as liquidity.
- Equal highs/lows are detected using configurable price tolerance.
- London and New York session high/low levels are represented using configurable broker-server hours.
- Bullish sweep: closed candle trades below a liquidity level and closes back above it.
- Bearish sweep: closed candle trades above a liquidity level and closes back below it.
- No sweep is inferred from the current forming candle.

## Safety
- Phase 3 cannot send an order.
- AI is not called from Phase 3.
- Any unavailable market data results in no signal.
