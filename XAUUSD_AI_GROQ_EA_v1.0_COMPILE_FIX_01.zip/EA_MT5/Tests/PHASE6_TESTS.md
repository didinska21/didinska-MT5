# PHASE 6 — SL / TP / RR Acceptance Tests

## SL
- BUY SL must be below entry.
- SELL SL must be above entry.
- SL = structural invalidation ± ATR * SLBufferATR.
- Broker stop distance must be respected when configured.
- Zero/invalid ATR must reject the candidate.

## TP
- BUY TP must be above entry.
- SELL TP must be below entry.
- TP must be an existing active favorable liquidity level.
- The engine must not invent a target when no favorable liquidity exists.

## RR
- RR = reward / risk using the final calculated SL and TP.
- Candidate is rejected when RR < MinimumRR.
- Candidate is accepted only when direction, SL, TP and RR are internally consistent.

## Safety
- No order is sent in Phase 6.
- No AI request is made in Phase 6.
- Bar 0 is not used to construct structure, SL, or TP.
