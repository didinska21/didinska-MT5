#ifndef __XAI_PHASE17_BACKTEST_TEST_MQH__
#define __XAI_PHASE17_BACKTEST_TEST_MQH__
// BT-001 spread assumptions explicit.
// BT-002 slippage explicit.
// BT-003 commission explicit.
// BT-004 same-bar SL/TP ambiguity uses SL-first.
// BT-005 no future-bar access.
// BT-006 incomplete candle cannot create historical signal.
// BT-007 every trade has exit reason.
// BT-008 equity/drawdown exported.
// BT-009 results are suitable for OOS/WFO.
// BT-010 MT5 Strategy Tester remains authoritative.
void Phase17BacktestAcceptanceMatrix(){}
#endif
