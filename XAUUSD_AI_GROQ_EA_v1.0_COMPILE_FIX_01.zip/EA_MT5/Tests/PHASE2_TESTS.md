# Phase 2 — Swing / Structure Acceptance Tests

These tests must pass before Phase 3 is accepted.

1. **Closed candle only** — candle index 0 must never create a swing or structure decision.
2. **Pivot confirmation** — a swing requires `SwingStrength` candles on both sides.
3. **Bullish structure** — latest confirmed high > previous high AND latest confirmed low > previous low.
4. **Bearish structure** — latest confirmed high < previous high AND latest confirmed low < previous low.
5. **Range** — mixed/inconclusive HH/HL/LH/LL must not be promoted to bullish/bearish structure.
6. **Insufficient data** — fewer than two confirmed highs or lows returns UNKNOWN.
7. **Determinism** — identical closed-candle input must produce identical swing/structure output.
8. **No trade** — Phase 2 alone must never submit an order.
9. **XAUUSD-only** — unrelated symbols must fail initialization.
10. **Restart safety** — phase 2 state may be rebuilt from closed market data; no historical order is generated.
