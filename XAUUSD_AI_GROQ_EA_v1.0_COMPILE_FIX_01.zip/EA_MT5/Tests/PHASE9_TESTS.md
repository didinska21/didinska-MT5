# PHASE 9 — POSITION MANAGEMENT ACCEPTANCE TESTS

## PM-001 Managed-position scope
- Open a position with the configured XAI magic number on XAUUSD.
- Confirm the EA manages it.
- Open a manual/non-XAI position.
- Confirm the EA does not modify it when `InpManageOnlyXAIPositions=true`.

## PM-002 Initial risk persistence
- Open a managed position with a valid SL.
- Confirm the initial risk distance is persisted in an MT5 Global Variable keyed by position ticket.
- Confirm subsequent trailing does not redefine the original 1R reference.

## PM-003 Break-even
- Configure `InpEnableBreakEven=true`.
- Reach `InpBreakEvenTriggerR`.
- Confirm SL moves to entry plus/minus the configured ATR buffer.
- Confirm SL never moves backwards.

## PM-004 Structure trailing
- Reach `InpTrailingStartR`.
- Provide a confirmed higher-low for BUY or lower-high for SELL.
- Confirm the candidate SL is structure-based with ATR buffer.
- Confirm trailing never worsens protection.

## PM-005 Broker constraints
- Attempt a management SL inside stops/freeze distance.
- Confirm modification is rejected locally.

## PM-006 AI independence
- Stop the Python gateway/Groq service while a position is active.
- Confirm break-even/trailing continues locally.

## PM-007 Restart recovery
- Restart MT5 after a position is active.
- Confirm the position is rediscovered by magic/symbol.
- Confirm management resumes without opening a new trade.

## PM-008 TP preservation
- Move SL while an existing TP is present.
- Confirm TP remains unchanged.

## PM-009 No blind retries
- Force a modification failure.
- Confirm the EA does not repeatedly spam modification requests on every tick.

## PM-010 Closed-position state
- Close a managed position.
- Confirm no further modification is attempted.
