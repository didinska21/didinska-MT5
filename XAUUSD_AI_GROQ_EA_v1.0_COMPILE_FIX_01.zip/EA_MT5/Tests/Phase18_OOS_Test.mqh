#ifndef __XAI_PHASE18_OOS_TEST_MQH__
#define __XAI_PHASE18_OOS_TEST_MQH__
// OOS-001 chronological train/test boundaries.
// OOS-002 fit never receives current test slice.
// OOS-003 parameters frozen before final OOS.
// OOS-004 multiple rolling windows.
// OOS-005 report all windows, including failures.
// OOS-006 include trend/range/high-volatility/low-volatility regimes.
// OOS-007 no post-OOS threshold tuning.
// OOS-008 final EA OOS run in MT5 Strategy Tester.
void Phase18OOSAcceptanceMatrix(){}
#endif
