# Phase 13 — News + Session Filters

## Session policy
- London and New York are enabled by default.
- Asia is not a trading session in v1.0.
- Session calculations are based on UTC.
- The implementation separates trading-session gating from liquidity-map construction.
- Session boundaries are configurable.

## News policy
- MT5 Economic Calendar is the primary news source.
- USD high-impact events are blocking events for XAUUSD.
- Default lock window: 30 minutes before through 30 minutes after.
- Calendar lookup failure is fail-closed by default.
- News state is independent of AI availability.

## Market gate order
Session -> News -> Spread -> Volatility.

A failed filter returns NO TRADE before an AI request.

## Acceptance tests
1. London only: PASS inside window.
2. New York only: PASS inside window.
3. Outside configured sessions: BLOCK.
4. High-impact USD event inside window: BLOCK.
5. Event outside window: no news block.
6. Calendar lookup failure with fail-closed: BLOCK.
7. High spread: BLOCK.
8. Extreme volatility: BLOCK.
9. All filters pass: PASS.
10. Existing position management continues even when new-entry filters block.
