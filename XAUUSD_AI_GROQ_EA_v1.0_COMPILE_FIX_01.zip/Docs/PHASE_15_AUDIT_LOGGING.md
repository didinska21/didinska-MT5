# Phase 15 — Audit & Logging

## MT5 audit trail
The EA writes structured CSV events with:
- UTC timestamp
- state
- request/setup IDs
- deterministic score
- AI decision/confidence
- risk assessment
- entry/SL/TP/RR
- volume/ticket/retcode
- message

## Gateway audit trail
SQLite stores:
- request/setup correlation
- technical score
- AI response
- latency
- success/error status
- error code

## Principle
Audit data is append-oriented and is not used to change trading decisions.
Secrets/API keys are never written to audit records.

## Traceability
A trade can be traced:
SETUP → SCORE → RISK → AI REQUEST → AI RESPONSE → FINAL GATE → ORDER → EXIT.
