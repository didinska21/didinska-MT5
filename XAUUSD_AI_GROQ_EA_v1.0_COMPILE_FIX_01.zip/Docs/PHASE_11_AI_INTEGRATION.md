# Phase 11 — Groq AI Integration

Implemented:
- Strict FastAPI request/response schemas
- Groq structured JSON-schema request
- Pydantic validation
- 10-key credential pool
- Retry-After aware cooldown
- Key rotation/failure isolation
- AI gate
- MT5 WebRequest client
- Fail-closed behavior

Ten API keys are not assumed to provide 10x organization/project quota.
Live secrets stay in `.env` and are never committed.
