# Phase 19 — Stress + Robustness

Stress dimensions:
- spread 2x/3x
- slippage
- high/extreme volatility
- AI timeout/failure
- all Groq keys unavailable
- gateway unavailable
- broker rejection
- terminal restart/recovery
- consecutive losses/drawdown
- duplicate-order attempts

Safety rule: infrastructure failure can never authorize a new trade.
Existing positions remain manageable without AI.

The Python harness validates robustness plumbing. Final certification requires
running the matrix against the actual EA in MT5 Strategy Tester and, where
possible, a controlled demo environment.
