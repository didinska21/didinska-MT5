# Phase 16 — Unit + Integration Testing

## Automated gateway tests
- Request schema validation
- Unknown-field rejection
- AI response confidence bounds
- API-key rotation
- Rate-limit cooldown
- Health endpoint
- Gateway authentication

## MT5 runtime acceptance
The included matrix covers:
- Core initialization
- Closed-candle structure
- Strategy/scoring gates
- RR/risk
- duplicate protection
- execution failures
- position management
- restart recovery
- AI gate/failure behavior
- news/session filters
- state machine
- audit traceability

## Release rule
A source-level/static check is not a substitute for MetaEditor compilation or
Strategy Tester execution. Phase 16 is only certified after the runtime matrix
passes on the target MT5 build.
