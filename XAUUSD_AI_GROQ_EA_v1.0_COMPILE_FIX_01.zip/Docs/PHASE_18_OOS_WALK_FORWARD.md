# Phase 18 — OOS + Walk-Forward

Implemented chronological rolling train/test validation.

Important distinction:
- Walk-forward windows may reuse historical observations in later TRAIN windows.
- The current window's TEST slice is never passed into its FIT step.
- Final OOS results must remain untouched by parameter tuning.

For the real XAUUSD EA:
1. Freeze strategy/risk/AI thresholds.
2. Define chronological windows before inspecting final OOS.
3. Include multiple market regimes.
4. Run each window in MT5 Strategy Tester.
5. Report every window, not just profitable windows.
6. Do not retune after seeing final OOS results.
