# Phase 14 — Full State Machine

The EA now has an explicit deterministic state machine.

## Main lifecycle

INIT
→ RECOVERY
→ IDLE
→ SCANNING
→ CANDIDATE
→ PRECHECK
→ AI_PENDING
→ AI_APPROVED
→ EXECUTION_PENDING
→ POSITION_ACTIVE
→ POSITION_MANAGING
→ COOLDOWN
→ IDLE

## Safety rules

- No new trade before recovery completes.
- AI can only be requested from PRECHECK.
- Execution can only start from AI_APPROVED.
- Execution cannot be triggered directly from a strategy signal.
- AI failure returns to IDLE.
- Execution failure returns to IDLE.
- Fatal errors transition to ERROR.
- Existing positions remain manageable independently of AI availability.
- State transitions are explicit; invalid transitions are rejected.
