# Phase 12 — MT5 ↔ AI Final Integration

## Final authority chain

1. Setup validity
2. Technical score
3. SL/TP/RR validity
4. Risk pre-check
5. News/session/local market gates
6. Groq AI validation
7. Final local re-check
8. Existing execution engine

AI cannot:
- change risk
- change lot size
- change SL/TP
- bypass news
- bypass session
- bypass drawdown
- bypass spread
- place orders directly

## Fail closed

If WebRequest fails, response is invalid, request ID mismatches, confidence is below
threshold, AI disagrees with the deterministic direction, or AI reports HIGH risk:
NO TRADE.

## MT5 setup

The Gateway URL must be added to MT5:
Tools → Options → Expert Advisors → Allow WebRequest for listed URL.

Never place a Groq API key inside the EA.
Only the Gateway receives Groq credentials.
