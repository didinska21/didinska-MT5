# Phase 17 — Backtest Framework

Implemented an OHLC research replay harness with explicit assumptions:
spread data, commission, slippage configuration, conservative same-bar SL-first
handling, trade ledger, equity curve, and performance metrics.

The signal callback receives only the current bar, preventing future-bar access.
This framework validates logic/statistics; final broker execution-model
certification must use MT5 Strategy Tester.
