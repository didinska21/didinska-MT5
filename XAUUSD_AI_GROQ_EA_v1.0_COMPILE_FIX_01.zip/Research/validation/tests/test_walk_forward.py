from validation.walk_forward import make_windows, walk_forward, summarize, oos_ratio, WindowResult

def test_window_generation_has_explicit_train_test_boundaries():
    ws=make_windows(100,40,20)
    assert ws
    for w in ws:
        assert w.train_start < w.train_end == w.test_start < w.test_end
        assert w.test_end <= 100
    # Adjacent walk-forward windows may overlap in training data; that is expected.
    assert ws[1].train_start < ws[0].test_end

def test_fit_never_sees_current_window_test_data():
    seen=[]
    def fit(train):
        seen.append(list(train))
        return sum(train)/len(train)
    def score(model,data):
        return sum(data)-model*len(data)
    data=list(range(100))
    rs=walk_forward(data,40,20,fit,score)
    assert rs
    for i,w in enumerate(make_windows(100,40,20)):
        assert max(seen[i]) < w.test_start

def test_summary_and_oos_ratio():
    ws=make_windows(60,20,10)
    rs=[WindowResult(ws[0],10,5,True),WindowResult(ws[1],8,4,True)]
    s=summarize(rs)
    assert s["windows"]==2
    assert s["pass_rate"]==1.0
    assert oos_ratio(rs)==0.5
