from dataclasses import dataclass
from validation.robustness import Scenario,perturb_bars,run_scenarios,summarize

@dataclass
class Bar:
    timestamp:str; open:float; high:float; low:float; close:float; spread_points:float=0.0

class FakeEngine:
    def __init__(self,scenario): self.scenario=scenario
    def run(self,bars,signal):
        trades=[]
        for b in bars:
            c=signal(b)
            if c: trades.append({"pnl":1.0})
        return {"initial_balance":1000,"final_balance":1000+len(trades),"trades":trades}

def bars(): return [Bar(str(i),100,101,99,100,20) for i in range(10)]

def test_perturbation_is_deterministic():
    a=perturb_bars(bars(),Scenario("noise",price_noise=.5),42)
    b=perturb_bars(bars(),Scenario("noise",price_noise=.5),42)
    assert [(x.open,x.close) for x in a]==[(x.open,x.close) for x in b]

def test_scenarios_execute_and_summarize():
    rs=run_scenarios(bars(),lambda s:FakeEngine(s),
        lambda b:{"direction":"BUY","sl":99,"tp":101,"volume":1},
        [Scenario("base"),Scenario("stress",spread_multiplier=3,price_noise=.5)])
    s=summarize(rs); assert s["scenarios"]==2; assert s["passed"]==2; assert s["failures"]==0

def test_engine_exception_is_fail():
    class Bad:
        def __init__(self,s): pass
        def run(self,bars,signal): raise RuntimeError("gateway down")
    rs=run_scenarios(bars(),Bad,lambda b:None,[Scenario("gateway_down")])
    assert not rs[0].passed and rs[0].failures==1
