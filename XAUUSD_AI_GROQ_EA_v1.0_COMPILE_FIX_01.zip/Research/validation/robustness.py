from dataclasses import dataclass, asdict
import random

@dataclass
class Scenario:
    name:str
    spread_multiplier:float=1.0
    slippage_points:float=0.0
    price_noise:float=0.0
    signal_delay_bars:int=0
    ai_failure_rate:float=0.0

@dataclass
class ScenarioResult:
    name:str
    trades:int
    net_profit:float
    max_drawdown:float
    failures:int
    passed:bool
    reason:str

def perturb_bars(bars,scenario,seed=1):
    rng=random.Random(seed); out=[]
    for b in bars:
        n=rng.uniform(-scenario.price_noise,scenario.price_noise)
        out.append(type(b)(b.timestamp,b.open+n,b.high+n,b.low+n,b.close+n,
                           b.spread_points*scenario.spread_multiplier))
    return out

def run_scenarios(base_bars,engine_factory,signal_fn,scenarios,seed=1):
    results=[]
    for i,s in enumerate(scenarios):
        bars=perturb_bars(base_bars,s,seed+i)
        try:
            result=engine_factory(s).run(bars,signal_fn)
            pnls=[float(t["pnl"]) for t in result.get("trades",[])]
            equity=float(result["initial_balance"]); peak=equity; dd=0.0
            for p in pnls:
                equity+=p; peak=max(peak,equity); dd=max(dd,peak-equity)
            finite=all(p==p and abs(p)!=float("inf") for p in pnls)
            results.append(ScenarioResult(s.name,len(pnls),
                float(result["final_balance"])-float(result["initial_balance"]),
                dd,0,finite,"PASS" if finite else "NON_FINITE_PNL"))
        except Exception as exc:
            results.append(ScenarioResult(s.name,0,0.0,0.0,1,False,type(exc).__name__))
    return results

def summarize(results):
    if not results: return {"scenarios":0,"passed":0,"pass_rate":0.0}
    return {"scenarios":len(results),"passed":sum(r.passed for r in results),
            "pass_rate":sum(r.passed for r in results)/len(results),
            "worst_net_profit":min(r.net_profit for r in results),
            "worst_drawdown":max(r.max_drawdown for r in results),
            "failures":sum(r.failures for r in results)}
