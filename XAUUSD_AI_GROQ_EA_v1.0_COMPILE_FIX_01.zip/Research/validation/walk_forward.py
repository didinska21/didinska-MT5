from dataclasses import dataclass
from typing import Callable, Sequence

@dataclass(frozen=True)
class Window:
    train_start:int; train_end:int; test_start:int; test_end:int

@dataclass
class WindowResult:
    window:Window; train_metric:float; test_metric:float; passed:bool

def make_windows(n:int,train_size:int,test_size:int,step:int|None=None):
    if train_size<=0 or test_size<=0: raise ValueError("window sizes must be positive")
    step=step or test_size
    out=[]; start=0
    while start+train_size+test_size<=n:
        out.append(Window(start,start+train_size,start+train_size,start+train_size+test_size))
        start+=step
    return out

def walk_forward(data:Sequence,train_size:int,test_size:int,fit_fn:Callable,
                 score_fn:Callable,step:int|None=None):
    results=[]
    for w in make_windows(len(data),train_size,test_size,step):
        model=fit_fn(data[w.train_start:w.train_end])
        tr=float(score_fn(model,data[w.train_start:w.train_end]))
        te=float(score_fn(model,data[w.test_start:w.test_end]))
        results.append(WindowResult(w,tr,te,te>=0.0))
    return results

def summarize(results):
    if not results:
        return {"windows":0,"passed_windows":0,"pass_rate":0.0,
                "mean_train_metric":0.0,"mean_test_metric":0.0,"median_test_metric":0.0}
    tr=[r.train_metric for r in results]; te=[r.test_metric for r in results]
    return {"windows":len(results),"passed_windows":sum(r.passed for r in results),
            "pass_rate":sum(r.passed for r in results)/len(results),
            "mean_train_metric":sum(tr)/len(tr),"mean_test_metric":sum(te)/len(te),
            "median_test_metric":sorted(te)[len(te)//2]}

def oos_ratio(results):
    tr=sum(r.train_metric for r in results); te=sum(r.test_metric for r in results)
    return te/tr if tr else 0.0
