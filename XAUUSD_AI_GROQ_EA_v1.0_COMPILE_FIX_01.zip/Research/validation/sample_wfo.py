from validation.walk_forward import walk_forward, summarize, oos_ratio
data=list(range(120))
def fit(train): return sum(train)/len(train)
def score(model,sample): return sum(sample)/len(sample)-model
if __name__=="__main__":
    r=walk_forward(data,60,20,fit,score)
    print(summarize(r)); print({"oos_to_is_ratio":oos_ratio(r)})
