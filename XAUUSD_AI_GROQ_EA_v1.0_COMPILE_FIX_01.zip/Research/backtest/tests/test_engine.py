from backtest.engine import BacktestEngine, Bar
from backtest.metrics import calculate_metrics

def base(low2=99):
    return [Bar("1",100,101,99,100),Bar("2",100,105,low2,104),
            Bar("3",104,106,103,105),Bar("4",105,106,95,96)]

def signal(bar, sl=98, tp=104):
    if bar.timestamp=="1":
        return {"direction":"BUY","entry":100,"sl":sl,"tp":tp,"volume":1}

def test_buy_hits_tp():
    result=BacktestEngine().run(base(99),lambda b:signal(b))
    assert result["trades"][0]["reason"]=="TP"

def test_same_bar_sl_tp_uses_conservative_sl():
    result=BacktestEngine().run(base(98),lambda b:signal(b,99,101))
    assert result["trades"][0]["reason"]=="SL"

def test_metrics():
    result={"initial_balance":1000,"final_balance":1100,
            "trades":[{"pnl":50},{"pnl":-20},{"pnl":70}]}
    m=calculate_metrics(result)
    assert m["trade_count"]==3
    assert m["net_profit"]==100
    assert m["win_rate_pct"]==2/3*100
