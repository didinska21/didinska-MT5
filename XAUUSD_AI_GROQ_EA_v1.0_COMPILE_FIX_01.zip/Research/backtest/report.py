import json
from pathlib import Path
from .metrics import calculate_metrics

def build_report(result,output):
    report={"metrics":calculate_metrics(result),"trades":result.get("trades",[])}
    Path(output).parent.mkdir(parents=True,exist_ok=True)
    Path(output).write_text(json.dumps(report,indent=2),encoding="utf-8")
    return report
