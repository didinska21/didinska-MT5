from dataclasses import dataclass, asdict
import csv

@dataclass
class Bar:
    timestamp: str
    open: float
    high: float
    low: float
    close: float
    spread_points: float = 0.0

@dataclass
class Trade:
    entry_time: str
    exit_time: str
    direction: str
    entry: float
    exit: float
    sl: float
    tp: float
    volume: float
    pnl: float
    reason: str

class BacktestEngine:
    """OHLC research replay. MT5 Strategy Tester remains final execution authority."""
    def __init__(self, initial_balance=10000.0, point_value=1.0,
                 commission_per_volume=0.0, slippage_points=0.0):
        self.initial_balance=initial_balance
        self.point_value=point_value
        self.commission_per_volume=commission_per_volume
        self.slippage_points=slippage_points

    def run(self,bars,signal_fn):
        bars=list(bars)
        balance=self.initial_balance
        equity=[balance]
        trades=[]
        position=None
        for bar in bars:
            if position:
                d=position["direction"]; sl=position["sl"]; tp=position["tp"]
                exit_price=reason=None
                # If both SL and TP are touched in one OHLC bar, SL wins.
                if d=="BUY":
                    if bar.low<=sl: exit_price,reason=sl,"SL"
                    elif bar.high>=tp: exit_price,reason=tp,"TP"
                else:
                    if bar.high>=sl: exit_price,reason=sl,"SL"
                    elif bar.low<=tp: exit_price,reason=tp,"TP"
                if exit_price is not None:
                    move=(exit_price-position["entry"]) if d=="BUY" else (position["entry"]-exit_price)
                    pnl=move*position["volume"]*self.point_value-position["volume"]*self.commission_per_volume
                    balance+=pnl
                    trades.append(asdict(Trade(position["entry_time"],bar.timestamp,d,
                        position["entry"],exit_price,sl,tp,position["volume"],pnl,reason)))
                    position=None
            if position is None:
                c=signal_fn(bar)
                if c:
                    d=c["direction"]; entry=float(c.get("entry",bar.close))
                    sl=float(c["sl"]); tp=float(c["tp"]); vol=float(c["volume"])
                    if d not in ("BUY","SELL") or vol<=0: raise ValueError("invalid candidate")
                    if d=="BUY" and not sl<entry<tp: raise ValueError("invalid BUY levels")
                    if d=="SELL" and not tp<entry<sl: raise ValueError("invalid SELL levels")
                    position={"direction":d,"entry":entry,"sl":sl,"tp":tp,
                              "volume":vol,"entry_time":bar.timestamp}
            equity.append(balance)
        if position and bars:
            last=bars[-1]; d=position["direction"]
            move=(last.close-position["entry"]) if d=="BUY" else (position["entry"]-last.close)
            pnl=move*position["volume"]*self.point_value-position["volume"]*self.commission_per_volume
            balance+=pnl
            trades.append(asdict(Trade(position["entry_time"],last.timestamp,d,
                position["entry"],last.close,position["sl"],position["tp"],
                position["volume"],pnl,"END_OF_TEST")))
            equity.append(balance)
        return {"initial_balance":self.initial_balance,"final_balance":balance,
                "equity_curve":equity,"trades":trades}

def load_csv(path):
    out=[]
    with open(path,newline="",encoding="utf-8") as f:
        for r in csv.DictReader(f):
            out.append(Bar(r["timestamp"],float(r["open"]),float(r["high"]),
                           float(r["low"]),float(r["close"]),
                           float(r.get("spread_points",0) or 0)))
    return out
