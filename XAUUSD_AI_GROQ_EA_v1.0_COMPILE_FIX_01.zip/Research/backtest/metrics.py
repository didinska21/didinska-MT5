import math

def calculate_metrics(result):
    pnls=[float(t["pnl"]) for t in result.get("trades",[])]
    initial=float(result["initial_balance"]); final=float(result["final_balance"])
    wins=[x for x in pnls if x>0]; losses=[x for x in pnls if x<0]
    peak=initial; dd=0.0; equity=initial
    for p in pnls:
        equity+=p; peak=max(peak,equity); dd=max(dd,peak-equity)
    gp=sum(wins); gl=abs(sum(losses))
    return {
        "initial_balance":initial,"final_balance":final,"net_profit":final-initial,
        "return_pct":((final/initial)-1)*100 if initial else 0.0,
        "trade_count":len(pnls),
        "win_rate_pct":len(wins)/len(pnls)*100 if pnls else 0.0,
        "profit_factor":gp/gl if gl else (math.inf if gp else 0.0),
        "expectancy_per_trade":sum(pnls)/len(pnls) if pnls else 0.0,
        "max_drawdown":dd,"max_drawdown_pct":dd/peak*100 if peak else 0.0,
        "gross_profit":gp,"gross_loss":gl
    }
