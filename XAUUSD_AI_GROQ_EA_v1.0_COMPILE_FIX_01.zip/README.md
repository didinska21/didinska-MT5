# XAUUSD AI-GROQ EA v1.0

Release-candidate package for the XAUUSD-only MT5 Expert Advisor with Groq AI
validation through a Python gateway and a 10-key rotation pool.

## Critical deployment rule
Never put Groq API keys inside the EA. Store them only in the Gateway environment.

## Certification sequence
1. Compile in MetaEditor.
2. Run MT5 Strategy Tester.
3. Run chronological OOS/WFO.
4. Run stress/robustness matrix.
5. Run demo forward test.
6. Only then consider live deployment.

See `Docs/FINAL_AUDIT_REPORT.md`.
