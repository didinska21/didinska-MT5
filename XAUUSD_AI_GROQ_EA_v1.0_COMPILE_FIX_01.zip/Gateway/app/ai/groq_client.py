import json, os, time, requests

GROQ_URL = "https://api.groq.com/openai/v1/chat/completions"

class GroqError(RuntimeError):
    def __init__(self, code, status=None, retry_after=None):
        super().__init__(code)
        self.code, self.status, self.retry_after = code, status, retry_after

class GroqClient:
    def __init__(self, api_key):
        self.api_key = api_key
        self.model = os.getenv("GROQ_MODEL", "openai/gpt-oss-120b")
        self.timeout = float(os.getenv("GROQ_TIMEOUT_SECONDS", "20"))

    def chat_json(self, system_prompt, payload, schema):
        body = {
            "model": self.model,
            "temperature": 0,
            "messages": [
                {"role":"system","content":system_prompt},
                {"role":"user","content":json.dumps(payload, separators=(",",":"))},
            ],
            "response_format": {
                "type":"json_schema",
                "json_schema":{"name":"xauusd_ai_decision","strict":True,"schema":schema}
            }
        }
        started=time.perf_counter()
        try:
            r=requests.post(GROQ_URL,
                headers={"Authorization":f"Bearer {self.api_key}","Content-Type":"application/json"},
                json=body, timeout=self.timeout)
        except requests.Timeout as e: raise GroqError("TIMEOUT") from e
        except requests.RequestException as e: raise GroqError("NETWORK_ERROR") from e

        headers={k.lower():v for k,v in r.headers.items()}
        retry_after=None
        if "retry-after" in headers:
            try: retry_after=float(headers["retry-after"])
            except ValueError: pass
        if r.status_code==429: raise GroqError("RATE_LIMITED",429,retry_after)
        if r.status_code==401: raise GroqError("AUTH_ERROR",401)
        if r.status_code==403: raise GroqError("FORBIDDEN",403)
        if r.status_code>=500: raise GroqError("UPSTREAM_5XX",r.status_code)
        if r.status_code>=400: raise GroqError("BAD_REQUEST",r.status_code)

        try:
            raw=r.json()
            content=raw["choices"][0]["message"]["content"]
            data=json.loads(content)
        except (ValueError, KeyError, IndexError, TypeError) as e:
            raise GroqError("MALFORMED_UPSTREAM") from e
        headers["x-local-latency-ms"]=str(int((time.perf_counter()-started)*1000))
        return data, headers
