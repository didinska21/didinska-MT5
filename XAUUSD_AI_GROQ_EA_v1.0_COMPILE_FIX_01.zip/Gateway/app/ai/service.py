import os
from pydantic import ValidationError
import time
from app.audit.store import AuditStore
from app.ai.groq_client import GroqClient, GroqError
from app.ai.prompt import SYSTEM_PROMPT, RESPONSE_SCHEMA
from app.api.schemas import DecisionData
from app.keys.key_manager import KeyManager

class AIService:
    def __init__(self):
        self.keys=KeyManager()
        self.max_retries=int(os.getenv("AI_MAX_RETRIES","3"))
        self.audit=AuditStore()

    def decide(self,payload):
        last=None
        started=time.perf_counter()
        for _ in range(self.max_retries):
            try: key=self.keys.acquire()
            except RuntimeError: raise RuntimeError("ALL_KEYS_UNAVAILABLE")
            try:
                data,_=GroqClient(key.secret).chat_json(SYSTEM_PROMPT,payload,RESPONSE_SCHEMA)
                result=DecisionData.model_validate(data)
                if result.request_id!=payload["request_id"]: raise RuntimeError("REQUEST_ID_MISMATCH")
                self.keys.success(key)
                self.audit.record(
                    request_id=payload["request_id"],
                    setup_id=payload["setup_id"],
                    symbol=payload["symbol"],
                    signal=payload["signal"],
                    technical_score=payload["technical_score"],
                    decision=result.decision,
                    confidence=result.confidence,
                    market_regime=result.market_regime,
                    setup_quality=result.setup_quality,
                    risk_assessment=result.risk_assessment,
                    reason_code=result.reason_code,
                    latency_ms=int((time.perf_counter()-started)*1000),
                    status="OK"
                )
                return result
            except GroqError as e:
                last=e.code
                if e.code=="RATE_LIMITED": self.keys.rate_limited(key,e.retry_after); continue
                if e.code=="AUTH_ERROR": self.keys.failure(key,True); continue
                self.keys.failure(key)
                if e.code in {"TIMEOUT","NETWORK_ERROR","UPSTREAM_5XX"}:
                    continue
                raise RuntimeError(e.code) from e
            except (ValidationError,RuntimeError) as e:
                self.keys.failure(key)
                raise RuntimeError(str(e)) from e
        self.audit.record(
            request_id=payload["request_id"],
            setup_id=payload["setup_id"],
            symbol=payload["symbol"],
            signal=payload["signal"],
            technical_score=payload["technical_score"],
            latency_ms=int((time.perf_counter()-started)*1000),
            status="ERROR",
            error_code=last or "AI_UNAVAILABLE"
        )
        raise RuntimeError(last or "AI_UNAVAILABLE")
