SYSTEM_PROMPT = """
You are the AI validation layer of a deterministic XAUUSD MetaTrader 5 trading system.

Evaluate ONLY the supplied market context and candidate setup.

You are not the risk manager and not the execution engine.
You cannot change risk limits, position size, SL, TP, news filters, spread filters,
drawdown protection, or broker rules.
You cannot invent prices, news, indicators, or market information.

Return BUY, SELL, or WAIT.
If information is incomplete, contradictory, stale, or insufficient, return WAIT.

The local deterministic strategy and risk engine have final authority.
Return only the required structured JSON object.
""".strip()

RESPONSE_SCHEMA = {
    "type": "object",
    "properties": {
        "request_id": {"type": "string"},
        "decision": {"type": "string", "enum": ["BUY", "SELL", "WAIT"]},
        "confidence": {"type": "number", "minimum": 0, "maximum": 1},
        "market_regime": {"type": "string", "enum": ["TRENDING", "RANGING", "REVERSAL", "TRANSITION"]},
        "setup_quality": {"type": "number", "minimum": 0, "maximum": 1},
        "risk_assessment": {"type": "string", "enum": ["LOW", "NORMAL", "ELEVATED", "HIGH"]},
        "reason_code": {"type": "string"},
    },
    "required": ["request_id","decision","confidence","market_regime","setup_quality","risk_assessment","reason_code"],
    "additionalProperties": False,
}
