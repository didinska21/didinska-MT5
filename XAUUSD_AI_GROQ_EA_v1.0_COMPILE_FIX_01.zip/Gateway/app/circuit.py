from __future__ import annotations
import time
from .config import settings

class CircuitBreaker:
    def __init__(self):
        self.failures = 0
        self.opened_at = 0.0

    @property
    def is_open(self):
        if self.opened_at == 0:
            return False
        if time.time() - self.opened_at >= settings.circuit_recovery:
            self.opened_at = 0
            self.failures = 0
            return False
        return True

    def success(self):
        self.failures = 0
        self.opened_at = 0

    def failure(self):
        self.failures += 1
        if self.failures >= settings.circuit_threshold:
            self.opened_at = time.time()

circuit = CircuitBreaker()
