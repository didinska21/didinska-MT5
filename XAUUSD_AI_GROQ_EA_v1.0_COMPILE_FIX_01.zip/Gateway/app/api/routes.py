import os
from fastapi import APIRouter, Header, HTTPException
from app.api.schemas import DecisionRequest, DecisionResponse
from app.ai.service import AIService

router=APIRouter()
_service=None

def service():
    global _service
    if _service is None: _service=AIService()
    return _service

def auth(token):
    expected=os.getenv("GATEWAY_TOKEN","")
    if not expected or token!=expected: raise HTTPException(401,"UNAUTHORIZED")

@router.get("/health")
def health(): return {"status":"ok"}

@router.get("/status")
def status(x_gateway_token: str|None=Header(default=None,alias="X-Gateway-Token")):
    auth(x_gateway_token)
    return {"status":"running","keys":service().keys.public_status()}

@router.post("/v1/decision",response_model=DecisionResponse)
def decision(req:DecisionRequest,x_gateway_token: str|None=Header(default=None,alias="X-Gateway-Token")):
    auth(x_gateway_token)
    try: result=service().decide(req.model_dump())
    except RuntimeError as e: raise HTTPException(503,str(e)) from e
    return {"status":"OK","data":result.model_dump()}
