from __future__ import annotations
import os
from dataclasses import dataclass
from dotenv import load_dotenv
load_dotenv()

@dataclass(frozen=True)
class Settings:
    host: str = os.getenv("GATEWAY_HOST", "127.0.0.1")
    port: int = int(os.getenv("GATEWAY_PORT", "8787"))
    gateway_token: str = os.getenv("GATEWAY_TOKEN", "")
    groq_base_url: str = os.getenv("GROQ_BASE_URL", "https://api.groq.com/openai/v1")
    groq_model: str = os.getenv("GROQ_MODEL", "openai/gpt-oss-120b")
    groq_timeout: float = float(os.getenv("GROQ_TIMEOUT_SECONDS", "12"))
    max_retries: int = int(os.getenv("GROQ_MAX_RETRIES", "3"))
    cache_ttl: int = int(os.getenv("AI_CACHE_TTL_SECONDS", "60"))
    default_cooldown: int = int(os.getenv("KEY_COOLDOWN_DEFAULT_SECONDS", "10"))
    circuit_threshold: int = int(os.getenv("CIRCUIT_FAILURE_THRESHOLD", "5"))
    circuit_recovery: int = int(os.getenv("CIRCUIT_RECOVERY_SECONDS", "30"))

    def keys(self) -> list[tuple[str, str]]:
        result = []
        for i in range(1, 11):
            key = os.getenv(f"GROQ_API_KEY_{i:02d}", "").strip()
            if key:
                result.append((f"KEY{i:02d}", key))
        return result

settings = Settings()
