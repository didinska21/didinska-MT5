from __future__ import annotations
import time
from .models import DecisionRequest, AIResult
from .cache import make_cache_key, get, set_value
from .groq_client import GroqClient
from .database import db

class DecisionService:
    def __init__(self, groq: GroqClient):
        self.groq = groq

    async def decide(self, req: DecisionRequest):
        if req.symbol.upper() not in {"XAUUSD", "XAUUSD.A", "XAUUSD.M", "XAUUSDm"}:
            raise ValueError("SYMBOL_NOT_ALLOWED")
        cache_key = make_cache_key(req.model_dump(mode="json"))
        cached = get(cache_key)
        if cached:
            return AIResult.model_validate(cached), "CACHE", 0.0
        started = time.perf_counter()
        try:
            result, key_id, latency = await self.groq.decide(req)
            set_value(cache_key, result.model_dump(mode="json"))
            db.execute("INSERT INTO ai_requests(request_id,setup_id,request_hash,model,key_id,timestamp_utc,status,latency_ms,created_at) VALUES(?,?,?,?,?,?,?,?,?)",
                       (req.request_id,req.setup_id,cache_key,self.groq.__dict__.get("model", ""),key_id,req.timestamp_utc,"SUCCESS",latency,time.time()))
            db.execute("INSERT INTO ai_responses(request_id,decision,confidence,market_regime,setup_quality,risk_assessment,reason_code,validation_status,created_at) VALUES(?,?,?,?,?,?,?,?,?)",
                       (result.request_id,result.decision.value,result.confidence,result.market_regime.value,result.setup_quality,result.risk_assessment.value,result.reason_code,"VALID",time.time()))
            return result, key_id, latency
        except Exception as exc:
            db.execute("INSERT INTO gateway_errors(timestamp,request_id,error_type,message_code) VALUES(?,?,?,?)",
                       (time.time(),req.request_id,type(exc).__name__,str(exc)[:128]))
            raise
