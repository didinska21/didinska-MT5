from __future__ import annotations
import hashlib, json, time
from .database import db
from .config import settings

def make_cache_key(payload: dict) -> str:
    raw = json.dumps(payload, sort_keys=True, separators=(",", ":"), ensure_ascii=False)
    return hashlib.sha256(raw.encode()).hexdigest()

def get(key: str):
    row = db.fetchone("SELECT response_json,expires_at FROM ai_cache WHERE cache_key=?", (key,))
    if not row:
        return None
    if time.time() >= row["expires_at"]:
        db.execute("DELETE FROM ai_cache WHERE cache_key=?", (key,))
        return None
    return json.loads(row["response_json"])

def set_value(key: str, response: dict):
    now = time.time()
    db.execute("INSERT OR REPLACE INTO ai_cache(cache_key,response_json,created_at,expires_at) VALUES(?,?,?,?)",
               (key, json.dumps(response, separators=(",", ":"), ensure_ascii=False), now, now + settings.cache_ttl))
