from __future__ import annotations
from enum import Enum
from typing import Any
from pydantic import BaseModel, ConfigDict, Field

class Decision(str, Enum):
    BUY = "BUY"
    SELL = "SELL"
    WAIT = "WAIT"

class MarketRegime(str, Enum):
    TRENDING = "TRENDING"
    RANGING = "RANGING"
    REVERSAL = "REVERSAL"
    TRANSITION = "TRANSITION"

class RiskAssessment(str, Enum):
    LOW = "LOW"
    NORMAL = "NORMAL"
    ELEVATED = "ELEVATED"
    HIGH = "HIGH"

class DecisionRequest(BaseModel):
    model_config = ConfigDict(extra="allow")
    request_id: str = Field(min_length=1, max_length=128)
    setup_id: str = Field(min_length=1, max_length=128)
    timestamp_utc: str
    symbol: str
    signal: Decision
    technical_score: float = Field(ge=0, le=1)
    market: dict[str, Any] = Field(default_factory=dict)
    structure: dict[str, Any] = Field(default_factory=dict)
    liquidity: dict[str, Any] = Field(default_factory=dict)
    momentum: dict[str, Any] = Field(default_factory=dict)
    volatility: dict[str, Any] = Field(default_factory=dict)
    session: dict[str, Any] = Field(default_factory=dict)
    news: dict[str, Any] = Field(default_factory=dict)
    risk_context: dict[str, Any] = Field(default_factory=dict)

class AIResult(BaseModel):
    model_config = ConfigDict(extra="forbid")
    request_id: str
    decision: Decision
    confidence: float = Field(ge=0, le=1)
    market_regime: MarketRegime
    setup_quality: float = Field(ge=0, le=1)
    risk_assessment: RiskAssessment
    reason_code: str = Field(min_length=1, max_length=128)

class GatewayResponse(BaseModel):
    status: str
    data: AIResult | None = None
    error_code: str | None = None
