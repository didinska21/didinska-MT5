from __future__ import annotations
import time
import threading
from dataclasses import dataclass
from .config import settings
from .database import db

@dataclass
class KeyState:
    key_id: str
    secret: str
    status: str = "AVAILABLE"
    last_used: float = 0.0
    cooldown_until: float = 0.0
    request_count: int = 0
    success_count: int = 0
    rate_limit_count: int = 0
    error_count: int = 0
    avg_latency_ms: float = 0.0

class KeyManager:
    def __init__(self):
        self.lock = threading.Lock()
        self.keys = {kid: KeyState(kid, secret) for kid, secret in settings.keys()}
        now = time.time()
        for state in self.keys.values():
            db.execute("INSERT OR IGNORE INTO api_key_stats(key_id,status,updated_at) VALUES(?,?,?)", (state.key_id, state.status, now))

    def _refresh(self, state: KeyState):
        if state.status == "COOLDOWN" and time.time() >= state.cooldown_until:
            state.status = "AVAILABLE"
            state.cooldown_until = 0

    def select(self) -> KeyState | None:
        with self.lock:
            for s in self.keys.values():
                self._refresh(s)
            available = [s for s in self.keys.values() if s.status == "AVAILABLE"]
            if not available:
                return None
            state = min(available, key=lambda s: s.last_used)
            state.status = "IN_USE"
            state.last_used = time.time()
            state.request_count += 1
            return state

    def success(self, state: KeyState, latency_ms: float):
        with self.lock:
            state.status = "AVAILABLE"
            state.success_count += 1
            state.avg_latency_ms = latency_ms if state.avg_latency_ms == 0 else (state.avg_latency_ms * 0.8 + latency_ms * 0.2)
            self._persist(state)

    def cooldown(self, state: KeyState, seconds: float):
        with self.lock:
            state.status = "COOLDOWN"
            state.cooldown_until = time.time() + max(seconds, settings.default_cooldown)
            state.rate_limit_count += 1
            self._persist(state)

    def failure(self, state: KeyState, disable: bool = False):
        with self.lock:
            state.status = "DISABLED" if disable else "AVAILABLE"
            state.error_count += 1
            self._persist(state)

    def _persist(self, s: KeyState):
        db.execute("""UPDATE api_key_stats SET status=?,last_used=?,cooldown_until=?,request_count=?,success_count=?,rate_limit_count=?,error_count=?,avg_latency_ms=?,updated_at=? WHERE key_id=?""",
                   (s.status,s.last_used,s.cooldown_until,s.request_count,s.success_count,s.rate_limit_count,s.error_count,s.avg_latency_ms,time.time(),s.key_id))

    def status(self):
        with self.lock:
            for s in self.keys.values(): self._refresh(s)
            return [{"key_id": s.key_id, "status": s.status, "last_used": s.last_used, "cooldown_until": s.cooldown_until,
                     "request_count": s.request_count, "success_count": s.success_count, "rate_limit_count": s.rate_limit_count,
                     "error_count": s.error_count, "avg_latency_ms": round(s.avg_latency_ms, 2)} for s in self.keys.values()]

    def available_count(self) -> int:
        with self.lock:
            for s in self.keys.values(): self._refresh(s)
            return sum(s.status == "AVAILABLE" for s in self.keys.values())
