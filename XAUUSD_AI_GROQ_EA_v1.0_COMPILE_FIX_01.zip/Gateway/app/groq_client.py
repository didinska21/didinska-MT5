from __future__ import annotations
import json, time
import httpx
from .config import settings
from .key_manager import KeyManager, KeyState
from .models import AIResult, DecisionRequest
from .circuit import circuit

SYSTEM_PROMPT = """You are the AI validation layer of a deterministic XAUUSD MetaTrader 5 trading system.\n\nEvaluate ONLY the supplied market context. You are NOT the risk manager and NOT the execution engine. You cannot override risk, news, spread, drawdown or broker rules. Never invent prices, news, indicators or missing information. If information is contradictory, incomplete or insufficient, return WAIT. Return only the required JSON schema."""

SCHEMA = {
    "type": "object",
    "properties": {
        "request_id": {"type": "string"},
        "decision": {"type": "string", "enum": ["BUY", "SELL", "WAIT"]},
        "confidence": {"type": "number", "minimum": 0, "maximum": 1},
        "market_regime": {"type": "string", "enum": ["TRENDING", "RANGING", "REVERSAL", "TRANSITION"]},
        "setup_quality": {"type": "number", "minimum": 0, "maximum": 1},
        "risk_assessment": {"type": "string", "enum": ["LOW", "NORMAL", "ELEVATED", "HIGH"]},
        "reason_code": {"type": "string"}
    },
    "required": ["request_id", "decision", "confidence", "market_regime", "setup_quality", "risk_assessment", "reason_code"],
    "additionalProperties": False,
}

class GroqClient:
    def __init__(self, key_manager: KeyManager):
        self.keys = key_manager

    def _payload(self, req: DecisionRequest):
        context = req.model_dump(mode="json")
        return {
            "model": settings.groq_model,
            "messages": [
                {"role": "system", "content": SYSTEM_PROMPT},
                {"role": "user", "content": json.dumps(context, separators=(",", ":"), ensure_ascii=False)},
            ],
            "temperature": 0,
            "reasoning_effort": "low",
            "response_format": {"type": "json_schema", "json_schema": {"name": "xauusd_ai_decision", "schema": SCHEMA}},
            "stream": False,
        }

    async def decide(self, req: DecisionRequest):
        if circuit.is_open:
            raise RuntimeError("CIRCUIT_OPEN")
        last_error = None
        for _ in range(settings.max_retries):
            key = self.keys.select()
            if key is None:
                raise RuntimeError("ALL_KEYS_UNAVAILABLE")
            started = time.perf_counter()
            try:
                async with httpx.AsyncClient(timeout=settings.groq_timeout) as client:
                    response = await client.post(
                        f"{settings.groq_base_url.rstrip('/')}/chat/completions",
                        headers={"Authorization": f"Bearer {key.secret}", "Content-Type": "application/json"},
                        json=self._payload(req),
                    )
                latency = (time.perf_counter() - started) * 1000
                if response.status_code == 429:
                    retry_after = response.headers.get("retry-after")
                    cooldown = float(retry_after) if retry_after and retry_after.replace('.', '', 1).isdigit() else settings.default_cooldown
                    self.keys.cooldown(key, cooldown)
                    last_error = "RATE_LIMIT"
                    continue
                if response.status_code in (401, 403):
                    self.keys.failure(key, disable=True)
                    last_error = "AUTH"
                    continue
                if response.status_code >= 500:
                    self.keys.failure(key)
                    circuit.failure()
                    last_error = f"UPSTREAM_{response.status_code}"
                    continue
                response.raise_for_status()
                body = response.json()
                content = body["choices"][0]["message"]["content"]
                parsed = AIResult.model_validate(json.loads(content))
                if parsed.request_id != req.request_id:
                    self.keys.failure(key)
                    last_error = "REQUEST_ID_MISMATCH"
                    continue
                self.keys.success(key, latency)
                circuit.success()
                return parsed, key.key_id, latency
            except (httpx.TimeoutException, httpx.NetworkError) as exc:
                self.keys.failure(key)
                circuit.failure()
                last_error = type(exc).__name__
                continue
            except Exception as exc:
                self.keys.failure(key)
                circuit.failure()
                last_error = type(exc).__name__
                continue
        raise RuntimeError(last_error or "AI_REQUEST_FAILED")
