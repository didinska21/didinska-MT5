from __future__ import annotations
import sqlite3
import threading
from pathlib import Path

DB_PATH = Path(__file__).resolve().parents[2] / "data" / "gateway.db"
DB_PATH.parent.mkdir(parents=True, exist_ok=True)

class Database:
    def __init__(self, path: Path = DB_PATH):
        self.path = path
        self.lock = threading.Lock()
        self.init()

    def connect(self):
        con = sqlite3.connect(self.path, timeout=10)
        con.row_factory = sqlite3.Row
        return con

    def init(self):
        with self.lock, self.connect() as con:
            con.executescript("""
            CREATE TABLE IF NOT EXISTS api_key_stats (
                key_id TEXT PRIMARY KEY,
                status TEXT NOT NULL,
                last_used REAL,
                cooldown_until REAL,
                request_count INTEGER NOT NULL DEFAULT 0,
                success_count INTEGER NOT NULL DEFAULT 0,
                rate_limit_count INTEGER NOT NULL DEFAULT 0,
                error_count INTEGER NOT NULL DEFAULT 0,
                avg_latency_ms REAL NOT NULL DEFAULT 0,
                updated_at REAL NOT NULL
            );
            CREATE TABLE IF NOT EXISTS ai_requests (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                request_id TEXT NOT NULL,
                setup_id TEXT NOT NULL,
                request_hash TEXT NOT NULL,
                model TEXT NOT NULL,
                key_id TEXT,
                timestamp_utc TEXT NOT NULL,
                status TEXT NOT NULL,
                latency_ms REAL,
                created_at REAL NOT NULL
            );
            CREATE TABLE IF NOT EXISTS ai_responses (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                request_id TEXT NOT NULL,
                decision TEXT NOT NULL,
                confidence REAL NOT NULL,
                market_regime TEXT NOT NULL,
                setup_quality REAL NOT NULL,
                risk_assessment TEXT NOT NULL,
                reason_code TEXT NOT NULL,
                validation_status TEXT NOT NULL,
                created_at REAL NOT NULL
            );
            CREATE TABLE IF NOT EXISTS ai_cache (
                cache_key TEXT PRIMARY KEY,
                response_json TEXT NOT NULL,
                created_at REAL NOT NULL,
                expires_at REAL NOT NULL
            );
            CREATE TABLE IF NOT EXISTS gateway_errors (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp REAL NOT NULL,
                request_id TEXT,
                key_id TEXT,
                error_type TEXT NOT NULL,
                http_status INTEGER,
                message_code TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS system_events (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp REAL NOT NULL,
                event_type TEXT NOT NULL,
                message TEXT NOT NULL
            );
            """)

    def execute(self, sql: str, params=()):
        with self.lock, self.connect() as con:
            cur = con.execute(sql, params)
            con.commit()
            return cur.lastrowid

    def fetchone(self, sql: str, params=()):
        with self.lock, self.connect() as con:
            return con.execute(sql, params).fetchone()

    def fetchall(self, sql: str, params=()):
        with self.lock, self.connect() as con:
            return con.execute(sql, params).fetchall()

db = Database()
