from fastapi import APIRouter, Header, HTTPException
import os
from app.audit.store import AuditStore

router = APIRouter(prefix="/v1/audit")
_store = None

def store():
    global _store
    if _store is None:
        _store = AuditStore()
    return _store

def auth(token):
    expected=os.getenv("GATEWAY_TOKEN","")
    if not expected or token != expected:
        raise HTTPException(401,"UNAUTHORIZED")

@router.get("/recent")
def recent(x_gateway_token: str|None=Header(default=None, alias="X-Gateway-Token"),
           limit: int=100):
    auth(x_gateway_token)
    limit=max(1,min(limit,500))
    return {"status":"OK","data":store().recent(limit)}
