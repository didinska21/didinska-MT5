import json
import os
import sqlite3
import threading
from datetime import datetime, timezone

class AuditStore:
    def __init__(self, path=None):
        self.path = path or os.getenv("AUDIT_DB_PATH", "data/audit.db")
        os.makedirs(os.path.dirname(self.path) or ".", exist_ok=True)
        self._lock = threading.Lock()
        self._init()

    def _connect(self):
        return sqlite3.connect(self.path, timeout=10)

    def _init(self):
        with self._connect() as db:
            db.execute("""
            CREATE TABLE IF NOT EXISTS ai_audit (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                created_utc TEXT NOT NULL,
                request_id TEXT NOT NULL,
                setup_id TEXT NOT NULL,
                symbol TEXT NOT NULL,
                signal TEXT NOT NULL,
                technical_score REAL NOT NULL,
                decision TEXT,
                confidence REAL,
                market_regime TEXT,
                setup_quality REAL,
                risk_assessment TEXT,
                reason_code TEXT,
                latency_ms INTEGER,
                status TEXT NOT NULL,
                error_code TEXT
            )
            """)
            db.execute("CREATE INDEX IF NOT EXISTS idx_ai_request ON ai_audit(request_id)")
            db.execute("CREATE INDEX IF NOT EXISTS idx_ai_created ON ai_audit(created_utc)")
            db.commit()

    def record(self, *, request_id, setup_id, symbol, signal, technical_score,
               decision=None, confidence=None, market_regime=None,
               setup_quality=None, risk_assessment=None, reason_code=None,
               latency_ms=None, status="OK", error_code=None):
        with self._lock, self._connect() as db:
            db.execute("""
                INSERT INTO ai_audit (
                    created_utc, request_id, setup_id, symbol, signal,
                    technical_score, decision, confidence, market_regime,
                    setup_quality, risk_assessment, reason_code, latency_ms,
                    status, error_code
                ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
            """, (
                datetime.now(timezone.utc).isoformat(),
                request_id, setup_id, symbol, signal, technical_score,
                decision, confidence, market_regime, setup_quality,
                risk_assessment, reason_code, latency_ms, status, error_code
            ))
            db.commit()

    def recent(self, limit=100):
        with self._connect() as db:
            db.row_factory = sqlite3.Row
            rows = db.execute(
                "SELECT * FROM ai_audit ORDER BY id DESC LIMIT ?", (int(limit),)
            ).fetchall()
            return [dict(row) for row in rows]
