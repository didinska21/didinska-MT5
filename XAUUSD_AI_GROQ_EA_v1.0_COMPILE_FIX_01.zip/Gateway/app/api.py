from fastapi import APIRouter, Depends, HTTPException
from .models import DecisionRequest, GatewayResponse
from .security import require_gateway_token
from .config import settings
from .key_manager import KeyManager
from .groq_client import GroqClient
from .service import DecisionService
from .circuit import circuit

router = APIRouter()
keys = KeyManager()
service = DecisionService(GroqClient(keys))

@router.get("/health")
def health():
    return {"status": "ok", "gateway": True, "available_keys": keys.available_count(), "circuit_open": circuit.is_open}

@router.get("/status", dependencies=[Depends(require_gateway_token)])
def status():
    return {
        "gateway": "RUNNING",
        "model": settings.groq_model,
        "available_keys": keys.available_count(),
        "keys": keys.status(),
        "circuit_open": circuit.is_open,
    }

@router.post("/v1/decision", response_model=GatewayResponse, dependencies=[Depends(require_gateway_token)])
async def decision(req: DecisionRequest):
    try:
        result, key_id, latency = await service.decide(req)
        return GatewayResponse(status="OK", data=result)
    except ValueError as exc:
        raise HTTPException(status_code=403 if str(exc) == "SYMBOL_NOT_ALLOWED" else 400, detail=str(exc))
    except RuntimeError as exc:
        code = str(exc)
        raise HTTPException(status_code=503, detail=code)
    except Exception:
        raise HTTPException(status_code=500, detail="AI_INTERNAL_ERROR")
