from fastapi import Header, HTTPException
from .config import settings

def require_gateway_token(x_gateway_token: str | None = Header(default=None)) -> None:
    if not settings.gateway_token:
        raise HTTPException(status_code=503, detail="GATEWAY_TOKEN_NOT_CONFIGURED")
    if x_gateway_token != settings.gateway_token:
        raise HTTPException(status_code=401, detail="UNAUTHORIZED")
