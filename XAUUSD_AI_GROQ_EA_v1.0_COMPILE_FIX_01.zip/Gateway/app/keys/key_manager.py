import os, time
from dataclasses import dataclass

@dataclass
class KeyState:
    key_id: str
    secret: str
    status: str = "AVAILABLE"
    cooldown_until: float = 0.0
    last_used: float = 0.0
    request_count: int = 0
    success_count: int = 0
    rate_limit_count: int = 0
    error_count: int = 0

class KeyManager:
    def __init__(self):
        self.keys=[]
        for i in range(1,11):
            secret=os.getenv(f"GROQ_API_KEY_{i:02d}","").strip()
            if secret: self.keys.append(KeyState(f"{i:02d}",secret))
        if not self.keys: raise RuntimeError("NO_GROQ_KEYS_CONFIGURED")

    def refresh(self):
        now=time.time()
        for k in self.keys:
            if k.status=="COOLDOWN" and k.cooldown_until<=now: k.status="AVAILABLE"

    def acquire(self):
        self.refresh()
        c=[k for k in self.keys if k.status=="AVAILABLE"]
        if not c: raise RuntimeError("ALL_KEYS_UNAVAILABLE")
        k=min(c,key=lambda x:x.last_used)
        k.status="IN_USE"; k.last_used=time.time(); k.request_count+=1
        return k

    def success(self,k): k.status="AVAILABLE"; k.success_count+=1
    def rate_limited(self,k,retry_after):
        k.rate_limit_count+=1; k.status="COOLDOWN"
        k.cooldown_until=time.time()+max(1.0,retry_after or 5.0)
    def failure(self,k,auth=False):
        k.error_count+=1; k.status="DISABLED" if auth else "AVAILABLE"

    def available_count(self):
        self.refresh()
        return sum(k.status=="AVAILABLE" for k in self.keys)

    def public_status(self):
        self.refresh()
        return {
            "total_configured":len(self.keys),
            "available":sum(k.status=="AVAILABLE" for k in self.keys),
            "cooldown":sum(k.status=="COOLDOWN" for k in self.keys),
            "disabled":sum(k.status=="DISABLED" for k in self.keys),
        }
