import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from app.api.schemas import DecisionData, DecisionRequest
from app.keys.key_manager import KeyManager

def valid_request():
    return {
        "request_id":"REQ-UNIT-1",
        "setup_id":"SETUP-UNIT-1",
        "timestamp_utc":"2026-08-15T00:00:00Z",
        "symbol":"XAUUSD",
        "signal":"BUY",
        "technical_score":0.82,
        "market":{},
        "structure":{},
        "liquidity":{},
        "momentum":{},
        "volatility":{},
        "session":{},
        "news":{},
        "risk_context":{}
    }

def test_request_schema_accepts_valid_payload():
    x=DecisionRequest.model_validate(valid_request())
    assert x.symbol=="XAUUSD"
    assert x.technical_score==0.82

def test_request_schema_rejects_unknown_fields():
    bad=valid_request()
    bad["unexpected"]=1
    try:
        DecisionRequest.model_validate(bad)
        assert False
    except Exception:
        assert True

def test_decision_schema_bounds_confidence():
    DecisionData(
        request_id="REQ-1", decision="BUY", confidence=0.75,
        market_regime="TRENDING", setup_quality=0.80,
        risk_assessment="NORMAL", reason_code="OK"
    )
    try:
        DecisionData(
            request_id="REQ-2", decision="BUY", confidence=1.1,
            market_regime="TRENDING", setup_quality=0.80,
            risk_assessment="NORMAL", reason_code="BAD"
        )
        assert False
    except Exception:
        assert True

def test_key_manager_rotates_available_keys(monkeypatch):
    monkeypatch.setenv("GROQ_API_KEY_01","key-a")
    monkeypatch.setenv("GROQ_API_KEY_02","key-b")
    km=KeyManager()
    a=km.acquire()
    km.success(a)
    b=km.acquire()
    assert {a.key_id,b.key_id}=={"01","02"}

def test_key_manager_cooldown(monkeypatch):
    monkeypatch.setenv("GROQ_API_KEY_01","key-a")
    monkeypatch.setenv("GROQ_API_KEY_02","key-b")
    km=KeyManager()
    a=km.acquire()
    km.rate_limited(a,60)
    assert a.status=="COOLDOWN"
    assert km.available_count()==1
