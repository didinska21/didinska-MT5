import sys
from pathlib import Path
from fastapi.testclient import TestClient

ROOT=Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path: sys.path.insert(0,str(ROOT))

def valid_payload():
    return {
        "request_id":"AUTH-TEST",
        "setup_id":"SETUP-AUTH",
        "timestamp_utc":"2026-08-15T00:00:00Z",
        "symbol":"XAUUSD",
        "signal":"BUY",
        "technical_score":0.80,
        "market":{},
        "structure":{},
        "liquidity":{},
        "momentum":{},
        "volatility":{},
        "session":{},
        "news":{},
        "risk_context":{}
    }

def test_health_endpoint(monkeypatch):
    monkeypatch.setenv("GATEWAY_TOKEN","test-token")
    from main import app
    c=TestClient(app)
    r=c.get("/health")
    assert r.status_code==200
    assert r.json()["status"]=="ok"

def test_decision_requires_gateway_auth(monkeypatch):
    monkeypatch.setenv("GATEWAY_TOKEN","test-token")
    from main import app
    c=TestClient(app)
    r=c.post("/v1/decision",json=valid_payload())
    assert r.status_code==401
