from app.models import DecisionRequest, AIResult

def test_request_and_response_models():
    req = DecisionRequest(
        request_id="REQ-1", setup_id="SETUP-1", timestamp_utc="2026-08-14T00:00:00Z",
        symbol="XAUUSD", signal="BUY", technical_score=0.82
    )
    assert req.symbol == "XAUUSD"
    result = AIResult(
        request_id="REQ-1", decision="BUY", confidence=0.84,
        market_regime="TRENDING", setup_quality=0.87,
        risk_assessment="NORMAL", reason_code="TREND_CONTINUATION"
    )
    assert result.confidence >= 0.75
