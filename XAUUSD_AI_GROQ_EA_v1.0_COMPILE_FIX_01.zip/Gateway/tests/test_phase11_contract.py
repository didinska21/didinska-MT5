from app.api.schemas import DecisionData

def test_valid_response():
    x=DecisionData(request_id="REQ-1",decision="BUY",confidence=0.84,
                   market_regime="TRENDING",setup_quality=0.87,
                   risk_assessment="NORMAL",reason_code="TREND_CONTINUATION")
    assert x.confidence>=0.75

def test_wait_response():
    x=DecisionData(request_id="REQ-2",decision="WAIT",confidence=0.99,
                   market_regime="TRANSITION",setup_quality=0.20,
                   risk_assessment="ELEVATED",reason_code="INSUFFICIENT_CONTEXT")
    assert x.decision=="WAIT"
