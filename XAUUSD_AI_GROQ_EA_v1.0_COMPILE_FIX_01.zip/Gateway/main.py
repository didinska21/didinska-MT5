from fastapi import FastAPI
from app.api.routes import router
from app.audit.routes import router as audit_router

app=FastAPI(title="XAUUSD AI-GROQ Gateway",version="1.0.0")
app.include_router(router)
app.include_router(audit_router)
