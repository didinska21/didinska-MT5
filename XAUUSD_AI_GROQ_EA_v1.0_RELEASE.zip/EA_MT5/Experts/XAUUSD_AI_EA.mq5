#property strict
#property version "1.0.0"
#property description "XAUUSD AI-GROQ EA - engineering baseline"

#include <XAUUSD_AI/Core/Types.mqh>
#include <XAUUSD_AI/Core/Config.mqh>
#include <XAUUSD_AI/Core/Logger.mqh>
#include <XAUUSD_AI/Market/MarketData.mqh>
#include <XAUUSD_AI/Market/ATRService.mqh>
#include <XAUUSD_AI/Market/SwingEngine.mqh>
#include <XAUUSD_AI/Market/StructureEngine.mqh>
#include <XAUUSD_AI/Strategy/StrategyEngine.mqh>
#include <XAUUSD_AI/Strategy/ScoreEngine.mqh>
#include <XAUUSD_AI/Risk/PositionSizer.mqh>
#include <XAUUSD_AI/Risk/RiskManager.mqh>
#include <XAUUSD_AI/Risk/SLTPCalculator.mqh>
#include <XAUUSD_AI/AI/AIClient.mqh>
#include <XAUUSD_AI/Execution/ExecutionManager.mqh>
#include <XAUUSD_AI/Recovery/RecoveryManager.mqh>
#include <XAUUSD_AI/Management/PositionManager.mqh>

CXAILogger g_log;
CXAIMarketData g_market;
CXAIATR g_atr;
CXAIStrategyEngine g_strategy;
CXAIScoreEngine g_score;
CXAIPositionSizer g_sizer;
CXAIRiskManager g_risk;
CXAISLTPService g_sltp;
CXAIClient g_ai;
CXAIExecutionManager g_exec;
CXAIRecoveryManager g_recovery;
CXAIPositionManager g_position_manager;

datetime g_last_m5_bar=0;
bool g_system_ready=false;

bool IsXAUUSD(string symbol) {
   string s=symbol; StringToUpper(s);
   return (StringFind(s,"XAUUSD")>=0 || StringFind(s,"GOLD")>=0);
}

bool IsNewBar() {
   datetime t=iTime(_Symbol,PERIOD_M5,0);
   if(t==0) return false;
   if(t!=g_last_m5_bar) { g_last_m5_bar=t; return true; }
   return false;
}

int OnInit() {
   if(!IsXAUUSD(_Symbol)) {
      g_log.Error("This EA is restricted to XAUUSD/GOLD symbols.");
      return INIT_FAILED;
   }
   if(!g_market.Initialize(_Symbol)) return INIT_FAILED;
   if(!g_atr.Initialize(_Symbol,InpATRPeriod)) return INIT_FAILED;
   g_strategy.Configure(InpSwingStrength,InpEqualLiquidityTolerancePrice,InpSweepBufferPrice,InpLondonLiquidityStartHour,InpLondonLiquidityEndHour,InpNewYorkLiquidityStartHour,InpNewYorkLiquidityEndHour);
   g_score.Configure(InpMinimumTechnicalScore);
   g_sltp.Configure(InpSLBufferATR,InpMinimumRR,g_market.StopsLevel(),SymbolInfoDouble(_Symbol,SYMBOL_POINT));
   g_risk.Configure(_Symbol,InpMagicNumber);
   g_ai.Configure(InpGatewayURL,InpGatewayToken,InpAITimeoutMs);
   g_exec.Configure(InpMagicNumber,InpMaxDeviationPoints);
   g_recovery.Configure(InpMagicNumber,_Symbol);
   g_position_manager.Configure(InpMagicNumber);
   if(!g_recovery.Recover()) {
      g_log.Error("Recovery failed; entering fail-closed startup state.");
      return INIT_FAILED;
   }
   g_system_ready=true;
   g_log.Info("Recovery: "+g_recovery.Status());
   g_log.Info("Initialized on "+_Symbol+". Live trading flag="+(InpAllowLiveTrading?"ON":"OFF"));
   return INIT_SUCCEEDED;
}

void OnDeinit(const int reason) {
   g_atr.Release();
   g_log.Info("Deinitialized. reason="+IntegerToString(reason));
}

void ManagePositions() {
   // Active positions are managed entirely locally. AI/Gateway is never required.
   const double atr=g_atr.Get(PERIOD_M5,1);
   const XAIStructureSnapshot structure=g_strategy.StructureSnapshot();
   g_position_manager.ManageAll(atr,structure);
}

void RunSignalPipeline() {
   if(!g_system_ready) return;
   if(g_recovery.IsExecutionLocked()) {
      g_log.Warning("Recovery execution lock active; NO NEW TRADE.");
      return;
   }
   MqlRates rates[];
   if(!g_market.GetRates(PERIOD_M5,160,rates)) {
      g_log.Warning("M5 rates unavailable.");
      return;
   }

   double atr=g_atr.Get(PERIOD_M5,1);
   if(atr<=0.0) {
      g_log.Warning("M5 ATR unavailable.");
      return;
   }

   if(!g_strategy.BuildStructure(rates,atr)) {
      g_log.Info("Structure not yet determinable; NO TRADE.");
      return;
   }

   XAISetupCandidate candidate;
   if(!g_strategy.Scan(rates,candidate)) {
      g_log.Info("No deterministic setup candidate; NO TRADE.");
      return;
   }

   XAIStructureSnapshot ss=g_strategy.StructureSnapshot();
   g_log.Info("Phase 4 structure="+IntegerToString((int)ss.state)+
              " score="+DoubleToString(ss.score,2)+
              " direction="+IntegerToString((int)candidate.direction)+
              " BOS(B/S)="+(g_strategy.IsBullishBOS()?"1":"0")+"/"+(g_strategy.IsBearishBOS()?"1":"0")+
              " CHoCH(B/S)="+(g_strategy.IsBullishCHoCH()?"1":"0")+"/"+(g_strategy.IsBearishCHoCH()?"1":"0")+
              " sweep(B/S)="+(g_strategy.HasBullishSweep()?"1":"0")+"/"+(g_strategy.HasBearishSweep()?"1":"0")+
              " liquidity="+IntegerToString(g_strategy.LiquidityCount()));

   SXAILiquidityLevel levels[];
   const int liquidity_count=g_strategy.LiquidityCount();
   ArrayResize(levels,liquidity_count);
   for(int i=0;i<liquidity_count;i++) levels[i]=g_strategy.Liquidity(i);

   const bool score_pass=g_score.Evaluate(
      candidate,
      rates,
      ss,
      levels,
      g_strategy.IsBullishBOS(),
      g_strategy.IsBearishBOS(),
      g_strategy.IsBullishCHoCH(),
      g_strategy.IsBearishCHoCH(),
      g_strategy.HasBullishSweep(),
      g_strategy.HasBearishSweep(),
      atr
   );

   g_log.Info("Phase 5 score="+DoubleToString(candidate.technical_score,4)+
              " trend="+DoubleToString(candidate.trend_score,3)+
              " structure="+DoubleToString(candidate.structure_score,3)+
              " liquidity="+DoubleToString(candidate.liquidity_score,3)+
              " confirmation="+DoubleToString(candidate.confirmation_score,3)+
              " momentum="+DoubleToString(candidate.momentum_score,3)+
              " volatility="+DoubleToString(candidate.volatility_score,3)+
              " rr_proxy="+DoubleToString(candidate.rr_score,3)+
              " result="+(score_pass?"PASS":"REJECT"));

   if(!score_pass) return;

   // Phase 6 constructs a real structural SL, a real liquidity target and
   // an exact RR. No order is sent at this stage.
   const double entry=(candidate.direction==XAI_DIR_BUY ? g_market.Ask() : g_market.Bid());
   if(entry<=0.0) {
      g_log.Warning("Phase 6 invalid entry price; NO TRADE.");
      return;
   }

   if(!g_sltp.Build(candidate,levels,atr,entry)) {
      g_log.Info("Phase 6 SL/TP/RR rejected candidate; NO TRADE. setup="+candidate.setup_id);
      return;
   }

   g_log.Info("Phase 6 setup="+candidate.setup_id+
              " entry="+DoubleToString(candidate.proposed_entry,_Digits)+
              " sl="+DoubleToString(candidate.proposed_sl,_Digits)+
              " tp="+DoubleToString(candidate.proposed_tp,_Digits)+
              " rr="+DoubleToString(candidate.rr_score,3)+
              " result=PASS");

   XAIRiskDecision risk=g_risk.Evaluate(candidate);
   g_log.Info("Phase 7 risk="+(risk.approved?"PASS":"REJECT")+
              " reason="+risk.reason_code+
              " risk_money="+DoubleToString(risk.risk_money,2)+
              " lot="+DoubleToString(risk.calculated_lot,2)+
              " daily_loss_pct="+DoubleToString(g_risk.CurrentDailyLossPct(),2)+
              " drawdown_pct="+DoubleToString(g_risk.CurrentDrawdownPct(),2)+
              " daily_trades="+IntegerToString(g_risk.CurrentDailyTrades())+
              " loss_streak="+IntegerToString(g_risk.CurrentLossStreak()));

   if(!risk.approved) return;

   // Phase 7 stops after local risk approval. AI and execution remain locked.
   // No order can be sent until the later execution phases are enabled.
}

void OnTick() {
   if(!g_system_ready) return;
   if(!g_market.IsValid()) return;
   ManagePositions();
   if(!IsNewBar()) return;
   RunSignalPipeline();
}

void OnTradeTransaction(const MqlTradeTransaction &trans,const MqlTradeRequest &request,const MqlTradeResult &result) {
   if(trans.symbol!=_Symbol) return;
   g_log.Trade("Trade transaction type="+IntegerToString((int)trans.type)+" retcode="+IntegerToString((int)result.retcode));
}
