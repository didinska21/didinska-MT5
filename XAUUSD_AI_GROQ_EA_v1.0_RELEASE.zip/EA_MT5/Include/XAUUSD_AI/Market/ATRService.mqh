#ifndef XAUUSD_AI_ATR_SERVICE_MQH
#define XAUUSD_AI_ATR_SERVICE_MQH

class CXAIATR {
private:
   string m_symbol;
   int m_period;
   int m_h1,m_m15,m_m5;
public:
   bool Initialize(string symbol,int period) {
      m_symbol=symbol; m_period=period;
      m_h1=iATR(symbol,PERIOD_H1,period);
      m_m15=iATR(symbol,PERIOD_M15,period);
      m_m5=iATR(symbol,PERIOD_M5,period);
      return (m_h1!=INVALID_HANDLE && m_m15!=INVALID_HANDLE && m_m5!=INVALID_HANDLE);
   }
   double Get(int handle) {
      double b[2]; ArraySetAsSeries(b,true);
      if(CopyBuffer(handle,0,1,1,b)!=1) return 0.0;
      return b[0];
   }
   double H1() { return Get(m_h1); }
   double M15() { return Get(m_m15); }
   double M5() { return Get(m_m5); }
   void Release() { if(m_h1!=INVALID_HANDLE) IndicatorRelease(m_h1); if(m_m15!=INVALID_HANDLE) IndicatorRelease(m_m15); if(m_m5!=INVALID_HANDLE) IndicatorRelease(m_m5); }
};

#endif
