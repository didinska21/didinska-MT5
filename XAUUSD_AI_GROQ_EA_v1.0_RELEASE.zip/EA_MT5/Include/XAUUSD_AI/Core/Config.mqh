#ifndef XAUUSD_AI_CONFIG_MQH
#define XAUUSD_AI_CONFIG_MQH

input group "XAI | Core"
input ulong InpMagicNumber = 26081401;
input int InpMaxDeviationPoints = 30;
input bool InpAllowLiveTrading = false;

input group "XAI | Risk"
input double InpRiskPerTradePct = 0.50;
input double InpMinimumRR = 1.50;
input double InpMaxDailyLossPct = 2.00;
input double InpMaxDrawdownPct = 10.00;
input int InpMaxOpenPositions = 1;
input int InpMaxDailyTrades = 3;
input int InpMaxConsecutiveLosses = 3;

input group "XAI | Strategy"
input int InpATRPeriod = 14;
input int InpSwingStrength = 2;
input double InpMinimumTechnicalScore = 0.70;
input double InpMinimumAIConfidence = 0.75;
input double InpSLBufferATR = 0.10;

input group "XAI | News"
input int InpNewsBeforeMinutes = 30;
input int InpNewsAfterMinutes = 30;

input group "XAI | AI Gateway"
input string InpGatewayURL = "http://127.0.0.1:8787";
input string InpGatewayToken = "CHANGE_ME";
input int InpAITimeoutMs = 12000;

#endif

input group "XAI | Phase 3 Liquidity"
input double InpEqualLiquidityTolerancePrice = 0.10;
input double InpSweepBufferPrice = 0.02;
input int InpLondonLiquidityStartHour = 8;
input int InpLondonLiquidityEndHour = 13;
input int InpNewYorkLiquidityStartHour = 13;
input int InpNewYorkLiquidityEndHour = 18;

input group "XAI | Position Management"
input bool InpEnableBreakEven = true;
input double InpBreakEvenBufferATR = 0.05;
input bool InpEnableStructureTrailing = true;
input double InpTrailingStartR = 1.50;
input double InpTrailingBufferATR = 0.10;
input bool InpManageOnlyXAIPositions = true;
