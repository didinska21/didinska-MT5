from __future__ import annotations
import os,time,threading
from dataclasses import dataclass
from app.config import settings

@dataclass
class KeyState:
    key_id:str
    secret:str
    status:str="AVAILABLE"
    last_used:float=0.0
    cooldown_until:float=0.0
    request_count:int=0
    success_count:int=0
    rate_limit_count:int=0
    error_count:int=0
    avg_latency_ms:float=0.0

class KeyManager:
    def __init__(self):
        self.lock=threading.Lock()
        self.keys={}
        for i in range(1,11):
            secret=os.getenv(f"GROQ_API_KEY_{i:02d}","").strip()
            if secret:
                self.keys[f"{i:02d}"]=KeyState(f"{i:02d}",secret)

    def _refresh(self,state):
        if state.status=="COOLDOWN" and time.time()>=state.cooldown_until:
            state.status="AVAILABLE"; state.cooldown_until=0.0

    def acquire(self):
        with self.lock:
            for s in self.keys.values(): self._refresh(s)
            available=[s for s in self.keys.values() if s.status=="AVAILABLE"]
            if not available: return None
            state=min(available,key=lambda s:s.last_used)
            state.status="IN_USE"; state.last_used=time.time(); state.request_count+=1
            return state

    def success(self,state,latency_ms:float=0.0):
        with self.lock:
            state.status="AVAILABLE"; state.success_count+=1
            if latency_ms>0:
                state.avg_latency_ms=(latency_ms if state.avg_latency_ms==0
                                      else state.avg_latency_ms*0.8+latency_ms*0.2)

    def rate_limited(self,state,retry_after=None):
        with self.lock:
            state.status="COOLDOWN"
            state.cooldown_until=time.time()+max(settings.default_cooldown,float(retry_after or 0))
            state.rate_limit_count+=1

    def failure(self,state,auth=False):
        with self.lock:
            state.status="DISABLED" if auth else "AVAILABLE"
            state.error_count+=1

    def refresh(self):
        with self.lock:
            for s in self.keys.values(): self._refresh(s)

    def available_count(self):
        self.refresh()
        return sum(s.status=="AVAILABLE" for s in self.keys.values())

    def status(self):
        self.refresh()
        return [{
            "key_id":s.key_id,"status":s.status,"last_used":s.last_used,
            "cooldown_until":s.cooldown_until,"request_count":s.request_count,
            "success_count":s.success_count,"rate_limit_count":s.rate_limit_count,
            "error_count":s.error_count,"avg_latency_ms":round(s.avg_latency_ms,2)
        } for s in self.keys.values()]

    def public_status(self):
        self.refresh()
        return {
            "total_configured":len(self.keys),
            "available":sum(s.status=="AVAILABLE" for s in self.keys.values()),
            "cooldown":sum(s.status=="COOLDOWN" for s in self.keys.values()),
            "disabled":sum(s.status=="DISABLED" for s in self.keys.values())
        }
