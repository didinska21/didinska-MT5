from __future__ import annotations
import json
import time
import httpx
from app.config import settings
from app.keys.key_manager import KeyManager, KeyState
from app.api.schemas import DecisionData

SYSTEM_PROMPT = """You are the AI validation layer of a deterministic XAUUSD MetaTrader 5 trading system.
Evaluate ONLY the supplied market context. You are NOT the risk manager and NOT the execution engine.
You cannot override risk, news, spread, drawdown, session, or broker rules.
Never invent prices, news, indicators, or missing information.
If information is contradictory, incomplete, or insufficient, return WAIT.
Return only the required JSON schema."""

RESPONSE_SCHEMA = {
    "type":"object",
    "properties":{
        "request_id":{"type":"string"},
        "decision":{"type":"string","enum":["BUY","SELL","WAIT"]},
        "confidence":{"type":"number","minimum":0,"maximum":1},
        "market_regime":{"type":"string","enum":["TRENDING","RANGING","REVERSAL","TRANSITION"]},
        "setup_quality":{"type":"number","minimum":0,"maximum":1},
        "risk_assessment":{"type":"string","enum":["LOW","NORMAL","ELEVATED","HIGH"]},
        "reason_code":{"type":"string"}
    },
    "required":["request_id","decision","confidence","market_regime",
                "setup_quality","risk_assessment","reason_code"],
    "additionalProperties":False
}

class GroqError(RuntimeError):
    def __init__(self,code,status=None,retry_after=None):
        super().__init__(code)
        self.code=code; self.status=status; self.retry_after=retry_after

class GroqClient:
    def __init__(self,key_manager:KeyManager):
        self.keys=key_manager

    def _payload(self,payload:dict)->dict:
        return {
            "model":settings.groq_model,
            "messages":[
                {"role":"system","content":SYSTEM_PROMPT},
                {"role":"user","content":json.dumps(payload,separators=(",",":"),ensure_ascii=False)}
            ],
            "temperature":0,
            "response_format":{
                "type":"json_schema",
                "json_schema":{"name":"xauusd_ai_decision","strict":True,"schema":RESPONSE_SCHEMA}
            },
            "stream":False
        }

    def decide(self,payload:dict):
        last_error=None
        for _ in range(settings.max_retries):
            key=self.keys.acquire()
            if key is None: raise RuntimeError("ALL_KEYS_UNAVAILABLE")
            started=time.perf_counter()
            try:
                with httpx.Client(timeout=settings.groq_timeout) as client:
                    response=client.post(
                        f"{settings.groq_base_url.rstrip('/')}/chat/completions",
                        headers={"Authorization":f"Bearer {key.secret}",
                                 "Content-Type":"application/json"},
                        json=self._payload(payload)
                    )
                latency=(time.perf_counter()-started)*1000
                retry_after=None
                raw=response.headers.get("retry-after")
                if raw:
                    try: retry_after=float(raw)
                    except ValueError: pass
                if response.status_code==429:
                    self.keys.rate_limited(key,retry_after); last_error="RATE_LIMITED"; continue
                if response.status_code in (401,403):
                    self.keys.failure(key,auth=True); last_error="AUTH_ERROR"; continue
                if response.status_code>=500:
                    self.keys.failure(key); last_error=f"UPSTREAM_{response.status_code}"; continue
                if response.status_code>=400:
                    self.keys.failure(key); raise GroqError("BAD_REQUEST",response.status_code)
                try:
                    body=response.json()
                    content=body["choices"][0]["message"]["content"]
                    result=DecisionData.model_validate(json.loads(content))
                except (ValueError,KeyError,IndexError,TypeError) as exc:
                    self.keys.failure(key); raise GroqError("MALFORMED_UPSTREAM") from exc
                if result.request_id!=payload["request_id"]:
                    self.keys.failure(key); last_error="REQUEST_ID_MISMATCH"; continue
                self.keys.success(key,latency)
                return result,key.key_id,latency
            except (httpx.TimeoutException,httpx.NetworkError):
                self.keys.failure(key); last_error="NETWORK_OR_TIMEOUT"; continue
            except GroqError:
                raise
        raise RuntimeError(last_error or "AI_REQUEST_FAILED")
