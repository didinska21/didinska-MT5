//+------------------------------------------------------------------+
//| EMAFilter.mqh — CEMAFilter, single EMA wrapper (any timeframe)   |
//+------------------------------------------------------------------+
#ifndef __DTE_EMAFILTER_MQH__
#define __DTE_EMAFILTER_MQH__

class CEMAFilter
  {
private:
   int    m_handle;
   string m_symbol;
   ENUM_TIMEFRAMES m_tf;
   int    m_period;

public:
   CEMAFilter() : m_handle(INVALID_HANDLE) {}

   bool Init(const string symbol,const ENUM_TIMEFRAMES tf,const int period,
             const ENUM_MA_METHOD method,const ENUM_APPLIED_PRICE price)
     {
      m_symbol=symbol;
      m_tf=tf;
      m_period=period;
      m_handle=iMA(symbol,tf,period,0,method,price);
      return(m_handle!=INVALID_HANDLE);
     }

   // shift=0 is the last CLOSED bar (index 1 on the chart) to avoid repaint on the forming bar
   bool GetValue(double &outValue,const int shift=1) const
     {
      if(m_handle==INVALID_HANDLE) return false;
      double buf[];
      ArraySetAsSeries(buf,true);
      if(CopyBuffer(m_handle,0,shift,1,buf)<=0) return false;
      outValue=buf[0];
      return true;
     }

   void Release()
     {
      if(m_handle!=INVALID_HANDLE)
        {
         IndicatorRelease(m_handle);
         m_handle=INVALID_HANDLE;
        }
     }
  };

#endif // __DTE_EMAFILTER_MQH__
