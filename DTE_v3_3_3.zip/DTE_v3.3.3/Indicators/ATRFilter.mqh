//+------------------------------------------------------------------+
//| ATRFilter.mqh — CATRFilter (unchanged from v2.x)                 |
//+------------------------------------------------------------------+
#ifndef __DTE_ATRFILTER_MQH__
#define __DTE_ATRFILTER_MQH__

#include "..\Config\Inputs.mqh"

class CATRFilter
  {
private:
   int    m_handle;
   string m_symbol;

public:
   CATRFilter() : m_handle(INVALID_HANDLE) {}

   bool Init(const string symbol,const int period)
     {
      m_symbol=symbol;
      m_handle=iATR(symbol,PERIOD_CURRENT,period);
      return(m_handle!=INVALID_HANDLE);
     }

   bool IsWithinRange() const
     {
      if(!InpUseAtrFilter) return true;
      if(m_handle==INVALID_HANDLE) return false;

      double buf[];
      ArraySetAsSeries(buf,true);
      if(CopyBuffer(m_handle,0,1,1,buf)<=0) return false;

      double atrPoints = buf[0]/SymbolInfoDouble(m_symbol,SYMBOL_POINT);
      return(atrPoints>=InpAtrMinPoints && atrPoints<=InpAtrMaxPoints);
     }

   void Release()
     {
      if(m_handle!=INVALID_HANDLE)
        {
         IndicatorRelease(m_handle);
         m_handle=INVALID_HANDLE;
        }
     }
  };

#endif // __DTE_ATRFILTER_MQH__
