DTE v3.3.2 — Execution-Safety Patch

This build is based on the DTE v3.3.1 architecture (unchanged — see below)
with two execution/tracking defects fixed, both required before baseline
Strategy Tester validation: (1) hedge close was treated as fully done as
soon as `TRADE_RETCODE_DONE_PARTIAL` came back from a close request, even
though DONE_PARTIAL means only part of the volume closed — the hedge
close path now re-verifies actual position volume and only clears
`hedgeActive`/`hedgeTicket` once that volume is confirmed zero, retrying
on a cooldown otherwise; (2) an order that executed but whose ticket
couldn't immediately be resolved was given exactly one orphan-close
attempt, and if that attempt failed the position could end up untracked —
it's now registered in a retried, cooldown-gated orphan-recovery list that
blocks new basket/recovery/hedge risk until the position is either
attached to normal tracking or verified fully closed. See
`Docs/V3.3.2_IMPLEMENTATION_NOTES.md` and `Docs/CHANGELOG.md` for full
detail. No strategy redesign, no new indicators, no changed strategy
defaults.

DTE v3.3.1 — Defect-Fix Patch

This build is based on the DTE v3.3.0 architecture (thesis-gated recovery,
equity-risk budgeting, short maximum basket lifetime, recovery timeout,
one-hedge protection with cooldown, market-closed suppression, small
basket TP, thesis invalidation, expanded forensic diagnostics) with six
verified defects fixed: a compile-blocking undefined identifier and a
missing struct field, a recovery-thesis gate that could skip M5
confirmation, a hedge risk model that couldn't recognize an opposing hedge
as protection, a spike-exit check that ran after (and so was starved by)
ordinary basket TP, unmanaged-orphan-position risk after an unresolved
order ticket, and trade execution that trusted the boolean return of
CTrade calls without checking the retcode. See `Docs/V3.3.1_IMPLEMENTATION_
NOTES.md` and `Docs/CHANGELOG.md` for full detail. No strategy redesign, no
new indicators, no changed defaults.

DTE v3.3.0 — Architecture Redesign

This build is based on the DTE v3.2.1 source and implements the v3.3.0 architecture requested by the strategy owner: thesis-gated recovery, equity-risk budgeting, short maximum basket lifetime, recovery timeout, one-hedge protection with cooldown, market-closed suppression, small basket TP, thesis invalidation, and expanded forensic diagnostics.

# Didinska Trading Engine (DTE) v3.2.1 — XAUUSD Research/Test Build

**Private use only. This is a RESEARCH build.** It is not claimed
profitable, not claimed live-ready, and the strategy is not claimed proven.
Read this file fully before attaching to any account, including the $10
experimental account.

## What's new in v3.2.1 (strict audit patch — no strategy changes)
- **Halt gate closed**: once the +900% profit-cycle target is reached
  (HALTED), no new basket, no new recovery layer, and no new hedge can
  open. Existing baskets/hedges are still safely managed and closed.
- **Flat lot integrity**: a basket's adaptive lot (0.01/0.02/0.03) is now
  truly locked for its whole lifetime — recovery layers either use that
  exact lot or are skipped, never silently downgraded to a smaller size.
- **Dashboard volume fixed**: "Volume" now reflects the basket's real flat
  lot × layer count, matching the "Adaptive Lot" block instead of
  contradicting it.
- **Profit-cycle progress fixed**: the dashboard now shows 0% at the
  baseline and 100% at the target (was previously non-zero at the
  baseline). Display only — the actual halt trigger is unchanged.

See `CHANGELOG.md` for full technical detail. This was a surgical patch —
strategy logic (H1→M15→M5, confluence, BOS/CHOCH, Fib/QM, ATR layering,
hedge, news/spread/session filters, basket TP, spike exit, persistence,
account validation, close-safety) is unchanged from v3.2.0.

## What's new in v3.2.0
- **Profit target is now a full lifecycle**, not a one-shot halt: ACTIVE →
  target reached → HALTED → manual reset (chart button) → new baseline →
  ACTIVE again, with a persisted cycle ID. See "Profit cycle" below.
- **Adaptive base lot** (0.01-0.03) computed from account capacity, not
  from trade outcome — see "Adaptive lot" below. Everything else (H1→M15→
  M5, confluence scoring, sequential layering, hedge, sessions, news,
  spread filter, position tracking, diagnostics) is unchanged from v3.1.0.

## Requirements
- **Hedging account.** DTE will refuse to initialize on a netting account
  (see `CAccountValidator`).
- Symbol: designed for XAUUSD. Timeframes are explicit inputs (H1/M15/M5 by
  default) and are independent of the chart timeframe the EA is attached to.

## Profit cycle
The dashboard shows a `PROFIT CYCLE` block: baseline, target %, target
balance, current balance, progress %, status (ACTIVE/HALTED), and cycle ID.
When halted, click the **RESET PROFIT TARGET** button on the chart twice
(first click arms it — button relabels `CONFIRM RESET?` — second click
within `InpResetConfirmSeconds` confirms). Reset is refused with
`RESET DENIED — ACTIVE BASKET EXISTS` if a basket is currently open. A
restart, recompile, timeframe/symbol change, or reconnect never resets the
cycle — only the confirmed button action does.

## Adaptive lot
DTE picks the largest of `InpBaseLot..InpMaxLotPerLayer` (stepped by
`InpAdaptiveLotStep`, default 0.01/0.02/0.03) whose **projected full
6-layer basket margin** still fits within `InpMaxBasketMarginPercent` of
current equity — not just what layer 1 alone would need. On a very small
account this normally resolves to 0.01, and DTE may still end up opening
only 1-2 real layers (the per-layer margin check is the actual real-time
safety net, unchanged from v3.1.0). The selected lot is fixed for the
whole basket's lifetime (flat across all layers — no martingale
progression). See the dashboard's `Adaptive Lot` block and the
`DTE ADAPTIVE LOT` log line at every basket open for the reasoning.

## Strategy summary
1. **H1 bias** (EMA20/50 gap scaled by ATR → NEUTRAL/BULL/STRONG_BULL/BEAR/
   STRONG_BEAR).
2. **M15 structure** (fractal-swing BOS/CHOCH heuristic — see scope note
   below).
3. **M5 trigger + confluence score** (structure break, Fib 50/61.8 proximity,
   a simplified Quasimodo retest, EMA alignment). A candidate direction only
   becomes a trade if its score meets `InpMinConfluenceScore`.
4. **Layer 1** opens on a passing trigger, at the adaptive base lot.
   **Layers 2-6** are added one at a time, at the SAME flat lot, only once
   price has moved against the basket by an ATR+structure-based distance,
   the thesis is still valid, margin allows it, and no news lock is active.
   `InpMaxLayers` is a cap, not a target.
5. **Hedge**: opened only on a genuine opposing CHOCH (not merely because
   the basket is losing), closed once that opposing structure fades.
6. **Basket exit**: net-profit take-profit (`InpBasketTpPercent` of
   cycle-start balance) or an optional favorable-spike early exit.
7. **900% profit-cycle target**: persists across restarts; manual reset
   only, via the dashboard button.

## Scope disclosures — read this before trusting the signals
- **Structure engine is simplified.** `CStructureEngine` uses classic 2-bar
  fractal swing detection and simple HH/HL vs LH/LL sequencing to derive
  BOS/CHOCH. This is a practical heuristic, not a rigorous Smart-Money-
  Concepts implementation. The "Quasimodo" check is a light retest-of-
  broken-level pattern, not a strict 4-point QM detector.
- **Commission in basket net-P/L is best-effort.** Entry-side commission
  already charged is summed from deal history; exit-side commission is
  unknown until a position actually closes.
- **News filter depends on the MQL5 Calendar API** being populated for your
  broker/terminal build. Behavior inside the Strategy Tester depends on
  that build's calendar emulation — verify it's actually firing before
  relying on it in a backtest.
- **No hard drawdown stop in this version**, by explicit design (this is a
  research build — see CHANGELOG section on v3.1.0). Statistics are
  recorded (`maxEquityDrawdownPct`, etc.) for later audit, but nothing
  forces a close based on them.

## Inputs
See `Config/Inputs.mqh` — grouped as Strategy / Recovery / Lot / Basket /
Hedge / Sessions / News / Spread / ATR / Margin Safety / Target /
Statistics / Misc, matching the specification's section 29 grouping.

## Persistence
GlobalVariable keys are namespaced
`DTE_<accountLogin>_<symbol>_<magic>_v<DTE_STATE_VERSION>_...` so two DTE
instances never collide. Basket state, the 900% target baseline, and the
halted flag all survive terminal/EA/VPS restart.

## Acceptance-criteria test notes
See the delivery report for how each of the 12 acceptance tests in the
specification was implemented and what could/couldn't be verified without
a live MetaEditor compiler in this environment.

## Version history
See `CHANGELOG.md`.
