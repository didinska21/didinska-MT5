//+------------------------------------------------------------------+
//| Inputs.mqh                                                       |
//| Didinska Trading Engine (DTE) v3.3.2                              |
//| Execution-Safety Patch — hedge partial-close tracking +          |
//| orphan-position recovery state machine                            |
//+------------------------------------------------------------------+
#ifndef __DTE_INPUTS_MQH__
#define __DTE_INPUTS_MQH__

#define DTE_VERSION "3.3.3"
#define DTE_BUILD   "004"
// v3.3.2: new fields added to SBasketState (hedgeCloseState/hedgeRemainingVolume/
// hedgeCloseRetryTime) are all read with GlobalVariableCheck(...)-guarded defaults
// in RestorePersistedState() (same backward-compatible pattern already used for
// selectedBaseLot/lastLayerPrice etc.) — no persisted-layout break, so
// DTE_STATE_VERSION is unchanged.
// v3.3.3: EXPECTANCY / RECOVERY BALANCE PATCH. No new SBasketState fields —
// only new in-memory throttling state inside CPositionManager (not persisted)
// and new SForensicCounters fields (see below), so DTE_STATE_VERSION is again
// unchanged — existing persisted baskets restore exactly as before.
#define DTE_STATE_VERSION 3

//====================================================================
// STRATEGY — timeframes are EXPLICIT, never PERIOD_CURRENT (section 4)
//====================================================================
input group "=== Strategy: Timeframes & Trend ==="
input ENUM_TIMEFRAMES InpTfBias    = PERIOD_H1;  // primary trend
input ENUM_TIMEFRAMES InpTfStruct  = PERIOD_M15; // structure / confirmation
input ENUM_TIMEFRAMES InpTfTrigger = PERIOD_M5;  // entry trigger
input int    InpEmaFastPeriod      = 20;
input int    InpEmaSlowPeriod      = 50;
input ENUM_MA_METHOD    InpEmaMethod = MODE_EMA;
input ENUM_APPLIED_PRICE InpEmaPrice = PRICE_CLOSE;

input group "=== Strategy: Confluence Scoring ==="
input int    InpMinConfluenceScore   = 3;  // min confluence "points" required to allow an entry
input int    InpRecoveryMinConfluenceScore = 2; // fresh confirmation required for recovery
input bool   InpRequireM5Trigger      = true;  // every entry/recovery must have M5 trigger confirmation
input bool   InpUseFibConfluence     = true;
input bool   InpUseStructureConfluence = true; // BOS/CHOCH heuristic
input bool   InpUseQmConfluence      = true;   // simplified Quasimodo heuristic
input bool   InpUseEmaConfluence     = true;
input double InpFibProximityAtrMult  = 0.35;   // "near fib level" tolerance, in ATR(M5) units

//====================================================================
// RECOVERY / LAYERING
//====================================================================
input group "=== Recovery / Layering ==="
input bool   InpRecoveryEnable      = true;
input int    InpMaxLayers           = 6;      // hard cap, NOT a forced target (section 1/10)
input double InpLayerAtrMultiplier  = 1.2;    // LayerDistance = ATR(M5) * this
input double InpMinLayerDistancePoints = 150.0; // additional floor, in points, after ATR calc
input int    InpAtrPeriodLayer      = 14;
input int    InpRecoveryTimeoutMinutes = 180; // after this, no new recovery layers
input int    InpMaxBasketHoldMinutes   = 720; // 12h default hard basket lifetime
input int    InpThesisInvalidationGraceMinutes = 30; // protection grace before forced exit
input double InpRecoveryRiskAtrMultiple = 2.0; // projected adverse move for equity-risk check

//====================================================================
// LOT MANAGEMENT (section 14, v3.1) — extended v3.2.0 with adaptive
// capacity model (section 10-19 of the v3.2.0 spec)
//====================================================================
input group "=== Lot Management ==="
input double InpBaseLot             = 0.01;  // floor of the adaptive range
input double InpMaxLotPerLayer      = 0.03;  // hard ceiling — absolute max, never exceeded
input double InpAdaptiveLotStep     = 0.01;  // candidate step between InpBaseLot..InpMaxLotPerLayer
input double InpMaxBasketMarginPercent = 15.0; // capacity model: max % of equity allocated to a full (maxLayers) basket
input double InpMarginSafetyBufferPct = 30.0;
input double InpMaxBasketEquityRiskPercent = 15.0; // preferred risk budget
input double InpHardBasketEquityRiskPercent = 20.0; // absolute ceiling
input double InpRiskSpreadSlippagePercent = 5.0; // buffer added to projected loss // extra safety margin required beyond broker minimum, per layer

//====================================================================
// PROFIT TARGET LIFECYCLE (v3.2.0) — persistent, cycle-based, manual reset
//====================================================================
input group "=== Profit Target Lifecycle ==="
input bool   InpTargetEnable            = true;
input double InpProfitTargetMultiplier  = 10.0; // 10.0x = 900% profit halt (target = baseline * this)
input int    InpResetConfirmSeconds     = 10;   // reset button: second click must occur within this window

//====================================================================
// BASKET TAKE PROFIT / SPIKE EXIT (section 15/16)
//====================================================================
input group "=== Basket Management ==="
input double InpBasketTpPercent      = 0.20;  // small scalping target: 0.20% of basket-start balance  // % of cycle-start balance, net basket profit
input bool   InpUseSpikeExit         = true;
input double InpSpikeExitMinPercent  = 0.25;  // basket must already be at least this profitable...
input double InpSpikeExitTriggerPoints = 300.0; // ...and move favorably by this many points within the window
input int    InpSpikeExitWindowSeconds = 60;
input double InpSpikeExitMinAtrMultiple = 0.75;

//====================================================================
// HEDGE (section 13)
//====================================================================
input group "=== Hedge ==="
input bool   InpHedgeEnable          = true;
input double InpHedgeLot             = 0.01;
input double InpHedgeMinStructureScore = 2;
input int    InpHedgeCooldownMinutes = 60;
input double InpHedgeMaxLot = 0.01; // minimum opposing-structure score required to arm a hedge

//====================================================================
// SESSIONS (section 21) — times in broker/server time, 0-23
//====================================================================
input group "=== Sessions ==="
input bool InpSessionUseFilter = true;
input bool InpSessionAsiaEnable   = true;
input int  InpSessionAsiaStart    = 0;
input int  InpSessionAsiaEnd      = 8;
input bool InpSessionLondonEnable = true;
input int  InpSessionLondonStart  = 8;
input int  InpSessionLondonEnd    = 16;
input bool InpSessionNyEnable     = true;
input int  InpSessionNyStart      = 13;
input int  InpSessionNyEnd        = 21;
input bool   InpTradeMonday        = true;
input bool   InpTradeTuesday       = true;
input bool   InpTradeWednesday     = true;
input bool   InpTradeThursday      = true;
input bool   InpTradeFriday        = true;

//====================================================================
// NEWS (section 22)
//====================================================================
input group "=== News Filter ==="
input bool InpNewsFilterEnable        = true;
input ENUM_CALENDAR_EVENT_IMPORTANCE InpNewsMinImportance = CALENDAR_IMPORTANCE_HIGH;
input int  InpNewsLockMinutesBefore   = 30;
input int  InpNewsLockMinutesAfter    = 15;
input int  InpNewsStabilizeMinutes    = 15; // after the lock window, wait this long before trusting new signals again

//====================================================================
// SPREAD FILTER (section 23)
//====================================================================
input group "=== Spread Filter ==="
input bool   InpUseSpreadFilter    = true;
input double InpMaxSpreadPoints    = 350.0;

//====================================================================
// ATR FILTER (pre-entry gate, unchanged concept from v3.0.x)
//====================================================================
input group "=== ATR Filter ==="
input bool   InpUseAtrFilter       = true;
input int    InpAtrPeriod          = 14;
input double InpAtrMinPoints       = 50.0;
input double InpAtrMaxPoints       = 4000.0;

//====================================================================
// MARGIN SAFETY (section 24)
//====================================================================
input group "=== Margin Safety ==="
input double InpMinFreeMarginPercent = 100.0;
input int    InpMarketClosedCooldownSeconds = 300; // required margin level % to allow a new layer

//====================================================================
// EXECUTION SAFETY (v3.3.2) — controlled-retry cooldowns for the two
// execution/tracking fixes in this patch. Neither changes strategy
// behavior; both only pace how often the EA re-attempts verifying/closing
// a not-yet-confirmed hedge partial-close or orphan position.
//====================================================================
input group "=== Execution Safety (v3.3.2) ==="
input int InpHedgeCloseRetrySeconds  = 5;  // cooldown between hedge partial-close retry attempts
input int InpOrphanCloseRetrySeconds = 10; // cooldown between orphan-position close retry attempts

//====================================================================
// STATISTICS ONLY — no hard drawdown stop in this version (section 25/26)
//====================================================================
input group "=== Statistics (no hard DD stop this version) ==="
input bool InpRecordDrawdownStats = true;

//====================================================================
// MISC
//====================================================================
input group "=== Misc ==="
input long   InpMagicNumber      = 330001;
input string InpTradeComment     = "DTE_v330";
input int    InpSlippagePoints   = 50;

//====================================================================
// ENUMS
//====================================================================
enum ENUM_CYCLE_DIRECTION
  {
   CYCLE_NONE = 0,
   CYCLE_BUY  = 1,
   CYCLE_SELL = 2
  };

enum ENUM_MARKET_BIAS
  {
   BIAS_STRONG_BEAR = -2,
   BIAS_BEAR        = -1,
   BIAS_NEUTRAL      = 0,
   BIAS_BULL         = 1,
   BIAS_STRONG_BULL  = 2
  };

enum ENUM_STRUCT_STATE
  {
   STRUCT_UNKNOWN   = 0,
   STRUCT_BULLISH   = 1, // HH/HL sequence
   STRUCT_BEARISH   = 2, // LH/LL sequence
   STRUCT_BOS_UP    = 3,
   STRUCT_BOS_DOWN  = 4,
   STRUCT_CHOCH_UP  = 5, // reversal signal turning bullish
   STRUCT_CHOCH_DOWN= 6  // reversal signal turning bearish
  };

enum ENUM_HEDGE_STATE
  {
   HEDGE_NORMAL         = 0,
   HEDGE_RECOVERY       = 1,
   HEDGE_REVERSAL_RISK  = 2,
   HEDGE_ACTIVE         = 3,
   HEDGE_BASKET_EXIT    = 4
  };

enum ENUM_MARKET_REGIME
  {
   REGIME_NO_TRADE = 0,
   REGIME_BULLISH_TREND = 1,
   REGIME_BEARISH_TREND = 2,
   REGIME_SIDEWAYS = 3,
   REGIME_HIGH_VOLATILITY = 4
  };

// v3.3.3 — PATCH OBJECTIVE #1: classifies an adverse move against an open
// basket BEFORE any recovery decision is made, so recovery can distinguish
// a genuine continuation (do not recover) from a retracement/pullback
// (preferred recovery scenario) or a sideways range (conservative recovery
// only). Existing concepts only (H1 bias, M15 BOS/CHOCH, M5 momentum) — no
// new indicators.
enum ENUM_ADVERSE_CLASSIFICATION
  {
   ADVERSE_NONE         = 0, // not evaluated / invalid direction
   ADVERSE_CONTINUATION = 1, // strong continuation against the basket — NO recovery
   ADVERSE_RETRACEMENT  = 2, // pullback with H1/M15 still compatible — preferred recovery
   ADVERSE_RANGE        = 3  // sideways/range — conservative recovery only
  };

enum ENUM_BASKET_STATE
  {
   BSTATE_IDLE = 0,
   BSTATE_ENTRY_ARMED = 1,
   BSTATE_ACTIVE = 2,
   BSTATE_RECOVERY_EVALUATION = 3,
   BSTATE_RECOVERY_ACTIVE = 4,
   BSTATE_THESIS_INVALIDATED = 5,
   BSTATE_HEDGE_ACTIVE = 6,
   BSTATE_EXIT_PENDING = 7,
   BSTATE_CLOSING = 8,
   BSTATE_HALTED = 9,
   BSTATE_CLOSED = 10,
   BSTATE_ORPHAN_RECOVERY = 11 // v3.3.2: a recovery-layer or hedge order executed but
                                // could not be attached to tracking — blocks new
                                // recovery/hedge until the orphan is confirmed closed
                                // or successfully attached. Appended at the end so
                                // persisted int values from older versions never collide.
  };

enum ENUM_HALT_CAUSE
  {
   HALT_NONE = 0,
   HALT_PROFIT_TARGET    = 3,
   HALT_ACCOUNT_TYPE     = 5 // netting account — hard init failure, not a runtime halt, kept for dashboard reuse
  };

enum ENUM_BASKET_CLOSE_REASON
  {
   CLOSE_NONE           = 0,
   CLOSE_TP             = 1,
   CLOSE_SPIKE_EXIT      = 2,
   CLOSE_MARGIN_CALL_EXT = 3,
   CLOSE_HEDGE_EXIT      = 4,
    CLOSE_MAX_HOLD          = 5,
    CLOSE_RECOVERY_TIMEOUT  = 6,
    CLOSE_THESIS_INVALID    = 7,
    CLOSE_RISK_LIMIT        = 8
  };

enum ENUM_SESSION_NAME
  {
   SESSION_NONE=0, SESSION_ASIA=1, SESSION_LONDON=2, SESSION_NY=3, SESSION_OVERLAP=4
  };

// v3.3.2 — issue #1 fix: hedge close is no longer a single boolean flip.
// TRADE_RETCODE_DONE_PARTIAL must never be treated as "hedge is gone".
enum ENUM_HEDGE_CLOSE_STATE
  {
   HEDGE_CLOSE_NONE    = 0, // no close in progress — hedge (if active) is fully open, untouched
   HEDGE_CLOSE_PARTIAL = 1  // a close was requested/attempted but confirmed remaining volume > 0;
                             // hedgeActive/hedgeTicket MUST stay set until this returns to NONE
                             // (via FinalizeHedgeClosed(), only once actual volume reaches 0)
  };

//====================================================================
// DTOs
//====================================================================

struct SConfluenceResult
  {
   int    score;
   bool   passed;
   ENUM_MARKET_BIAS  h1Bias;
   ENUM_STRUCT_STATE m15Structure;
   bool   fibHit;
   bool   qmHit;
   bool   emaHit;
   ENUM_CYCLE_DIRECTION direction;
   // v3.3.1 PATCH P1: these two fields were referenced by ConfluenceEngine
   // (r.m5Trigger / r.regime), PositionManager (fresh.m5Trigger), and
   // DiagnosticEngine (conf.m5Trigger / conf.regime) in v3.3.0 but were
   // never declared here — a compile-blocking undefined-member error.
   bool               m5Trigger;
   ENUM_MARKET_REGIME regime;
  };

struct SBasketState
  {
   bool                 active;
   ENUM_CYCLE_DIRECTION direction;
   int                  layersOpen;
   double               cycleStartBalance;
   double               basketFloatingProfit; // net: profit+swap+commission
   double               basketTpTarget;       // absolute currency value
   datetime             cycleStartTime;
   double               lastLayerPrice;
   ENUM_HEDGE_STATE     hedgeState;
   bool                 hedgeActive;
   ulong                hedgeTicket;
   double               peakFloatingProfit;   // for spike-exit window tracking
   datetime             peakFloatingTime;
   double               selectedBaseLot;
    ENUM_BASKET_STATE    state;
    datetime             recoveryStartTime;
    datetime             lastHedgeCloseTime;
    datetime             thesisInvalidatedTime;
    double               maxBasketRiskPct;      // v3.2.0: adaptive lot, fixed for this basket's whole lifetime (flat across layers)
    // v3.3.2 — issue #1: hedge close is tracked as a verified state machine,
    // never inferred from CTrade's boolean/DONE_PARTIAL return alone.
    ENUM_HEDGE_CLOSE_STATE hedgeCloseState;
    double               hedgeRemainingVolume; // last verified remaining volume while HEDGE_CLOSE_PARTIAL
    datetime             hedgeCloseRetryTime;  // cooldown gate — do not retry the close every tick
  };

struct SDiagnosticSnapshot
  {
   ENUM_MARKET_BIAS  h1Bias;
   ENUM_STRUCT_STATE m15Structure;
   ENUM_CYCLE_DIRECTION m5Signal;
   SBasketState      basket;
   bool              haltActive;
   ENUM_HALT_CAUSE   haltCause;
   double            sessionStartBalance;
   double            currentEquity;
   double            profitTargetProgressPct;
   bool              sessionOk;
   bool              spreadOk;
   bool              atrOk;
   bool              marginOk;
   bool              newsLockActive;
   ENUM_SESSION_NAME currentSession;
   string            lastEntryReason;
   string            lastCloseReason;
   double            currentDrawdownPct;
   // v3.2.0: profit-cycle lifecycle
   ulong             profitCycleId;
   double            profitCycleBaseline;
   double            profitCycleTargetBalance;
   double            currentBalance;
   string            resetStatusMessage; // transient — set after a reset attempt, empty otherwise
   // v3.2.0: adaptive lot info
   double            adaptiveLotLastSelected;
   double            adaptiveMarginCapacityPct;
   double            adaptiveEstSixLayerExposureLots;
   // v3.3.2 — issue #2 visibility: how many orphan positions are currently
   // being tracked/retried (0 in normal operation).
   int               pendingOrphanCount;
  };

struct SForensicCounters
  {
   long basketsOpened;
   long basketsClosedByTp;
   long basketsClosedBySpike;
   long basketsClosedByMarginCall;
   long basketsClosedByHedgeExit;

   long layersPerBasketMin;
   long layersPerBasketMax;
   long layersPerBasketSum;

   long basketHoldSecondsMin;
   long basketHoldSecondsMax;
   long basketHoldSecondsSum;

   long cycleDirectionBuy;
   long cycleDirectionSell;

   long confluencePassCount;
   long confluenceRejectCount;

   long layersSkippedMargin;
   long entriesSkippedSpread;
   long entriesSkippedSession;
   long entriesSkippedNews;
   long entriesSkippedDuplicateSignal;
   long entriesSkippedInvalidThesis;

   long recoveryAccepted;
    long recoveryRejected;
    long thesisInvalidations;
    long maxHoldExits;
    long recoveryTimeoutExits;
    long basketRiskRejected;
    long marketClosedEvents;
    long hedgeRejected;
    long hedgeCooldownRejected;
    long hedgeEventsOpened;
   long hedgeEventsClosed;

   long profitTargetHaltEvents;
   long closeVerifyRetries;
   long closeVerifyFailures;

   double maxEquityDrawdownPct;
   double maxBalanceDrawdownPct;
   double maxFloatingLoss;
   double maxBasketLoss;
   double maxBasketRiskPct;
   long   maxLayerCountSeen;
   long   longestRecoverySeconds;
   double maxMarginUsagePct;

   // v3.3.3 PATCH OBJECTIVE #6 — LOSS ANATOMY. Indexed by ENUM_LOSS_EXIT_REASON
   // (below). Only accumulated for baskets that closed at a net loss
   // (finalized basketFloatingProfit < 0). Answers "which exit mechanism
   // creates the large losing trades?".
   long   lossExitCount[6];
   double lossExitTotal[6];      // sum of losses (positive magnitude) per reason
   double lossExitLargest[6];    // largest single loss (positive magnitude) per reason
   long   lossExitHoldSum[6];    // seconds, for average-hold-by-reason
   long   lossExitHoldMax[6];

   // v3.3.3 PATCH OBJECTIVE #9 — SPIKE EXIT DIAGNOSTICS.
   long spikeEvaluationCount;   // CheckSpikeExit() called
   long spikeCandidateCount;    // basket already met the profit floor
   long spikeAcceptedCount;     // spike exit actually triggered
   long spikeRejectedByProfit;  // floor not met
   long spikeRejectedByMove;    // profit floor met, favorable move too small
   long spikeRejectedByAtr;     // profit floor met, ATR-scaled threshold not cleared
   long spikeRejectedByWindow;  // no usable M1 bar in the lookback window
  };

// v3.3.3 — indices into SForensicCounters.lossExit*[] arrays. Kept separate
// from ENUM_BASKET_CLOSE_REASON so the loss-anatomy buckets stay a small,
// stable, print-friendly set even as close reasons evolve.
enum ENUM_LOSS_EXIT_REASON
  {
   LOSS_EXIT_MAXHOLD          = 0,
   LOSS_EXIT_THESIS_INVALID   = 1,
   LOSS_EXIT_RECOVERY_TIMEOUT = 2,
   LOSS_EXIT_BASKET_TP        = 3, // included for completeness/audit only — a TP close
                                    // (floating >= tpTarget > 0) should never be negative;
                                    // a non-zero count here would itself be a red flag.
   LOSS_EXIT_SPIKE            = 4,
   LOSS_EXIT_OTHER            = 5  // margin-call/external, hedge-exit, risk-limit, unknown
  };

#endif // __DTE_INPUTS_MQH__
