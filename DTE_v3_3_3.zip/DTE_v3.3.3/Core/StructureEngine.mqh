//+------------------------------------------------------------------+
//| StructureEngine.mqh — CStructureEngine                            |
//| v3.1.0                                                             |
//|                                                                     |
//| IMPORTANT — SCOPE DISCLOSURE:                                      |
//| This is a PRACTICAL, SIMPLIFIED market-structure engine, not a     |
//| full Smart-Money-Concepts library. It uses classic 2-bar fractal   |
//| swing detection to find recent swing highs/lows, derives a         |
//| bullish/bearish structure bias from HH/HL vs LH/LL sequencing,     |
//| flags a Break-of-Structure (BOS) when price closes beyond the      |
//| relevant swing point, and treats a BOS that runs counter to the    |
//| prevailing structure as a Change-of-Character (CHOCH). The         |
//| "Quasimodo" (QM) heuristic below is a light pattern check (retest  |
//| of a freshly-broken swing level after a CHOCH) — NOT a rigorous    |
//| 4-point QM pattern detector. Treat all of this as one input among  |
//| several in the confluence score, not as ground truth.              |
//+------------------------------------------------------------------+
#ifndef __DTE_STRUCTUREENGINE_MQH__
#define __DTE_STRUCTUREENGINE_MQH__

#include "..\Config\Inputs.mqh"

struct SStructureAnalysis
  {
   ENUM_STRUCT_STATE state;
   double            lastSwingHigh;
   double            lastSwingLow;
   double            priorSwingHigh;
   double            priorSwingLow;
   datetime          lastSwingHighTime;
   datetime          lastSwingLowTime;
   bool              valid;
  };

class CStructureEngine
  {
private:
   string m_symbol;

   // 2-bar fractal: bar i is a swing high if its high is >= the 2 bars each side.
   bool IsFractalHigh(const double &highs[],const int i,const int total) const
     {
      if(i<2 || i>total-3) return false;
      return(highs[i]>=highs[i-1] && highs[i]>=highs[i-2] &&
             highs[i]>=highs[i+1] && highs[i]>=highs[i+2]);
     }

   bool IsFractalLow(const double &lows[],const int i,const int total) const
     {
      if(i<2 || i>total-3) return false;
      return(lows[i]<=lows[i-1] && lows[i]<=lows[i-2] &&
             lows[i]<=lows[i+1] && lows[i]<=lows[i+2]);
     }

public:
   void Init(const string symbol) { m_symbol=symbol; }

   SStructureAnalysis Analyze(const ENUM_TIMEFRAMES tf,const int barsToScan=150) const
     {
      SStructureAnalysis res;
      ZeroMemory(res);
      res.state=STRUCT_UNKNOWN;
      res.valid=false;

      MqlRates rates[];
      ArraySetAsSeries(rates,true);
      int copied=CopyRates(m_symbol,tf,1,barsToScan,rates); // shift 1 = skip forming bar
      if(copied<10) return res; // not enough data

      double highs[],lows[];
      ArrayResize(highs,copied);
      ArrayResize(lows,copied);
      for(int i=0;i<copied;i++) { highs[i]=rates[i].high; lows[i]=rates[i].low; }
      // rates[] is time-descending (index 0 = most recent closed bar). Fractal
      // check needs chronological order, so we index from the "oldest" end.
      // Convert conceptually: position p (chronological) = copied-1-i (series index).

      double swingHighs[]; datetime swingHighTimes[];
      double swingLows[];  datetime swingLowTimes[];
      ArrayResize(swingHighs,0); ArrayResize(swingHighTimes,0);
      ArrayResize(swingLows,0);  ArrayResize(swingLowTimes,0);

      // Reverse arrays to chronological order for straightforward fractal scanning.
      double chronoHigh[],chronoLow[]; datetime chronoTime[];
      ArrayResize(chronoHigh,copied); ArrayResize(chronoLow,copied); ArrayResize(chronoTime,copied);
      for(int i=0;i<copied;i++)
        {
         chronoHigh[i]=rates[copied-1-i].high;
         chronoLow[i]=rates[copied-1-i].low;
         chronoTime[i]=rates[copied-1-i].time;
        }

      for(int i=2;i<copied-2;i++)
        {
         if(IsFractalHigh(chronoHigh,i,copied))
           {
            int n=ArraySize(swingHighs);
            ArrayResize(swingHighs,n+1); ArrayResize(swingHighTimes,n+1);
            swingHighs[n]=chronoHigh[i]; swingHighTimes[n]=chronoTime[i];
           }
         if(IsFractalLow(chronoLow,i,copied))
           {
            int n=ArraySize(swingLows);
            ArrayResize(swingLows,n+1); ArrayResize(swingLowTimes,n+1);
            swingLows[n]=chronoLow[i]; swingLowTimes[n]=chronoTime[i];
           }
        }

      int nh=ArraySize(swingHighs), nl=ArraySize(swingLows);
      if(nh<2 || nl<2) return res; // not enough confirmed swings yet

      res.lastSwingHigh=swingHighs[nh-1];
      res.priorSwingHigh=swingHighs[nh-2];
      res.lastSwingLow=swingLows[nl-1];
      res.priorSwingLow=swingLows[nl-2];
      res.lastSwingHighTime=swingHighTimes[nh-1];
      res.lastSwingLowTime=swingLowTimes[nl-1];
      res.valid=true;

      ENUM_STRUCT_STATE prevailingBias=STRUCT_UNKNOWN;
      if(res.lastSwingHigh>res.priorSwingHigh && res.lastSwingLow>res.priorSwingLow)
         prevailingBias=STRUCT_BULLISH;
      else if(res.lastSwingHigh<res.priorSwingHigh && res.lastSwingLow<res.priorSwingLow)
         prevailingBias=STRUCT_BEARISH;

      double lastClose=rates[0].close; // most recent closed bar
      if(lastClose>res.lastSwingHigh)
         res.state = (prevailingBias==STRUCT_BEARISH) ? STRUCT_CHOCH_UP : STRUCT_BOS_UP;
      else if(lastClose<res.lastSwingLow)
         res.state = (prevailingBias==STRUCT_BULLISH) ? STRUCT_CHOCH_DOWN : STRUCT_BOS_DOWN;
      else
         res.state = prevailingBias;

      return res;
     }

   // Simplified QM heuristic: price broke structure (CHOCH) and is now
   // retesting the broken swing level (which flipped role: former resistance
   // acting as support, or vice versa) within an ATR-based tolerance.
   bool CheckQuasimodoRetest(const SStructureAnalysis &a,const double currentPrice,
                              const double tolerance,ENUM_CYCLE_DIRECTION &outDir) const
     {
      outDir=CYCLE_NONE;
      if(!a.valid) return false;

      if(a.state==STRUCT_CHOCH_UP)
        {
         if(MathAbs(currentPrice-a.lastSwingHigh)<=tolerance)
           {
            outDir=CYCLE_BUY;
            return true;
           }
        }
      else if(a.state==STRUCT_CHOCH_DOWN)
        {
         if(MathAbs(currentPrice-a.lastSwingLow)<=tolerance)
           {
            outDir=CYCLE_SELL;
            return true;
           }
        }
      return false;
     }

   // Fib retracement of the most recent swing leg (priorSwing -> lastSwing on
   // the trending side), returns 50%/61.8% levels of that leg.
   bool GetFibLevels(const SStructureAnalysis &a,double &fib50,double &fib618) const
     {
      if(!a.valid) return false;

      double legHigh,legLow;
      if(a.state==STRUCT_BULLISH || a.state==STRUCT_BOS_UP || a.state==STRUCT_CHOCH_UP)
        {
         legLow=a.lastSwingLow;
         legHigh=a.lastSwingHigh;
        }
      else if(a.state==STRUCT_BEARISH || a.state==STRUCT_BOS_DOWN || a.state==STRUCT_CHOCH_DOWN)
        {
         legLow=a.lastSwingLow;
         legHigh=a.lastSwingHigh;
        }
      else
         return false;

      double range=legHigh-legLow;
      if(range<=0.0) return false;

      // Retracement measured from the most recent extreme back toward the prior one.
      bool bullishLeg=(a.state==STRUCT_BULLISH || a.state==STRUCT_BOS_UP || a.state==STRUCT_CHOCH_UP);
      if(bullishLeg)
        {
         fib50 = legHigh - range*0.50;
         fib618= legHigh - range*0.618;
        }
      else
        {
         fib50 = legLow + range*0.50;
         fib618= legLow + range*0.618;
        }
      return true;
     }
  };

#endif // __DTE_STRUCTUREENGINE_MQH__
