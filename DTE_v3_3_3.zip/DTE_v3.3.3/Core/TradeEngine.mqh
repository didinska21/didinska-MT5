//+------------------------------------------------------------------+
//| TradeEngine.mqh — CTradeEngine, wraps CTrade                      |
//+------------------------------------------------------------------+
#ifndef __DTE_TRADEENGINE_MQH__
#define __DTE_TRADEENGINE_MQH__

#include <Trade\Trade.mqh>
#include "..\Config\Inputs.mqh"
#include "Logger.mqh"

class CTradeEngine
  {
private:
   CTrade m_trade;
   string m_symbol;
   datetime m_marketClosedUntil;
   bool     m_lastMarketClosedEvent;
   uint     m_lastCloseRetcode; // v3.3.2: exposed so callers can log the real retcode
                                // on a partial/failed close without re-deriving it

public:
   CTradeEngine() : m_marketClosedUntil(0), m_lastMarketClosedEvent(false), m_lastCloseRetcode(0) {}

   bool Init(const string symbol,const long magic)
     {
      m_symbol=symbol;
      m_marketClosedUntil=0;
      m_lastMarketClosedEvent=false;
      m_trade.SetExpertMagicNumber(magic);
      m_trade.SetTypeFillingBySymbol(symbol);
      m_trade.SetDeviationInPoints(InpSlippagePoints);
      return true;
     }

   // NO stop-loss / take-profit set on individual layers — by design.
   // v3.1: comment carries the basket ID so CPositionManager can identify
   // positions unambiguously by symbol+magic+comment (section 18), not just
   // by scanning newest position time.
   bool OpenMarket(const ENUM_CYCLE_DIRECTION dir,const double lot,const string comment,
                   ulong &outPositionTicket,string &errorOut)
     {
      errorOut="";
      outPositionTicket=0;
      m_lastMarketClosedEvent=false;

      if(m_marketClosedUntil>0 && TimeCurrent()<m_marketClosedUntil)
        {
         errorOut=StringFormat("market-closed cooldown active until %s",
                               TimeToString(m_marketClosedUntil));
         return false;
        }

      bool ok=false;
      double price=0.0;

      if(dir==CYCLE_BUY)
        {
         price=SymbolInfoDouble(m_symbol,SYMBOL_ASK);
         ok=m_trade.Buy(lot,m_symbol,price,0.0,0.0,comment);
        }
      else if(dir==CYCLE_SELL)
        {
         price=SymbolInfoDouble(m_symbol,SYMBOL_BID);
         ok=m_trade.Sell(lot,m_symbol,price,0.0,0.0,comment);
        }
      else
        {
         errorOut="invalid direction";
         return false;
        }

      // v3.3.1 PATCH P6: CTrade::Buy()/Sell() returning true means the
      // request was ACCEPTED by the trade layer, not necessarily that a
      // position was actually opened. Explicitly verify the retcode before
      // trusting the result, and use ResultDeal()/ResultVolume() rather
      // than assuming a full fill.
      uint rc=m_trade.ResultRetcode();

      if(rc==TRADE_RETCODE_MARKET_CLOSED)
        {
         // v3.3.0/P7: preserve the existing market-closed cooldown —
         // do not retry every tick.
         m_marketClosedUntil=TimeCurrent()+InpMarketClosedCooldownSeconds;
         m_lastMarketClosedEvent=true;
         errorOut=StringFormat("MARKET_CLOSED cooldown=%ds",InpMarketClosedCooldownSeconds);
         PrintFormat("[DTE][EXECUTION][FAIL] retcode=%d description=MARKET_CLOSED",rc);
         return false;
        }

      if(!ok || (rc!=TRADE_RETCODE_DONE && rc!=TRADE_RETCODE_DONE_PARTIAL))
        {
         errorOut=StringFormat("retcode=%d desc=%s",rc,m_trade.ResultRetcodeDescription());
         PrintFormat("[DTE][EXECUTION][FAIL] retcode=%d description=%s",
                     rc,m_trade.ResultRetcodeDescription());
         return false;
        }

      if(rc==TRADE_RETCODE_DONE_PARTIAL)
        {
         CLogger::Warn("TradeEngine",StringFormat(
            "Partial fill on open: requested=%.2f filled=%.2f",lot,m_trade.ResultVolume()));
        }

      ulong deal=m_trade.ResultDeal();
      if(deal>0 && HistoryDealSelect(deal))
         outPositionTicket=(ulong)HistoryDealGetInteger(deal,DEAL_POSITION_ID);

      if(outPositionTicket==0)
        {
         errorOut="ResultDeal ok but DEAL_POSITION_ID not yet resolvable";
        }
      return true;
     }

   bool WasMarketClosedEvent() const { return m_lastMarketClosedEvent; }
   datetime MarketClosedUntil() const { return m_marketClosedUntil; }

   bool ClosePositionByTicket(const ulong ticket,string &errorOut)
     {
      errorOut="";
      m_lastMarketClosedEvent=false;

      if(!m_trade.PositionClose(ticket))
        {
         uint rc=m_trade.ResultRetcode();
         m_lastCloseRetcode=rc;
         if(rc==TRADE_RETCODE_MARKET_CLOSED)
           {
            m_marketClosedUntil=TimeCurrent()+InpMarketClosedCooldownSeconds;
            m_lastMarketClosedEvent=true;
            errorOut=StringFormat("MARKET_CLOSED cooldown=%ds",InpMarketClosedCooldownSeconds);
           }
         else
            errorOut=StringFormat("retcode=%d desc=%s",rc,m_trade.ResultRetcodeDescription());
         PrintFormat("[DTE][EXECUTION][FAIL] retcode=%d description=%s",
                     rc,m_trade.ResultRetcodeDescription());
         return false;
        }

      // v3.3.1 PATCH P6: verify the close actually executed rather than
      // trusting the boolean return alone.
      uint rc=m_trade.ResultRetcode();
      m_lastCloseRetcode=rc;
      if(rc!=TRADE_RETCODE_DONE && rc!=TRADE_RETCODE_DONE_PARTIAL)
        {
         errorOut=StringFormat("retcode=%d desc=%s",rc,m_trade.ResultRetcodeDescription());
         PrintFormat("[DTE][EXECUTION][FAIL] retcode=%d description=%s",
                     rc,m_trade.ResultRetcodeDescription());
         return false;
        }

      // v3.3.2: a DONE_PARTIAL retcode here is deliberately NOT treated as
      // "fully closed" by any caller — CTradeEngine only reports what the
      // trade layer said. Whether real remaining volume is 0 is verified by
      // the caller via PositionSelectByTicket()/POSITION_VOLUME, never
      // inferred from this retcode alone (issue #1 — see PositionManager's
      // hedge close state machine and the basket-layer close-verify loop,
      // both already re-check actual position state independently of this
      // return value).
      if(rc==TRADE_RETCODE_DONE_PARTIAL)
        {
         CLogger::Warn("TradeEngine",StringFormat(
            "Partial close on ticket=%d — remaining volume will retry next tick.",(int)ticket));
        }

      return true;
     }

   // v3.3.2: last retcode seen by ClosePositionByTicket() (success or
   // failure) — used by callers that need to log the real retcode on a
   // confirmed partial/failed close (e.g. [DTE][HEDGE][PARTIAL_CLOSE]).
   uint LastCloseRetcode() const { return m_lastCloseRetcode; }
  };

#endif // __DTE_TRADEENGINE_MQH__
