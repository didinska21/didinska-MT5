//+------------------------------------------------------------------+
//| SessionManager.mqh — CSessionManager                              |
//| v3.1.0: named sessions (Asia/London/NY), configurable per-session |
//| enable + hours. Session transitions never touch basket state —   |
//| callers must independently keep managing any open basket even if |
//| IsTradingAllowed() becomes false (section 21).                   |
//+------------------------------------------------------------------+
#ifndef __DTE_SESSIONMANAGER_MQH__
#define __DTE_SESSIONMANAGER_MQH__

#include "..\Config\Inputs.mqh"

class CSessionManager
  {
public:
   ENUM_SESSION_NAME CurrentSession() const
     {
      MqlDateTime t; TimeToStruct(TimeCurrent(),t);
      bool asia   = InpSessionAsiaEnable   && InHours(t.hour,InpSessionAsiaStart,InpSessionAsiaEnd);
      bool london = InpSessionLondonEnable && InHours(t.hour,InpSessionLondonStart,InpSessionLondonEnd);
      bool ny     = InpSessionNyEnable     && InHours(t.hour,InpSessionNyStart,InpSessionNyEnd);

      if((london && ny)) return SESSION_OVERLAP;
      if(london) return SESSION_LONDON;
      if(ny)     return SESSION_NY;
      if(asia)   return SESSION_ASIA;
      return SESSION_NONE;
     }

   // Gate for opening NEW trades only — does not affect management of
   // already-open baskets (composition root must keep calling basket
   // management regardless of this result).
   bool IsTradingAllowed() const
     {
      if(!InpSessionUseFilter) return true;

      MqlDateTime t; TimeToStruct(TimeCurrent(),t);
      if(!DayAllowed(t.day_of_week)) return false;

      return (CurrentSession()!=SESSION_NONE);
     }

private:
   bool InHours(const int hour,const int start,const int end) const
     {
      if(start<=end) return (hour>=start && hour<end);
      return (hour>=start || hour<end); // overnight wrap
     }

   bool DayAllowed(const int dow) const
     {
      switch(dow)
        {
         case 1: return InpTradeMonday;
         case 2: return InpTradeTuesday;
         case 3: return InpTradeWednesday;
         case 4: return InpTradeThursday;
         case 5: return InpTradeFriday;
         default: return false; // Sat/Sun never traded
        }
     }
  };

#endif // __DTE_SESSIONMANAGER_MQH__
