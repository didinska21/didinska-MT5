//+------------------------------------------------------------------+
//| SpreadFilter.mqh — CSpreadFilter                                  |
//| v3.1.0: blocks NEW entries when spread is abnormal. Never closes  |
//| an existing basket for spread alone (section 23).                 |
//+------------------------------------------------------------------+
#ifndef __DTE_SPREADFILTER_MQH__
#define __DTE_SPREADFILTER_MQH__

#include "..\Config\Inputs.mqh"

class CSpreadFilter
  {
private:
   string m_symbol;

public:
   void Init(const string symbol) { m_symbol=symbol; }

   double CurrentSpreadPoints() const
     {
      return (double)SymbolInfoInteger(m_symbol,SYMBOL_SPREAD);
     }

   bool IsOkForNewEntry() const
     {
      if(!InpUseSpreadFilter) return true;
      return (CurrentSpreadPoints()<=InpMaxSpreadPoints);
     }
  };

#endif // __DTE_SPREADFILTER_MQH__
