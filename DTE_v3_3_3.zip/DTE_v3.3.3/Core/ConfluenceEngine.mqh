//+------------------------------------------------------------------+
//| ConfluenceEngine.mqh — CConfluenceEngine                          |
//| v3.3.0: combines H1 bias (with strength), M15 structure (BOS/     |
//| CHOCH heuristic), and M5 confluence sources (Fib 50/61.8, a       |
//| simplified QM retest, EMA alignment) into a single scored          |
//| candidate direction. Thresholds are configurable, not hard-coded  |
//| "perfect setup" logic (section 6).                                 |
//+------------------------------------------------------------------+
#ifndef __DTE_CONFLUENCEENGINE_MQH__
#define __DTE_CONFLUENCEENGINE_MQH__

#include "..\Config\Inputs.mqh"
#include "..\Indicators\EMAFilter.mqh"
#include "StructureEngine.mqh"

class CConfluenceEngine
  {
private:
   string m_symbol;

   CEMAFilter m_h1Fast, m_h1Slow;
   int        m_h1AtrHandle;

   CEMAFilter m_m5Fast, m_m5Slow;
   int        m_m5AtrHandle;

   CStructureEngine m_structure;

   double GetAtrValue(const int handle,const int shift=1) const
     {
      if(handle==INVALID_HANDLE) return 0.0;
      double buf[];
      ArraySetAsSeries(buf,true);
      if(CopyBuffer(handle,0,shift,1,buf)<=0) return 0.0;
      return buf[0];
     }


public:
   // v3.3.3 — exposed so ClassifyAdverseMove() (and any future caller) can
   // evaluate M5 momentum in an EXPLICIT direction, including the direction
   // opposite the basket (i.e. "is momentum expanding against me right
   // now?"). Logic itself is unchanged from v3.3.2 — same candle-body/EMA
   // check used by Evaluate() for normal entries.
   bool IsM5TriggerValid(const ENUM_CYCLE_DIRECTION candidate) const
     {
      if(candidate==CYCLE_NONE) return false;
      double f,s;
      if(!m_m5Fast.GetValue(f,1) || !m_m5Slow.GetValue(s,1)) return false;
      MqlRates rates[];
      ArraySetAsSeries(rates,true);
      if(CopyRates(m_symbol,InpTfTrigger,1,2,rates)<2) return false;

      double body=MathAbs(rates[0].close-rates[0].open);
      double range=rates[0].high-rates[0].low;
      if(range<=0.0) return false;
      bool directionalCandle=(candidate==CYCLE_BUY)
                             ? (rates[0].close>rates[0].open && rates[0].close>f)
                             : (rates[0].close<rates[0].open && rates[0].close<f);
      // A very small candle is not a meaningful trigger; 10% of range is
      // deliberately permissive to avoid turning the entry engine into a
      // rare-signal filter.
      return directionalCandle && body>=range*0.10 &&
             ((candidate==CYCLE_BUY && f>s) || (candidate==CYCLE_SELL && f<s));
     }

   ENUM_MARKET_REGIME GetMarketRegime() const
     {
      ENUM_MARKET_BIAS bias=GetH1Bias();
      SStructureAnalysis m15=GetM15Structure();

      double atr=GetAtrValue(m_m5AtrHandle,1);
      double point=SymbolInfoDouble(m_symbol,SYMBOL_POINT);
      if(atr>0.0 && point>0.0 && (atr/point)>=InpAtrMaxPoints)
         return REGIME_HIGH_VOLATILITY;

      if(bias==BIAS_STRONG_BULL || bias==BIAS_BULL)
         return REGIME_BULLISH_TREND;
      if(bias==BIAS_STRONG_BEAR || bias==BIAS_BEAR)
         return REGIME_BEARISH_TREND;

      if(m15.valid && (m15.state==STRUCT_BULLISH || m15.state==STRUCT_BOS_UP || m15.state==STRUCT_CHOCH_UP))
         return REGIME_BULLISH_TREND;
      if(m15.valid && (m15.state==STRUCT_BEARISH || m15.state==STRUCT_BOS_DOWN || m15.state==STRUCT_CHOCH_DOWN))
         return REGIME_BEARISH_TREND;

      if(bias==BIAS_NEUTRAL && (!m15.valid || m15.state==STRUCT_UNKNOWN))
         return REGIME_SIDEWAYS;

      return REGIME_NO_TRADE;
     }

public:
   bool Init(const string symbol)
     {
      m_symbol=symbol;
      bool ok=true;
      ok = ok && m_h1Fast.Init(symbol,InpTfBias,InpEmaFastPeriod,InpEmaMethod,InpEmaPrice);
      ok = ok && m_h1Slow.Init(symbol,InpTfBias,InpEmaSlowPeriod,InpEmaMethod,InpEmaPrice);
      m_h1AtrHandle=iATR(symbol,InpTfBias,14);
      ok = ok && (m_h1AtrHandle!=INVALID_HANDLE);

      ok = ok && m_m5Fast.Init(symbol,InpTfTrigger,InpEmaFastPeriod,InpEmaMethod,InpEmaPrice);
      ok = ok && m_m5Slow.Init(symbol,InpTfTrigger,InpEmaSlowPeriod,InpEmaMethod,InpEmaPrice);
      m_m5AtrHandle=iATR(symbol,InpTfTrigger,InpAtrPeriod);
      ok = ok && (m_m5AtrHandle!=INVALID_HANDLE);

      m_structure.Init(symbol);
      return ok;
     }

   ENUM_MARKET_BIAS GetH1Bias() const
     {
      double fast,slow;
      if(!m_h1Fast.GetValue(fast,1) || !m_h1Slow.GetValue(slow,1)) return BIAS_NEUTRAL;
      double atr=GetAtrValue(m_h1AtrHandle,1);
      if(atr<=0.0) return BIAS_NEUTRAL;

      double gap=fast-slow;
      double ratio=MathAbs(gap)/atr;

      if(ratio<0.15) return BIAS_NEUTRAL;
      if(gap>0) return (ratio>=1.0)?BIAS_STRONG_BULL:BIAS_BULL;
      return (ratio>=1.0)?BIAS_STRONG_BEAR:BIAS_BEAR;
     }

   SStructureAnalysis GetM15Structure() const
     {
      return m_structure.Analyze(InpTfStruct);
     }

   // Full evaluation used at the M5 trigger moment (called by CSignalEngine).
   SConfluenceResult Evaluate() const
     {
      SConfluenceResult r;
      ZeroMemory(r);
      r.direction=CYCLE_NONE;

      r.h1Bias = GetH1Bias();
      SStructureAnalysis m15 = GetM15Structure();
      r.m15Structure = m15.state;

      bool bullishStruct = (m15.state==STRUCT_BULLISH || m15.state==STRUCT_BOS_UP || m15.state==STRUCT_CHOCH_UP);
      bool bearishStruct = (m15.state==STRUCT_BEARISH || m15.state==STRUCT_BOS_DOWN || m15.state==STRUCT_CHOCH_DOWN);

      bool buyAllowedByBias  = (r.h1Bias!=BIAS_STRONG_BEAR);
      bool sellAllowedByBias = (r.h1Bias!=BIAS_STRONG_BULL);

      ENUM_CYCLE_DIRECTION candidate=CYCLE_NONE;
      if(bullishStruct && buyAllowedByBias && !bearishStruct) candidate=CYCLE_BUY;
      else if(bearishStruct && sellAllowedByBias && !bullishStruct) candidate=CYCLE_SELL;

      r.direction=candidate;
      if(candidate==CYCLE_NONE)
        {
         r.score=0;
         r.m5Trigger=false;
         r.regime=GetMarketRegime();
         r.passed=false;
         return r;
        }

      int score=0;
      double price = (candidate==CYCLE_BUY) ? SymbolInfoDouble(m_symbol,SYMBOL_ASK)
                                             : SymbolInfoDouble(m_symbol,SYMBOL_BID);
      double m5Atr = GetAtrValue(m_m5AtrHandle,1);
      double tolerance = (m5Atr>0.0) ? m5Atr*InpFibProximityAtrMult : 0.0;

      // Structural confluence: an actual BOS/CHOCH (not just plain continuation) adds a point.
      if(InpUseStructureConfluence)
        {
         bool structBreak = (m15.state==STRUCT_BOS_UP || m15.state==STRUCT_CHOCH_UP ||
                              m15.state==STRUCT_BOS_DOWN || m15.state==STRUCT_CHOCH_DOWN);
         if(structBreak) score++;
        }

      // Fibonacci 50 / 61.8 proximity.
      if(InpUseFibConfluence && tolerance>0.0)
        {
         double fib50,fib618;
         if(m_structure.GetFibLevels(m15,fib50,fib618))
           {
            if(MathAbs(price-fib50)<=tolerance || MathAbs(price-fib618)<=tolerance)
              {
               r.fibHit=true;
               score++;
              }
           }
        }

      // Simplified Quasimodo-style retest of a freshly broken structure level.
      if(InpUseQmConfluence && tolerance>0.0)
        {
         ENUM_CYCLE_DIRECTION qmDir;
         if(m_structure.CheckQuasimodoRetest(m15,price,tolerance,qmDir) && qmDir==candidate)
           {
            r.qmHit=true;
            score++;
           }
        }

      // M5 EMA alignment with the candidate direction.
      if(InpUseEmaConfluence)
        {
         double f,s;
         if(m_m5Fast.GetValue(f,1) && m_m5Slow.GetValue(s,1))
           {
            if((candidate==CYCLE_BUY && f>s) || (candidate==CYCLE_SELL && f<s))
              {
               r.emaHit=true;
               score++;
              }
           }
        }

      r.score=score;
      r.m5Trigger=IsM5TriggerValid(candidate);
      r.regime=GetMarketRegime();
      r.passed=(score>=InpMinConfluenceScore) && (!InpRequireM5Trigger || r.m5Trigger);
      return r;
     }

   //=====================================================================
   // v3.3.3 PATCH OBJECTIVE #1 — RECOVERY MUST DISTINGUISH RETRACEMENT
   // FROM CONTINUATION.
   //
   // Called ONCE a recovery-distance threshold has been reached (i.e. price
   // already moved against the basket by the layer-distance amount), BEFORE
   // any recovery is attempted. Classifies the adverse move into one of
   // three buckets using ONLY existing concepts (H1 bias, M15 BOS/CHOCH,
   // M5 momentum/EMA/candle-body, fib/QM proximity from Evaluate()) — no
   // new indicators, no ML, no external data.
   //
   //   ADVERSE_CONTINUATION — H1 turns strongly against the basket, OR M15
   //     prints a BOS/CHOCH against the basket, OR M5 momentum is actively
   //     expanding in the adverse direction right now. Recovery must NOT be
   //     attempted; the caller should instead let thesis-invalidation /
   //     controlled-exit logic run.
   //
   //   ADVERSE_RETRACEMENT — H1 remains supportive of the basket direction,
   //     M15 structure is still compatible (not broken against), AND price
   //     is either near a meaningful confluence level (fib/QM, via
   //     Evaluate()'s existing fibHit/qmHit) or already has a fresh M5
   //     trigger in the basket's own direction. This is the PREFERRED
   //     recovery scenario.
   //
   //   ADVERSE_RANGE — H1 is neutral and the market regime/M15 structure is
   //     not strongly directional either way. Recovery may still be
   //     permitted, but conservatively (caller applies a tighter layer cap).
   //
   // out/reasonOut mirror ValidateRecoveryThesis()'s signature so callers
   // can log the fresh confluence snapshot alongside the classification.
   //=====================================================================
   ENUM_ADVERSE_CLASSIFICATION ClassifyAdverseMove(const ENUM_CYCLE_DIRECTION dir,
                                                    SConfluenceResult &freshOut,
                                                    string &reasonOut) const
     {
      ZeroMemory(freshOut);
      reasonOut="";
      if(dir==CYCLE_NONE) { reasonOut="invalid direction"; return ADVERSE_NONE; }

      ENUM_MARKET_BIAS  bias=GetH1Bias();
      SStructureAnalysis m15=GetM15Structure();
      SConfluenceResult fresh=Evaluate();
      freshOut=fresh;

      bool h1StrongAgainst=(dir==CYCLE_BUY  && bias==BIAS_STRONG_BEAR) ||
                            (dir==CYCLE_SELL && bias==BIAS_STRONG_BULL);

      bool m15BreakAgainst=(dir==CYCLE_BUY  && (m15.valid && (m15.state==STRUCT_BOS_DOWN || m15.state==STRUCT_CHOCH_DOWN))) ||
                            (dir==CYCLE_SELL && (m15.valid && (m15.state==STRUCT_BOS_UP   || m15.state==STRUCT_CHOCH_UP)));

      // Momentum expanding AGAINST the basket direction right now — i.e. a
      // valid M5 trigger in the opposite direction of the basket.
      ENUM_CYCLE_DIRECTION oppositeDir=(dir==CYCLE_BUY)?CYCLE_SELL:CYCLE_BUY;
      bool m5AgainstExpanding=IsM5TriggerValid(oppositeDir);

      if(h1StrongAgainst || m15BreakAgainst || m5AgainstExpanding)
        {
         reasonOut=StringFormat(
            "strong continuation against basket (h1StrongAgainst=%s m15BreakAgainst=%s m5AgainstExpanding=%s)",
            (h1StrongAgainst?"Y":"N"),(m15BreakAgainst?"Y":"N"),(m5AgainstExpanding?"Y":"N"));
         return ADVERSE_CONTINUATION;
        }

      bool h1Support=(dir==CYCLE_BUY)
                     ? (bias==BIAS_BULL || bias==BIAS_STRONG_BULL)
                     : (bias==BIAS_BEAR || bias==BIAS_STRONG_BEAR);

      bool m15Compatible=(dir==CYCLE_BUY)
                     ? (m15.valid && (m15.state==STRUCT_BULLISH || m15.state==STRUCT_BOS_UP || m15.state==STRUCT_CHOCH_UP))
                     : (m15.valid && (m15.state==STRUCT_BEARISH || m15.state==STRUCT_BOS_DOWN || m15.state==STRUCT_CHOCH_DOWN));

      bool nearMeaningfulLevel=(fresh.fibHit || fresh.qmHit);
      bool freshM5InDir=(fresh.m5Trigger && fresh.direction==dir);

      if(h1Support && m15Compatible && (nearMeaningfulLevel || freshM5InDir))
        {
         reasonOut=StringFormat(
            "retracement/pullback — H1 supportive, M15 compatible, %s",
            (nearMeaningfulLevel?"near fib/QM level":"fresh M5 reclaim/BOS/CHOCH in basket direction"));
         return ADVERSE_RETRACEMENT;
        }

      bool h1Neutral=(bias==BIAS_NEUTRAL);
      bool m15NotStronglyDirectional=(!m15.valid || m15.state==STRUCT_UNKNOWN ||
                                       m15.state==STRUCT_BULLISH || m15.state==STRUCT_BEARISH);
      bool regimeSideways=(fresh.regime==REGIME_SIDEWAYS);

      if(h1Neutral && (regimeSideways || m15NotStronglyDirectional))
        {
         reasonOut="sideways/range — H1 neutral, no strongly directional M15 structure";
         return ADVERSE_RANGE;
        }

      // Ambiguous (e.g. H1 mildly supportive but M15 not compatible, or vice
      // versa) — default to the conservative RANGE bucket rather than the
      // preferred RETRACEMENT path, per section C of the recovery model.
      reasonOut="ambiguous conditions — treated conservatively as range";
      return ADVERSE_RANGE;
     }

   // Recovery validation is deliberately stricter than simple thesis survival:
   // price distance only arms an evaluation. A fresh directional confirmation
   // is required before another layer can be opened.
   bool ValidateRecoveryThesis(const ENUM_CYCLE_DIRECTION dir,
                               SConfluenceResult &out,
                               string &reason) const
     {
      ZeroMemory(out);
      reason="";
      if(dir==CYCLE_NONE) { reason="invalid direction"; return false; }

      ENUM_MARKET_BIAS bias=GetH1Bias();
      SStructureAnalysis m15=GetM15Structure();

      bool h1Support=(dir==CYCLE_BUY)
                     ? (bias==BIAS_BULL || bias==BIAS_STRONG_BULL || bias==BIAS_NEUTRAL)
                     : (bias==BIAS_BEAR || bias==BIAS_STRONG_BEAR || bias==BIAS_NEUTRAL);

      bool m15BrokenAgainst=(dir==CYCLE_BUY)
                             ? (m15.valid && (m15.state==STRUCT_CHOCH_DOWN || m15.state==STRUCT_BOS_DOWN))
                             : (m15.valid && (m15.state==STRUCT_CHOCH_UP || m15.state==STRUCT_BOS_UP));

      if((dir==CYCLE_BUY && bias==BIAS_STRONG_BEAR) ||
         (dir==CYCLE_SELL && bias==BIAS_STRONG_BULL))
        {
         reason="H1 strong bias against basket";
         return false;
        }

      if(m15BrokenAgainst)
        {
         reason="M15 structure confirmed against basket";
         return false;
        }

      SConfluenceResult fresh=Evaluate();
      out=fresh;

      bool m15Directional=(dir==CYCLE_BUY)
                           ? (m15.state==STRUCT_BULLISH || m15.state==STRUCT_BOS_UP || m15.state==STRUCT_CHOCH_UP)
                           : (m15.state==STRUCT_BEARISH || m15.state==STRUCT_BOS_DOWN || m15.state==STRUCT_CHOCH_DOWN);

      bool freshM5=fresh.m5Trigger && fresh.direction==dir;
      bool scoreOk=(fresh.score>=InpRecoveryMinConfluenceScore);

      // v3.3.1 PATCH P2: M5 execution confirmation is no longer optional.
      // v3.3.0 allowed "m15Directional || freshM5" — meaning a recovery
      // layer could open on M15 structure alone, with NO fresh M5 trigger
      // at all. That contradicts the H1(context)->M15(structure)->
      // M5(execution confirmation) architecture. When InpRequireM5Trigger
      // is enabled (the default), a fresh M5 trigger in the basket's exact
      // direction is now a HARD requirement — M15 alignment can no longer
      // substitute for it. (If InpRequireM5Trigger is explicitly disabled
      // by the user, the M5 gate is bypassed here exactly as it already is
      // for normal entries in Evaluate() — no new behavior invented.)
      bool m5Ok = freshM5 || !InpRequireM5Trigger;

      if(InpRequireM5Trigger && !freshM5)
        {
         reason="M5 trigger required for recovery — no fresh M5 confirmation in basket direction";
         PrintFormat("[DTE][RECOVERY][REJECT] reason=\"%s\" score=%d m15Directional=%s m5Trigger=%s",
                     reason,fresh.score,(m15Directional?"Y":"N"),(fresh.m5Trigger?"Y":"N"));
         return false;
        }

      if(h1Support && m15Directional && m5Ok && scoreOk)
         return true;

      reason=StringFormat("no fresh confirmation (score=%d h1Support=%s m15Directional=%s m5Trigger=%s)",
                          fresh.score,(h1Support?"Y":"N"),(m15Directional?"Y":"N"),(freshM5?"Y":"N"));
      PrintFormat("[DTE][RECOVERY][REJECT] reason=\"%s\"",reason);
      return false;
     }

   bool IsThesisValid(const ENUM_CYCLE_DIRECTION dir) const
     {
      if(dir==CYCLE_NONE) return false;
      ENUM_MARKET_BIAS bias=GetH1Bias();
      SStructureAnalysis m15=GetM15Structure();

      if(dir==CYCLE_BUY)
        {
         if(bias==BIAS_STRONG_BEAR) return false;
         if(m15.valid && (m15.state==STRUCT_CHOCH_DOWN || m15.state==STRUCT_BOS_DOWN)) return false;
        }
      else if(dir==CYCLE_SELL)
        {
         if(bias==BIAS_STRONG_BULL) return false;
         if(m15.valid && (m15.state==STRUCT_CHOCH_UP || m15.state==STRUCT_BOS_UP)) return false;
        }
      return true;
     }

   void Release()
     {
      m_h1Fast.Release(); m_h1Slow.Release();
      m_m5Fast.Release(); m_m5Slow.Release();
      if(m_h1AtrHandle!=INVALID_HANDLE) IndicatorRelease(m_h1AtrHandle);
      if(m_m5AtrHandle!=INVALID_HANDLE) IndicatorRelease(m_m5AtrHandle);
     }
  };

#endif // __DTE_CONFLUENCEENGINE_MQH__
