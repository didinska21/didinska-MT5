//+------------------------------------------------------------------+
//| SignalEngine.mqh — CSignalEngine                                  |
//| v3.1.0: H1->M15->M5 architecture is chart-timeframe independent   |
//| (all timeframes are explicit inputs — section 4). Confluence      |
//| scoring is delegated to CConfluenceEngine. A new M5 bar is        |
//| required to re-evaluate, and only one basket can be active at a   |
//| time (enforced by the composition root) — together these prevent  |
//| uncontrolled duplicate baskets from an unchanged signal (section  |
//| 9 / acceptance test 10).                                          |
//+------------------------------------------------------------------+
#ifndef __DTE_SIGNALENGINE_MQH__
#define __DTE_SIGNALENGINE_MQH__

#include "..\Config\Inputs.mqh"
#include "ConfluenceEngine.mqh"
#include "DiagnosticEngine.mqh"

class CSignalEngine
  {
private:
   string             m_symbol;
   CConfluenceEngine *m_confluence; // not owned — shared with CPositionManager
   datetime           m_lastTriggerBarTime;
   CDiagnosticEngine *m_diag; // not owned

public:
   CSignalEngine() : m_confluence(NULL), m_lastTriggerBarTime(0), m_diag(NULL) {}

   void Init(const string symbol,CConfluenceEngine *confluence,CDiagnosticEngine *diag)
     {
      m_symbol=symbol;
      m_confluence=confluence;
      m_diag=diag;
     }

   ENUM_MARKET_BIAS GetH1Bias() const { return (m_confluence!=NULL)?m_confluence.GetH1Bias():BIAS_NEUTRAL; }
   ENUM_STRUCT_STATE GetM15Structure() const
     { return (m_confluence!=NULL)?m_confluence.GetM15Structure().state:STRUCT_UNKNOWN; }

   // Returns true ONLY on the tick where a NEW trigger-timeframe bar has
   // formed AND the confluence score passes threshold. Caller must also
   // ensure no basket is currently active (one basket at a time).
   bool CheckTrigger(SConfluenceResult &outResult)
     {
      ZeroMemory(outResult);
      outResult.direction=CYCLE_NONE;
      if(m_confluence==NULL) return false;

      datetime curBarTime=iTime(m_symbol,InpTfTrigger,0);
      if(curBarTime==0) return false;
      if(curBarTime==m_lastTriggerBarTime) return false; // no new bar yet — not a repeated-signal spam, just not due

      m_lastTriggerBarTime=curBarTime; // mark this bar as evaluated regardless of outcome

      SConfluenceResult r = m_confluence.Evaluate();
      outResult=r;

      if(m_diag!=NULL)
        {
         if(r.passed) m_diag.OnConfluencePass();
         else         m_diag.OnConfluenceReject();
        }

      return r.passed;
     }

   // Marks the current trigger-timeframe bar as already handled — call the
   // instant a basket closes so a new cycle can't fire mid-bar on the same
   // candle the previous basket just closed on.
   void SuppressCurrentBar()
     {
      datetime curBarTime=iTime(m_symbol,InpTfTrigger,0);
      if(curBarTime>0) m_lastTriggerBarTime=curBarTime;
     }
  };

#endif // __DTE_SIGNALENGINE_MQH__
