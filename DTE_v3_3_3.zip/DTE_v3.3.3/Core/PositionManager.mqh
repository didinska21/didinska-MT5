//+------------------------------------------------------------------+
//| PositionManager.mqh — CPositionManager                            |
//| v3.3.0 — major rewrite vs v3.0.1:                                  |
//|  - Layers are NO LONGER all opened at once. Layer 1 opens on       |
//|    trigger; layer N+1 requires price to have moved against the    |
//|    basket by an ATR+structure-based distance AND the original     |
//|    thesis to still be valid AND margin to permit it (section 10-  |
//|    12).                                                            |
//|  - Lot size is dynamically affordable per layer (CLotSizing),      |
//|    never assumes InpMaxLayers is reachable (section 1/14).         |
//|  - Hedge engine integration: a hedge is opened only on genuine     |
//|    opposing structure, never merely because the basket is losing  |
//|    (section 13).                                                   |
//|  - Basket TP is computed on NET profit (profit+swap+best-effort    |
//|    entry commission) (section 15), with an optional spike-exit     |
//|    (section 16).                                                   |
//|  - CRITICAL close-safety: a basket is NEVER finalized until every  |
//|    tracked position (and hedge) is verified actually closed. If    |
//|    any remain, state stays alive and closing is retried (section  |
//|    17).                                                            |
//|  - Position tracking uses symbol+magic+comment (basket ID encoded  |
//|    in the order comment), not just newest-position-time scanning  |
//|    (section 18).                                                   |
//|  - Persistence is namespaced by account login+symbol+magic+state   |
//|    version (section 19), independent basket-ID sequence also       |
//|    persisted so IDs stay unique across restarts.                   |
//|                                                                     |
//| v3.3.2 — execution-safety patch (no strategy change):              |
//|  - Issue #1: hedge close is now a verified state machine.          |
//|    TRADE_RETCODE_DONE_PARTIAL (or any close attempt) is NEVER      |
//|    treated as "hedge gone" — hedgeActive/hedgeTicket only clear    |
//|    once the actual position is re-selected and confirmed absent.   |
//|  - Issue #2: an order that executed but couldn't be resolved to a  |
//|    tracked ticket is now registered in a session-persistent        |
//|    orphan-recovery list (m_orphans[]) instead of a single one-shot |
//|    close attempt. It is retried every tick (cooldown-gated) until  |
//|    either attached/tracked or verified fully closed, and blocks    |
//|    new basket/recovery/hedge risk in the meantime — see            |
//|    HasPendingOrphans(). Known limitation: this list is in-memory   |
//|    only (not GlobalVariable-persisted) — see                       |
//|    Docs/V3.3.2_IMPLEMENTATION_NOTES.md.                            |
//+------------------------------------------------------------------+
#ifndef __DTE_POSITIONMANAGER_MQH__
#define __DTE_POSITIONMANAGER_MQH__

#include "..\Config\Inputs.mqh"
#include "TradeEngine.mqh"
#include "RiskEngine.mqh"
#include "DiagnosticEngine.mqh"
#include "Logger.mqh"
#include "ConfluenceEngine.mqh"
#include "HedgeEngine.mqh"
#include "NewsFilter.mqh"
#include "LotSizing.mqh"
#include "Utils.mqh"

// v3.3.2 — issue #2: tracks one order that executed but could not (yet) be
// attached to normal basket/hedge tracking. Never dropped until either
// attached or verified fully closed — see CPositionManager::ProcessOrphanRecovery().
struct SOrphanRecord
  {
   ulong    ticket;          // 0 until a matching position is found by rescan
   bool     ticketKnown;     // true once `ticket` refers to a real, matched position
   string   expectedComment; // exact comment used for symbol+magic+comment identity matching
   string   context;         // "layer1" / "recovery" / "hedge" — logging only
   datetime nextRetryTime;   // cooldown gate — do not re-attempt every tick
   int      attempts;
  };

class CPositionManager
  {
private:
   string        m_symbol;
   long          m_magic;
   string        m_gvPrefix;

   CTradeEngine       *m_tradeEngine;  // not owned
   CConfluenceEngine  *m_confluence;   // not owned — thesis validity + structure
   CHedgeEngine       *m_hedge;        // not owned
   CNewsFilter        *m_news;         // not owned
   CDiagnosticEngine  *m_diag;         // not owned
   CRiskEngine        *m_risk;         // not owned

   int            m_layerAtrHandle;

   SBasketState  m_basket;
   ulong         m_tickets[];
   ulong         m_currentBasketId;
   int           m_lastKnownStillOpen;

   bool                     m_closePending;
   ENUM_BASKET_CLOSE_REASON m_closePendingReason;

   SOrphanRecord m_orphans[]; // v3.3.2 issue #2 — see struct comment above

   // v3.3.3 PATCH OBJECTIVE #4 — RECOVERY EVALUATION MUST BE EVENT-DRIVEN.
   // In-memory only (not persisted — same tolerance as m_orphans[]; worst
   // case after a restart is one extra evaluation on the next new event,
   // never a correctness issue). A "recovery opportunity" is identified by
   // (layersOpen, current M5 bar time); once that opportunity has been
   // evaluated once, it is not re-evaluated again until a new M5 candle
   // forms (a "new market event"), regardless of how many ticks occur.
   datetime m_lastRecoveryEvalBarTime;
   int      m_lastRecoveryEvalLayer;

   // v3.3.3 PATCH OBJECTIVE #5 — RECOVERY REJECTION LOGGING. Throttled: the
   // same opportunity/reason is printed once, then stays silent (counter
   // still increments internally) until the opportunity actually changes.
   string   m_lastRecoveryRejectReason;
   int      m_lastRecoveryRejectLayer;
   long     m_recoveryRejectRepeatCount;

public:
   CPositionManager() : m_tradeEngine(NULL), m_confluence(NULL), m_hedge(NULL),
                         m_news(NULL), m_diag(NULL), m_risk(NULL), m_layerAtrHandle(INVALID_HANDLE),
                         m_currentBasketId(0), m_lastKnownStillOpen(0),
                         m_closePending(false), m_closePendingReason(CLOSE_NONE),
                         m_lastRecoveryEvalBarTime(0), m_lastRecoveryEvalLayer(0),
                         m_lastRecoveryRejectReason(""), m_lastRecoveryRejectLayer(0),
                         m_recoveryRejectRepeatCount(0)
     {
      ZeroMemory(m_basket);
     }

   bool Init(const string symbol,const long magic,CTradeEngine *tradeEngine,
             CConfluenceEngine *confluence,CHedgeEngine *hedge,CNewsFilter *news,
             CDiagnosticEngine *diag,CRiskEngine *risk)
     {
      m_symbol=symbol;
      m_magic=magic;
      m_tradeEngine=tradeEngine;
      m_confluence=confluence;
      m_hedge=hedge;
      m_news=news;
      m_diag=diag;
      m_risk=risk;

      long login=AccountInfoInteger(ACCOUNT_LOGIN);
      m_gvPrefix=StringFormat("DTE_%I64d_%s_%d_v%d",login,symbol,(int)magic,DTE_STATE_VERSION);

      m_layerAtrHandle=iATR(symbol,InpTfTrigger,InpAtrPeriodLayer);

      ZeroMemory(m_basket);
      ArrayResize(m_tickets,0);
      m_lastKnownStillOpen=0;
      m_closePending=false;
      ArrayResize(m_orphans,0);
      m_lastRecoveryEvalBarTime=0;
      m_lastRecoveryEvalLayer=0;
      m_lastRecoveryRejectReason="";
      m_lastRecoveryRejectLayer=0;
      m_recoveryRejectRepeatCount=0;

      RestorePersistedState();
      return (m_layerAtrHandle!=INVALID_HANDLE);
     }

   void SyncHaltState(const bool halted)
     {
      if(!m_basket.active) return;
      if(halted)
        {
         if(!m_closePending && m_basket.state!=BSTATE_EXIT_PENDING &&
            m_basket.state!=BSTATE_CLOSING)
            m_basket.state=BSTATE_HALTED;
        }
      else if(m_basket.state==BSTATE_HALTED)
         m_basket.state=BSTATE_ACTIVE;
     }

   bool IsBasketActive() const { return m_basket.active; }
   SBasketState GetBasketState() const { return m_basket; }

   //=====================================================================
   // ENTRY — opens LAYER 1 ONLY. Subsequent layers are added by
   // TryAddRecoveryLayer(), called every tick while the basket is open.
   //=====================================================================
   void StartBasket(const ENUM_CYCLE_DIRECTION dir,const SConfluenceResult &conf,
                     const ENUM_SESSION_NAME session)
     {
      if(m_basket.active) return; // guard — one basket at a time
      // v3.3.2 issue #2: never open a new basket while a previous order's
      // execution is still unresolved — that position may exist unmanaged
      // on the broker side even though m_basket.active never got set.
      if(HasPendingOrphans())
        {
         CLogger::Warn("PositionManager",
            "New basket blocked — orphan position recovery still in progress.");
         return;
        }

      double lot; string lotReason;
      if(!CLotSizing::CalculateAdaptiveBaseLot(m_symbol,dir,InpMaxLayers,lot,lotReason))
        {
         CLogger::Info("PositionManager",StringFormat(
            "No trade this cycle — %s",lotReason));
         return;
        }
      LogAdaptiveLot(lot,lotReason);

      m_currentBasketId=NextBasketId();
      string comment=BuildComment(m_currentBasketId);

      double projectedRisk=ProjectedBasketRiskPct(lot,true,dir);
      if(m_diag!=NULL) m_diag.RecordBasketRisk(projectedRisk);
      if(projectedRisk>InpHardBasketEquityRiskPercent)
        {
         if(m_diag!=NULL) m_diag.OnBasketRiskRejected();
         CDiagnosticEngine::LogRiskReject(m_currentBasketId,projectedRisk,
                                           InpMaxBasketEquityRiskPercent,
                                           InpHardBasketEquityRiskPercent,
                                           "initial basket exceeds hard equity-risk ceiling");
         return;
        }

      ulong ticket=0; string err;
      if(!m_tradeEngine.OpenMarket(dir,lot,comment,ticket,err))
        {
         if(m_tradeEngine.WasMarketClosedEvent() && m_diag!=NULL) m_diag.OnMarketClosed();
         CLogger::Warn("PositionManager",StringFormat("Layer #1 broker rejection: %s",err));
         return;
        }
      if(ticket==0) ticket=ResolveExecutedTicket(comment);
      if(ticket==0)
        {
         CLogger::Error("PositionManager","Layer #1 executed but ticket could not be resolved after retries.");
         RegisterOrphan(comment,"layer1");
         return;
        }

      ZeroMemory(m_basket);
      ArrayResize(m_tickets,0);
      ArrayResize(m_tickets,1);
      m_tickets[0]=ticket;

      m_basket.active             = true;
      m_basket.direction          = dir;
      m_basket.cycleStartBalance  = AccountInfoDouble(ACCOUNT_BALANCE);
      m_basket.cycleStartTime     = TimeCurrent();
      m_basket.basketTpTarget     = m_basket.cycleStartBalance*(InpBasketTpPercent/100.0);
      m_basket.layersOpen         = 1;
      m_basket.lastLayerPrice     = (dir==CYCLE_BUY)?SymbolInfoDouble(m_symbol,SYMBOL_ASK)
                                                     :SymbolInfoDouble(m_symbol,SYMBOL_BID);
      m_basket.hedgeState         = HEDGE_NORMAL;
      m_basket.hedgeActive        = false;
      m_basket.hedgeTicket        = 0;
      m_basket.peakFloatingProfit = 0.0;
      m_basket.peakFloatingTime   = TimeCurrent();
      m_basket.selectedBaseLot    = lot;
      m_basket.state             = BSTATE_ACTIVE;
      m_basket.recoveryStartTime = 0;
      m_basket.lastHedgeCloseTime = 0;
      m_basket.thesisInvalidatedTime = 0;
      m_basket.maxBasketRiskPct  = projectedRisk;

      m_lastKnownStillOpen=1;

      if(m_diag!=NULL) m_diag.OnBasketOpened(dir);

      CDiagnosticEngine::LogEntry(m_currentBasketId,dir,"initial trigger",conf,1,
                                   m_basket.lastLayerPrice,lot,GetLayerAtr(),
                                   (double)SymbolInfoInteger(m_symbol,SYMBOL_SPREAD),
                                   AccountInfoDouble(ACCOUNT_MARGIN_LEVEL),session);

      PersistState();

      CLogger::Info("PositionManager",StringFormat(
         "Basket #%I64u opened: dir=%s lot=%.2f cycleStartBalance=%.2f tpTarget(+%.2f%%)=%.2f",
         m_currentBasketId,(dir==CYCLE_BUY?"BUY":"SELL"),lot,m_basket.cycleStartBalance,
         InpBasketTpPercent,m_basket.basketTpTarget));
     }

   //=====================================================================
   // Call every tick while a basket is active (before or after TP check —
   // order doesn't matter much, but do it before TP so a same-tick TP can
   // still close everything including a layer just added).
   //=====================================================================
   // v3.3.0 PATCH 1: riskHalted is a defensive second gate (composition root
   // is expected to already check CRiskEngine::IsHalted() before calling this)
   // — once the +900% target is reached, NO new recovery layer may open,
   // regardless of what the caller does.
   void TryAddRecoveryLayer(const ENUM_SESSION_NAME session,const bool riskHalted)
     {
      if(!m_basket.active || m_closePending) return;
      if(riskHalted) return;
      // v3.3.2 issue #2: no new recovery layer while a previous order's
      // execution is still unresolved (e.g. a hedge or an earlier layer).
      if(HasPendingOrphans()) return;
      if(!InpRecoveryEnable) return;
      if(m_basket.layersOpen>=InpMaxLayers) return;
      if(m_basket.hedgeActive) return; // protection mode: never layer while hedge is active

      datetime now=TimeCurrent();
      long holdSeconds=(long)(now-m_basket.cycleStartTime);
      // v3.3.3 PATCH OBJECTIVE #8 — MAX HOLD IS A TRUE HARD LIMIT. Timer
      // started once at StartBasket() and is NEVER reset by a new layer,
      // hedge, or restart (see cycleStartTime — unchanged since v3.3.2, this
      // patch only makes the ENFORCEMENT stricter/more visible). Once
      // reached: no new recovery, no new hedge (see ManageHedge), no new
      // entry (already gated by IsBasketActive() in OnTick) — only a
      // controlled exit.
      if(InpMaxBasketHoldMinutes>0 && holdSeconds >= InpMaxBasketHoldMinutes*60)
        {
         if(m_basket.state!=BSTATE_THESIS_INVALIDATED)
           {
            m_basket.state=BSTATE_EXIT_PENDING;
            if(m_diag!=NULL) m_diag.OnMaxHoldExit();
            PrintFormat("[DTE][EXIT][MAX_HOLD] duration=%ds layers=%d floating=%.2f finalLoss=%.2f "
                        "reason=\"true hard basket-lifetime limit reached — no new recovery/hedge/entry\"",
                        holdSeconds,m_basket.layersOpen,m_basket.basketFloatingProfit,
                        (m_basket.basketFloatingProfit<0.0?m_basket.basketFloatingProfit:0.0));
            InitiateClose(CLOSE_MAX_HOLD);
           }
         return;
        }

      // Once thesis is invalid, recovery is permanently disabled for this basket.
      if(m_confluence!=NULL && !m_confluence.IsThesisValid(m_basket.direction))
        {
         if(m_basket.state!=BSTATE_THESIS_INVALIDATED)
           {
            m_basket.state=BSTATE_THESIS_INVALIDATED;
            m_basket.thesisInvalidatedTime=now;
            if(m_diag!=NULL) m_diag.OnThesisInvalidation();
            CDiagnosticEngine::LogThesisInvalid(m_currentBasketId,
                                                "H1/M15 thesis invalidated; recovery disabled");
           }

         long invalidAge=(long)(now-m_basket.thesisInvalidatedTime);
         // v3.3.3 PATCH OBJECTIVE #7 — LOSS MAGNITUDE CONTROL: once thesis is
         // invalid, don't always wait out the full grace period. If the
         // basket's actual floating loss has already reached the PREFERRED
         // risk budget (InpMaxBasketEquityRiskPercent — still well inside
         // the InpHardBasketEquityRiskPercent ceiling, which is never
         // touched by this patch), exit immediately under the existing
         // risk/thesis framework rather than hoping for a reversal.
         double equityNow=AccountInfoDouble(ACCOUNT_EQUITY);
         double lossRiskNow=(equityNow>0.0 && m_basket.basketFloatingProfit<0.0)
                             ? (-m_basket.basketFloatingProfit/equityNow)*100.0 : 0.0;
         bool graceExpired=(InpThesisInvalidationGraceMinutes<=0 ||
                             invalidAge>=InpThesisInvalidationGraceMinutes*60);
         bool damageControl=(lossRiskNow>=InpMaxBasketEquityRiskPercent);
         if(graceExpired || damageControl)
           InitiateClose(CLOSE_THESIS_INVALID);
         return;
        }

      if(m_basket.state==BSTATE_THESIS_INVALIDATED) return;

      // Recovery timeout is independent from total basket lifetime.
      if(m_basket.layersOpen>1 && m_basket.recoveryStartTime>0 &&
         InpRecoveryTimeoutMinutes>0 &&
         (now-m_basket.recoveryStartTime)>=InpRecoveryTimeoutMinutes*60)
        {
         m_basket.state=BSTATE_EXIT_PENDING;
         if(m_diag!=NULL) m_diag.OnRecoveryTimeoutExit();
         InitiateClose(CLOSE_RECOVERY_TIMEOUT);
         return;
        }

      if(m_news!=NULL && m_news.Evaluate())
        {
         if(m_diag!=NULL) m_diag.OnEntrySkippedNews();
         return;
        }

      double distance=ComputeLayerDistance();
      if(distance<=0.0) return;

      double curPrice=(m_basket.direction==CYCLE_BUY)?SymbolInfoDouble(m_symbol,SYMBOL_BID)
                                                       :SymbolInfoDouble(m_symbol,SYMBOL_ASK);
      double movedAgainst=(m_basket.direction==CYCLE_BUY)
                           ? (m_basket.lastLayerPrice-curPrice)
                           : (curPrice-m_basket.lastLayerPrice);
      if(movedAgainst<distance) return; // distance only arms evaluation

      // v3.3.3 PATCH OBJECTIVE #4 — EVENT-DRIVEN RECOVERY EVALUATION.
      // The recovery-distance threshold can stay "reached" for many ticks
      // (price hovering, or awaiting a new M5 bar). Only evaluate a given
      // opportunity — identified by (target layer, current M5 bar) — ONCE.
      // A new evaluation is allowed when a new M5 candle forms (a "new
      // market event" per the spec) or the target layer number changes.
      datetime curM5Bar=iTime(m_symbol,InpTfTrigger,0);
      bool isNewOpportunity=(curM5Bar!=m_lastRecoveryEvalBarTime) ||
                             (m_basket.layersOpen!=m_lastRecoveryEvalLayer);
      if(!isNewOpportunity)
        {
         // Same opportunity already evaluated this bar — stay silent,
         // no re-evaluation, no re-logging. Keep state as-is.
         if(m_basket.state==BSTATE_RECOVERY_EVALUATION) m_basket.state=BSTATE_ACTIVE;
         return;
        }
      m_lastRecoveryEvalBarTime=curM5Bar;
      m_lastRecoveryEvalLayer=m_basket.layersOpen;

      m_basket.state=BSTATE_RECOVERY_EVALUATION;

      double point=SymbolInfoDouble(m_symbol,SYMBOL_POINT);
      double movedPts=(point>0.0)?movedAgainst/point:0.0;
      double distPts=(point>0.0)?distance/point:0.0;
      int    targetLayer=m_basket.layersOpen+1;

      // v3.3.3 PATCH OBJECTIVE #1 — classify the adverse move BEFORE
      // attempting any recovery. Strong continuation against the basket
      // blocks recovery outright and lets thesis-invalidation/controlled-
      // exit logic (above, next tick once IsThesisValid() catches up, or
      // immediately if the continuation itself already broke H1/M15) take
      // over — this function never force-closes on classification alone.
      SConfluenceResult classFresh; string classReason;
      ENUM_ADVERSE_CLASSIFICATION cls=(m_confluence!=NULL)
         ? m_confluence.ClassifyAdverseMove(m_basket.direction,classFresh,classReason)
         : ADVERSE_NONE;

      if(cls==ADVERSE_CONTINUATION)
        {
         if(m_diag!=NULL) m_diag.OnRecoveryRejected();
         LogRecoveryRejectThrottled(targetLayer,classFresh.score,classReason);
         CDiagnosticEngine::LogRecoveryDecision(m_currentBasketId,false,targetLayer,
                                                movedPts,distPts,classFresh.score,classReason);
         m_basket.state=BSTATE_ACTIVE;
         return;
        }

      // v3.3.3 PATCH OBJECTIVE #2 — M5 remains the mandatory execution
      // confirmation (InpRequireM5Trigger untouched). ValidateRecoveryThesis
      // already enforces "direction == basket direction" and a fresh M5
      // trigger via the existing ConfluenceEngine infrastructure — reused
      // as-is here, not reimplemented.
      SConfluenceResult fresh;
      string thesisReason;
      bool freshOk=(m_confluence!=NULL &&
                    m_confluence.ValidateRecoveryThesis(m_basket.direction,fresh,thesisReason));

      if(!freshOk)
        {
         if(m_diag!=NULL) m_diag.OnRecoveryRejected();
         LogRecoveryRejectThrottled(targetLayer,fresh.score,thesisReason);
         CDiagnosticEngine::LogRecoveryDecision(m_currentBasketId,false,targetLayer,
                                                movedPts,distPts,fresh.score,thesisReason);
         m_basket.state=BSTATE_ACTIVE;
         return;
        }

      // v3.3.3 PATCH OBJECTIVE #3 — RECOVERY IS SELECTIVE BY LAYER NUMBER.
      // Layer 1 = normal entry (StartBasket, not here). Layer 2 = the
      // ValidateRecoveryThesis() check above (unchanged v3.3.x baseline).
      // Layer 3 = stronger score required. Layers 4-6 = full confluence +
      // mandatory M5 trigger (kept from v3.3.2) — and additionally, in a
      // classified RANGE (sideways) move, layers beyond 3 are refused
      // outright ("do not aggressively stack layers in sideways
      // conditions"). 6 layers remains the hard maximum (InpMaxLayers,
      // enforced above and in OnInit — unchanged).
      if(targetLayer==3 && fresh.score<InpRecoveryMinConfluenceScore+1)
        {
         if(m_diag!=NULL) m_diag.OnRecoveryRejected();
         string r="layer 3 requires stronger-than-normal fresh confluence";
         LogRecoveryRejectThrottled(targetLayer,fresh.score,r);
         CDiagnosticEngine::LogRecoveryDecision(m_currentBasketId,false,targetLayer,
                                                movedPts,distPts,fresh.score,r);
         m_basket.state=BSTATE_ACTIVE;
         return;
        }

      if(targetLayer>=4)
        {
         // Layers 4-6 are emergency territory: require the strongest fresh
         // confluence tier rather than treating them as normal averaging.
         if(fresh.score<InpMinConfluenceScore || !fresh.m5Trigger)
           {
            if(m_diag!=NULL) m_diag.OnRecoveryRejected();
            string r="layer 4+ requires full fresh confluence (rare/emergency recovery only)";
            LogRecoveryRejectThrottled(targetLayer,fresh.score,r);
            CDiagnosticEngine::LogRecoveryDecision(m_currentBasketId,false,targetLayer,
                                                   movedPts,distPts,fresh.score,r);
            m_basket.state=BSTATE_ACTIVE;
            return;
           }
        }

      if(targetLayer>=4 && cls==ADVERSE_RANGE)
        {
         if(m_diag!=NULL) m_diag.OnRecoveryRejected();
         string r="sideways/range conditions — no aggressive layer stacking beyond layer 3";
         LogRecoveryRejectThrottled(targetLayer,fresh.score,r);
         CDiagnosticEngine::LogRecoveryDecision(m_currentBasketId,false,targetLayer,
                                                movedPts,distPts,fresh.score,r);
         m_basket.state=BSTATE_ACTIVE;
         return;
        }

      double lot; string lotReason;
      if(!CLotSizing::GetAffordableLot(m_symbol,m_basket.direction,m_basket.selectedBaseLot,
                                       lot,lotReason,true))
        {
         if(m_diag!=NULL) m_diag.OnLayerSkippedMargin();
         m_basket.state=BSTATE_ACTIVE;
         CLogger::Info("PositionManager",StringFormat(
            "Recovery layer skipped — exact selected lot %.2f not safely affordable (%s).",
            m_basket.selectedBaseLot,lotReason));
         return;
        }

      // v3.3.1 PATCH P1: "dir" is not a parameter of TryAddRecoveryLayer() —
      // it was an undefined identifier (compile blocker). The correct value
      // is the basket's own locked-in direction.
      double projectedRisk=ProjectedBasketRiskPct(lot,true,m_basket.direction);
      m_basket.maxBasketRiskPct=MathMax(m_basket.maxBasketRiskPct,projectedRisk);
      if(projectedRisk>InpHardBasketEquityRiskPercent)
        {
         if(m_diag!=NULL) m_diag.OnBasketRiskRejected();
         CDiagnosticEngine::LogRiskReject(m_currentBasketId,projectedRisk,
                                           InpMaxBasketEquityRiskPercent,
                                           InpHardBasketEquityRiskPercent,
                                           "new recovery exceeds hard equity-risk ceiling");
         m_basket.state=BSTATE_ACTIVE;
         return;
        }

      string comment=BuildComment(m_currentBasketId);
      ulong ticket=0; string err;
      if(!m_tradeEngine.OpenMarket(m_basket.direction,lot,comment,ticket,err))
        {
         if(m_tradeEngine.WasMarketClosedEvent() && m_diag!=NULL) m_diag.OnMarketClosed();
         CLogger::Warn("PositionManager",StringFormat("Recovery layer broker rejection: %s",err));
         m_basket.state=BSTATE_ACTIVE;
         return;
        }

      if(ticket==0) ticket=ResolveExecutedTicket(comment);
      if(ticket==0)
        {
         CLogger::Error("PositionManager","Recovery layer executed but ticket unresolved after retries.");
         RegisterOrphan(comment,"recovery"); // sets BSTATE_ORPHAN_RECOVERY internally
         return;
        }

      int n=ArraySize(m_tickets);
      ArrayResize(m_tickets,n+1);
      m_tickets[n]=ticket;
      m_basket.layersOpen=n+1;
      m_basket.lastLayerPrice=curPrice;
      m_lastKnownStillOpen=n+1;
      if(m_basket.recoveryStartTime==0) m_basket.recoveryStartTime=now;
      m_basket.state=BSTATE_RECOVERY_ACTIVE;
      if(m_diag!=NULL) m_diag.OnRecoveryAccepted();

      CDiagnosticEngine::LogRecoveryDecision(m_currentBasketId,true,m_basket.layersOpen,
                                             movedPts,distPts,fresh.score,
                                             "distance + fresh thesis + equity risk passed");
      CDiagnosticEngine::LogEntry(m_currentBasketId,m_basket.direction,"recovery thesis confirmed",
                                  fresh,m_basket.layersOpen,curPrice,lot,GetLayerAtr(),
                                  (double)SymbolInfoInteger(m_symbol,SYMBOL_SPREAD),
                                  AccountInfoDouble(ACCOUNT_MARGIN_LEVEL),session);
      PersistState();
     }

   //=====================================================================
   // Hedge management (section 13) — called every tick while basket active.
   //=====================================================================
   // v3.3.0 PATCH 1: riskHalted blocks OPENING a new hedge only. Closing an
   // already-active hedge must keep working even while halted — halted means
   // "no new risk", not "stop managing what's already open" (existing
   // positions, including an open hedge, must still be safely manageable).
   void ManageHedge(const ENUM_SESSION_NAME session,const bool riskHalted)
     {
      if(!m_basket.active || m_closePending || m_hedge==NULL) return;
      if(!InpHedgeEnable) return;

      ENUM_HEDGE_STATE hs=m_hedge.Evaluate(m_basket.direction,IsBasketLosing());
      double structScore=m_hedge.OpposingStructureScore(m_basket.direction);
      m_basket.hedgeState=hs;

      // v3.3.2 issue #1: a confirmed partial hedge close is still in
      // progress — finish that first. Never re-evaluate open/close while
      // remaining volume hasn't been verified as zero.
      if(m_basket.hedgeActive && m_basket.hedgeCloseState==HEDGE_CLOSE_PARTIAL)
        {
         AttemptHedgeClose(hs);
         return;
        }

      // v3.3.3 PATCH OBJECTIVE #8 — MAX HOLD IS A TRUE HARD LIMIT: no NEW
      // hedge may open once the basket's lifetime cap is reached. An
      // already-open hedge must still be manageable/closeable — this only
      // blocks the OPEN path below, never the close path.
      long holdSecondsNow=(long)(TimeCurrent()-m_basket.cycleStartTime);
      bool maxHoldReached=(InpMaxBasketHoldMinutes>0 && holdSecondsNow>=InpMaxBasketHoldMinutes*60);
      if(maxHoldReached)
        {
         if(m_basket.hedgeActive &&
            (hs==HEDGE_NORMAL || hs==HEDGE_RECOVERY) &&
            structScore<InpHedgeMinStructureScore)
            AttemptHedgeClose(hs);
         return;
        }

      // v3.3.2 issue #2: never open a new hedge while a previous order's
      // execution is still unresolved.
      if(!riskHalted && !maxHoldReached && !m_basket.hedgeActive && !HasPendingOrphans() && hs==HEDGE_ACTIVE &&
         structScore>=InpHedgeMinStructureScore)
        {
         if(m_basket.lastHedgeCloseTime>0 &&
            (TimeCurrent()-m_basket.lastHedgeCloseTime)<InpHedgeCooldownMinutes*60)
           {
            if(m_diag!=NULL) m_diag.OnHedgeCooldownRejected();
            return;
           }

         double lot; string lotReason;
         double hedgeDesired=MathMin(InpHedgeLot,InpHedgeMaxLot);
         if(!CLotSizing::GetAffordableLot(m_symbol,OppositeDir(m_basket.direction),
                                          hedgeDesired,lot,lotReason,true))
           {
            if(m_diag!=NULL) m_diag.OnHedgeRejected();
            CLogger::Info("PositionManager",StringFormat("Hedge rejected — %s",lotReason));
            return;
           }

         // v3.3.1 PATCH P3: a hedge is protection only if its projected NET
         // exposure damage (basket + hedge evaluated under ONE coherent
         // price scenario) is lower than the unhedged basket's damage.
         // v3.3.0's ProjectedBasketRiskPct() evaluated the basket layers
         // against their own adverse move AND a candidate opposite-direction
         // lot against ITS OWN (opposite) adverse move — two contradictory
         // price scenarios added together, which could never show a hedge
         // reducing risk. ProjectedNetRiskPct() instead applies a single
         // adverse price move (against the basket's own direction) to every
         // position — basket layers, any existing hedge, and the candidate
         // hedge — so an opposing hedge position correctly nets off basket
         // loss instead of being double-counted as independent risk.
         double riskBefore=ProjectedNetRiskPct(0.0,false);
         double riskAfter=ProjectedNetRiskPct(lot,true);
         if(riskAfter>=riskBefore)
           {
            if(m_diag!=NULL) m_diag.OnHedgeRejected();
            CDiagnosticEngine::LogRiskReject(m_currentBasketId,riskAfter,
                                              InpMaxBasketEquityRiskPercent,
                                              InpHardBasketEquityRiskPercent,
                                              "hedge would not reduce projected net exposure risk");
            PrintFormat("[DTE][HEDGE][REJECT] reason=\"hedge does not reduce net risk\" "
                        "riskBefore=%.2f%% riskAfter=%.2f%%",riskBefore,riskAfter);
            return;
           }

         string comment=BuildComment(m_currentBasketId)+"H";
         ulong ticket=0; string err;
         ENUM_CYCLE_DIRECTION hedgeDir=OppositeDir(m_basket.direction);
         if(!m_tradeEngine.OpenMarket(hedgeDir,lot,comment,ticket,err))
           {
            if(m_tradeEngine.WasMarketClosedEvent() && m_diag!=NULL) m_diag.OnMarketClosed();
            if(m_diag!=NULL) m_diag.OnHedgeRejected();
            CLogger::Warn("PositionManager",StringFormat("Hedge open rejection: %s",err));
            return;
           }

         if(ticket==0) ticket=ResolveExecutedTicket(comment);
         if(ticket==0)
           {
            if(m_diag!=NULL) m_diag.OnHedgeRejected();
            CLogger::Error("PositionManager","Hedge executed but ticket unresolved after retries.");
            RegisterOrphan(comment,"hedge");
            return;
           }

         m_basket.hedgeActive=true;
         m_basket.hedgeTicket=ticket;
         m_basket.state=BSTATE_HEDGE_ACTIVE;
         if(m_diag!=NULL) m_diag.OnHedgeOpened();
         CDiagnosticEngine::LogHedgeEvent(m_currentBasketId,true,hs,
            StringFormat("confirmed M15 reversal structure score=%.1f; max 1 active hedge",structScore));
         PersistState();
        }
      else if(m_basket.hedgeActive &&
              (hs==HEDGE_NORMAL || hs==HEDGE_RECOVERY) &&
              structScore<InpHedgeMinStructureScore)
        {
         AttemptHedgeClose(hs);
        }
     }

   //=====================================================================
   // Call every tick while a basket is active. Handles TP, spike-exit,
   // margin-call reconciliation, and close-safety retries.
   //=====================================================================
   void UpdateAndCheckTp()
     {
      if(!m_basket.active) return;

      if(m_closePending)
        {
         AttemptCloseRetry();
         return;
        }

      double floating=0.0;
      int stillOpen=0;
      for(int i=0;i<ArraySize(m_tickets);i++)
        {
         if(PositionSelectByTicket(m_tickets[i]))
           {
            floating += PositionGetDouble(POSITION_PROFIT)+PositionGetDouble(POSITION_SWAP);
            floating += BestEffortEntryCommission(m_tickets[i]);
            stillOpen++;
           }
        }
      if(m_basket.hedgeActive && PositionSelectByTicket(m_basket.hedgeTicket))
        {
         floating += PositionGetDouble(POSITION_PROFIT)+PositionGetDouble(POSITION_SWAP);
         floating += BestEffortEntryCommission(m_basket.hedgeTicket);
        }

      m_basket.basketFloatingProfit=floating;
      if(floating>m_basket.peakFloatingProfit)
        {
         m_basket.peakFloatingProfit=floating;
         m_basket.peakFloatingTime=TimeCurrent();
        }

      if(stillOpen!=m_lastKnownStillOpen)
        {
         if(stillOpen>0 && stillOpen<ArraySize(m_tickets))
            CLogger::Warn("PositionManager",StringFormat(
               "Partial stop-out detected: %d/%d layers remain open.",stillOpen,ArraySize(m_tickets)));
         m_basket.layersOpen=stillOpen;
         m_lastKnownStillOpen=stillOpen;
         PersistState();
        }

      if(stillOpen==0 && ArraySize(m_tickets)>0)
        {
         CLogger::Warn("PositionManager","All basket layers closed externally (likely margin call/stop-out).");
         FinalizeBasket(CLOSE_MARGIN_CALL_EXT);
         return;
        }

      long holdSeconds=(long)(TimeCurrent()-m_basket.cycleStartTime);
      if(InpMaxBasketHoldMinutes>0 && holdSeconds>=InpMaxBasketHoldMinutes*60)
        {
         if(m_diag!=NULL) m_diag.OnMaxHoldExit();
         InitiateClose(CLOSE_MAX_HOLD);
         return;
        }

      double equity=AccountInfoDouble(ACCOUNT_EQUITY);
      double actualLossRisk=(equity>0.0 && floating<0.0)
                             ? (-floating/equity)*100.0 : 0.0;
      if(m_diag!=NULL) m_diag.RecordBasketRisk(actualLossRisk);
      if(actualLossRisk>=InpHardBasketEquityRiskPercent)
        {
         if(m_diag!=NULL) m_diag.OnBasketRiskRejected();
         CDiagnosticEngine::LogRiskReject(m_currentBasketId,actualLossRisk,
                                           InpMaxBasketEquityRiskPercent,
                                           InpHardBasketEquityRiskPercent,
                                           "actual floating loss reached hard equity-risk ceiling");
         InitiateClose(CLOSE_RISK_LIMIT);
         return;
        }

      // v3.3.1 PATCH P4: spike exit must be evaluated BEFORE the ordinary
      // basket TP check. In v3.3.0, TP (default 0.20% of cycle-start
      // balance) ran first and InpSpikeExitMinPercent defaults to 0.25% —
      // a higher threshold — so a basket almost always hit ordinary TP
      // before it could ever reach the spike-exit profitability floor,
      // making CLOSE_SPIKE_EXIT effectively unreachable. Spike detection
      // itself (CheckSpikeExit) is unchanged — it still requires the
      // basket to already be at InpSpikeExitMinPercent profit AND a fast
      // favorable move within the window, so trivial small-profit ticks
      // still cannot trigger it; this only fixes the evaluation ORDER.
      if(InpUseSpikeExit && CheckSpikeExit(floating))
        {
         InitiateClose(CLOSE_SPIKE_EXIT);
         return;
        }

      if(floating>=m_basket.basketTpTarget)
        {
         InitiateClose(CLOSE_TP);
         return;
        }

      if(m_basket.state==BSTATE_THESIS_INVALIDATED &&
         m_basket.thesisInvalidatedTime>0 &&
         (TimeCurrent()-m_basket.thesisInvalidatedTime)>=InpThesisInvalidationGraceMinutes*60)
        {
         InitiateClose(CLOSE_THESIS_INVALID);
         return;
        }
     }

   void ManageProtection()
     {
      // No per-position SL/BE/trailing in this strategy — unchanged.
      // v3.3.2: this is also the tick hook used to drive orphan-position
      // recovery retries (issue #2). It must run every tick regardless of
      // basket-active state, since an orphan can exist even when
      // m_basket.active is still false (e.g. layer #1 orphaned before the
      // basket was ever marked active).
      ProcessOrphanRecovery();
     }

   // v3.3.2 — issue #2: true while any order execution is still unresolved
   // (not yet attached to tracking, not yet verified closed). Composition
   // root doesn't need to check this directly — StartBasket()/
   // TryAddRecoveryLayer()/ManageHedge() all self-guard on it, same pattern
   // already used for the halted flag.
   bool HasPendingOrphans() const { return ArraySize(m_orphans)>0; }
   int  PendingOrphanCount() const { return ArraySize(m_orphans); }

private:
   double ProjectedBasketRiskPct(const double newLot,const bool includeNewLayer,const ENUM_CYCLE_DIRECTION extraDir=CYCLE_NONE) const
     {
      double equity=AccountInfoDouble(ACCOUNT_EQUITY);
      if(equity<=0.0) return 100.0;

      double currentFloatingLoss=0.0;
      for(int i=0;i<ArraySize(m_tickets);i++)
        {
         if(PositionSelectByTicket(m_tickets[i]))
           {
            double p=PositionGetDouble(POSITION_PROFIT)+PositionGetDouble(POSITION_SWAP);
            currentFloatingLoss += (p<0.0 ? -p : 0.0);
           }
        }
      if(m_basket.hedgeActive && PositionSelectByTicket(m_basket.hedgeTicket))
        {
         double hp=PositionGetDouble(POSITION_PROFIT)+PositionGetDouble(POSITION_SWAP);
         currentFloatingLoss += (hp<0.0 ? -hp : 0.0);
        }

      double atr=GetLayerAtr();
      if(atr<=0.0) return 100.0;
      double adverseMove=atr*InpRecoveryRiskAtrMultiple;
      double ask=SymbolInfoDouble(m_symbol,SYMBOL_ASK);
      double bid=SymbolInfoDouble(m_symbol,SYMBOL_BID);
      double adversePriceBuy=bid-adverseMove;
      double adversePriceSell=ask+adverseMove;
      double projectedAdditional=0.0;

      for(int i=0;i<ArraySize(m_tickets);i++)
        {
         if(!PositionSelectByTicket(m_tickets[i])) continue;
         ENUM_POSITION_TYPE ptype=(ENUM_POSITION_TYPE)PositionGetInteger(POSITION_TYPE);
         double volume=PositionGetDouble(POSITION_VOLUME);
         ENUM_ORDER_TYPE otype=(ptype==POSITION_TYPE_BUY)?ORDER_TYPE_BUY:ORDER_TYPE_SELL;
         double fromPrice=(ptype==POSITION_TYPE_BUY)?bid:ask;
         double toPrice=(ptype==POSITION_TYPE_BUY)?adversePriceBuy:adversePriceSell;
         double loss=0.0;
         if(OrderCalcProfit(otype,m_symbol,volume,fromPrice,toPrice,loss) && loss<0.0)
            projectedAdditional += -loss;
        }

      if(includeNewLayer && newLot>0.0)
        {
         ENUM_CYCLE_DIRECTION projectedDir=(extraDir==CYCLE_NONE)?m_basket.direction:extraDir;
         ENUM_ORDER_TYPE otype=(projectedDir==CYCLE_BUY)?ORDER_TYPE_BUY:ORDER_TYPE_SELL;
         double fromPrice=(projectedDir==CYCLE_BUY)?ask:bid;
         double toPrice=(projectedDir==CYCLE_BUY)?adversePriceBuy:adversePriceSell;
         double loss=0.0;
         if(OrderCalcProfit(otype,m_symbol,newLot,fromPrice,toPrice,loss) && loss<0.0)
            projectedAdditional += -loss;
        }

      double buffer=projectedAdditional*(InpRiskSpreadSlippagePercent/100.0);
      double totalDamage=currentFloatingLoss+projectedAdditional+buffer;
      double riskPct=(totalDamage/equity)*100.0;
      return riskPct;
     }

   //=====================================================================
   // v3.3.1 PATCH P3 — NET exposure risk model, used only for hedge
   // accept/reject decisions. Applies a SINGLE coherent adverse price
   // scenario (price moving against the basket's own direction) to every
   // position that would exist under the candidate — basket layers, an
   // already-open hedge, and the candidate new hedge — and nets their
   // signed P/L. An opposing-direction hedge naturally offsets basket loss
   // in this single scenario instead of being treated as independent risk.
   //=====================================================================
   double ProjectedNetRiskPct(const double candidateHedgeLot,const bool includeCandidateHedge) const
     {
      double equity=AccountInfoDouble(ACCOUNT_EQUITY);
      if(equity<=0.0) return 100.0;

      double atr=GetLayerAtr();
      if(atr<=0.0) return 100.0;
      double adverseMove=atr*InpRecoveryRiskAtrMultiple;

      double bid=SymbolInfoDouble(m_symbol,SYMBOL_BID);
      double ask=SymbolInfoDouble(m_symbol,SYMBOL_ASK);

      // One coherent scenario: price moves against the basket's own direction.
      bool basketIsBuy=(m_basket.direction==CYCLE_BUY);
      double scenarioPrice = basketIsBuy ? (bid-adverseMove) : (ask+adverseMove);

      double netPnl=0.0; // signed — negative means net loss under the scenario

      for(int i=0;i<ArraySize(m_tickets);i++)
        {
         if(!PositionSelectByTicket(m_tickets[i])) continue;
         ENUM_POSITION_TYPE ptype=(ENUM_POSITION_TYPE)PositionGetInteger(POSITION_TYPE);
         double volume=PositionGetDouble(POSITION_VOLUME);
         ENUM_ORDER_TYPE otype=(ptype==POSITION_TYPE_BUY)?ORDER_TYPE_BUY:ORDER_TYPE_SELL;
         double fromPrice=(ptype==POSITION_TYPE_BUY)?bid:ask;
         double pnl=0.0;
         if(OrderCalcProfit(otype,m_symbol,volume,fromPrice,scenarioPrice,pnl))
            netPnl+=pnl;
        }

      if(m_basket.hedgeActive && PositionSelectByTicket(m_basket.hedgeTicket))
        {
         ENUM_POSITION_TYPE ptype=(ENUM_POSITION_TYPE)PositionGetInteger(POSITION_TYPE);
         double volume=PositionGetDouble(POSITION_VOLUME);
         ENUM_ORDER_TYPE otype=(ptype==POSITION_TYPE_BUY)?ORDER_TYPE_BUY:ORDER_TYPE_SELL;
         double fromPrice=(ptype==POSITION_TYPE_BUY)?bid:ask;
         double pnl=0.0;
         if(OrderCalcProfit(otype,m_symbol,volume,fromPrice,scenarioPrice,pnl))
            netPnl+=pnl;
        }

      if(includeCandidateHedge && candidateHedgeLot>0.0)
        {
         ENUM_CYCLE_DIRECTION hedgeDir=OppositeDir(m_basket.direction);
         ENUM_ORDER_TYPE otype=(hedgeDir==CYCLE_BUY)?ORDER_TYPE_BUY:ORDER_TYPE_SELL;
         double fromPrice=(hedgeDir==CYCLE_BUY)?ask:bid; // opening price for a new position
         double pnl=0.0;
         if(OrderCalcProfit(otype,m_symbol,candidateHedgeLot,fromPrice,scenarioPrice,pnl))
            netPnl+=pnl;
        }

      double netLoss=(netPnl<0.0)?-netPnl:0.0;
      double buffer=netLoss*(InpRiskSpreadSlippagePercent/100.0);
      double riskPct=((netLoss+buffer)/equity)*100.0;
      return riskPct;
     }

   double CurrentBasketExposureLots() const
     {
      double lots=0.0;
      for(int i=0;i<ArraySize(m_tickets);i++)
        if(PositionSelectByTicket(m_tickets[i]))
           lots+=PositionGetDouble(POSITION_VOLUME);
      return lots;
     }

   ENUM_CYCLE_DIRECTION OppositeDir(const ENUM_CYCLE_DIRECTION d) const
     { return (d==CYCLE_BUY)?CYCLE_SELL:CYCLE_BUY; }

   bool IsBasketLosing() const { return m_basket.basketFloatingProfit<0.0; }

   double GetLayerAtr() const
     {
      if(m_layerAtrHandle==INVALID_HANDLE) return 0.0;
      double buf[]; ArraySetAsSeries(buf,true);
      if(CopyBuffer(m_layerAtrHandle,0,1,1,buf)<=0) return 0.0;
      return buf[0];
     }

   // v3.2.0 section 19 — audit log for every adaptive lot decision at basket open.
   void LogAdaptiveLot(const double selectedLot,const string reason) const
     {
      double exposure=CLotSizing::EstimateFullBasketExposureLots(selectedLot,InpMaxLayers);
      Print("[DTE] DTE ADAPTIVE LOT");
      PrintFormat("  Balance: %.2f",AccountInfoDouble(ACCOUNT_BALANCE));
      PrintFormat("  Equity: %.2f",AccountInfoDouble(ACCOUNT_EQUITY));
      PrintFormat("  Free Margin: %.2f",AccountInfoDouble(ACCOUNT_MARGIN_FREE));
      PrintFormat("  Selected Lot: %.2f",selectedLot);
      PrintFormat("  Max Layers: %d",InpMaxLayers);
      PrintFormat("  Estimated Basket Exposure: %.2f lots",exposure);
      PrintFormat("  Reason: %s",reason);
     }

   //=====================================================================
   // Layer distance (section 11): ATR(M5)*multiplier, floored by a minimum
   // points distance, and validated against spread + broker stop/freeze
   // levels so we never compute a distance smaller than what the broker
   // would even allow as meaningfully separated orders.
   //=====================================================================
   double ComputeLayerDistance() const
     {
      double atr=GetLayerAtr();
      double point=SymbolInfoDouble(m_symbol,SYMBOL_POINT);
      double atrDistance=atr*InpLayerAtrMultiplier;
      double minFloor=InpMinLayerDistancePoints*point;

      double distance=MathMax(atrDistance,minFloor);

      double stopLevelPts=(double)SymbolInfoInteger(m_symbol,SYMBOL_TRADE_STOP_LEVEL);
      double freezeLevelPts=(double)SymbolInfoInteger(m_symbol,SYMBOL_TRADE_FREEZE_LEVEL);
      double brokerFloor=MathMax(stopLevelPts,freezeLevelPts)*point;
      double spreadPts=(double)SymbolInfoInteger(m_symbol,SYMBOL_SPREAD)*point;

      distance=MathMax(distance,brokerFloor);
      distance=MathMax(distance,spreadPts*2.0); // never smaller than 2x current spread

      return distance;
     }

   //=====================================================================
   // v3.3.3 PATCH OBJECTIVE #5 — RECOVERY REJECTION LOGGING, throttled.
   // Prints once per distinct (layer, reason) opportunity, then stays
   // silent — internal repeat counter still increments — until the
   // opportunity or the reason actually changes. Combined with the
   // event-driven throttle in TryAddRecoveryLayer() (objective #4), this
   // keeps the Experts log from printing thousands of identical
   // "RECOVERY REJECTED" lines for one unresolved opportunity.
   //=====================================================================
   void LogRecoveryRejectThrottled(const int layer,const int score,const string reason)
     {
      if(m_lastRecoveryRejectLayer==layer && m_lastRecoveryRejectReason==reason)
        {
         m_recoveryRejectRepeatCount++;
         return; // same opportunity, already logged once — remain silent
        }

      m_lastRecoveryRejectLayer=layer;
      m_lastRecoveryRejectReason=reason;
      m_recoveryRejectRepeatCount=0;

      PrintFormat("[DTE][RECOVERY][REJECT] opportunity_id=%I64u_%d layer=%d reason=\"%s\" score=%d direction=%s",
                  m_currentBasketId,layer,layer,reason,score,
                  (m_basket.direction==CYCLE_BUY?"BUY":"SELL")); // opportunity_id = basketId_targetLayer
     }

   //=====================================================================
   // Spike exit (section 16): basket already meaningfully profitable AND
   // the underlying price has moved favorably by >= InpSpikeExitTriggerPoints
   // within the last InpSpikeExitWindowSeconds (measured on M1 closes).
   //=====================================================================
   // v3.3.3 PATCH OBJECTIVE #9 — instrumented with diagnostics at every
   // rejection point so the forensic summary can explain WHY SpikeExit was
   // 0 (or low) in the baseline. Algorithm itself is UNCHANGED — same
   // thresholds, same order of checks — only counters were added.
   bool CheckSpikeExit(const double floating) const
     {
      if(m_diag!=NULL) m_diag.OnSpikeEvaluated();

      if(floating<(InpSpikeExitMinPercent/100.0)*m_basket.cycleStartBalance)
        {
         if(m_diag!=NULL) m_diag.OnSpikeRejectedByProfit();
         return false;
        }
      if(m_diag!=NULL) m_diag.OnSpikeCandidate();

      datetime pastTime=TimeCurrent()-InpSpikeExitWindowSeconds;
      int shift=iBarShift(m_symbol,PERIOD_M1,pastTime,false);
      if(shift<0)
        {
         if(m_diag!=NULL) m_diag.OnSpikeRejectedByWindow();
         return false;
        }

      double pastPrice=iClose(m_symbol,PERIOD_M1,shift);
      if(pastPrice<=0.0)
        {
         if(m_diag!=NULL) m_diag.OnSpikeRejectedByWindow();
         return false;
        }

      double curPrice=(m_basket.direction==CYCLE_BUY)?SymbolInfoDouble(m_symbol,SYMBOL_BID)
                                                       :SymbolInfoDouble(m_symbol,SYMBOL_ASK);
      double point=SymbolInfoDouble(m_symbol,SYMBOL_POINT);
      double movePts = (m_basket.direction==CYCLE_BUY) ? (curPrice-pastPrice)/point
                                                         : (pastPrice-curPrice)/point;
      double atr=GetLayerAtr();
      double atrPts=(point>0.0 && atr>0.0)?(atr/point)*InpSpikeExitMinAtrMultiple:0.0;
      double triggerPts=MathMax(InpSpikeExitTriggerPoints,atrPts);

      bool pass=(movePts>=triggerPts);
      if(!pass)
        {
         // Distinguish "the ATR-scaled floor is what's binding" from "the
         // raw configured points threshold is what's binding" for audit
         // clarity — does not change the trigger decision itself.
         if(m_diag!=NULL)
           {
            if(atrPts>InpSpikeExitTriggerPoints) m_diag.OnSpikeRejectedByAtr();
            else                                 m_diag.OnSpikeRejectedByMove();
           }
         return false;
        }

      if(m_diag!=NULL) m_diag.OnSpikeAccepted();
      return true;
     }

   // Best-effort: sums commission already charged on deals belonging to this
   // position so far (entry side). Exit-side commission is not knowable
   // until the position actually closes, so this is an approximation, not
   // an exact net figure — documented limitation (section 15).
   double BestEffortEntryCommission(const ulong ticket) const
     {
      double total=0.0;
      if(!HistorySelectByPosition(ticket)) return 0.0;
      int total_deals=HistoryDealsTotal();
      for(int i=0;i<total_deals;i++)
        {
         ulong dealTicket=HistoryDealGetTicket(i);
         if(dealTicket==0) continue;
         total+=HistoryDealGetDouble(dealTicket,DEAL_COMMISSION);
        }
      return total;
     }

   //=====================================================================
   // CRITICAL close-safety (section 17): never finalize until every
   // position is verified actually closed. Retries safely, logs failures,
   // and NEVER clears state while orphan positions remain.
   //=====================================================================
   void InitiateClose(const ENUM_BASKET_CLOSE_REASON reason)
     {
      if(m_closePending) return;
      m_closePending=true;
      m_basket.state=BSTATE_CLOSING;
      m_closePendingReason=reason;
      PersistState();
      AttemptCloseRetry();
     }

   //=====================================================================
   // v3.3.2 — issue #1: hedge close, verified. CTradeEngine::
   // ClosePositionByTicket() returning true (or retcode DONE/DONE_PARTIAL)
   // means the request was accepted, NOT that the position is gone —
   // TRADE_RETCODE_DONE_PARTIAL specifically means only part of the volume
   // closed. This method NEVER clears hedgeActive/hedgeTicket from the
   // trade-call result alone: it always re-selects the position afterward
   // and only finalizes once that re-select confirms it's actually absent
   // (or, on the very first call, already absent — e.g. closed externally
   // by a margin call). A confirmed non-zero remaining volume is recorded
   // as HEDGE_CLOSE_PARTIAL and retried on a cooldown, never every tick.
   //=====================================================================
   void AttemptHedgeClose(const ENUM_HEDGE_STATE hs)
     {
      datetime now=TimeCurrent();
      if(m_basket.hedgeCloseState==HEDGE_CLOSE_PARTIAL && now<m_basket.hedgeCloseRetryTime)
         return; // cooldown — do not spam close requests every tick

      if(!PositionSelectByTicket(m_basket.hedgeTicket))
        {
         // Already gone — either never needed a request this call, or a
         // previous session/tick's close already fully succeeded.
         FinalizeHedgeClosed(hs);
         return;
        }

      double volBefore=PositionGetDouble(POSITION_VOLUME);
      ulong  ticket=m_basket.hedgeTicket;

      string err;
      m_tradeEngine.ClosePositionByTicket(ticket,err); // result intentionally not trusted alone — see below
      uint rc=m_tradeEngine.LastCloseRetcode();

      // Always re-verify actual MT5 position state — never infer from the
      // boolean/retcode above.
      bool stillOpen=PositionSelectByTicket(ticket);
      double volAfter=stillOpen?PositionGetDouble(POSITION_VOLUME):0.0;

      if(!stillOpen || volAfter<=0.0)
        {
         FinalizeHedgeClosed(hs);
         return;
        }

      // Confirmed partial (or outright failed) close — remaining volume > 0.
      // hedgeActive/hedgeTicket stay exactly as they were; only the
      // close-state/retry bookkeeping changes.
      m_basket.hedgeCloseState=HEDGE_CLOSE_PARTIAL;
      m_basket.hedgeRemainingVolume=volAfter;
      m_basket.hedgeCloseRetryTime=now+InpHedgeCloseRetrySeconds;
      PersistState();

      PrintFormat("[DTE][HEDGE][PARTIAL_CLOSE] ticket=%d requested=%.2f remaining=%.2f retcode=%d",
                  (int)ticket,volBefore,volAfter,rc);
     }

   void FinalizeHedgeClosed(const ENUM_HEDGE_STATE hs)
     {
      if(m_diag!=NULL) m_diag.OnHedgeClosed();
      CDiagnosticEngine::LogHedgeEvent(m_currentBasketId,false,hs,
         "opposing structure faded — verified fully closed (volume=0)");
      m_basket.hedgeActive=false;
      m_basket.hedgeTicket=0;
      m_basket.hedgeCloseState=HEDGE_CLOSE_NONE;
      m_basket.hedgeRemainingVolume=0.0;
      m_basket.hedgeCloseRetryTime=0;
      m_basket.lastHedgeCloseTime=TimeCurrent();
      m_basket.state=(m_basket.state==BSTATE_THESIS_INVALIDATED)?BSTATE_THESIS_INVALIDATED:BSTATE_ACTIVE;
      PersistState();
     }

   void AttemptCloseRetry()
     {
      bool allClosed=true;

      if(m_tradeEngine!=NULL && m_tradeEngine.MarketClosedUntil()>TimeCurrent())
        {
         // Market-closed is a state, not a per-tick retry condition.
         return;
        }

      for(int i=0;i<ArraySize(m_tickets);i++)
        {
         if(PositionSelectByTicket(m_tickets[i]))
           {
            allClosed=false;
            string err;
            if(!m_tradeEngine.ClosePositionByTicket(m_tickets[i],err))
               CLogger::Warn("PositionManager",StringFormat(
                  "Close retry failed ticket=%d err=%s",(int)m_tickets[i],err));
           }
        }

      if(m_basket.hedgeActive && PositionSelectByTicket(m_basket.hedgeTicket))
        {
         allClosed=false;
         string err;
         if(!m_tradeEngine.ClosePositionByTicket(m_basket.hedgeTicket,err))
            CLogger::Warn("PositionManager",StringFormat(
               "Hedge close retry failed ticket=%d err=%s",(int)m_basket.hedgeTicket,err));
        }

      if(allClosed)
        {
         m_closePending=false;
         FinalizeBasket(m_closePendingReason);
        }
      else
        {
         if(m_diag!=NULL) m_diag.OnCloseVerifyRetry();
         CLogger::Warn("PositionManager",
            "Basket close verification: one or more positions still open — "
            "state kept alive, will retry next tick. NOT finalizing.");
        }
     }

   void FinalizeBasket(const ENUM_BASKET_CLOSE_REASON reason)
     {
      long holdSeconds=(long)(TimeCurrent()-m_basket.cycleStartTime);
      if(m_diag!=NULL) m_diag.OnBasketClosed(reason,m_basket.layersOpen,holdSeconds);

      // v3.3.3 PATCH OBJECTIVE #6 — LOSS ANATOMY: only recorded when this
      // basket's final net result was actually negative. Never touched for
      // winning baskets (which is the overwhelming majority, per baseline
      // win rate — this is deliberately the minority-case forensic trail).
      if(m_diag!=NULL && m_basket.basketFloatingProfit<0.0)
         m_diag.OnBasketClosedLoss(reason,m_basket.basketFloatingProfit,holdSeconds);

      CDiagnosticEngine::LogClose(m_currentBasketId,reason,m_basket.layersOpen,
                                   m_basket.basketFloatingProfit,holdSeconds);

      ZeroMemory(m_basket);
      ArrayResize(m_tickets,0);
      m_lastKnownStillOpen=0;
      m_closePending=false;
      // v3.3.3: reset recovery-evaluation/rejection throttle state too —
      // a new basket must start with a clean opportunity-tracking slate.
      m_lastRecoveryEvalBarTime=0;
      m_lastRecoveryEvalLayer=0;
      m_lastRecoveryRejectReason="";
      m_lastRecoveryRejectLayer=0;
      m_recoveryRejectRepeatCount=0;
      ClearPersistedState();
     }

   string BuildComment(const ulong basketId) const
     {
      return InpTradeComment+"_"+IntegerToString(basketId);
     }

   bool IsTicketTracked(const ulong ticket) const
     {
      for(int i=0;i<ArraySize(m_tickets);i++)
         if(m_tickets[i]==ticket) return true;
      if(ticket==m_basket.hedgeTicket) return true;
      // v3.3.2: also exclude tickets already claimed by an in-progress
      // orphan record, so two orphan entries (or an orphan entry and the
      // normal fallback lookup) can never both attach to the same position.
      for(int i=0;i<ArraySize(m_orphans);i++)
         if(m_orphans[i].ticketKnown && m_orphans[i].ticket==ticket) return true;
      return false;
     }

   //=====================================================================
   // v3.3.1 PATCH P5 — orphan-position protection.
   // ResolveExecutedTicket(): after an apparently-successful order whose
   // ticket wasn't immediately resolvable via ResultDeal(), retries the
   // symbol+magic+comment rescan a few times (a broker/terminal can have a
   // short delay before the new position is visible to PositionsTotal()).
   //=====================================================================
   ulong ResolveExecutedTicket(const string expectedComment) const
     {
      ulong ticket=FallbackFindUntrackedTicket(expectedComment);
      for(int attempt=0; attempt<3 && ticket==0; attempt++)
        {
         Sleep(200);
         ticket=FallbackFindUntrackedTicket(expectedComment);
        }
      return ticket;
     }

   //=====================================================================
   // v3.3.2 PATCH — issue #2: orphan-position recovery, tracked until
   // resolved. Superseded the v3.3.1 one-shot AttemptOrphanClose(), which
   // could return to normal state without guaranteeing the orphan stayed
   // tracked if its single close attempt failed. RegisterOrphan() records
   // the unresolved order; ProcessOrphanRecovery() (driven every tick from
   // ManageProtection()) keeps retrying — re-resolve, then safe-close, then
   // re-verify — on a cooldown, until the position is either attached to
   // normal tracking or confirmed fully closed. Never dropped in between.
   //=====================================================================
   void RegisterOrphan(const string expectedComment,const string context)
     {
      int n=ArraySize(m_orphans);
      ArrayResize(m_orphans,n+1);
      m_orphans[n].ticket=0;
      m_orphans[n].ticketKnown=false;
      m_orphans[n].expectedComment=expectedComment;
      m_orphans[n].context=context;
      m_orphans[n].nextRetryTime=0; // eligible for the first attempt on the very next tick
      m_orphans[n].attempts=0;

      // Visible on the dashboard/state machine even though m_basket may not
      // be active yet (e.g. a layer #1 orphan) — only set it when there IS
      // an active basket to mark.
      if(m_basket.active) m_basket.state=BSTATE_ORPHAN_RECOVERY;

      PrintFormat("[DTE][EXECUTION][ORPHAN_DETECTED] symbol=%s magic=%d expectedComment=%s context=%s",
                  m_symbol,(int)m_magic,expectedComment,context);
     }

   // Driven every tick (via ManageProtection()) regardless of basket-active
   // state. Cooldown-gated per orphan record — never spams a request every
   // tick. Never removes a record except on confirmed resolution.
   void ProcessOrphanRecovery()
     {
      datetime now=TimeCurrent();

      for(int i=ArraySize(m_orphans)-1; i>=0; i--)
        {
         if(now<m_orphans[i].nextRetryTime) continue;

         if(!m_orphans[i].ticketKnown)
           {
            ulong t=FallbackFindUntrackedTicket(m_orphans[i].expectedComment);
            if(t==0)
              {
               // Still not found by identity rescan — keep waiting; do not
               // guess, do not touch any other position.
               m_orphans[i].attempts++;
               m_orphans[i].nextRetryTime=now+InpOrphanCloseRetrySeconds;
               continue;
              }
            m_orphans[i].ticket=t;
            m_orphans[i].ticketKnown=true;
            PrintFormat("[DTE][EXECUTION][ORPHAN_TRACKED] symbol=%s ticket=%d magic=%d context=%s",
                        m_symbol,(int)t,(int)m_magic,m_orphans[i].context);
           }

         if(!PositionSelectByTicket(m_orphans[i].ticket))
           {
            // Gone — resolved (closed by us, by the broker, or the order
            // never actually filled after all).
            PrintFormat("[DTE][EXECUTION][ORPHAN_CLOSED] symbol=%s ticket=%d magic=%d context=%s attempts=%d",
                        m_symbol,(int)m_orphans[i].ticket,(int)m_magic,m_orphans[i].context,m_orphans[i].attempts);
            RemoveOrphanAt(i);
            continue;
           }

         // Strict identity re-check before ever touching it — never close
         // based on a stale ticket that might now refer to something else.
         if(PositionGetString(POSITION_SYMBOL)!=m_symbol ||
            (long)PositionGetInteger(POSITION_MAGIC)!=m_magic ||
            PositionGetString(POSITION_COMMENT)!=m_orphans[i].expectedComment)
           {
            PrintFormat("[DTE][EXECUTION][ORPHAN_FAILURE] symbol=%s ticket=%d magic=%d context=%s "
                        "reason=\"identity no longer matches on retry — will not touch, keeping tracked\"",
                        m_symbol,(int)m_orphans[i].ticket,(int)m_magic,m_orphans[i].context);
            m_orphans[i].attempts++;
            m_orphans[i].nextRetryTime=now+InpOrphanCloseRetrySeconds;
            continue;
           }

         double vol=PositionGetDouble(POSITION_VOLUME);
         ENUM_POSITION_TYPE ptype=(ENUM_POSITION_TYPE)PositionGetInteger(POSITION_TYPE);

         string err;
         m_orphans[i].attempts++;
         m_tradeEngine.ClosePositionByTicket(m_orphans[i].ticket,err); // result not trusted alone
         uint rc=m_tradeEngine.LastCloseRetcode();

         bool stillOpen=PositionSelectByTicket(m_orphans[i].ticket);
         if(!stillOpen)
           {
            PrintFormat("[DTE][EXECUTION][ORPHAN_CLOSED] symbol=%s ticket=%d dir=%s volume=%.2f magic=%d "
                        "context=%s attempts=%d",
                        m_symbol,(int)m_orphans[i].ticket,(ptype==POSITION_TYPE_BUY?"BUY":"SELL"),
                        vol,(int)m_magic,m_orphans[i].context,m_orphans[i].attempts);
            RemoveOrphanAt(i);
           }
         else
           {
            m_orphans[i].nextRetryTime=now+InpOrphanCloseRetrySeconds;
            PrintFormat("[DTE][EXECUTION][ORPHAN_CLOSE_RETRY] symbol=%s ticket=%d dir=%s volume=%.2f magic=%d "
                        "context=%s attempts=%d retcode=%d err=%s",
                        m_symbol,(int)m_orphans[i].ticket,(ptype==POSITION_TYPE_BUY?"BUY":"SELL"),
                        vol,(int)m_magic,m_orphans[i].context,m_orphans[i].attempts,rc,err);
           }
        }

      // Once every orphan is resolved, release the basket-level marker
      // (if it was set) back to normal — TryAddRecoveryLayer()'s own
      // thesis/state checks will re-derive whatever state actually applies.
      if(ArraySize(m_orphans)==0 && m_basket.active && m_basket.state==BSTATE_ORPHAN_RECOVERY)
         m_basket.state=BSTATE_ACTIVE;
     }

   void RemoveOrphanAt(const int idx)
     {
      int n=ArraySize(m_orphans);
      for(int j=idx; j<n-1; j++) m_orphans[j]=m_orphans[j+1];
      ArrayResize(m_orphans,n-1);
     }

   // Fallback only — used when ResultDeal()->DEAL_POSITION_ID wasn't resolvable.
   // Matches by symbol+magic+comment (section 18) rather than just newest time,
   // so it never accidentally picks up another EA's or another basket's position.
   ulong FallbackFindUntrackedTicket(const string expectedComment) const
     {
      ulong best=0;
      datetime bestTime=0;
      int total=PositionsTotal();
      for(int i=0;i<total;i++)
        {
         ulong ticket=PositionGetTicket(i);
         if(ticket==0) continue;
         if(!PositionSelectByTicket(ticket)) continue;
         if(PositionGetString(POSITION_SYMBOL)!=m_symbol) continue;
         if((long)PositionGetInteger(POSITION_MAGIC)!=m_magic) continue;
         if(PositionGetString(POSITION_COMMENT)!=expectedComment) continue;
         if(IsTicketTracked(ticket)) continue;

         datetime t=(datetime)PositionGetInteger(POSITION_TIME);
         if(t>=bestTime) { bestTime=t; best=ticket; }
        }
      return best;
     }

   //=====================================================================
   // Persistence (section 19) — namespaced by account login+symbol+magic+
   // state version. Basket-ID sequence is also persisted so IDs stay
   // unique across restarts.
   //=====================================================================
   string GvKey(const string suffix) const { return m_gvPrefix+"_BASKET_"+suffix; }

   ulong NextBasketId()
     {
      string key=m_gvPrefix+"_basketSeq";
      double cur = GlobalVariableCheck(key) ? GlobalVariableGet(key) : 0.0;
      double next=cur+1.0;
      GlobalVariableSet(key,next);
      return (ulong)next;
     }

   void PersistState()
     {
      GlobalVariableSet(GvKey("active"),m_basket.active?1.0:0.0);
      GlobalVariableSet(GvKey("id"),(double)m_currentBasketId);
      GlobalVariableSet(GvKey("direction"),(double)m_basket.direction);
      GlobalVariableSet(GvKey("layers"),(double)m_basket.layersOpen);
      GlobalVariableSet(GvKey("cycleStartBalance"),m_basket.cycleStartBalance);
      GlobalVariableSet(GvKey("cycleStartTime"),(double)m_basket.cycleStartTime);
      GlobalVariableSet(GvKey("tpTarget"),m_basket.basketTpTarget);
      GlobalVariableSet(GvKey("lastLayerPrice"),m_basket.lastLayerPrice);
      GlobalVariableSet(GvKey("selectedBaseLot"),m_basket.selectedBaseLot);
      GlobalVariableSet(GvKey("state"),(double)m_basket.state);
      GlobalVariableSet(GvKey("recoveryStartTime"),(double)m_basket.recoveryStartTime);
      GlobalVariableSet(GvKey("lastHedgeCloseTime"),(double)m_basket.lastHedgeCloseTime);
      GlobalVariableSet(GvKey("thesisInvalidatedTime"),(double)m_basket.thesisInvalidatedTime);
      GlobalVariableSet(GvKey("maxBasketRiskPct"),m_basket.maxBasketRiskPct);
      GlobalVariableSet(GvKey("hedgeActive"),m_basket.hedgeActive?1.0:0.0);
      GlobalVariableSet(GvKey("hedgeTicket"),(double)m_basket.hedgeTicket);
      // v3.3.2 issue #1: persist hedge-close-in-progress state too, so a
      // restart mid-partial-close doesn't silently forget the hedge still
      // has open volume.
      GlobalVariableSet(GvKey("hedgeCloseState"),(double)m_basket.hedgeCloseState);
      GlobalVariableSet(GvKey("hedgeRemainingVolume"),m_basket.hedgeRemainingVolume);
      GlobalVariableSet(GvKey("hedgeCloseRetryTime"),(double)m_basket.hedgeCloseRetryTime);
      GlobalVariableSet(GvKey("ticketCount"),(double)ArraySize(m_tickets));
      for(int i=0;i<ArraySize(m_tickets);i++)
         GlobalVariableSet(GvKey("ticket_"+IntegerToString(i)),(double)m_tickets[i]);
     }

   void ClearPersistedState()
     {
      GlobalVariableDel(GvKey("active"));
      GlobalVariableDel(GvKey("id"));
      GlobalVariableDel(GvKey("direction"));
      GlobalVariableDel(GvKey("layers"));
      GlobalVariableDel(GvKey("cycleStartBalance"));
      GlobalVariableDel(GvKey("cycleStartTime"));
      GlobalVariableDel(GvKey("tpTarget"));
      GlobalVariableDel(GvKey("lastLayerPrice"));
      GlobalVariableDel(GvKey("selectedBaseLot"));
      GlobalVariableDel(GvKey("state"));
      GlobalVariableDel(GvKey("recoveryStartTime"));
      GlobalVariableDel(GvKey("lastHedgeCloseTime"));
      GlobalVariableDel(GvKey("thesisInvalidatedTime"));
      GlobalVariableDel(GvKey("maxBasketRiskPct"));
      GlobalVariableDel(GvKey("hedgeActive"));
      GlobalVariableDel(GvKey("hedgeTicket"));
      GlobalVariableDel(GvKey("hedgeCloseState"));
      GlobalVariableDel(GvKey("hedgeRemainingVolume"));
      GlobalVariableDel(GvKey("hedgeCloseRetryTime"));

      int oldCount=GlobalVariableCheck(GvKey("ticketCount"))?(int)GlobalVariableGet(GvKey("ticketCount")):0;
      for(int i=0;i<oldCount;i++)
         GlobalVariableDel(GvKey("ticket_"+IntegerToString(i)));
      GlobalVariableDel(GvKey("ticketCount"));
     }

   void RestorePersistedState()
     {
      if(!GlobalVariableCheck(GvKey("active"))) return;
      if(GlobalVariableGet(GvKey("active"))<0.5) return;

      SBasketState restored;
      ZeroMemory(restored);
      restored.active            = true;
      restored.direction         = (ENUM_CYCLE_DIRECTION)(int)GlobalVariableGet(GvKey("direction"));
      restored.cycleStartBalance = GlobalVariableGet(GvKey("cycleStartBalance"));
      restored.cycleStartTime    = (datetime)(long)GlobalVariableGet(GvKey("cycleStartTime"));
      restored.basketTpTarget    = GlobalVariableGet(GvKey("tpTarget"));
      restored.lastLayerPrice    = GlobalVariableCheck(GvKey("lastLayerPrice"))?GlobalVariableGet(GvKey("lastLayerPrice")):0.0;
      restored.selectedBaseLot   = GlobalVariableCheck(GvKey("selectedBaseLot"))?GlobalVariableGet(GvKey("selectedBaseLot")):InpBaseLot;
      restored.state             = GlobalVariableCheck(GvKey("state"))?(ENUM_BASKET_STATE)(int)GlobalVariableGet(GvKey("state")):BSTATE_ACTIVE;
      restored.recoveryStartTime = GlobalVariableCheck(GvKey("recoveryStartTime"))?(datetime)(long)GlobalVariableGet(GvKey("recoveryStartTime")):0;
      restored.lastHedgeCloseTime = GlobalVariableCheck(GvKey("lastHedgeCloseTime"))?(datetime)(long)GlobalVariableGet(GvKey("lastHedgeCloseTime")):0;
      restored.thesisInvalidatedTime = GlobalVariableCheck(GvKey("thesisInvalidatedTime"))?(datetime)(long)GlobalVariableGet(GvKey("thesisInvalidatedTime")):0;
      restored.maxBasketRiskPct = GlobalVariableCheck(GvKey("maxBasketRiskPct"))?GlobalVariableGet(GvKey("maxBasketRiskPct")):0.0;
      restored.hedgeActive       = GlobalVariableCheck(GvKey("hedgeActive")) && GlobalVariableGet(GvKey("hedgeActive"))>0.5;
      restored.hedgeTicket       = GlobalVariableCheck(GvKey("hedgeTicket"))?(ulong)(long)GlobalVariableGet(GvKey("hedgeTicket")):0;
      // v3.3.2 — backward-compatible: a v3.3.1 persisted basket has none of
      // these keys, so they default to "no close in progress".
      restored.hedgeCloseState   = GlobalVariableCheck(GvKey("hedgeCloseState"))?(ENUM_HEDGE_CLOSE_STATE)(int)GlobalVariableGet(GvKey("hedgeCloseState")):HEDGE_CLOSE_NONE;
      restored.hedgeRemainingVolume = GlobalVariableCheck(GvKey("hedgeRemainingVolume"))?GlobalVariableGet(GvKey("hedgeRemainingVolume")):0.0;
      restored.hedgeCloseRetryTime  = GlobalVariableCheck(GvKey("hedgeCloseRetryTime"))?(datetime)(long)GlobalVariableGet(GvKey("hedgeCloseRetryTime")):0;

      ulong basketId = GlobalVariableCheck(GvKey("id"))?(ulong)(long)GlobalVariableGet(GvKey("id")):0;

      int ticketCount=(int)GlobalVariableGet(GvKey("ticketCount"));
      ulong recoveredTickets[];
      ArrayResize(recoveredTickets,0);

      for(int i=0;i<ticketCount;i++)
        {
         string key=GvKey("ticket_"+IntegerToString(i));
         if(!GlobalVariableCheck(key)) continue;
         ulong t=(ulong)(long)GlobalVariableGet(key);
         if(t==0) continue;
         if(PositionSelectByTicket(t))
           {
            int n=ArraySize(recoveredTickets);
            ArrayResize(recoveredTickets,n+1);
            recoveredTickets[n]=t;
           }
        }

      bool hedgeStillOpen = restored.hedgeActive && restored.hedgeTicket>0 &&
                             PositionSelectByTicket(restored.hedgeTicket);
      if(!hedgeStillOpen)
        {
         restored.hedgeActive=false;
         restored.hedgeTicket=0;
         // v3.3.2: if the hedge is gone, any close-in-progress bookkeeping
         // is moot too — it already reached volume 0 while detached.
         restored.hedgeCloseState=HEDGE_CLOSE_NONE;
         restored.hedgeRemainingVolume=0.0;
         restored.hedgeCloseRetryTime=0;
        }

      if(ArraySize(recoveredTickets)==0)
        {
         CLogger::Warn("PositionManager",
            "Persisted basket found but no tracked tickets are still open — "
            "basket was fully closed while EA was detached. Clearing state.");
         ClearPersistedState();
         return;
        }

      m_basket=restored;
      m_basket.layersOpen=ArraySize(recoveredTickets);
      m_basket.peakFloatingProfit=0.0;
      m_basket.peakFloatingTime=TimeCurrent();
      ArrayResize(m_tickets,ArraySize(recoveredTickets));
      for(int i=0;i<ArraySize(recoveredTickets);i++) m_tickets[i]=recoveredTickets[i];
      m_lastKnownStillOpen=ArraySize(recoveredTickets);
      m_currentBasketId=basketId;

      CLogger::Info("PositionManager",StringFormat(
         "Recovered basket #%I64u from previous session: dir=%s layers=%d (originally %d) "
         "cycleStartBalance=%.2f tpTarget=%.2f hedgeActive=%s",
         m_currentBasketId,(m_basket.direction==CYCLE_BUY?"BUY":"SELL"),
         m_basket.layersOpen,ticketCount,m_basket.cycleStartBalance,m_basket.basketTpTarget,
         (m_basket.hedgeActive?"YES":"NO")));

      PersistState();
     }
  };

#endif // __DTE_POSITIONMANAGER_MQH__
