//+------------------------------------------------------------------+
//| AccountValidator.mqh — CAccountValidator                          |
//| v3.1.0: DTE's basket-layer architecture requires distinguishable  |
//| individual positions, which only exists on HEDGING accounts.      |
//| On a NETTING account, initialization must fail safely (section 3).|
//+------------------------------------------------------------------+
#ifndef __DTE_ACCOUNTVALIDATOR_MQH__
#define __DTE_ACCOUNTVALIDATOR_MQH__

#include "Logger.mqh"

class CAccountValidator
  {
public:
   // Returns true if the account type is compatible with this EA.
   static bool ValidateAccountType()
     {
      ENUM_ACCOUNT_MARGIN_MODE mode=(ENUM_ACCOUNT_MARGIN_MODE)AccountInfoInteger(ACCOUNT_MARGIN_MODE);

      if(mode==ACCOUNT_MARGIN_MODE_RETAIL_NETTING)
        {
         string msg="DTE basket-layer architecture requires a HEDGING account. "
                     "This account is running in NETTING mode, where individual layers "
                     "cannot exist as distinguishable positions (they would be netted into "
                     "a single aggregate position). Attach this EA to a hedging-enabled "
                     "account/broker instead.";
         CLogger::Error("AccountValidator",msg);
         Comment("DTE INIT FAILED\n\nAccount type: NETTING\n"
                 "DTE requires a HEDGING account.\nSee Experts log for details.");
         return false;
        }

      CLogger::Info("AccountValidator",StringFormat(
         "Account margin mode OK (%s).",
         (mode==ACCOUNT_MARGIN_MODE_RETAIL_HEDGING?"HEDGING":"EXCHANGE/OTHER")));
      return true;
     }
  };

#endif // __DTE_ACCOUNTVALIDATOR_MQH__
