//+------------------------------------------------------------------+
//| LotSizing.mqh — CLotSizing                                        |
//| v3.3.0: GetAffordableLot() — dynamic lot affordability, never      |
//|         assumes a fixed layer count is affordable.                |
//| v3.2.0: CalculateAdaptiveBaseLot() — centralized, non-martingale   |
//|         capacity model (section 10-19 of the v3.2.0 spec). Picks   |
//|         the largest of {0.01,0.02,0.03} (InpBaseLot..              |
//|         InpMaxLotPerLayer stepped by InpAdaptiveLotStep) whose      |
//|         PROJECTED full-basket (InpMaxLayers) margin usage still     |
//|         fits within InpMaxBasketMarginPercent of equity — NOT       |
//|         just layer 1. Determined purely from account capacity,      |
//|         never from trade outcome (no martingale). GetAffordableLot |
//|         now takes the desired lot as a parameter so the SAME        |
//|         adaptive lot can be reused flat across every layer of a     |
//|         basket (section 20 — flat lot progression).                 |
//+------------------------------------------------------------------+
#ifndef __DTE_LOTSIZING_MQH__
#define __DTE_LOTSIZING_MQH__

#include "..\Config\Inputs.mqh"
#include "Utils.mqh"

class CLotSizing
  {
public:
   // Returns true + an affordable, broker-normalized lot in outLot if ANY
   // safe lot (down to broker minimum) can be opened right now, searching
   // downward FROM desiredLot. Returns false if even the broker minimum is
   // not currently affordable.
   // v3.3.0 PATCH 2: added `exact` (default false — unchanged behavior for
   // every existing caller, e.g. the hedge lot). When exact=true, this
   // validates ONLY the normalized desiredLot itself and never searches
   // downward — used by recovery layers so a basket's selectedBaseLot
   // stays flat across every layer instead of silently shrinking
   // (0.03 -> 0.02 -> 0.01) as margin tightens.
   static bool GetAffordableLot(const string symbol,const ENUM_CYCLE_DIRECTION dir,
                                 const double desiredLot,double &outLot,string &reasonOut,
                                 const bool exact=false)
     {
      outLot=0.0;
      reasonOut="";

      double minLot  = SymbolInfoDouble(symbol,SYMBOL_VOLUME_MIN);
      double step    = SymbolInfoDouble(symbol,SYMBOL_VOLUME_STEP);
      if(step<=0.0) step=0.01;

      double desired = MathMin(desiredLot,InpMaxLotPerLayer); // v3.2.0: 0.03 hard ceiling never bypassed
      desired = CUtils::NormalizeLot(symbol,desired);

      double freeMargin  = AccountInfoDouble(ACCOUNT_MARGIN_FREE);
      double marginLevel = AccountInfoDouble(ACCOUNT_MARGIN_LEVEL);
      if(marginLevel>0.0 && marginLevel<InpMinFreeMarginPercent)
        {
         reasonOut=StringFormat("margin level %.1f%% below minimum %.1f%%",
                                 marginLevel,InpMinFreeMarginPercent);
         return false;
        }

      ENUM_ORDER_TYPE otype=(dir==CYCLE_BUY)?ORDER_TYPE_BUY:ORDER_TYPE_SELL;
      double price=(dir==CYCLE_BUY)?SymbolInfoDouble(symbol,SYMBOL_ASK):SymbolInfoDouble(symbol,SYMBOL_BID);

      if(exact)
        {
         // v3.3.0 PATCH 2: strict mode — validate the EXACT desired lot only.
         // No downward search. If it doesn't fit, the caller must skip the
         // layer, never silently accept a smaller lot.
         double marginRequired=0.0;
         if(!OrderCalcMargin(otype,symbol,desired,price,marginRequired))
           {
            reasonOut=StringFormat("could not calculate margin for exact lot %.2f",desired);
            return false;
           }
         double buffer=marginRequired*(1.0+InpMarginSafetyBufferPct/100.0);
         if(freeMargin>=buffer)
           {
            outLot=desired;
            return true;
           }
         reasonOut=StringFormat(
            "exact selected lot %.2f no longer safely affordable "
            "(freeMargin=%.2f, required-with-buffer=%.2f)",
            desired,freeMargin,buffer);
         return false;
        }

      // Try from the desired lot down to broker minimum, in one step increments,
      // and pick the largest one the account can safely support.
      for(double lot=desired; lot>=minLot-1e-9; lot-=step)
        {
         lot=CUtils::NormalizeLot(symbol,lot);
         double marginRequired=0.0;
         if(!OrderCalcMargin(otype,symbol,lot,price,marginRequired)) continue;

         double buffer = marginRequired*(1.0+InpMarginSafetyBufferPct/100.0);
         if(freeMargin>=buffer)
           {
            outLot=lot;
            return true;
           }
         if(lot<=minLot) break;
        }

      reasonOut=StringFormat("even broker-minimum lot %.2f not safely affordable "
                              "(freeMargin=%.2f)",minLot,freeMargin);
      return false;
     }

   //=====================================================================
   // v3.2.0 — Adaptive base lot (section 10-19). NON-MARTINGALE: depends
   // only on current account capacity (equity/free margin/margin level),
   // never on whether the previous trade won or lost. Computed ONCE per
   // basket (at StartBasket) and reused flat across every layer.
   //
   // Candidates are InpBaseLot..InpMaxLotPerLayer stepped by
   // InpAdaptiveLotStep (default 0.01/0.02/0.03). For each candidate,
   // largest first, this projects the margin a FULL basket of InpMaxLayers
   // layers at that lot would require, and only selects it if that
   // projection fits within InpMaxBasketMarginPercent of current equity.
   // This deliberately answers "if I eventually reach six layers, is this
   // base lot still reasonable?" rather than sizing for layer 1 alone.
   //
   // If no candidate's 6-layer projection fits, falls back to the broker
   // minimum lot (still capacity-checked for a SINGLE layer) rather than
   // refusing outright — actual layering beyond that is still gated layer
   // -by-layer by GetAffordableLot(), which is the real-time safety net.
   //=====================================================================
   static bool CalculateAdaptiveBaseLot(const string symbol,const ENUM_CYCLE_DIRECTION dir,
                                         const int maxLayers,double &outLot,string &outReason)
     {
      outLot=0.0;
      outReason="";

      double minLot=SymbolInfoDouble(symbol,SYMBOL_VOLUME_MIN);
      double step=SymbolInfoDouble(symbol,SYMBOL_VOLUME_STEP);
      if(step<=0.0) step=0.01;
      double lotStep=MathMax(InpAdaptiveLotStep,step);

      double equity=AccountInfoDouble(ACCOUNT_EQUITY);
      double freeMargin=AccountInfoDouble(ACCOUNT_MARGIN_FREE);
      double marginLevel=AccountInfoDouble(ACCOUNT_MARGIN_LEVEL);

      if(marginLevel>0.0 && marginLevel<InpMinFreeMarginPercent)
        {
         outReason=StringFormat("margin level %.1f%% below minimum %.1f%% — no lot selected",
                                 marginLevel,InpMinFreeMarginPercent);
         return false;
        }

      double allowedBasketMargin = equity*(InpMaxBasketMarginPercent/100.0);

      ENUM_ORDER_TYPE otype=(dir==CYCLE_BUY)?ORDER_TYPE_BUY:ORDER_TYPE_SELL;
      double price=(dir==CYCLE_BUY)?SymbolInfoDouble(symbol,SYMBOL_ASK):SymbolInfoDouble(symbol,SYMBOL_BID);

      double topCandidate=CUtils::NormalizeLot(symbol,MathMin(InpMaxLotPerLayer,InpMaxLotPerLayer));

      // Largest candidate first: 0.03, 0.02, 0.01 (or whatever InpAdaptiveLotStep yields).
      for(double lot=topCandidate; lot>=InpBaseLot-1e-9; lot-=lotStep)
        {
         double normalized=CUtils::NormalizeLot(symbol,lot);
         if(normalized<minLot) continue;

         double marginPerLayer=0.0;
         if(!OrderCalcMargin(otype,symbol,normalized,price,marginPerLayer)) continue;

         double estFullBasketMargin = marginPerLayer*maxLayers;
         double singleLayerBuffer   = marginPerLayer*(1.0+InpMarginSafetyBufferPct/100.0);

         bool projectionOk = (estFullBasketMargin<=allowedBasketMargin);
         bool immediateOk  = (freeMargin>=singleLayerBuffer);

         if(projectionOk && immediateOk)
           {
            outLot=normalized;
            outReason=StringFormat(
               "lot %.2f supported: projected %d-layer margin %.2f <= capacity %.2f "
               "(equity %.2f x %.1f%%); immediate free margin OK",
               normalized,maxLayers,estFullBasketMargin,allowedBasketMargin,
               equity,InpMaxBasketMarginPercent);
            return true;
           }

         if(normalized<=minLot) break;
        }

      // Nothing in the adaptive range cleared the 6-layer projection.
      // Fall back to broker minimum, single-layer-safe only. Real-time
      // per-layer checks (GetAffordableLot) remain the actual safety net
      // for how many layers actually get opened (section 1/14: "if only
      // one layer is affordable, open only one — do not force six").
      double fallback=CUtils::NormalizeLot(symbol,minLot);
      double marginFallback=0.0;
      if(OrderCalcMargin(otype,symbol,fallback,price,marginFallback))
        {
         double buf=marginFallback*(1.0+InpMarginSafetyBufferPct/100.0);
         if(freeMargin>=buf)
           {
            outLot=fallback;
            outReason=StringFormat(
               "no tier's %d-layer projection fit within capacity %.2f (equity %.2f x %.1f%%); "
               "using broker-minimum %.2f — real-time per-layer checks will cap actual layering",
               maxLayers,allowedBasketMargin,equity,InpMaxBasketMarginPercent,fallback);
            return true;
           }
        }

      outReason="even broker-minimum lot not currently affordable for a single layer";
      return false;
     }

   // Estimated total lots if a basket eventually reaches maxLayers at the
   // given flat lot — used for dashboard/audit display only (section 19).
   static double EstimateFullBasketExposureLots(const double flatLot,const int maxLayers)
     {
      return flatLot*maxLayers;
     }
  };

#endif // __DTE_LOTSIZING_MQH__
