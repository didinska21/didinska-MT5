//+------------------------------------------------------------------+
//| Utils.mqh — static helpers (unchanged responsibility from v2.x)  |
//+------------------------------------------------------------------+
#ifndef __DTE_UTILS_MQH__
#define __DTE_UTILS_MQH__

class CUtils
  {
public:
   static double PointsToPrice(const string symbol,const double points)
     {
      return points*SymbolInfoDouble(symbol,SYMBOL_POINT);
     }

   static double PriceToPoints(const string symbol,const double priceDelta)
     {
      double pt=SymbolInfoDouble(symbol,SYMBOL_POINT);
      if(pt<=0.0) return 0.0;
      return priceDelta/pt;
     }

   static double NormalizeLot(const string symbol,double lot)
     {
      double minLot  = SymbolInfoDouble(symbol,SYMBOL_VOLUME_MIN);
      double maxLot  = SymbolInfoDouble(symbol,SYMBOL_VOLUME_MAX);
      double step    = SymbolInfoDouble(symbol,SYMBOL_VOLUME_STEP);
      if(step<=0.0) step=0.01;
      lot = MathRound(lot/step)*step;
      if(lot<minLot) lot=minLot;
      if(lot>maxLot) lot=maxLot;
      return NormalizeDouble(lot,2);
     }

   static string DirToString(const int dir) // 1=buy 2=sell 0=none
     {
      if(dir==1) return "BUY";
      if(dir==2) return "SELL";
      return "NONE";
     }

   static string FmtMoney(const double v)
     {
      return DoubleToString(v,2);
     }

   static string FmtPct(const double v)
     {
      return DoubleToString(v,2)+"%";
     }

   static long SecondsBetween(const datetime a,const datetime b)
     {
      return (long)(b-a);
     }
  };

#endif // __DTE_UTILS_MQH__
