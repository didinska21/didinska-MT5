//+------------------------------------------------------------------+
//| Dashboard.mqh — CDashboard                                        |
//| v3.1.0: DTO-only render via Comment(). No engine-class includes.  |
//+------------------------------------------------------------------+
#ifndef __DTE_DASHBOARD_MQH__
#define __DTE_DASHBOARD_MQH__

#include "..\Config\Inputs.mqh"

class CDashboard
  {
public:
   void Render(const SDiagnosticSnapshot &s) const
     {
      string txt="";
      txt+="==== DTE v"+DTE_VERSION+" ====\n";
      txt+="Status: "+StatusStr(s)+"\n";
      txt+="Session: "+SessionStr(s.currentSession)+"\n\n";

      txt+=StringFormat("H1 bias: %s   M15 structure: %s   M5 signal: %s\n",
              BiasStr(s.h1Bias),StructStr(s.m15Structure),DirStr(s.m5Signal));

      txt+="--- Gates ---\n";
      txt+=StringFormat("Session:%s  Spread:%s  ATR:%s  Margin:%s  NewsLock:%s\n",
              BoolStr(s.sessionOk),BoolStr(s.spreadOk),BoolStr(s.atrOk),
              BoolStr(s.marginOk),(s.newsLockActive?"LOCK":"clear"));

      // v3.3.2 issue #2 visibility: an unresolved orphan position blocks new
      // basket/recovery/hedge risk — make that state impossible to miss.
      if(s.pendingOrphanCount>0)
        {
         txt+=StringFormat("\n>>> ORPHAN RECOVERY IN PROGRESS (%d) — new basket/recovery/hedge blocked <<<\n\n",
                 s.pendingOrphanCount);
        }

      txt+="--- Basket ---\n";
      if(s.basket.active)
        {
         // v3.2.1 PATCH 3: use the basket's actual flat lot (selectedBaseLot),
         // not the fixed InpBaseLot input — the adaptive lot can be 0.01/0.02/0.03,
         // and the dashboard must reflect real exposure, not the input floor.
         txt+=StringFormat("Active: YES  Dir:%s  Layers:%d/%d  Volume:%.2f lots (lot/layer:%.2f)\n",
                 DirStr(s.basket.direction),s.basket.layersOpen,InpMaxLayers,
                 s.basket.layersOpen*s.basket.selectedBaseLot,s.basket.selectedBaseLot);
         txt+=StringFormat("CycleStartBalance: %.2f\n",s.basket.cycleStartBalance);
         txt+=StringFormat("Floating P/L (net): %.2f   TP target: %.2f (%.1f%%)\n",
                 s.basket.basketFloatingProfit,s.basket.basketTpTarget,InpBasketTpPercent*100.0);
         double tpProgress = s.basket.basketTpTarget>0.0 ?
            (s.basket.basketFloatingProfit/s.basket.basketTpTarget)*100.0 : 0.0;
         txt+=StringFormat("TP progress: %.1f%%\n",tpProgress);
         txt+=StringFormat("Hedge: %s (state=%s)\n",
                 (s.basket.hedgeActive?"ACTIVE":"none"),HedgeStr(s.basket.hedgeState));
         // v3.3.2 issue #1 visibility: a hedge that's mid verified-close
         // (remaining volume confirmed > 0) is shown explicitly rather than
         // silently still reading as "ACTIVE".
         if(s.basket.hedgeActive && s.basket.hedgeCloseState==HEDGE_CLOSE_PARTIAL)
            txt+=StringFormat("  Hedge close: PARTIAL — remaining %.2f lots, retrying\n",
                    s.basket.hedgeRemainingVolume);
        }
      else
        {
         txt+="Active: NO (waiting for next valid confluence setup)\n";
        }

      txt+="--- Risk / Drawdown ---\n";
      txt+=StringFormat("Current drawdown: %.2f%%   Margin level: %s\n",
              s.currentDrawdownPct,
              (s.marginOk?"OK":"LOW"));

      txt+="--- PROFIT CYCLE ---\n";
      txt+=StringFormat("Cycle ID: %I64u\n",s.profitCycleId);
      txt+=StringFormat("Baseline: $%.2f\n",s.profitCycleBaseline);
      txt+=StringFormat("Target: +%.0f%%   Target Balance: $%.2f\n",
              (InpProfitTargetMultiplier-1.0)*100.0,s.profitCycleTargetBalance);
      txt+=StringFormat("Current Balance: $%.2f\n",s.currentBalance);
      txt+=StringFormat("Progress: %.2f%%\n",s.profitTargetProgressPct);
      txt+="Status: "+(s.haltActive?"HALTED":"ACTIVE")+"\n";
      if(s.haltActive)
        {
         txt+="\n>>> TARGET REACHED <<<\n>>> MANUAL RESET REQUIRED <<<\n";
         txt+="(click the \"RESET PROFIT TARGET\" button on the chart)\n";
        }
      if(s.resetStatusMessage!="")
        {
         txt+="\n"+s.resetStatusMessage+"\n";
        }

      txt+="\n--- Adaptive Lot ---\n";
      txt+=StringFormat("Adaptive Lot: %.2f   Maximum Lot: %.2f\n",
              s.adaptiveLotLastSelected,InpMaxLotPerLayer);
      txt+=StringFormat("Margin Capacity: %.1f%%   Est. %d-Layer Exposure: %.2f lots\n",
              s.adaptiveMarginCapacityPct,InpMaxLayers,s.adaptiveEstSixLayerExposureLots);

      if(s.lastEntryReason!="") txt+="\nLast entry: "+s.lastEntryReason+"\n";
      if(s.lastCloseReason!="") txt+="Last close: "+s.lastCloseReason+"\n";

      Comment(txt);
     }

private:
   string StatusStr(const SDiagnosticSnapshot &s) const
     {
      if(s.haltActive) return "HALTED";
      if(!s.sessionOk) return "Paused (outside session)";
      return "Trading";
     }

   string DirStr(const ENUM_CYCLE_DIRECTION d) const
     {
      if(d==CYCLE_BUY)  return "BUY";
      if(d==CYCLE_SELL) return "SELL";
      return "NONE";
     }

   string BiasStr(const ENUM_MARKET_BIAS b) const
     {
      switch(b)
        {
         case BIAS_STRONG_BULL: return "STRONG BULL";
         case BIAS_BULL:        return "BULL";
         case BIAS_BEAR:        return "BEAR";
         case BIAS_STRONG_BEAR: return "STRONG BEAR";
         default: return "NEUTRAL";
        }
     }

   string StructStr(const ENUM_STRUCT_STATE st) const
     {
      switch(st)
        {
         case STRUCT_BULLISH:    return "BULLISH (HH/HL)";
         case STRUCT_BEARISH:    return "BEARISH (LH/LL)";
         case STRUCT_BOS_UP:     return "BOS UP";
         case STRUCT_BOS_DOWN:   return "BOS DOWN";
         case STRUCT_CHOCH_UP:   return "CHOCH UP";
         case STRUCT_CHOCH_DOWN: return "CHOCH DOWN";
         default: return "UNKNOWN";
        }
     }

   string HedgeStr(const ENUM_HEDGE_STATE h) const
     {
      switch(h)
        {
         case HEDGE_RECOVERY:      return "RECOVERY";
         case HEDGE_REVERSAL_RISK: return "REVERSAL_RISK";
         case HEDGE_ACTIVE:        return "HEDGE";
         case HEDGE_BASKET_EXIT:   return "BASKET_EXIT";
         default: return "NORMAL";
        }
     }

   string SessionStr(const ENUM_SESSION_NAME s) const
     {
      switch(s)
        {
         case SESSION_ASIA:    return "Asia";
         case SESSION_LONDON:  return "London";
         case SESSION_NY:      return "New York";
         case SESSION_OVERLAP: return "London/NY overlap";
         default: return "Closed";
        }
     }

   string BoolStr(const bool b) const { return b?"OK":"BLOCK"; }
  };

#endif // __DTE_DASHBOARD_MQH__
