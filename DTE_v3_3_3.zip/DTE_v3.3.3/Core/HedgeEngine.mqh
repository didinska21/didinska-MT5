//+------------------------------------------------------------------+
//| HedgeEngine.mqh — CHedgeEngine                                    |
//| v3.3.0: state-driven hedge decisions. A hedge must be justified by |
//| genuine opposing structure (CHOCH against the basket direction,   |
//| confirmed by the same StructureEngine used for entries) — never   |
//| opened merely because the basket is losing (section 13). No       |
//| random BUY/SELL alternation.                                      |
//+------------------------------------------------------------------+
#ifndef __DTE_HEDGEENGINE_MQH__
#define __DTE_HEDGEENGINE_MQH__

#include "..\Config\Inputs.mqh"
#include "StructureEngine.mqh"

class CHedgeEngine
  {
private:
   CStructureEngine *m_structure; // not owned (shared reference not required — recompute is cheap)

public:
   void Init(CStructureEngine *structure) { m_structure=structure; }

   // Evaluates whether the basket should transition into HEDGE_ACTIVE.
   // basketDirection: the basket's original direction.
   // Returns the recommended hedge state; caller (PositionManager) decides
   // whether to actually open the hedge order based on this + margin checks.
   ENUM_HEDGE_STATE Evaluate(const ENUM_CYCLE_DIRECTION basketDirection,
                              const bool basketLosing) const
     {
      if(!InpHedgeEnable) return HEDGE_NORMAL;
      if(m_structure==NULL) return HEDGE_NORMAL;

      SStructureAnalysis m15 = m_structure.Analyze(InpTfStruct);
      if(!m15.valid) return basketLosing?HEDGE_RECOVERY:HEDGE_NORMAL;

      bool opposingChoch =
         (basketDirection==CYCLE_BUY  && m15.state==STRUCT_CHOCH_DOWN) ||
         (basketDirection==CYCLE_SELL && m15.state==STRUCT_CHOCH_UP);

      bool opposingBos =
         (basketDirection==CYCLE_BUY  && m15.state==STRUCT_BOS_DOWN) ||
         (basketDirection==CYCLE_SELL && m15.state==STRUCT_BOS_UP);

      if(opposingChoch)
         return HEDGE_ACTIVE; // genuine reversal signal — arm the hedge

      if(opposingBos)
         return HEDGE_REVERSAL_RISK; // warning state, not yet a confirmed reversal

      if(basketLosing)
         return HEDGE_RECOVERY; // losing but no opposing structure — recovery layering path, not hedge

      return HEDGE_NORMAL;
     }

   // Opposing-structure "strength" used against InpHedgeMinStructureScore.
   // Simple heuristic: CHOCH = 2 points, opposing BOS = 1 point, else 0.
   double OpposingStructureScore(const ENUM_CYCLE_DIRECTION basketDirection) const
     {
      if(m_structure==NULL) return 0.0;
      SStructureAnalysis m15 = m_structure.Analyze(InpTfStruct);
      if(!m15.valid) return 0.0;

      bool opposingChoch =
         (basketDirection==CYCLE_BUY  && m15.state==STRUCT_CHOCH_DOWN) ||
         (basketDirection==CYCLE_SELL && m15.state==STRUCT_CHOCH_UP);
      if(opposingChoch) return 2.0;

      bool opposingBos =
         (basketDirection==CYCLE_BUY  && m15.state==STRUCT_BOS_DOWN) ||
         (basketDirection==CYCLE_SELL && m15.state==STRUCT_BOS_UP);
      if(opposingBos) return 1.0;

      return 0.0;
     }
  };

#endif // __DTE_HEDGEENGINE_MQH__
