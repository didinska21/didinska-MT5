//+------------------------------------------------------------------+
//|                                         GoldHedgeRecovery.mq5     |
//|                    Didinska Trading Engine (DTE) v3.3.3           |
//|   EXPECTANCY / RECOVERY BALANCE PATCH on top of v3.3.2 —          |
//|   recovery now classifies adverse moves (continuation/retracement/|
//|   range) before deciding to layer, recovery evaluation is event-  |
//|   driven with throttled rejection logging, layers are tiered by   |
//|   confirmation strength, max basket hold is a stricter true hard  |
//|   limit (blocks new hedges too), and new loss-anatomy + spike-exit|
//|   diagnostics were added. Risk architecture (layer/lot caps, no   |
//|   martingale, hedge behavior, hard equity-risk ceiling) preserved |
//|   unchanged. See Docs/CHANGELOG.md.                                |
//|                                                                     |
//| RESEARCH / TEST BUILD. Not claimed profitable, not claimed         |
//| live-ready, strategy not claimed proven. See Docs/README.md.       |
//| STRICT PATCH RELEASE — no strategy redesign. See CHANGELOG.        |
//+------------------------------------------------------------------+
#property copyright "Didinska — private use only"
#property version   "3.33"
#property strict

#include "Config\Inputs.mqh"
#include "Core\Utils.mqh"
#include "Core\Logger.mqh"
#include "Core\AccountValidator.mqh"
#include "Core\SessionManager.mqh"
#include "Core\SpreadFilter.mqh"
#include "Core\NewsFilter.mqh"
#include "Core\StructureEngine.mqh"
#include "Core\ConfluenceEngine.mqh"
#include "Core\HedgeEngine.mqh"
#include "Core\SignalEngine.mqh"
#include "Core\RiskEngine.mqh"
#include "Core\LotSizing.mqh"
#include "Core\PositionManager.mqh"
#include "Core\TradeEngine.mqh"
#include "Core\Dashboard.mqh"
#include "Core\DiagnosticEngine.mqh"
#include "Indicators\ATRFilter.mqh"

CSessionManager    g_session;
CSpreadFilter      g_spread;
CATRFilter         g_atr;
CNewsFilter        g_news;
CStructureEngine   g_structureForHedge;
CConfluenceEngine  g_confluence;
CHedgeEngine       g_hedge;
CSignalEngine      g_signal;
CRiskEngine        g_risk;
CTradeEngine       g_tradeEngine;
CPositionManager   g_posMgr;
CDashboard         g_dashboard;
CDiagnosticEngine  g_diag;

string g_symbol;
string g_lastEntryReason="";
string g_lastCloseReason="";
string g_resetStatusMessage="";

// v3.3.0 manual reset button — two-stage arm/confirm so a single accidental
// click can never reset the profit cycle (section 6-8).
#define DTE_RESET_BTN_NAME "DTE_ResetProfitTargetBtn"
bool     g_resetArmed=false;
datetime g_resetArmedUntil=0;

//+------------------------------------------------------------------+
int OnInit()
  {
   g_symbol=_Symbol;

   // section 3: hedging account required — hard init failure on netting.
   if(!CAccountValidator::ValidateAccountType())
      return(INIT_FAILED);

   // section 29 / basic sanity — validation, not optimization.
   if(InpMaxLayers<=0 || InpMaxLayers>6)
     { CLogger::Error("OnInit","InpMaxLayers must be between 1 and hard cap 6"); return(INIT_PARAMETERS_INCORRECT); }
   if(InpMaxLotPerLayer<=0.0 || InpMaxLotPerLayer>0.03)
     { CLogger::Error("OnInit","InpMaxLotPerLayer must be > 0 and <= hard cap 0.03"); return(INIT_PARAMETERS_INCORRECT); }
   if(InpHedgeMaxLot>0.01)
     { CLogger::Error("OnInit","InpHedgeMaxLot must be <= 0.01"); return(INIT_PARAMETERS_INCORRECT); }
   if(InpMaxBasketEquityRiskPercent<=0.0 ||
      InpMaxBasketEquityRiskPercent>InpHardBasketEquityRiskPercent ||
      InpHardBasketEquityRiskPercent>20.0)
     { CLogger::Error("OnInit","Basket equity risk settings invalid: preferred <= hard <= 20%"); return(INIT_PARAMETERS_INCORRECT); }
   if(InpMaxLotPerLayer<InpBaseLot)
     { CLogger::Error("OnInit","InpMaxLotPerLayer must be >= InpBaseLot"); return(INIT_PARAMETERS_INCORRECT); }
   double brokerMinLot=SymbolInfoDouble(g_symbol,SYMBOL_VOLUME_MIN);
   if(InpMaxLotPerLayer<brokerMinLot)
     {
      CLogger::Error("OnInit",StringFormat(
         "InpMaxLotPerLayer=%.2f is below broker minimum %.2f for %s",
         InpMaxLotPerLayer,brokerMinLot,g_symbol));
      return(INIT_PARAMETERS_INCORRECT);
     }
   if(InpBasketTpPercent<=0.0 || InpBasketTpPercent>=5.0)
     { CLogger::Error("OnInit","InpBasketTpPercent must be > 0 and remain scalping-sized (<5%)"); return(INIT_PARAMETERS_INCORRECT); }
   if(InpMaxBasketHoldMinutes<=0)
     { CLogger::Error("OnInit","InpMaxBasketHoldMinutes must be > 0"); return(INIT_PARAMETERS_INCORRECT); }
   if(InpTargetEnable && InpProfitTargetMultiplier<=1.0)
     { CLogger::Error("OnInit","InpProfitTargetMultiplier must be > 1.0"); return(INIT_PARAMETERS_INCORRECT); }
   if(InpTfBias==InpTfStruct || InpTfStruct==InpTfTrigger || InpTfBias==InpTfTrigger)
     { CLogger::Error("OnInit","InpTfBias/InpTfStruct/InpTfTrigger must all be different timeframes"); return(INIT_PARAMETERS_INCORRECT); }

   g_diag.Init();

   g_spread.Init(g_symbol);
   g_news.Init(g_symbol);
   g_structureForHedge.Init(g_symbol);
   g_hedge.Init(GetPointer(g_structureForHedge));

   if(!g_atr.Init(g_symbol,InpAtrPeriod))
     { CLogger::Error("OnInit","ATR filter init failed"); return(INIT_FAILED); }

   if(!g_confluence.Init(g_symbol))
     { CLogger::Error("OnInit","ConfluenceEngine init failed — check H1/M15/M5 data availability"); return(INIT_FAILED); }

   g_signal.Init(g_symbol,GetPointer(g_confluence),GetPointer(g_diag));

   g_risk.Init(g_symbol,GetPointer(g_diag));

   if(!g_tradeEngine.Init(g_symbol,InpMagicNumber))
     { CLogger::Error("OnInit","TradeEngine init failed"); return(INIT_FAILED); }

   if(!g_posMgr.Init(g_symbol,InpMagicNumber,GetPointer(g_tradeEngine),GetPointer(g_confluence),
                     GetPointer(g_hedge),GetPointer(g_news),GetPointer(g_diag),GetPointer(g_risk)))
     { CLogger::Error("OnInit","PositionManager init failed (layer ATR handle)"); return(INIT_FAILED); }

   CreateResetButton();

   CLogger::Info("OnInit",StringFormat("DTE v%s Build %s initialized on %s (H1->M15->M5, architecture v3.3.3)",
                 DTE_VERSION,DTE_BUILD,g_symbol));

   return(INIT_SUCCEEDED);
  }

//+------------------------------------------------------------------+
void CreateResetButton()
  {
   if(ObjectFind(0,DTE_RESET_BTN_NAME)>=0) ObjectDelete(0,DTE_RESET_BTN_NAME);

   ObjectCreate(0,DTE_RESET_BTN_NAME,OBJ_BUTTON,0,0,0);
   ObjectSetInteger(0,DTE_RESET_BTN_NAME,OBJPROP_CORNER,CORNER_LEFT_UPPER);
   ObjectSetInteger(0,DTE_RESET_BTN_NAME,OBJPROP_XDISTANCE,10);
   ObjectSetInteger(0,DTE_RESET_BTN_NAME,OBJPROP_YDISTANCE,10);
   ObjectSetInteger(0,DTE_RESET_BTN_NAME,OBJPROP_XSIZE,190);
   ObjectSetInteger(0,DTE_RESET_BTN_NAME,OBJPROP_YSIZE,26);
   ObjectSetString(0,DTE_RESET_BTN_NAME,OBJPROP_TEXT,"RESET PROFIT TARGET");
   ObjectSetInteger(0,DTE_RESET_BTN_NAME,OBJPROP_COLOR,clrWhite);
   ObjectSetInteger(0,DTE_RESET_BTN_NAME,OBJPROP_BGCOLOR,clrDarkSlateGray);
   ObjectSetInteger(0,DTE_RESET_BTN_NAME,OBJPROP_BORDER_COLOR,clrBlack);
   ObjectSetInteger(0,DTE_RESET_BTN_NAME,OBJPROP_STATE,false);
   ObjectSetInteger(0,DTE_RESET_BTN_NAME,OBJPROP_HIDDEN,true);
   ObjectSetInteger(0,DTE_RESET_BTN_NAME,OBJPROP_SELECTABLE,false);
   ChartRedraw(0);
  }

//+------------------------------------------------------------------+
void OnDeinit(const int reason)
  {
   g_diag.PrintSummary();
   g_confluence.Release();
   g_atr.Release();
   ObjectDelete(0,DTE_RESET_BTN_NAME);
   Comment("");
  }

//+------------------------------------------------------------------+
void OnTick()
  {
   g_risk.EvaluateHalts();

   bool sessionOk = g_session.IsTradingAllowed();
   ENUM_SESSION_NAME session = g_session.CurrentSession();
   bool spreadOk  = g_spread.IsOkForNewEntry();
   bool atrOk     = g_atr.IsWithinRange();
   bool newsLock  = g_news.Evaluate();

   g_posMgr.ManageProtection(); // no per-position SL/BE/trailing; also drives v3.3.2 orphan-recovery retries every tick

   // v3.2.1 PATCH 1: HALTED must block all NEW risk (new basket, new
   // recovery layer, new hedge) but existing positions must still be
   // safely managed/closed. New-basket gate below already checked
   // !g_risk.IsHalted() before this patch — that was already correct.
   // TryAddRecoveryLayer/ManageHedge now also receive the halted flag as a
   // defensive guard (PositionManager itself refuses new risk when halted,
   // so a future caller here can't accidentally bypass the rule).
   bool halted=g_risk.IsHalted();
   g_posMgr.SyncHaltState(halted);

   bool wasActive=g_posMgr.IsBasketActive();
   if(wasActive)
     {
      g_posMgr.TryAddRecoveryLayer(session,halted);
      g_posMgr.ManageHedge(session,halted);
      g_posMgr.UpdateAndCheckTp(); // never gated by halted — existing basket must still reach TP/spike-exit/close-verify
     }
   if(wasActive && !g_posMgr.IsBasketActive())
     {
      g_signal.SuppressCurrentBar();
      g_lastCloseReason="basket closed (see Experts log for reason)";
     }

   // Statistics only (section 25) — no forced action from this.
   SBasketState bs=g_posMgr.GetBasketState();
   g_risk.RecordDrawdownStats(GetPointer(g_diag),bs.basketFloatingProfit,bs.layersOpen,
                               (bs.basketFloatingProfit<0.0?bs.basketFloatingProfit:0.0));

   if(!g_risk.IsHalted() && !g_posMgr.IsBasketActive())
     {
      SConfluenceResult conf;
      bool triggered=g_signal.CheckTrigger(conf);
      if(triggered)
        {
         if(!sessionOk)
           {
            g_diag.OnEntrySkippedSession();
           }
         else if(!spreadOk)
           {
            g_diag.OnEntrySkippedSpread();
           }
         else if(!atrOk)
           {
            // covered by ATR pre-entry gate; no dedicated counter beyond confluence reject
           }
         else if(newsLock)
           {
            g_diag.OnEntrySkippedNews();
           }
         else
           {
            g_posMgr.StartBasket(conf.direction,conf,session);
            g_lastEntryReason=StringFormat("score=%d fib=%s qm=%s ema=%s structBreak=%s",
               conf.score,(conf.fibHit?"Y":"N"),(conf.qmHit?"Y":"N"),(conf.emaHit?"Y":"N"),
               ((conf.m15Structure==STRUCT_BOS_UP||conf.m15Structure==STRUCT_BOS_DOWN||
                 conf.m15Structure==STRUCT_CHOCH_UP||conf.m15Structure==STRUCT_CHOCH_DOWN)?"Y":"N"));
           }
        }
     }

   RenderDashboard(sessionOk,spreadOk,atrOk,newsLock,session);
  }

//+------------------------------------------------------------------+
double CurrentDrawdownPct()
  {
   double balance=AccountInfoDouble(ACCOUNT_BALANCE);
   double equity=AccountInfoDouble(ACCOUNT_EQUITY);
   if(balance<=0.0) return 0.0;
   return MathMax(0.0,((balance-equity)/balance)*100.0);
  }

//+------------------------------------------------------------------+
void RenderDashboard(const bool sessionOk,const bool spreadOk,const bool atrOk,
                      const bool newsLock,const ENUM_SESSION_NAME session)
  {
   SDiagnosticSnapshot snap;
   ZeroMemory(snap);

   snap.h1Bias        = g_signal.GetH1Bias();
   snap.m15Structure  = g_signal.GetM15Structure();
   snap.m5Signal      = CYCLE_NONE; // informational only; actual trigger evaluated on new bars

   snap.basket = g_posMgr.GetBasketState();

   snap.haltActive = g_risk.IsHalted();
   snap.haltCause  = g_risk.HaltCause();
   snap.sessionStartBalance = g_risk.CycleBaseline();
   snap.currentEquity = AccountInfoDouble(ACCOUNT_EQUITY);
   snap.profitTargetProgressPct = g_risk.ProfitTargetProgressPct();

   snap.sessionOk = sessionOk;
   snap.spreadOk  = spreadOk;
   snap.atrOk     = atrOk;
   snap.marginOk  = (AccountInfoDouble(ACCOUNT_MARGIN_LEVEL)<=0.0 ||
                      AccountInfoDouble(ACCOUNT_MARGIN_LEVEL)>=InpMinFreeMarginPercent);
   snap.newsLockActive = newsLock;
   snap.currentSession = session;
   snap.lastEntryReason = g_lastEntryReason;
   snap.lastCloseReason = g_lastCloseReason;
   snap.currentDrawdownPct = CurrentDrawdownPct();

   // v3.2.0 — profit-cycle lifecycle
   snap.profitCycleId          = g_risk.CycleId();
   snap.profitCycleBaseline    = g_risk.CycleBaseline();
   snap.profitCycleTargetBalance = g_risk.TargetBalance();
   snap.currentBalance         = AccountInfoDouble(ACCOUNT_BALANCE);
   snap.resetStatusMessage     = g_resetStatusMessage;

   // v3.2.0 — adaptive lot info (live preview when no basket is open;
   // the basket's own locked-in flat lot once one is active).
   SBasketState curBasket=snap.basket;
   double previewLot=0.0;
   if(curBasket.active)
     {
      previewLot=curBasket.selectedBaseLot;
     }
   else
     {
      string previewReason;
      CLotSizing::CalculateAdaptiveBaseLot(g_symbol,CYCLE_BUY,InpMaxLayers,previewLot,previewReason);
     }
   snap.adaptiveLotLastSelected = previewLot;
   snap.adaptiveMarginCapacityPct = InpMaxBasketMarginPercent;
   snap.adaptiveEstSixLayerExposureLots = CLotSizing::EstimateFullBasketExposureLots(previewLot,InpMaxLayers);
   // v3.3.2 issue #2 visibility: surface pending orphan-position recovery
   // count on the dashboard so it's never a silent background state.
   snap.pendingOrphanCount = g_posMgr.PendingOrphanCount();

   g_dashboard.Render(snap);
  }

//+------------------------------------------------------------------+
//+------------------------------------------------------------------+
// v3.2.0 — manual reset via dashboard button, two-stage arm/confirm so a
// single accidental click can never reset the profit cycle (section 6-8).
// First click arms (button relabels to CONFIRM?), second click within
// InpResetConfirmSeconds performs the actual reset (which itself still
// refuses if a basket is active — RiskEngine::RequestManualReset).
//+------------------------------------------------------------------+
void OnChartEvent(const int id,const long &lparam,const double &dparam,const string &sparam)
  {
   if(id!=CHARTEVENT_OBJECT_CLICK) return;
   if(sparam!=DTE_RESET_BTN_NAME) return;

   ObjectSetInteger(0,DTE_RESET_BTN_NAME,OBJPROP_STATE,false); // un-press visually
   datetime now=TimeCurrent();

   if(!g_resetArmed || now>g_resetArmedUntil)
     {
      // First click (or a stale arm expired) — arm, require confirmation.
      g_resetArmed=true;
      g_resetArmedUntil=now+InpResetConfirmSeconds;
      ObjectSetString(0,DTE_RESET_BTN_NAME,OBJPROP_TEXT,"CONFIRM RESET?");
      ObjectSetInteger(0,DTE_RESET_BTN_NAME,OBJPROP_BGCOLOR,clrDarkOrange);
      g_resetStatusMessage=StringFormat(
         "Reset armed — click again within %d seconds to confirm.",InpResetConfirmSeconds);
      CLogger::Info("ResetButton",g_resetStatusMessage);
      ChartRedraw(0);
      return;
     }

   // Second click within the confirm window — verify and execute.
   g_resetArmed=false;
   string msg;
   bool ok=g_risk.RequestManualReset(g_posMgr.IsBasketActive(),msg);
   g_resetStatusMessage=msg;

   ObjectSetString(0,DTE_RESET_BTN_NAME,OBJPROP_TEXT,"RESET PROFIT TARGET");
   ObjectSetInteger(0,DTE_RESET_BTN_NAME,OBJPROP_BGCOLOR,(ok?clrDarkSlateGray:clrFireBrick));
   ChartRedraw(0);
  }

//+------------------------------------------------------------------+
void OnTradeTransaction(const MqlTradeTransaction &trans,
                        const MqlTradeRequest &request,
                        const MqlTradeResult &result)
  {
   // Reserved hook: basket lifecycle (TP/spike-exit close verification and
   // margin-call reconciliation) is handled by CPositionManager polling
   // ticket state each tick, which is sufficient for this EA's
   // single-basket-at-a-time model plus one optional hedge ticket.
  }
//+------------------------------------------------------------------+
