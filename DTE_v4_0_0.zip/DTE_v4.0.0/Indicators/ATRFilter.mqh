//+------------------------------------------------------------------+
//| ATRFilter.mqh — CATRFilter (unchanged from v2.x)                 |
//+------------------------------------------------------------------+
#ifndef __DTE_ATRFILTER_MQH__
#define __DTE_ATRFILTER_MQH__

#include "..\Config\Inputs.mqh"

class CATRFilter
  {
private:
   int    m_handle;
   string m_symbol;

public:
   CATRFilter() : m_handle(INVALID_HANDLE) {}

   bool Init(const string symbol,const int period,const ENUM_TIMEFRAMES tf=PERIOD_CURRENT)
     {
      m_symbol=symbol;
      // v4.0.0 fix: v3.3.x always passed PERIOD_CURRENT here — i.e. the ATR
      // regime gate was silently reading whatever timeframe the chart the
      // EA is attached to happens to be on, not necessarily InpTfTrigger
      // (M5) as intended. Callers should now pass InpTfTrigger explicitly;
      // the default is kept only for source compatibility.
      m_handle=iATR(symbol,tf,period);
      return(m_handle!=INVALID_HANDLE);
     }

   bool IsWithinRange() const
     {
      if(!InpUseAtrFilter) return true;
      double pts=GetAtrPoints(1);
      if(pts<=0.0) return false;
      return(pts>=InpAtrMinPoints && pts<=InpAtrMaxPoints);
     }

   // Raw ATR value in price units (not points).
   double GetAtr(const int shift=1) const
     {
      if(m_handle==INVALID_HANDLE) return 0.0;
      double buf[];
      ArraySetAsSeries(buf,true);
      if(CopyBuffer(m_handle,0,shift,1,buf)<=0) return 0.0;
      return buf[0];
     }

   double GetAtrPoints(const int shift=1) const
     {
      double atr=GetAtr(shift);
      double point=SymbolInfoDouble(m_symbol,SYMBOL_POINT);
      return (point>0.0) ? atr/point : 0.0;
     }

   void Release()
     {
      if(m_handle!=INVALID_HANDLE)
        {
         IndicatorRelease(m_handle);
         m_handle=INVALID_HANDLE;
        }
     }
  };

#endif // __DTE_ATRFILTER_MQH__
