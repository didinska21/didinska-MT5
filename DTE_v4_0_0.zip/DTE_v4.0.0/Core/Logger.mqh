//+------------------------------------------------------------------+
//| Logger.mqh — CLogger, named event logging                        |
//| v4.0.0 SECTION 31 — full required tag set. BuildForensicSummary() |
//| prints the general OPERATIONAL forensic block; loss-anatomy and   |
//| expectancy reporting are printed separately by their own modules  |
//| (Recovery/LossAnatomy.mqh, Recovery/ExpectancyEngine.mqh) so each  |
//| stays a self-contained deliverable per section 50.                |
//+------------------------------------------------------------------+
#ifndef __DTE_LOGGER_MQH__
#define __DTE_LOGGER_MQH__

#include "..\Config\Inputs.mqh"

class CLogger
  {
public:
   static void Info(const string tag,const string msg)  { PrintFormat("[DTE][%s] %s",tag,msg); }
   static void Warn(const string tag,const string msg)   { PrintFormat("[DTE][WARN][%s] %s",tag,msg); }
   static void Error(const string tag,const string msg)  { PrintFormat("[DTE][ERROR][%s] %s",tag,msg); }

   static void Halt(const ENUM_HALT_CAUSE cause,const string reason)
     {
      PrintFormat("[DTE][HALT] cause=%s reason=%s",HaltCauseToString(cause),reason);
     }

   static string HaltCauseToString(const ENUM_HALT_CAUSE cause)
     {
      switch(cause)
        {
         case HALT_PROFIT_TARGET:   return "PROFIT_TARGET_REACHED";
         case HALT_ACCOUNT_TYPE:    return "NETTING_ACCOUNT_UNSUPPORTED";
         case HALT_EQUITY_DRAWDOWN: return "EQUITY_DRAWDOWN_CEILING";
         default: return "NONE";
        }
     }

   //--- section 31 required tags -----------------------------------------
   static void Entry(const ulong basketId,const ENUM_CYCLE_DIRECTION dir,const int layer,
                      const double lot,const int score,const ENUM_MARKET_REGIME regime,const string reason)
     {
      PrintFormat("[DTE][ENTRY] basket_id=%I64u dir=%s layer=%d lot=%.2f score=%d regime=%d reason=\"%s\"",
                  basketId,(dir==CYCLE_BUY?"BUY":"SELL"),layer,lot,score,(int)regime,reason);
     }

   static void Thesis(const ulong basketId,const ENUM_THESIS_STATE state,const int invalidationScore)
     {
      PrintFormat("[DTE][THESIS] basket_id=%I64u state=%s score=%d",
                  basketId,ThesisStr(state),invalidationScore);
     }

   static void ThesisWeak(const ulong basketId,const int score,const string reason)
     {
      PrintFormat("[DTE][THESIS_WEAK] basket_id=%I64u score=%d reason=\"%s\"",basketId,score,reason);
     }

   static void ThesisInvalid(const ulong basketId,const int score,const string reason)
     {
      PrintFormat("[DTE][THESIS_INVALID] basket_id=%I64u score=%d reason=\"%s\"",basketId,score,reason);
     }

   static void RecoveryEvaluate(const ulong basketId,const int layer,const ENUM_ADVERSE_CLASS cls)
     {
      PrintFormat("[DTE][RECOVERY][EVALUATE] basket_id=%I64u layer=%d class=%s",
                  basketId,layer,AdverseClassStr(cls));
     }

   static void RecoveryAccept(const ulong basketId,const int layer,const int score,const string reason)
     {
      PrintFormat("[DTE][RECOVERY][ACCEPT] basket_id=%I64u layer=%d score=%d reason=\"%s\"",
                  basketId,layer,score,reason);
     }

   // section 31: every recovery rejection states basket id, layer, direction,
   // score, threshold, M5/M15/H1 status, ATR, distance, floating loss, reason.
   static void RecoveryReject(const ulong basketId,const int layer,const ENUM_CYCLE_DIRECTION dir,
                               const int score,const int threshold,const bool m5Ok,
                               const ENUM_STRUCT_STATE m15,const ENUM_MARKET_BIAS h1,
                               const double atr,const double distancePts,const double floatingLoss,
                               const string reason)
     {
      PrintFormat("[DTE][RECOVERY][REJECT] basket_id=%I64u layer=%d dir=%s score=%d threshold=%d "
                  "m5=%s m15=%d h1=%d atr=%.5f distancePts=%.1f floatingLoss=%.2f reason=\"%s\"",
                  basketId,layer,(dir==CYCLE_BUY?"BUY":"SELL"),score,threshold,
                  (m5Ok?"OK":"NO"),(int)m15,(int)h1,atr,distancePts,floatingLoss,reason);
     }

   static void HedgeEvaluate(const ulong basketId,const ENUM_HEDGE_STATE state,const double structScore)
     {
      PrintFormat("[DTE][HEDGE][EVALUATE] basket_id=%I64u state=%d structScore=%.1f",
                  basketId,(int)state,structScore);
     }

   static void HedgeOpen(const ulong basketId,const string reason,const ENUM_CYCLE_DIRECTION dir,
                          const double lot,const double price)
     {
      PrintFormat("[DTE][HEDGE][OPEN] basket_id=%I64u reason=\"%s\" dir=%s lot=%.2f price=%.5f",
                  basketId,reason,(dir==CYCLE_BUY?"BUY":"SELL"),lot,price);
     }

   static void HedgeClose(const ulong basketId,const string reason,const double remainingLots)
     {
      PrintFormat("[DTE][HEDGE][CLOSE] basket_id=%I64u reason=\"%s\" remainingLots=%.2f",
                  basketId,reason,remainingLots);
     }

   static void Exit(const ulong basketId,const ENUM_BASKET_CLOSE_REASON reason,const int layers,
                     const double netProfit,const long holdSeconds)
     {
      PrintFormat("[DTE][EXIT] basket_id=%I64u reason=%s layers=%d netProfit=%.2f holdSec=%d",
                  basketId,CloseReasonStr(reason),layers,netProfit,holdSeconds);
     }

   static void MaxHold(const ulong basketId,const long ageSeconds,const long maxSeconds,const int layers,
                        const double floatingPl,const ENUM_CYCLE_DIRECTION dir,const string action)
     {
      PrintFormat("[BASKET][MAX_HOLD] basket_id=%I64u age_seconds=%d configured_max_seconds=%d layers=%d "
                  "floating_pl=%.2f direction=%s action=\"%s\"",
                  basketId,ageSeconds,maxSeconds,layers,floatingPl,
                  (dir==CYCLE_BUY?"BUY":"SELL"),action);
     }

   static void Spike(const ulong basketId,const double floating,const string outcome)
     {
      PrintFormat("[DTE][SPIKE] basket_id=%I64u floating=%.2f outcome=\"%s\"",basketId,floating,outcome);
     }

   static void Risk(const string what,const double value,const double limit,const string action)
     {
      PrintFormat("[DTE][RISK] what=\"%s\" value=%.3f limit=%.3f action=\"%s\"",what,value,limit,action);
     }

   static void Basket(const ulong basketId,const string what)
     {
      PrintFormat("[DTE][BASKET] basket_id=%I64u %s",basketId,what);
     }

   static void Target(const double initialBalance,const double currentBalance,const double profit,
                       const double profitPct,const double targetPct)
     {
      PrintFormat("[DTE][TARGET][HALT] initial_balance=%.2f current_balance=%.2f profit=%.2f "
                  "profit_pct=%.2f target_pct=%.2f timestamp=%s",
                  initialBalance,currentBalance,profit,profitPct,targetPct,
                  TimeToString(TimeCurrent(),TIME_DATE|TIME_SECONDS));
     }

   static string ThesisStr(const ENUM_THESIS_STATE s)
     {
      switch(s)
        {
         case THESIS_VALID:     return "VALID";
         case THESIS_WEAKENING: return "WEAKENING";
         case THESIS_INVALID:   return "INVALID";
         default: return "?";
        }
     }

   static string AdverseClassStr(const ENUM_ADVERSE_CLASS c)
     {
      switch(c)
        {
         case ADVERSE_RETRACEMENT:  return "RETRACEMENT";
         case ADVERSE_CONTINUATION: return "CONTINUATION";
         case ADVERSE_REVERSAL:     return "REVERSAL";
         default: return "NONE";
        }
     }

   static string RegimeStr(const ENUM_MARKET_REGIME r)
     {
      switch(r)
        {
         case REGIME_TREND_UP:        return "TREND_UP";
         case REGIME_TREND_DOWN:      return "TREND_DOWN";
         case REGIME_RANGE:           return "RANGE";
         case REGIME_HIGH_VOLATILITY: return "HIGH_VOLATILITY";
         case REGIME_LOW_VOLATILITY:  return "LOW_VOLATILITY";
         case REGIME_TRANSITION:      return "TRANSITION";
         default: return "UNKNOWN";
        }
     }

   static string CloseReasonStr(const ENUM_BASKET_CLOSE_REASON r)
     {
      switch(r)
        {
         case CLOSE_TP:             return "BASKET_TP";
         case CLOSE_MICRO_TP:       return "MICRO_TP";
         case CLOSE_SPIKE_EXIT:     return "SPIKE_EXIT";
         case CLOSE_THESIS_INVALID: return "THESIS_INVALID";
         case CLOSE_MAX_HOLD:       return "MAX_HOLD";
         case CLOSE_RISK_LIMIT:     return "RISK_EXIT";
         case CLOSE_HEDGE_EXIT:     return "HEDGE_EXIT";
         case CLOSE_MARGIN_CALL_EXT:return "MARGIN_CALL_EXT";
         default: return "OTHER";
        }
     }

   // Maps a close reason onto the 7-bucket loss-anatomy/expectancy index
   // (section 32/33) — single source of truth so LossAnatomy and
   // ExpectancyEngine never disagree on the mapping.
   static int LossReasonIndex(const ENUM_BASKET_CLOSE_REASON r)
     {
      switch(r)
        {
         case CLOSE_TP:              return (int)LOSS_EXIT_BASKET_TP;
         case CLOSE_MICRO_TP:        return (int)LOSS_EXIT_BASKET_TP;
         case CLOSE_SPIKE_EXIT:      return (int)LOSS_EXIT_SPIKE_EXIT;
         case CLOSE_THESIS_INVALID:  return (int)LOSS_EXIT_THESIS_INVALID;
         case CLOSE_MAX_HOLD:        return (int)LOSS_EXIT_MAX_HOLD;
         case CLOSE_RISK_LIMIT:      return (int)LOSS_EXIT_RISK_EXIT;
         case CLOSE_HEDGE_EXIT:      return (int)LOSS_EXIT_HEDGE_EXIT;
         default:                    return (int)LOSS_EXIT_OTHER;
        }
     }

   // Printed once at OnDeinit — the general OPERATIONAL forensic block.
   static void BuildForensicSummary(const SForensicCounters &c)
     {
      Print("================ DTE v4.0.0 FORENSIC SUMMARY ================");
      PrintFormat("Baskets: opened=%d tp=%d microTp=%d spike=%d marginCall=%d hedgeExit=%d",
                  c.basketsOpened,c.basketsClosedByTp,c.basketsClosedByMicroTp,c.basketsClosedBySpike,
                  c.basketsClosedByMarginCall,c.basketsClosedByHedgeExit);

      double avgLayers = c.basketsOpened>0 ? (double)c.layersPerBasketSum/c.basketsOpened : 0.0;
      PrintFormat("Layers/basket  : min=%d max=%d avg=%.2f",
                  c.layersPerBasketMin,c.layersPerBasketMax,avgLayers);

      double avgHold = c.basketsOpened>0 ? (double)c.basketHoldSecondsSum/c.basketsOpened : 0.0;
      PrintFormat("Hold time(sec) : min=%d max=%d avg=%.1f longestRecovery=%d",
                  c.basketHoldSecondsMin,c.basketHoldSecondsMax,avgHold,c.longestRecoverySeconds);

      PrintFormat("Cycle direction: buy=%d sell=%d",c.cycleDirectionBuy,c.cycleDirectionSell);
      PrintFormat("Entry score    : pass=%d reject=%d",c.entryScorePassCount,c.entryScoreRejectCount);
      PrintFormat("Entries skipped: margin=%d spread=%d session=%d news=%d dupSignal=%d invalidThesis=%d",
                  c.layersSkippedMargin,c.entriesSkippedSpread,c.entriesSkippedSession,
                  c.entriesSkippedNews,c.entriesSkippedDuplicateSignal,c.entriesSkippedInvalidThesis);
      PrintFormat("Recovery       : accepted=%d rejected=%d weakening=%d thesisInvalid=%d maxHold=%d "
                  "timeout=%d riskReject=%d",
                  c.recoveryAccepted,c.recoveryRejected,c.thesisWeakeningEvents,c.thesisInvalidations,
                  c.maxHoldExits,c.recoveryTimeoutExits,c.basketRiskRejected);
      PrintFormat("Adverse class  : retracement=%d continuation=%d reversal=%d",
                  c.adverseRetracementCount,c.adverseContinuationCount,c.adverseReversalCount);
      PrintFormat("Hedge events   : opened=%d closed=%d rejected=%d cooldownReject=%d maxPerBasketReject=%d",
                  c.hedgeEventsOpened,c.hedgeEventsClosed,c.hedgeRejected,c.hedgeCooldownRejected,
                  c.hedgeMaxPerBasketRejected);
      PrintFormat("Market closed  : %d",c.marketClosedEvents);
      PrintFormat("Halts          : profitTarget=%d equityDrawdown=%d",
                  c.profitTargetHaltEvents,c.equityDrawdownHaltEvents);
      PrintFormat("Close-verify   : retries=%d failures=%d",c.closeVerifyRetries,c.closeVerifyFailures);
      PrintFormat("Stats (audit)  : maxEquityDD=%.2f%% maxBalanceDD=%.2f%% maxFloatingLoss=%.2f "
                  "maxBasketLoss=%.2f maxBasketRisk=%.2f%% maxLayers=%d maxMarginUsage=%.2f%%",
                  c.maxEquityDrawdownPct,c.maxBalanceDrawdownPct,c.maxFloatingLoss,
                  c.maxBasketLoss,c.maxBasketRiskPct,c.maxLayerCountSeen,c.maxMarginUsagePct);
      PrintFormat("Thesis-invalid exit trigger: structural=%d equity=%d grace=%d",
                  c.thesisExitByStructural,c.thesisExitByEquity,c.thesisExitByGrace);

      Print("---- REGIME OCCURRENCE (section 34) ----");
      string rn[7]={"UNKNOWN","TREND_UP","TREND_DOWN","RANGE","HIGH_VOLATILITY","LOW_VOLATILITY","TRANSITION"};
      for(int i=0;i<7;i++)
         PrintFormat("  %-16s seenCount=%d",rn[i],c.regimeSeenCount[i]);

      Print("---- SPIKE EXIT DIAGNOSTICS ----");
      PrintFormat("  evaluated=%d candidates=%d accepted=%d "
                  "rejByProfit=%d rejByMove=%d rejByAtr=%d rejByWindow=%d",
                  c.spikeEvaluationCount,c.spikeCandidateCount,c.spikeAcceptedCount,
                  c.spikeRejectedByProfit,c.spikeRejectedByMove,c.spikeRejectedByAtr,
                  c.spikeRejectedByWindow);

      Print("=============================================================");
     }
  };

#endif // __DTE_LOGGER_MQH__
