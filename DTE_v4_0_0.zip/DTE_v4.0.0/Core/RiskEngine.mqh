//+------------------------------------------------------------------+
//| RiskEngine.mqh — CRiskEngine                                      |
//| Profit-target lifecycle (section 23) carried over verbatim from    |
//| v3.3.x — already correct: baseline/cycle-id/halted state persists  |
//| across restart, only an explicit manual reset (never a restart)    |
//| can clear it, and reset is refused while a basket is active.       |
//|                                                                     |
//| v4.0.0 NEW — section 16/40: InpMaxEquityDrawdownPercent is now a    |
//| enforced ACCOUNT-level circuit breaker (HALT_EQUITY_DRAWDOWN),      |
//| not just a passively tracked forensic statistic. It halts NEW       |
//| baskets the same way the profit target does — it does NOT force-    |
//| close an already-open basket (that would risk crystallizing a       |
//| loss at the worst possible moment; the basket's own thesis/risk     |
//| exits keep handling that). InpPreferredEquityDrawdownPercent is a   |
//| softer threshold that only LOGS a warning once per crossing.        |
//+------------------------------------------------------------------+
#ifndef __DTE_RISKENGINE_MQH__
#define __DTE_RISKENGINE_MQH__

#include "..\Config\Inputs.mqh"
#include "Logger.mqh"

class CRiskEngine
  {
private:
   string   m_symbol;
   string   m_gvPrefix;
   double   m_cycleBaseline;
   ulong    m_cycleId;
   double   m_peakBalance;
   double   m_peakEquity;
   bool     m_halted;
   ENUM_HALT_CAUSE m_haltCause;
   bool     m_preferredDdWarned;
   // v4.0.0 compile fix: MQL5 does not allow a pointer OR a reference
   // member to a struct type (only to class-type objects). SForensicCounters
   // is a struct, so CRiskEngine owns its own copy of the counters it is
   // responsible for, instead of pointing at an external one. The
   // composition root merges this with CPositionManager's own copy at
   // OnDeinit — see GoldHedgeRecovery.mq5.
   SForensicCounters m_fc;

   string GvKey(const string suffix) const { return m_gvPrefix+"_TARGET_"+suffix; }

public:
   CRiskEngine() : m_cycleBaseline(0.0), m_cycleId(0), m_peakBalance(0.0), m_peakEquity(0.0),
                   m_halted(false), m_haltCause(HALT_NONE), m_preferredDdWarned(false) { ZeroMemory(m_fc); }

   void Init(const string symbol)
     {
      m_symbol=symbol;
      ZeroMemory(m_fc);

      long login=AccountInfoInteger(ACCOUNT_LOGIN);
      m_gvPrefix=StringFormat("DTE_%I64d_%s_%d_v%d",login,symbol,(int)InpMagicNumber,DTE_STATE_VERSION);

      if(GlobalVariableCheck(GvKey("baseline")))
        {
         m_cycleBaseline=GlobalVariableGet(GvKey("baseline"));
         m_cycleId = GlobalVariableCheck(GvKey("cycleId")) ? (ulong)(long)GlobalVariableGet(GvKey("cycleId")) : 1;
        }
      else
        {
         m_cycleBaseline=AccountInfoDouble(ACCOUNT_BALANCE);
         m_cycleId=1;
         GlobalVariableSet(GvKey("baseline"),m_cycleBaseline);
         GlobalVariableSet(GvKey("cycleId"),(double)m_cycleId);
        }

      m_peakBalance=AccountInfoDouble(ACCOUNT_BALANCE);
      m_peakEquity =AccountInfoDouble(ACCOUNT_EQUITY);

      if(GlobalVariableCheck(GvKey("halted")) && GlobalVariableGet(GvKey("halted"))>0.5)
        {
         m_halted=true;
         m_haltCause=(ENUM_HALT_CAUSE)(GlobalVariableCheck(GvKey("haltCause"))
                       ?(int)GlobalVariableGet(GvKey("haltCause")):(int)HALT_PROFIT_TARGET);
         CLogger::Warn("RiskEngine",StringFormat(
            "Restored HALTED state from previous session (cycle #%I64u, cause=%s). Manual reset required.",
            m_cycleId,CLogger::HaltCauseToString(m_haltCause)));
        }

      CLogger::Info("RiskEngine",StringFormat(
         "Profit cycle #%I64u baseline=%.2f (persisted). Target at %.1fx (+%.0f%%). "
         "Equity-DD ceiling=%.1f%% (preferred warn=%.1f%%).",
         m_cycleId,m_cycleBaseline,InpProfitTargetMultiplier,(InpProfitTargetMultiplier-1.0)*100.0,
         InpMaxEquityDrawdownPercent,InpPreferredEquityDrawdownPercent));
     }

   bool IsHalted() const              { return m_halted; }
   ENUM_HALT_CAUSE HaltCause() const  { return m_haltCause; }
   double CycleBaseline() const       { return m_cycleBaseline; }
   ulong  CycleId() const             { return m_cycleId; }
   double TargetBalance() const       { return m_cycleBaseline*InpProfitTargetMultiplier; }

   double ProfitTargetProgressPct() const
     {
      double target=TargetBalance();
      double range=target-m_cycleBaseline;
      if(range<=0.0) return 0.0;
      double equity=AccountInfoDouble(ACCOUNT_EQUITY);
      double progress=((equity-m_cycleBaseline)/range)*100.0;
      if(progress<0.0) progress=0.0;
      if(progress>100.0) progress=100.0;
      return progress;
     }

   double CurrentDrawdownPct() const
     {
      double equity=AccountInfoDouble(ACCOUNT_EQUITY);
      if(m_peakEquity<=0.0) return 0.0;
      return MathMax(0.0,((m_peakEquity-equity)/m_peakEquity)*100.0);
     }

   // Call every tick.
   void EvaluateHalts()
     {
      double balance=AccountInfoDouble(ACCOUNT_BALANCE);
      double equity=AccountInfoDouble(ACCOUNT_EQUITY);
      if(balance>m_peakBalance) m_peakBalance=balance;
      if(equity>m_peakEquity)   m_peakEquity=equity;

      if(m_halted) return;

      if(InpTargetEnable && m_cycleBaseline>0.0 && equity>=TargetBalance())
        {
         m_halted=true; m_haltCause=HALT_PROFIT_TARGET;
         GlobalVariableSet(GvKey("halted"),1.0);
         GlobalVariableSet(GvKey("haltCause"),(double)HALT_PROFIT_TARGET);
         m_fc.profitTargetHaltEvents++;
         CLogger::Halt(m_haltCause,StringFormat("cycle #%I64u equity=%.2f reached target=%.2f",
                       m_cycleId,equity,TargetBalance()));
         CLogger::Target(m_cycleBaseline,AccountInfoDouble(ACCOUNT_BALANCE),
                          AccountInfoDouble(ACCOUNT_BALANCE)-m_cycleBaseline,
                          ((AccountInfoDouble(ACCOUNT_BALANCE)-m_cycleBaseline)/m_cycleBaseline)*100.0,
                          (InpProfitTargetMultiplier-1.0)*100.0);
         return;
        }

      // v4.0.0 NEW — account-level equity-drawdown circuit breaker.
      double ddPct=CurrentDrawdownPct();
      if(InpMaxEquityDrawdownPercent>0.0 && ddPct>=InpMaxEquityDrawdownPercent)
        {
         m_halted=true; m_haltCause=HALT_EQUITY_DRAWDOWN;
         GlobalVariableSet(GvKey("halted"),1.0);
         GlobalVariableSet(GvKey("haltCause"),(double)HALT_EQUITY_DRAWDOWN);
         m_fc.equityDrawdownHaltEvents++;
         CLogger::Halt(m_haltCause,StringFormat(
            "equity drawdown %.2f%% reached hard ceiling %.2f%% (peakEquity=%.2f currentEquity=%.2f)",
            ddPct,InpMaxEquityDrawdownPercent,m_peakEquity,equity));
         return;
        }

      if(!m_preferredDdWarned && InpPreferredEquityDrawdownPercent>0.0 &&
         ddPct>=InpPreferredEquityDrawdownPercent)
        {
         m_preferredDdWarned=true;
         CLogger::Warn("RiskEngine",StringFormat(
            "equity drawdown %.2f%% crossed preferred threshold %.2f%% (informational — not halted)",
            ddPct,InpPreferredEquityDrawdownPercent));
        }
      else if(m_preferredDdWarned && ddPct<InpPreferredEquityDrawdownPercent*0.5)
        {
         m_preferredDdWarned=false; // allow the warning to fire again after a real recovery
        }
     }

   bool RequestManualReset(const bool basketActive,string &resultMsg)
     {
      if(basketActive)
        {
         resultMsg="RESET DENIED — ACTIVE BASKET EXISTS";
         CLogger::Warn("RiskEngine",resultMsg);
         return false;
        }

      ulong previousCycle=m_cycleId;
      double previousBaseline=m_cycleBaseline;
      double currentBalance=AccountInfoDouble(ACCOUNT_BALANCE);

      m_cycleId=previousCycle+1;
      m_cycleBaseline=currentBalance;
      m_halted=false;
      m_haltCause=HALT_NONE;
      m_preferredDdWarned=false;
      m_peakBalance=currentBalance;
      m_peakEquity=AccountInfoDouble(ACCOUNT_EQUITY);

      GlobalVariableSet(GvKey("baseline"),m_cycleBaseline);
      GlobalVariableSet(GvKey("cycleId"),(double)m_cycleId);
      GlobalVariableSet(GvKey("halted"),0.0);
      GlobalVariableSet(GvKey("haltCause"),(double)HALT_NONE);

      resultMsg=StringFormat("Cycle #%I64u -> #%I64u, new baseline $%.2f",previousCycle,m_cycleId,m_cycleBaseline);

      Print("================================================");
      Print("DTE v4.0.0 PROFIT/RISK CYCLE RESET");
      PrintFormat("Previous cycle: #%I64u  Previous baseline: $%.2f",previousCycle,previousBaseline);
      PrintFormat("Current balance: $%.2f  New cycle: #%I64u  New baseline: $%.2f",
                  currentBalance,m_cycleId,m_cycleBaseline);
      Print("Status: ACTIVE");
      Print("================================================");
      return true;
     }

   void RecordDrawdownStats(const double basketFloating,const int layerCount,
                             const double basketLossIfNegative)
     {
      double balance=AccountInfoDouble(ACCOUNT_BALANCE);
      double equity =AccountInfoDouble(ACCOUNT_EQUITY);
      if(balance>m_peakBalance) m_peakBalance=balance;
      if(equity>m_peakEquity)   m_peakEquity=equity;

      double balanceDdPct = m_peakBalance>0.0 ? ((m_peakBalance-balance)/m_peakBalance)*100.0 : 0.0;
      double equityDdPct  = m_peakEquity>0.0  ? ((m_peakEquity-equity)/m_peakEquity)*100.0 : 0.0;
      double marginUsed=AccountInfoDouble(ACCOUNT_MARGIN);
      double marginUsagePct = (equity>0.0) ? (marginUsed/equity)*100.0 : 0.0;

      m_fc.maxEquityDrawdownPct=MathMax(m_fc.maxEquityDrawdownPct,equityDdPct);
      m_fc.maxBalanceDrawdownPct=MathMax(m_fc.maxBalanceDrawdownPct,balanceDdPct);
      m_fc.maxMarginUsagePct=MathMax(m_fc.maxMarginUsagePct,marginUsagePct);
      if(basketFloating<0.0) m_fc.maxFloatingLoss=MathMax(m_fc.maxFloatingLoss,-basketFloating);
      if(basketLossIfNegative<0.0) m_fc.maxBasketLoss=MathMax(m_fc.maxBasketLoss,-basketLossIfNegative);
      m_fc.maxLayerCountSeen=MathMax(m_fc.maxLayerCountSeen,(long)layerCount);
     }

   SForensicCounters GetForensicCounters() const { return m_fc; }
  };

#endif // __DTE_RISKENGINE_MQH__
