//+------------------------------------------------------------------+
//| PositionManager.mqh — CPositionManager                            |
//| v4.0.0 — orchestrator. Owns the basket lifecycle and delegates    |
//| every STRATEGY decision to its own module: entry scoring          |
//| (Strategy/SignalEngine.mqh), thesis validity (Strategy/            |
//| ThesisEngine.mqh), regime (Strategy/RegimeEngine.mqh), recovery    |
//| scoring (Recovery/RecoveryEngine.mqh), hedge decisions (Recovery/  |
//| HedgeEngine.mqh), and forensic reporting (Recovery/LossAnatomy.mqh,|
//| Recovery/ExpectancyEngine.mqh). PositionManager itself keeps only  |
//| EXECUTION plumbing — the parts that were already correct and       |
//| carefully hardened in v3.3.x and did not need to change:           |
//|  - CRITICAL close-safety: never finalize until every position is   |
//|    verified actually closed (section 30).                          |
//|  - Orphan-position recovery (an order executed but wasn't          |
//|    resolvable to a tracked ticket) — tracked and retried until      |
//|    resolved, never dropped (section 29/42).                        |
//|  - Hedge-close verified state machine — TRADE_RETCODE_DONE_PARTIAL |
//|    is never treated as "hedge gone".                               |
//|  - Restart-safe GlobalVariable persistence, namespaced by account  |
//|    login+symbol+magic+state version (section 28/29).               |
//|  - Non-martingale, capacity-based lot sizing (Core/LotSizing.mqh,  |
//|    unchanged verbatim — section 15/22).                            |
//+------------------------------------------------------------------+
#ifndef __DTE_POSITIONMANAGER_MQH__
#define __DTE_POSITIONMANAGER_MQH__

#include "..\Config\Inputs.mqh"
#include "TradeEngine.mqh"
#include "Logger.mqh"
#include "DealInfo.mqh"
#include "LotSizing.mqh"
#include "NewsFilter.mqh"
#include "SessionManager.mqh"
#include "..\Strategy\TrendEngine.mqh"
#include "..\Strategy\RegimeEngine.mqh"
#include "..\Strategy\SignalEngine.mqh"
#include "..\Strategy\ThesisEngine.mqh"
#include "..\Recovery\RecoveryEngine.mqh"
#include "..\Recovery\HedgeEngine.mqh"
#include "..\Recovery\LossAnatomy.mqh"
#include "..\Recovery\ExpectancyEngine.mqh"

// v3.3.2 issue #2, carried over verbatim — tracks one order that executed
// but could not (yet) be attached to normal basket/hedge tracking.
struct SOrphanRecord
  {
   ulong    ticket;
   bool     ticketKnown;
   string   expectedComment;
   string   context;
   datetime nextRetryTime;
   int      attempts;
  };

class CPositionManager
  {
private:
   string        m_symbol;
   long          m_magic;
   string        m_gvPrefix;

   CTradeEngine     *m_tradeEngine;  // not owned
   CTrendEngine     *m_trend;        // not owned
   CRegimeEngine    *m_regime;       // not owned
   CSignalEngine    *m_signal;       // not owned
   CThesisEngine    *m_thesisEngine; // not owned
   CRecoveryEngine  *m_recovery;     // not owned
   CHedgeEngine     *m_hedge;        // not owned
   CNewsFilter      *m_news;         // not owned
   CLossAnatomy     *m_lossAnatomy;  // not owned
   CExpectancyEngine*m_expectancy;   // not owned
   // v4.0.0 compile fix: MQL5 allows neither a pointer NOR a reference
   // member to a struct type (only to class-type objects). CPositionManager
   // therefore owns its counters directly; the composition root merges
   // this with CRiskEngine's own copy at OnDeinit (see GoldHedgeRecovery.mq5).
   SForensicCounters m_fc;

   int            m_layerAtrHandle;

   SBasketState  m_basket;
   SThesis       m_thesis; // in-memory only — see SThesis comment in Config/Inputs.mqh
   ulong         m_tickets[];
   ulong         m_currentBasketId;
   int           m_lastKnownStillOpen;

   bool                     m_closePending;
   ENUM_BASKET_CLOSE_REASON m_closePendingReason;

   SOrphanRecord m_orphans[];

   // event-driven recovery evaluation (carried from v3.3.3/4) — a recovery
   // opportunity (target layer + current M5 bar) is evaluated once, not
   // every tick, until a new M5 candle forms.
   datetime m_lastRecoveryEvalBarTime;
   int      m_lastRecoveryEvalLayer;
   string   m_lastRecoveryRejectReason;
   int      m_lastRecoveryRejectLayer;

public:
   CPositionManager() : m_tradeEngine(NULL), m_trend(NULL), m_regime(NULL), m_signal(NULL),
                         m_thesisEngine(NULL), m_recovery(NULL), m_hedge(NULL), m_news(NULL),
                         m_lossAnatomy(NULL), m_expectancy(NULL),
                         m_layerAtrHandle(INVALID_HANDLE), m_currentBasketId(0), m_lastKnownStillOpen(0),
                         m_closePending(false), m_closePendingReason(CLOSE_NONE),
                         m_lastRecoveryEvalBarTime(0), m_lastRecoveryEvalLayer(0),
                         m_lastRecoveryRejectReason(""), m_lastRecoveryRejectLayer(0)
     {
      ZeroMemory(m_basket); ZeroMemory(m_thesis); ZeroMemory(m_fc);
     }

   bool Init(const string symbol,const long magic,CTradeEngine *tradeEngine,CTrendEngine *trend,
             CRegimeEngine *regime,CSignalEngine *signal,CThesisEngine *thesisEngine,
             CRecoveryEngine *recovery,CHedgeEngine *hedge,CNewsFilter *news,
             CLossAnatomy *lossAnatomy,CExpectancyEngine *expectancy)
     {
      m_symbol=symbol; m_magic=magic;
      m_tradeEngine=tradeEngine; m_trend=trend; m_regime=regime; m_signal=signal;
      m_thesisEngine=thesisEngine; m_recovery=recovery; m_hedge=hedge; m_news=news;
      m_lossAnatomy=lossAnatomy; m_expectancy=expectancy;
      ZeroMemory(m_fc);

      long login=AccountInfoInteger(ACCOUNT_LOGIN);
      m_gvPrefix=StringFormat("DTE_%I64d_%s_%d_v%d",login,symbol,(int)magic,DTE_STATE_VERSION);
      m_layerAtrHandle=iATR(symbol,InpTfTrigger,InpAtrPeriod);

      ZeroMemory(m_basket); ZeroMemory(m_thesis);
      ArrayResize(m_tickets,0);
      m_lastKnownStillOpen=0;
      m_closePending=false;
      ArrayResize(m_orphans,0);
      m_lastRecoveryEvalBarTime=0; m_lastRecoveryEvalLayer=0;
      m_lastRecoveryRejectReason=""; m_lastRecoveryRejectLayer=0;

      RestorePersistedState();
      return (m_layerAtrHandle!=INVALID_HANDLE);
     }

   void SyncHaltState(const bool halted)
     {
      if(!m_basket.active) return;
      if(halted)
        {
         if(!m_closePending && m_basket.state!=BSTATE_EXIT_EVALUATION &&
            m_basket.state!=BSTATE_BASKET_CLOSE_PENDING)
            m_basket.state=BSTATE_HALTED;
        }
      else if(m_basket.state==BSTATE_HALTED)
         m_basket.state=BSTATE_POSITION_ACTIVE;
     }

   bool IsBasketActive() const { return m_basket.active; }
   SBasketState GetBasketState() const { return m_basket; }
   SThesis      GetThesis() const { return m_thesis; }
   SForensicCounters GetForensicCounters() const { return m_fc; }
   bool HasPendingOrphans() const { return ArraySize(m_orphans)>0; }
   int  PendingOrphanCount() const { return ArraySize(m_orphans); }

   //=====================================================================
   // ENTRY — opens LAYER 1 ONLY (section 3/7). Builds the explicit trade
   // thesis at the same moment.
   //=====================================================================
   void StartBasket(const ENUM_CYCLE_DIRECTION dir,const SEntryScore &entry,
                     const ENUM_SESSION_NAME session)
     {
      if(m_basket.active) return;
      if(HasPendingOrphans())
        {
         CLogger::Warn("PositionManager","New basket blocked — orphan recovery still in progress.");
         return;
        }

      double lot; string lotReason;
      if(!CLotSizing::CalculateAdaptiveBaseLot(m_symbol,dir,InpMaxLayers,lot,lotReason))
        {
         CLogger::Info("PositionManager",StringFormat("No trade this cycle — %s",lotReason));
         return;
        }

      m_currentBasketId=NextBasketId();
      string comment=BuildComment(m_currentBasketId);

      double projectedRisk=ProjectedBasketRiskPct(lot,true,dir);
      m_fc.maxBasketRiskPct=MathMax(m_fc.maxBasketRiskPct,projectedRisk);
      if(projectedRisk>InpHardBasketRiskPercent)
        {
         m_fc.basketRiskRejected++;
         CLogger::Risk("initial basket risk",projectedRisk,InpHardBasketRiskPercent,"REJECTED — exceeds hard ceiling");
         return;
        }

      ulong ticket=0; string err;
      if(!m_tradeEngine.OpenMarket(dir,lot,comment,ticket,err))
        {
         if(m_tradeEngine.WasMarketClosedEvent()) m_fc.marketClosedEvents++;
         CLogger::Warn("PositionManager",StringFormat("Layer #1 broker rejection: %s",err));
         return;
        }
      if(ticket==0) ticket=ResolveExecutedTicket(comment);
      if(ticket==0)
        {
         CLogger::Error("PositionManager","Layer #1 executed but ticket could not be resolved after retries.");
         RegisterOrphan(comment,"layer1");
         return;
        }

      ZeroMemory(m_basket);
      ArrayResize(m_tickets,0); ArrayResize(m_tickets,1);
      m_tickets[0]=ticket;

      double entryPrice=(dir==CYCLE_BUY)?SymbolInfoDouble(m_symbol,SYMBOL_ASK):SymbolInfoDouble(m_symbol,SYMBOL_BID);

      m_basket.active             = true;
      m_basket.direction          = dir;
      m_basket.cycleStartBalance  = AccountInfoDouble(ACCOUNT_BALANCE);
      m_basket.cycleStartTime     = TimeCurrent(); // TRUE lifecycle start — never reset (section 17)
      m_basket.basketTpTarget     = m_basket.cycleStartBalance*(InpBasketTpPercent/100.0);
      m_basket.layersOpen         = 1;
      m_basket.lastLayerPrice     = entryPrice;
      m_basket.hedgeState         = HEDGE_NORMAL;
      m_basket.hedgeActive        = false;
      m_basket.hedgeTicket        = 0;
      m_basket.hedgeEventCount    = 0;
      m_basket.peakFloatingProfit = 0.0;
      m_basket.peakFloatingTime   = TimeCurrent();
      m_basket.selectedBaseLot    = lot;
      m_basket.state              = BSTATE_POSITION_ACTIVE;
      m_basket.thesisState        = THESIS_VALID;
      m_basket.entryScore         = entry.score;
      m_basket.entryRegime        = entry.regime;
      m_basket.recoveryStartTime  = 0;
      m_basket.lastHedgeCloseTime = 0;
      m_basket.thesisInvalidatedTime = 0;
      m_basket.thesisWeakeningTime   = 0;
      m_basket.maxAdverseExcursionPts   = 0.0;
      m_basket.maxFavorableExcursionPts = 0.0;
      m_basket.maxBasketRiskPct   = projectedRisk;

      m_thesis=m_thesisEngine.BuildThesis(dir,entryPrice,entry);
      m_lastKnownStillOpen=1;

        {
         m_fc.basketsOpened++;
         if(dir==CYCLE_BUY) m_fc.cycleDirectionBuy++; else m_fc.cycleDirectionSell++;
         m_fc.regimeSeenCount[(int)entry.regime]++;
        }

      CLogger::Entry(m_currentBasketId,dir,1,lot,entry.score,entry.regime,"initial trigger");
      PersistState();

      CLogger::Info("PositionManager",StringFormat(
         "Basket #%I64u opened: dir=%s lot=%.2f score=%d regime=%s cycleStartBalance=%.2f tpTarget(+%.2f%%)=%.2f",
         m_currentBasketId,(dir==CYCLE_BUY?"BUY":"SELL"),lot,entry.score,CLogger::RegimeStr(entry.regime),
         m_basket.cycleStartBalance,InpBasketTpPercent,m_basket.basketTpTarget));
     }

   //=====================================================================
   // RECOVERY (sections 8-14) — thesis re-evaluated first, THEN recovery
   // scored. Event-driven: a given opportunity is evaluated once per new
   // M5 bar, not every tick (section 38 performance requirement).
   //=====================================================================
   void TryAddRecoveryLayer(const ENUM_SESSION_NAME session,const bool riskHalted)
     {
      if(!m_basket.active || m_closePending) return;
      if(riskHalted) return;
      if(HasPendingOrphans()) return;

      datetime now=TimeCurrent();
      long holdSeconds=(long)(now-m_basket.cycleStartTime);

      // section 17 — TRUE HARD max-hold limit. Timer never resets on layer/
      // hedge/restart (cycleStartTime set once in StartBasket()).
      if(InpMaxBasketHoldMinutes>0 && holdSeconds>=InpMaxBasketHoldMinutes*60)
        {
         if(m_basket.state!=BSTATE_MAX_HOLD_EXIT)
           {
            m_basket.state=BSTATE_MAX_HOLD_EXIT;
            m_fc.maxHoldExits++;
            CLogger::MaxHold(m_currentBasketId,holdSeconds,(long)InpMaxBasketHoldMinutes*60,
                              m_basket.layersOpen,m_basket.basketFloatingProfit,m_basket.direction,
                              "force-exit — no new recovery/hedge/entry");
            InitiateClose(CLOSE_MAX_HOLD);
           }
         return;
        }

      // Re-evaluate thesis every management pass (cheap — indicator reads
      // only, no per-tick loops) so state transitions are caught promptly.
      string invReason;
      int invScore=m_thesisEngine.EvaluateInvalidation(m_thesis,invReason);
      ENUM_THESIS_STATE prevState=m_basket.thesisState;
      m_basket.thesisState=m_thesis.state;

      if(m_thesis.state!=prevState)
        {
         if(m_thesis.state==THESIS_WEAKENING)
           {
            m_basket.thesisWeakeningTime=now;
            m_fc.thesisWeakeningEvents++;
            CLogger::ThesisWeak(m_currentBasketId,invScore,invReason);
           }
         else if(m_thesis.state==THESIS_INVALID)
           {
            m_basket.thesisInvalidatedTime=now;
            m_fc.thesisInvalidations++;
            CLogger::ThesisInvalid(m_currentBasketId,invScore,invReason);
           }
        }
      CLogger::Thesis(m_currentBasketId,m_thesis.state,invScore);

      double curPriceForExcursion=(m_basket.direction==CYCLE_BUY)?SymbolInfoDouble(m_symbol,SYMBOL_BID)
                                                                   :SymbolInfoDouble(m_symbol,SYMBOL_ASK);
      m_thesisEngine.UpdateExcursion(m_thesis,curPriceForExcursion);
      m_basket.maxAdverseExcursionPts=m_thesis.maxAdverseExcursionPts;
      m_basket.maxFavorableExcursionPts=m_thesis.maxFavorableExcursionPts;

      // section 9/13 — once thesis is INVALID, recovery is permanently
      // disabled for this basket; only the grace/structural/equity exit
      // triggers apply (handled in UpdateAndCheckTp()).
      if(m_thesis.state==THESIS_INVALID) { m_basket.state=BSTATE_THESIS_INVALID; return; }
      if(m_thesis.state==THESIS_WEAKENING) m_basket.state=BSTATE_THESIS_WEAKENING;

      if(!InpRecoveryEnable) return;
      if(m_basket.layersOpen>=InpMaxLayers) return;
      if(m_basket.hedgeActive) return; // protection mode: never layer while hedge is active

      if(m_basket.layersOpen>1 && m_basket.recoveryStartTime>0 && InpRecoveryTimeoutMinutes>0 &&
         (now-m_basket.recoveryStartTime)>=InpRecoveryTimeoutMinutes*60)
        {
         m_fc.recoveryTimeoutExits++;
         InitiateClose(CLOSE_RISK_LIMIT);
         return;
        }

      if(m_news!=NULL && m_news.Evaluate())
        {
         m_fc.entriesSkippedNews++;
         return;
        }

      double distance=m_recovery.ComputeLayerDistance();
      if(distance<=0.0) return;

      double curPrice=(m_basket.direction==CYCLE_BUY)?SymbolInfoDouble(m_symbol,SYMBOL_BID)
                                                       :SymbolInfoDouble(m_symbol,SYMBOL_ASK);
      double movedAgainst=(m_basket.direction==CYCLE_BUY)
                           ? (m_basket.lastLayerPrice-curPrice) : (curPrice-m_basket.lastLayerPrice);
      if(movedAgainst<distance) return; // distance only arms evaluation

      // event-driven throttle (section 38) — one evaluation per new M5 bar
      // per target layer, not every tick.
      datetime curM5Bar=iTime(m_symbol,InpTfTrigger,0);
      bool isNewOpportunity=(curM5Bar!=m_lastRecoveryEvalBarTime) || (m_basket.layersOpen!=m_lastRecoveryEvalLayer);
      if(!isNewOpportunity) return;
      m_lastRecoveryEvalBarTime=curM5Bar;
      m_lastRecoveryEvalLayer=m_basket.layersOpen;

      m_basket.state=BSTATE_RECOVERY_EVALUATION;
      int targetLayer=m_basket.layersOpen+1;

      ENUM_ADVERSE_CLASS cls=m_thesisEngine.ClassifyAdverseMove(m_thesis);
        {
         if(cls==ADVERSE_RETRACEMENT)  m_fc.adverseRetracementCount++;
         if(cls==ADVERSE_CONTINUATION) m_fc.adverseContinuationCount++;
         if(cls==ADVERSE_REVERSAL)     m_fc.adverseReversalCount++;
        }
      CLogger::RecoveryEvaluate(m_currentBasketId,targetLayer,cls);

      SRecoveryScore rec=m_recovery.Evaluate(m_thesis,targetLayer,m_regime.Classify());

      double point=SymbolInfoDouble(m_symbol,SYMBOL_POINT);
      double movedPts=(point>0.0)?movedAgainst/point:0.0;
      double distPts=(point>0.0)?distance/point:0.0;
      double atr=(m_layerAtrHandle!=INVALID_HANDLE)?GetLayerAtr():0.0;

      if(!rec.passed)
        {
         m_fc.recoveryRejected++;
         LogRecoveryRejectThrottled(targetLayer,rec.score,rec.reason,movedPts,distPts,atr);
         m_basket.state=BSTATE_POSITION_ACTIVE;
         return;
        }

      double lot; string lotReason;
      if(!CLotSizing::GetAffordableLot(m_symbol,m_basket.direction,m_basket.selectedBaseLot,lot,lotReason,true))
        {
         m_fc.layersSkippedMargin++;
         m_basket.state=BSTATE_POSITION_ACTIVE;
         CLogger::Info("PositionManager",StringFormat(
            "Recovery layer skipped — lot %.2f not safely affordable (%s).",m_basket.selectedBaseLot,lotReason));
         return;
        }

      double projectedRisk=ProjectedBasketRiskPct(lot,true,m_basket.direction);
      m_basket.maxBasketRiskPct=MathMax(m_basket.maxBasketRiskPct,projectedRisk);
      m_fc.maxBasketRiskPct=MathMax(m_fc.maxBasketRiskPct,projectedRisk);
      if(projectedRisk>InpHardBasketRiskPercent)
        {
         m_fc.basketRiskRejected++;
         CLogger::Risk("recovery layer risk",projectedRisk,InpHardBasketRiskPercent,"REJECTED — exceeds hard ceiling");
         m_basket.state=BSTATE_POSITION_ACTIVE;
         return;
        }

      string comment=BuildComment(m_currentBasketId);
      ulong ticket=0; string err;
      if(!m_tradeEngine.OpenMarket(m_basket.direction,lot,comment,ticket,err))
        {
         if(m_tradeEngine.WasMarketClosedEvent()) m_fc.marketClosedEvents++;
         CLogger::Warn("PositionManager",StringFormat("Recovery layer broker rejection: %s",err));
         m_basket.state=BSTATE_POSITION_ACTIVE;
         return;
        }
      if(ticket==0) ticket=ResolveExecutedTicket(comment);
      if(ticket==0)
        {
         CLogger::Error("PositionManager","Recovery layer executed but ticket unresolved after retries.");
         RegisterOrphan(comment,"recovery");
         return;
        }

      int n=ArraySize(m_tickets);
      ArrayResize(m_tickets,n+1);
      m_tickets[n]=ticket;
      m_basket.layersOpen=n+1;
      m_thesis.currentLayer=n+1;
      m_basket.lastLayerPrice=curPrice;
      m_lastKnownStillOpen=n+1;
      if(m_basket.recoveryStartTime==0) m_basket.recoveryStartTime=now;
      m_basket.state=BSTATE_RECOVERY_PENDING;
        {
         m_fc.recoveryAccepted++;
         m_fc.maxLayerCountSeen=MathMax(m_fc.maxLayerCountSeen,(long)m_basket.layersOpen);
        }

      CLogger::RecoveryAccept(m_currentBasketId,targetLayer,rec.score,rec.reason);
      CLogger::Entry(m_currentBasketId,m_basket.direction,targetLayer,lot,rec.score,m_regime.Classify(),
                     "recovery layer confirmed");
      m_basket.state=BSTATE_POSITION_ACTIVE;
      PersistState();
     }

   //=====================================================================
   // HEDGE (section 21) — pure risk-management tool, structural-only
   // trigger (CHedgeEngine, unchanged from v3.3.x), capped by
   // InpMaxHedgesPerBasket (NEW — prevents any hedge-loop scenario).
   //=====================================================================
   void ManageHedge(const ENUM_SESSION_NAME session,const bool riskHalted)
     {
      if(!m_basket.active || m_closePending || m_hedge==NULL) return;
      if(!InpHedgeEnable) return;

      ENUM_HEDGE_STATE hs=m_hedge.Evaluate(m_basket.direction,IsBasketLosing());
      double structScore=m_hedge.OpposingStructureScore(m_basket.direction);
      m_basket.hedgeState=hs;

      if(m_basket.hedgeActive && m_basket.hedgeCloseState==HEDGE_CLOSE_PARTIAL)
        {
         AttemptHedgeClose(hs);
         return;
        }

      long holdSecondsNow=(long)(TimeCurrent()-m_basket.cycleStartTime);
      bool maxHoldReached=(InpMaxBasketHoldMinutes>0 && holdSecondsNow>=InpMaxBasketHoldMinutes*60);
      if(maxHoldReached)
        {
         if(m_basket.hedgeActive && (hs==HEDGE_NORMAL||hs==HEDGE_RECOVERY) && structScore<InpHedgeMinStructureScore)
            AttemptHedgeClose(hs);
         return;
        }

      bool hedgeBudgetLeft=(m_basket.hedgeEventCount<InpMaxHedgesPerBasket);

      if(!riskHalted && !m_basket.hedgeActive && !HasPendingOrphans() && hedgeBudgetLeft &&
         hs==HEDGE_ACTIVE && structScore>=InpHedgeMinStructureScore)
        {
         CLogger::HedgeEvaluate(m_currentBasketId,hs,structScore);

         if(m_basket.lastHedgeCloseTime>0 &&
            (TimeCurrent()-m_basket.lastHedgeCloseTime)<InpHedgeCooldownMinutes*60)
           {
            m_fc.hedgeCooldownRejected++;
            return;
           }

         double lot; string lotReason;
         double hedgeDesired=MathMin(InpHedgeLot,InpHedgeMaxLot);
         if(!CLotSizing::GetAffordableLot(m_symbol,OppositeDir(m_basket.direction),hedgeDesired,lot,lotReason,true))
           {
            m_fc.hedgeRejected++;
            CLogger::Info("PositionManager",StringFormat("Hedge rejected — %s",lotReason));
            return;
           }

         double riskBefore=ProjectedNetRiskPct(0.0,false);
         double riskAfter=ProjectedNetRiskPct(lot,true);
         if(riskAfter>=riskBefore)
           {
            m_fc.hedgeRejected++;
            CLogger::Risk("hedge net risk",riskAfter,riskBefore,"REJECTED — does not reduce net exposure");
            return;
           }

         string comment=BuildComment(m_currentBasketId)+"H";
         ulong ticket=0; string err;
         ENUM_CYCLE_DIRECTION hedgeDir=OppositeDir(m_basket.direction);
         if(!m_tradeEngine.OpenMarket(hedgeDir,lot,comment,ticket,err))
           {
            if(m_tradeEngine.WasMarketClosedEvent()) m_fc.marketClosedEvents++;
            m_fc.hedgeRejected++;
            CLogger::Warn("PositionManager",StringFormat("Hedge open rejection: %s",err));
            return;
           }
         if(ticket==0) ticket=ResolveExecutedTicket(comment);
         if(ticket==0)
           {
            m_fc.hedgeRejected++;
            CLogger::Error("PositionManager","Hedge executed but ticket unresolved after retries.");
            RegisterOrphan(comment,"hedge");
            return;
           }

         m_basket.hedgeActive=true;
         m_basket.hedgeTicket=ticket;
         m_basket.hedgeEventCount++;
         m_basket.state=BSTATE_HEDGE_ACTIVE;
         m_fc.hedgeEventsOpened++;
         CLogger::HedgeOpen(m_currentBasketId,
            StringFormat("confirmed opposing structure score=%.1f (event %d/%d this basket)",
                         structScore,m_basket.hedgeEventCount,InpMaxHedgesPerBasket),
            hedgeDir,lot,(hedgeDir==CYCLE_BUY)?SymbolInfoDouble(m_symbol,SYMBOL_ASK):SymbolInfoDouble(m_symbol,SYMBOL_BID));
         PersistState();
        }
      else if(!hedgeBudgetLeft && !m_basket.hedgeActive && hs==HEDGE_ACTIVE &&
              structScore>=InpHedgeMinStructureScore)
        {
         m_fc.hedgeMaxPerBasketRejected++;
        }
      else if(m_basket.hedgeActive && (hs==HEDGE_NORMAL||hs==HEDGE_RECOVERY) && structScore<InpHedgeMinStructureScore)
        {
         AttemptHedgeClose(hs);
        }
     }

   //=====================================================================
   // Exit engine (section 18-20) — spike, then ordinary TP, then micro-
   // profit mode, then thesis-invalid triggers, then risk-limit.
   //=====================================================================
   void UpdateAndCheckTp()
     {
      if(!m_basket.active) return;
      if(m_closePending) { AttemptCloseRetry(); return; }

      double floating=0.0;
      int stillOpen=0;
      for(int i=0;i<ArraySize(m_tickets);i++)
        {
         if(PositionSelectByTicket(m_tickets[i]))
           {
            floating+=PositionGetDouble(POSITION_PROFIT)+PositionGetDouble(POSITION_SWAP);
            floating+=CDteDealInfo::BestEffortEntryCommission(m_tickets[i]);
            stillOpen++;
           }
        }
      if(m_basket.hedgeActive && PositionSelectByTicket(m_basket.hedgeTicket))
        {
         floating+=PositionGetDouble(POSITION_PROFIT)+PositionGetDouble(POSITION_SWAP);
         floating+=CDteDealInfo::BestEffortEntryCommission(m_basket.hedgeTicket);
        }

      m_basket.basketFloatingProfit=floating;
      if(floating>m_basket.peakFloatingProfit)
        { m_basket.peakFloatingProfit=floating; m_basket.peakFloatingTime=TimeCurrent(); }

      if(stillOpen!=m_lastKnownStillOpen)
        {
         if(stillOpen>0 && stillOpen<ArraySize(m_tickets))
            CLogger::Warn("PositionManager",StringFormat("Partial stop-out: %d/%d layers remain.",stillOpen,ArraySize(m_tickets)));
         m_basket.layersOpen=stillOpen;
         m_lastKnownStillOpen=stillOpen;
         PersistState();
        }

      if(stillOpen==0 && ArraySize(m_tickets)>0)
        {
         CLogger::Warn("PositionManager","All basket layers closed externally (likely margin call/stop-out).");
         FinalizeBasket(CLOSE_MARGIN_CALL_EXT);
         return;
        }

      long holdSeconds=(long)(TimeCurrent()-m_basket.cycleStartTime);
      if(InpMaxBasketHoldMinutes>0 && holdSeconds>=InpMaxBasketHoldMinutes*60)
        {
         CLogger::MaxHold(m_currentBasketId,holdSeconds,(long)InpMaxBasketHoldMinutes*60,
                           m_basket.layersOpen,floating,m_basket.direction,"force-exit on management pass");
         InitiateClose(CLOSE_MAX_HOLD);
         return;
        }

      double equity=AccountInfoDouble(ACCOUNT_EQUITY);
      double actualLossRisk=(equity>0.0 && floating<0.0)?(-floating/equity)*100.0:0.0;
      m_fc.maxBasketRiskPct=MathMax(m_fc.maxBasketRiskPct,actualLossRisk);
      if(actualLossRisk>=InpHardBasketRiskPercent)
        {
         m_fc.basketRiskRejected++;
         CLogger::Risk("actual floating loss",actualLossRisk,InpHardBasketRiskPercent,"force-exit — hard ceiling");
         InitiateClose(CLOSE_RISK_LIMIT);
         return;
        }

      if(InpUseSpikeExit && CheckSpikeExit(floating))
        {
         CLogger::Spike(m_currentBasketId,floating,"favorable impulse — closing now, not waiting for pullback");
         InitiateClose(CLOSE_SPIKE_EXIT);
         return;
        }

      if(floating>=m_basket.basketTpTarget)
        {
         InitiateClose(CLOSE_TP);
         return;
        }

      // section 19 — MICRO-PROFIT MODE: close early once the basket has a
      // small positive expected value, rather than forcing every basket to
      // reach the full TP target. Guarded by a minimum hold so a basket
      // isn't closed for a few cents seconds after opening.
      if(InpUseMicroProfitMode &&
         holdSeconds>=InpMicroProfitMinHoldMinutes*60 &&
         floating>=(InpMicroProfitMinPercent/100.0)*m_basket.cycleStartBalance)
        {
         InitiateClose(CLOSE_MICRO_TP);
         return;
        }

      // section 9/13 — thesis-invalid exit triggers. Structural (basket-
      // relative) trigger carried from the v3.3.4 hot-fix — the equity-%
      // trigger alone was found to almost never fire at small lot sizes.
      if(m_thesis.state==THESIS_INVALID && m_basket.thesisInvalidatedTime>0)
        {
         long invalidAge=(long)(TimeCurrent()-m_basket.thesisInvalidatedTime);
         bool graceExpired=(InpThesisInvalidationGraceMinutes<=0 ||
                             invalidAge>=InpThesisInvalidationGraceMinutes*60);

         double structuralCap=m_basket.basketTpTarget*InpThesisInvalidLossToTpMultiple;
         bool structuralTrigger=(structuralCap>0.0 && floating<0.0 && (-floating)>=structuralCap);

         bool equityTrigger=(actualLossRisk>=InpMaxBasketRiskPercent);

         if(graceExpired || structuralTrigger || equityTrigger)
           {
              {
               if(structuralTrigger)   m_fc.thesisExitByStructural++;
               else if(equityTrigger)  m_fc.thesisExitByEquity++;
               else                    m_fc.thesisExitByGrace++;
              }
            InitiateClose(CLOSE_THESIS_INVALID);
           }
         return;
        }
     }

   void ManageProtection() { ProcessOrphanRecovery(); }

private:
   //=====================================================================
   // Risk projection helpers — same coherent-scenario models as v3.3.x
   // (unchanged; already correct — section 48 "do not destroy the good
   // parts").
   //=====================================================================
   double ProjectedBasketRiskPct(const double newLot,const bool includeNewLayer,
                                  const ENUM_CYCLE_DIRECTION extraDir=CYCLE_NONE) const
     {
      double equity=AccountInfoDouble(ACCOUNT_EQUITY);
      if(equity<=0.0) return 100.0;

      double currentFloatingLoss=0.0;
      for(int i=0;i<ArraySize(m_tickets);i++)
         if(PositionSelectByTicket(m_tickets[i]))
           {
            double p=PositionGetDouble(POSITION_PROFIT)+PositionGetDouble(POSITION_SWAP);
            currentFloatingLoss += (p<0.0 ? -p : 0.0);
           }
      if(m_basket.hedgeActive && PositionSelectByTicket(m_basket.hedgeTicket))
        {
         double hp=PositionGetDouble(POSITION_PROFIT)+PositionGetDouble(POSITION_SWAP);
         currentFloatingLoss += (hp<0.0 ? -hp : 0.0);
        }

      double atr=GetLayerAtr();
      if(atr<=0.0) return 100.0;
      double adverseMove=atr*InpAtrMultiplier;
      double ask=SymbolInfoDouble(m_symbol,SYMBOL_ASK);
      double bid=SymbolInfoDouble(m_symbol,SYMBOL_BID);
      double adversePriceBuy=bid-adverseMove;
      double adversePriceSell=ask+adverseMove;
      double projectedAdditional=0.0;

      for(int i=0;i<ArraySize(m_tickets);i++)
        {
         if(!PositionSelectByTicket(m_tickets[i])) continue;
         ENUM_POSITION_TYPE ptype=(ENUM_POSITION_TYPE)PositionGetInteger(POSITION_TYPE);
         double volume=PositionGetDouble(POSITION_VOLUME);
         ENUM_ORDER_TYPE otype=(ptype==POSITION_TYPE_BUY)?ORDER_TYPE_BUY:ORDER_TYPE_SELL;
         double fromPrice=(ptype==POSITION_TYPE_BUY)?bid:ask;
         double toPrice=(ptype==POSITION_TYPE_BUY)?adversePriceBuy:adversePriceSell;
         double loss=0.0;
         if(OrderCalcProfit(otype,m_symbol,volume,fromPrice,toPrice,loss) && loss<0.0)
            projectedAdditional += -loss;
        }

      if(includeNewLayer && newLot>0.0)
        {
         ENUM_CYCLE_DIRECTION projectedDir=(extraDir==CYCLE_NONE)?m_basket.direction:extraDir;
         ENUM_ORDER_TYPE otype=(projectedDir==CYCLE_BUY)?ORDER_TYPE_BUY:ORDER_TYPE_SELL;
         double fromPrice=(projectedDir==CYCLE_BUY)?ask:bid;
         double toPrice=(projectedDir==CYCLE_BUY)?adversePriceBuy:adversePriceSell;
         double loss=0.0;
         if(OrderCalcProfit(otype,m_symbol,newLot,fromPrice,toPrice,loss) && loss<0.0)
            projectedAdditional += -loss;
        }

      double buffer=projectedAdditional*(InpRiskSpreadSlippagePercent/100.0);
      double totalDamage=currentFloatingLoss+projectedAdditional+buffer;
      return (totalDamage/equity)*100.0;
     }

   double ProjectedNetRiskPct(const double candidateHedgeLot,const bool includeCandidateHedge) const
     {
      double equity=AccountInfoDouble(ACCOUNT_EQUITY);
      if(equity<=0.0) return 100.0;
      double atr=GetLayerAtr();
      if(atr<=0.0) return 100.0;
      double adverseMove=atr*InpAtrMultiplier;

      double bid=SymbolInfoDouble(m_symbol,SYMBOL_BID);
      double ask=SymbolInfoDouble(m_symbol,SYMBOL_ASK);
      bool basketIsBuy=(m_basket.direction==CYCLE_BUY);
      double scenarioPrice=basketIsBuy?(bid-adverseMove):(ask+adverseMove);

      double netPnl=0.0;
      for(int i=0;i<ArraySize(m_tickets);i++)
        {
         if(!PositionSelectByTicket(m_tickets[i])) continue;
         ENUM_POSITION_TYPE ptype=(ENUM_POSITION_TYPE)PositionGetInteger(POSITION_TYPE);
         double volume=PositionGetDouble(POSITION_VOLUME);
         ENUM_ORDER_TYPE otype=(ptype==POSITION_TYPE_BUY)?ORDER_TYPE_BUY:ORDER_TYPE_SELL;
         double fromPrice=(ptype==POSITION_TYPE_BUY)?bid:ask;
         double pnl=0.0;
         if(OrderCalcProfit(otype,m_symbol,volume,fromPrice,scenarioPrice,pnl)) netPnl+=pnl;
        }
      if(m_basket.hedgeActive && PositionSelectByTicket(m_basket.hedgeTicket))
        {
         ENUM_POSITION_TYPE ptype=(ENUM_POSITION_TYPE)PositionGetInteger(POSITION_TYPE);
         double volume=PositionGetDouble(POSITION_VOLUME);
         ENUM_ORDER_TYPE otype=(ptype==POSITION_TYPE_BUY)?ORDER_TYPE_BUY:ORDER_TYPE_SELL;
         double fromPrice=(ptype==POSITION_TYPE_BUY)?bid:ask;
         double pnl=0.0;
         if(OrderCalcProfit(otype,m_symbol,volume,fromPrice,scenarioPrice,pnl)) netPnl+=pnl;
        }
      if(includeCandidateHedge && candidateHedgeLot>0.0)
        {
         ENUM_CYCLE_DIRECTION hedgeDir=OppositeDir(m_basket.direction);
         ENUM_ORDER_TYPE otype=(hedgeDir==CYCLE_BUY)?ORDER_TYPE_BUY:ORDER_TYPE_SELL;
         double fromPrice=(hedgeDir==CYCLE_BUY)?ask:bid;
         double pnl=0.0;
         if(OrderCalcProfit(otype,m_symbol,candidateHedgeLot,fromPrice,scenarioPrice,pnl)) netPnl+=pnl;
        }

      double netLoss=(netPnl<0.0)?-netPnl:0.0;
      double buffer=netLoss*(InpRiskSpreadSlippagePercent/100.0);
      return ((netLoss+buffer)/equity)*100.0;
     }

   ENUM_CYCLE_DIRECTION OppositeDir(const ENUM_CYCLE_DIRECTION d) const { return (d==CYCLE_BUY)?CYCLE_SELL:CYCLE_BUY; }
   bool IsBasketLosing() const { return m_basket.basketFloatingProfit<0.0; }

   double GetLayerAtr() const
     {
      if(m_layerAtrHandle==INVALID_HANDLE) return 0.0;
      double buf[]; ArraySetAsSeries(buf,true);
      if(CopyBuffer(m_layerAtrHandle,0,1,1,buf)<=0) return 0.0;
      return buf[0];
     }

   void LogRecoveryRejectThrottled(const int layer,const int score,const string reason,
                                    const double movedPts,const double distPts,const double atr)
     {
      if(m_lastRecoveryRejectLayer==layer && m_lastRecoveryRejectReason==reason) return;
      m_lastRecoveryRejectLayer=layer; m_lastRecoveryRejectReason=reason;

      SStructureAnalysis m15; ZeroMemory(m15);
      if(m_regime!=NULL && m_regime.Structure()!=NULL) m15=m_regime.Structure().Analyze(InpTfStruct);
      bool m5Ok=(m_signal!=NULL)?m_signal.IsM5TriggerValid(m_basket.direction):false;

      CLogger::RecoveryReject(m_currentBasketId,layer,m_basket.direction,score,InpMinRecoveryScore,
                               m5Ok,m15.state,(m_trend!=NULL?m_trend.GetBias():BIAS_NEUTRAL),
                               atr,distPts,m_basket.basketFloatingProfit,reason);
     }

   //=====================================================================
   // Spike exit (section 20) — unchanged algorithm from v3.3.x.
   //=====================================================================
   bool CheckSpikeExit(const double floating)
     {
      m_fc.spikeEvaluationCount++;
      if(floating<(InpSpikeExitMinPercent/100.0)*m_basket.cycleStartBalance)
        { m_fc.spikeRejectedByProfit++; return false; }
      m_fc.spikeCandidateCount++;

      datetime pastTime=TimeCurrent()-InpSpikeExitWindowSeconds;
      int shift=iBarShift(m_symbol,PERIOD_M1,pastTime,false);
      if(shift<0) { m_fc.spikeRejectedByWindow++; return false; }
      double pastPrice=iClose(m_symbol,PERIOD_M1,shift);
      if(pastPrice<=0.0) { m_fc.spikeRejectedByWindow++; return false; }

      double curPrice=(m_basket.direction==CYCLE_BUY)?SymbolInfoDouble(m_symbol,SYMBOL_BID):SymbolInfoDouble(m_symbol,SYMBOL_ASK);
      double point=SymbolInfoDouble(m_symbol,SYMBOL_POINT);
      double movePts=(m_basket.direction==CYCLE_BUY)?(curPrice-pastPrice)/point:(pastPrice-curPrice)/point;
      double atr=GetLayerAtr();
      double atrPts=(point>0.0 && atr>0.0)?(atr/point)*InpSpikeExitMinAtrMultiple:0.0;
      double triggerPts=MathMax(InpSpikeExitTriggerPoints,atrPts);

      bool pass=(movePts>=triggerPts);
      if(!pass)
        {
           { if(atrPts>InpSpikeExitTriggerPoints) m_fc.spikeRejectedByAtr++; else m_fc.spikeRejectedByMove++; }
         return false;
        }
      m_fc.spikeAcceptedCount++;
      return true;
     }

   //=====================================================================
   // CRITICAL close-safety (section 30) — unchanged from v3.3.x.
   //=====================================================================
   void InitiateClose(const ENUM_BASKET_CLOSE_REASON reason)
     {
      if(m_closePending) return;
      m_closePending=true;
      m_basket.state=BSTATE_BASKET_CLOSE_PENDING;
      m_closePendingReason=reason;
      PersistState();
      AttemptCloseRetry();
     }

   void AttemptHedgeClose(const ENUM_HEDGE_STATE hs)
     {
      datetime now=TimeCurrent();
      if(m_basket.hedgeCloseState==HEDGE_CLOSE_PARTIAL && now<m_basket.hedgeCloseRetryTime) return;

      if(!PositionSelectByTicket(m_basket.hedgeTicket)) { FinalizeHedgeClosed(hs); return; }

      double volBefore=PositionGetDouble(POSITION_VOLUME);
      ulong ticket=m_basket.hedgeTicket;
      string err;
      m_tradeEngine.ClosePositionByTicket(ticket,err);
      uint rc=m_tradeEngine.LastCloseRetcode();

      bool stillOpen=PositionSelectByTicket(ticket);
      double volAfter=stillOpen?PositionGetDouble(POSITION_VOLUME):0.0;

      if(!stillOpen || volAfter<=0.0) { FinalizeHedgeClosed(hs); return; }

      m_basket.hedgeCloseState=HEDGE_CLOSE_PARTIAL;
      m_basket.hedgeRemainingVolume=volAfter;
      m_basket.hedgeCloseRetryTime=now+InpHedgeCloseRetrySeconds;
      PersistState();
      PrintFormat("[DTE][HEDGE][PARTIAL_CLOSE] ticket=%d requested=%.2f remaining=%.2f retcode=%d",
                  (int)ticket,volBefore,volAfter,rc);
     }

   void FinalizeHedgeClosed(const ENUM_HEDGE_STATE hs)
     {
      m_fc.hedgeEventsClosed++;
      CLogger::HedgeClose(m_currentBasketId,"opposing structure faded — verified fully closed",0.0);
      m_basket.hedgeActive=false;
      m_basket.hedgeTicket=0;
      m_basket.hedgeCloseState=HEDGE_CLOSE_NONE;
      m_basket.hedgeRemainingVolume=0.0;
      m_basket.hedgeCloseRetryTime=0;
      m_basket.lastHedgeCloseTime=TimeCurrent();
      m_basket.state=(m_basket.thesisState==THESIS_INVALID)?BSTATE_THESIS_INVALID:BSTATE_POSITION_ACTIVE;
      PersistState();
     }

   void AttemptCloseRetry()
     {
      bool allClosed=true;
      if(m_tradeEngine!=NULL && m_tradeEngine.MarketClosedUntil()>TimeCurrent()) return;

      for(int i=0;i<ArraySize(m_tickets);i++)
        {
         if(PositionSelectByTicket(m_tickets[i]))
           {
            allClosed=false;
            string err;
            if(!m_tradeEngine.ClosePositionByTicket(m_tickets[i],err))
               CLogger::Warn("PositionManager",StringFormat("Close retry failed ticket=%d err=%s",(int)m_tickets[i],err));
           }
        }
      if(m_basket.hedgeActive && PositionSelectByTicket(m_basket.hedgeTicket))
        {
         allClosed=false;
         string err;
         if(!m_tradeEngine.ClosePositionByTicket(m_basket.hedgeTicket,err))
            CLogger::Warn("PositionManager",StringFormat("Hedge close retry failed ticket=%d err=%s",(int)m_basket.hedgeTicket,err));
        }

      if(allClosed) { m_closePending=false; FinalizeBasket(m_closePendingReason); }
      else
        {
         m_fc.closeVerifyRetries++;
         CLogger::Warn("PositionManager","Basket close verification: positions still open — retrying, NOT finalizing.");
        }
     }

   void FinalizeBasket(const ENUM_BASKET_CLOSE_REASON reason)
     {
      long holdSeconds=(long)(TimeCurrent()-m_basket.cycleStartTime);

      // Prefer the EXACT realized result (sum of all deals on every basket
      // ticket, entry+exit sides) now that the positions are actually
      // closed, falling back to the last live floating snapshot if history
      // lookup comes back empty (e.g. some tester edge cases).
      double exactNet=0.0; bool haveExact=true;
      for(int i=0;i<ArraySize(m_tickets);i++)
        {
         double p,s,c;
         if(CDteDealInfo::FinalRealizedResult(m_tickets[i],p,s,c)) exactNet+=(p+s+c);
         else haveExact=false;
        }
      if(m_basket.hedgeTicket>0)
        {
         double p,s,c;
         if(CDteDealInfo::FinalRealizedResult(m_basket.hedgeTicket,p,s,c)) exactNet+=(p+s+c);
        }
      double netProfit=haveExact?exactNet:m_basket.basketFloatingProfit;

        {
         switch(reason)
           {
            case CLOSE_TP:              m_fc.basketsClosedByTp++; break;
            case CLOSE_MICRO_TP:        m_fc.basketsClosedByMicroTp++; break;
            case CLOSE_SPIKE_EXIT:      m_fc.basketsClosedBySpike++; break;
            case CLOSE_MARGIN_CALL_EXT: m_fc.basketsClosedByMarginCall++; break;
            case CLOSE_HEDGE_EXIT:      m_fc.basketsClosedByHedgeExit++; break;
            default: break;
           }
         m_fc.layersPerBasketSum+=m_basket.layersOpen;
         if(m_fc.layersPerBasketMin==0 || m_basket.layersOpen<m_fc.layersPerBasketMin) m_fc.layersPerBasketMin=m_basket.layersOpen;
         if(m_basket.layersOpen>m_fc.layersPerBasketMax) m_fc.layersPerBasketMax=m_basket.layersOpen;
         m_fc.basketHoldSecondsSum+=holdSeconds;
         if(m_fc.basketHoldSecondsMin==0 || holdSeconds<m_fc.basketHoldSecondsMin) m_fc.basketHoldSecondsMin=holdSeconds;
         if(holdSeconds>m_fc.basketHoldSecondsMax) m_fc.basketHoldSecondsMax=holdSeconds;
         if(m_basket.layersOpen>1) m_fc.longestRecoverySeconds=MathMax(m_fc.longestRecoverySeconds,holdSeconds);
         if(netProfit<0.0 && (-netProfit)>m_fc.maxBasketLoss) m_fc.maxBasketLoss=-netProfit;
        }

      if(m_lossAnatomy!=NULL) m_lossAnatomy.Record(reason,netProfit,holdSeconds);
      if(m_expectancy!=NULL)
        {
         CSessionManager sess; // stateless helper — cheap to construct
         m_expectancy.Record(m_basket.direction,sess.CurrentSession(),m_basket.entryRegime,
                              m_basket.layersOpen,reason,m_basket.thesisState,netProfit);
        }

      CLogger::Exit(m_currentBasketId,reason,m_basket.layersOpen,netProfit,holdSeconds);

      ZeroMemory(m_basket); ZeroMemory(m_thesis);
      ArrayResize(m_tickets,0);
      m_lastKnownStillOpen=0;
      m_closePending=false;
      m_lastRecoveryEvalBarTime=0; m_lastRecoveryEvalLayer=0;
      m_lastRecoveryRejectReason=""; m_lastRecoveryRejectLayer=0;
      ClearPersistedState();
     }

   string BuildComment(const ulong basketId) const { return InpTradeComment+"_"+IntegerToString(basketId); }

   bool IsTicketTracked(const ulong ticket) const
     {
      for(int i=0;i<ArraySize(m_tickets);i++) if(m_tickets[i]==ticket) return true;
      if(ticket==m_basket.hedgeTicket) return true;
      for(int i=0;i<ArraySize(m_orphans);i++) if(m_orphans[i].ticketKnown && m_orphans[i].ticket==ticket) return true;
      return false;
     }

   ulong ResolveExecutedTicket(const string expectedComment) const
     {
      ulong ticket=FallbackFindUntrackedTicket(expectedComment);
      for(int attempt=0; attempt<3 && ticket==0; attempt++)
        { Sleep(200); ticket=FallbackFindUntrackedTicket(expectedComment); }
      return ticket;
     }

   void RegisterOrphan(const string expectedComment,const string context)
     {
      int n=ArraySize(m_orphans);
      ArrayResize(m_orphans,n+1);
      m_orphans[n].ticket=0; m_orphans[n].ticketKnown=false;
      m_orphans[n].expectedComment=expectedComment; m_orphans[n].context=context;
      m_orphans[n].nextRetryTime=0; m_orphans[n].attempts=0;
      if(m_basket.active) m_basket.state=BSTATE_ORPHAN_RECOVERY;
      PrintFormat("[DTE][EXECUTION][ORPHAN_DETECTED] symbol=%s magic=%d expectedComment=%s context=%s",
                  m_symbol,(int)m_magic,expectedComment,context);
     }

   void ProcessOrphanRecovery()
     {
      datetime now=TimeCurrent();
      for(int i=ArraySize(m_orphans)-1; i>=0; i--)
        {
         if(now<m_orphans[i].nextRetryTime) continue;

         if(!m_orphans[i].ticketKnown)
           {
            ulong t=FallbackFindUntrackedTicket(m_orphans[i].expectedComment);
            if(t==0)
              { m_orphans[i].attempts++; m_orphans[i].nextRetryTime=now+InpOrphanCloseRetrySeconds; continue; }
            m_orphans[i].ticket=t; m_orphans[i].ticketKnown=true;
            PrintFormat("[DTE][EXECUTION][ORPHAN_TRACKED] symbol=%s ticket=%d magic=%d context=%s",
                        m_symbol,(int)t,(int)m_magic,m_orphans[i].context);
           }

         if(!PositionSelectByTicket(m_orphans[i].ticket))
           {
            PrintFormat("[DTE][EXECUTION][ORPHAN_CLOSED] symbol=%s ticket=%d magic=%d context=%s attempts=%d",
                        m_symbol,(int)m_orphans[i].ticket,(int)m_magic,m_orphans[i].context,m_orphans[i].attempts);
            RemoveOrphanAt(i);
            continue;
           }

         if(PositionGetString(POSITION_SYMBOL)!=m_symbol ||
            (long)PositionGetInteger(POSITION_MAGIC)!=m_magic ||
            PositionGetString(POSITION_COMMENT)!=m_orphans[i].expectedComment)
           {
            PrintFormat("[DTE][EXECUTION][ORPHAN_FAILURE] symbol=%s ticket=%d magic=%d context=%s "
                        "reason=\"identity no longer matches — will not touch, keeping tracked\"",
                        m_symbol,(int)m_orphans[i].ticket,(int)m_magic,m_orphans[i].context);
            m_orphans[i].attempts++; m_orphans[i].nextRetryTime=now+InpOrphanCloseRetrySeconds;
            continue;
           }

         double vol=PositionGetDouble(POSITION_VOLUME);
         ENUM_POSITION_TYPE ptype=(ENUM_POSITION_TYPE)PositionGetInteger(POSITION_TYPE);
         string err;
         m_orphans[i].attempts++;
         m_tradeEngine.ClosePositionByTicket(m_orphans[i].ticket,err);
         uint rc=m_tradeEngine.LastCloseRetcode();
         bool stillOpen=PositionSelectByTicket(m_orphans[i].ticket);
         if(!stillOpen)
           {
            PrintFormat("[DTE][EXECUTION][ORPHAN_CLOSED] symbol=%s ticket=%d dir=%s volume=%.2f magic=%d context=%s attempts=%d",
                        m_symbol,(int)m_orphans[i].ticket,(ptype==POSITION_TYPE_BUY?"BUY":"SELL"),
                        vol,(int)m_magic,m_orphans[i].context,m_orphans[i].attempts);
            RemoveOrphanAt(i);
           }
         else
           {
            m_orphans[i].nextRetryTime=now+InpOrphanCloseRetrySeconds;
            PrintFormat("[DTE][EXECUTION][ORPHAN_CLOSE_RETRY] symbol=%s ticket=%d dir=%s volume=%.2f magic=%d "
                        "context=%s attempts=%d retcode=%d err=%s",
                        m_symbol,(int)m_orphans[i].ticket,(ptype==POSITION_TYPE_BUY?"BUY":"SELL"),
                        vol,(int)m_magic,m_orphans[i].context,m_orphans[i].attempts,rc,err);
           }
        }
      if(ArraySize(m_orphans)==0 && m_basket.active && m_basket.state==BSTATE_ORPHAN_RECOVERY)
         m_basket.state=BSTATE_POSITION_ACTIVE;
     }

   void RemoveOrphanAt(const int idx)
     {
      int n=ArraySize(m_orphans);
      for(int j=idx; j<n-1; j++) m_orphans[j]=m_orphans[j+1];
      ArrayResize(m_orphans,n-1);
     }

   ulong FallbackFindUntrackedTicket(const string expectedComment) const
     {
      ulong best=0; datetime bestTime=0;
      int total=PositionsTotal();
      for(int i=0;i<total;i++)
        {
         ulong ticket=PositionGetTicket(i);
         if(ticket==0) continue;
         if(!PositionSelectByTicket(ticket)) continue;
         if(PositionGetString(POSITION_SYMBOL)!=m_symbol) continue;
         if((long)PositionGetInteger(POSITION_MAGIC)!=m_magic) continue;
         if(PositionGetString(POSITION_COMMENT)!=expectedComment) continue;
         if(IsTicketTracked(ticket)) continue;
         datetime t=(datetime)PositionGetInteger(POSITION_TIME);
         if(t>=bestTime) { bestTime=t; best=ticket; }
        }
      return best;
     }

   //=====================================================================
   // Persistence — namespaced by account login+symbol+magic+state version.
   //=====================================================================
   string GvKey(const string suffix) const { return m_gvPrefix+"_BASKET_"+suffix; }

   ulong NextBasketId()
     {
      string key=m_gvPrefix+"_basketSeq";
      double cur=GlobalVariableCheck(key)?GlobalVariableGet(key):0.0;
      double next=cur+1.0;
      GlobalVariableSet(key,next);
      return (ulong)next;
     }

   void PersistState()
     {
      GlobalVariableSet(GvKey("active"),m_basket.active?1.0:0.0);
      GlobalVariableSet(GvKey("id"),(double)m_currentBasketId);
      GlobalVariableSet(GvKey("direction"),(double)m_basket.direction);
      GlobalVariableSet(GvKey("layers"),(double)m_basket.layersOpen);
      GlobalVariableSet(GvKey("cycleStartBalance"),m_basket.cycleStartBalance);
      GlobalVariableSet(GvKey("cycleStartTime"),(double)m_basket.cycleStartTime);
      GlobalVariableSet(GvKey("tpTarget"),m_basket.basketTpTarget);
      GlobalVariableSet(GvKey("lastLayerPrice"),m_basket.lastLayerPrice);
      GlobalVariableSet(GvKey("selectedBaseLot"),m_basket.selectedBaseLot);
      GlobalVariableSet(GvKey("state"),(double)m_basket.state);
      GlobalVariableSet(GvKey("recoveryStartTime"),(double)m_basket.recoveryStartTime);
      GlobalVariableSet(GvKey("lastHedgeCloseTime"),(double)m_basket.lastHedgeCloseTime);
      GlobalVariableSet(GvKey("thesisInvalidatedTime"),(double)m_basket.thesisInvalidatedTime);
      GlobalVariableSet(GvKey("thesisWeakeningTime"),(double)m_basket.thesisWeakeningTime);
      GlobalVariableSet(GvKey("thesisState"),(double)m_basket.thesisState);
      GlobalVariableSet(GvKey("entryScore"),(double)m_basket.entryScore);
      GlobalVariableSet(GvKey("entryRegime"),(double)m_basket.entryRegime);
      GlobalVariableSet(GvKey("hedgeEventCount"),(double)m_basket.hedgeEventCount);
      GlobalVariableSet(GvKey("maxBasketRiskPct"),m_basket.maxBasketRiskPct);
      GlobalVariableSet(GvKey("hedgeActive"),m_basket.hedgeActive?1.0:0.0);
      GlobalVariableSet(GvKey("hedgeTicket"),(double)m_basket.hedgeTicket);
      GlobalVariableSet(GvKey("hedgeCloseState"),(double)m_basket.hedgeCloseState);
      GlobalVariableSet(GvKey("hedgeRemainingVolume"),m_basket.hedgeRemainingVolume);
      GlobalVariableSet(GvKey("hedgeCloseRetryTime"),(double)m_basket.hedgeCloseRetryTime);
      GlobalVariableSet(GvKey("ticketCount"),(double)ArraySize(m_tickets));
      for(int i=0;i<ArraySize(m_tickets);i++)
         GlobalVariableSet(GvKey("ticket_"+IntegerToString(i)),(double)m_tickets[i]);
     }

   void ClearPersistedState()
     {
      string keys[]={"active","id","direction","layers","cycleStartBalance","cycleStartTime","tpTarget",
                      "lastLayerPrice","selectedBaseLot","state","recoveryStartTime","lastHedgeCloseTime",
                      "thesisInvalidatedTime","thesisWeakeningTime","thesisState","entryScore","entryRegime",
                      "hedgeEventCount","maxBasketRiskPct","hedgeActive","hedgeTicket","hedgeCloseState",
                      "hedgeRemainingVolume","hedgeCloseRetryTime"};
      for(int i=0;i<ArraySize(keys);i++) GlobalVariableDel(GvKey(keys[i]));

      int oldCount=GlobalVariableCheck(GvKey("ticketCount"))?(int)GlobalVariableGet(GvKey("ticketCount")):0;
      for(int i=0;i<oldCount;i++) GlobalVariableDel(GvKey("ticket_"+IntegerToString(i)));
      GlobalVariableDel(GvKey("ticketCount"));
     }

   void RestorePersistedState()
     {
      if(!GlobalVariableCheck(GvKey("active"))) return;
      if(GlobalVariableGet(GvKey("active"))<0.5) return;

      SBasketState restored; ZeroMemory(restored);
      restored.active=true;
      restored.direction=(ENUM_CYCLE_DIRECTION)(int)GlobalVariableGet(GvKey("direction"));
      restored.cycleStartBalance=GlobalVariableGet(GvKey("cycleStartBalance"));
      restored.cycleStartTime=(datetime)(long)GlobalVariableGet(GvKey("cycleStartTime"));
      restored.basketTpTarget=GlobalVariableGet(GvKey("tpTarget"));
      restored.lastLayerPrice=GlobalVariableCheck(GvKey("lastLayerPrice"))?GlobalVariableGet(GvKey("lastLayerPrice")):0.0;
      restored.selectedBaseLot=GlobalVariableCheck(GvKey("selectedBaseLot"))?GlobalVariableGet(GvKey("selectedBaseLot")):InpBaseLot;
      restored.state=GlobalVariableCheck(GvKey("state"))?(ENUM_BASKET_STATE)(int)GlobalVariableGet(GvKey("state")):BSTATE_POSITION_ACTIVE;
      restored.recoveryStartTime=GlobalVariableCheck(GvKey("recoveryStartTime"))?(datetime)(long)GlobalVariableGet(GvKey("recoveryStartTime")):0;
      restored.lastHedgeCloseTime=GlobalVariableCheck(GvKey("lastHedgeCloseTime"))?(datetime)(long)GlobalVariableGet(GvKey("lastHedgeCloseTime")):0;
      restored.thesisInvalidatedTime=GlobalVariableCheck(GvKey("thesisInvalidatedTime"))?(datetime)(long)GlobalVariableGet(GvKey("thesisInvalidatedTime")):0;
      restored.thesisWeakeningTime=GlobalVariableCheck(GvKey("thesisWeakeningTime"))?(datetime)(long)GlobalVariableGet(GvKey("thesisWeakeningTime")):0;
      restored.thesisState=GlobalVariableCheck(GvKey("thesisState"))?(ENUM_THESIS_STATE)(int)GlobalVariableGet(GvKey("thesisState")):THESIS_VALID;
      restored.entryScore=GlobalVariableCheck(GvKey("entryScore"))?(int)GlobalVariableGet(GvKey("entryScore")):0;
      restored.entryRegime=GlobalVariableCheck(GvKey("entryRegime"))?(ENUM_MARKET_REGIME)(int)GlobalVariableGet(GvKey("entryRegime")):REGIME_UNKNOWN;
      restored.hedgeEventCount=GlobalVariableCheck(GvKey("hedgeEventCount"))?(int)GlobalVariableGet(GvKey("hedgeEventCount")):0;
      restored.maxBasketRiskPct=GlobalVariableCheck(GvKey("maxBasketRiskPct"))?GlobalVariableGet(GvKey("maxBasketRiskPct")):0.0;
      restored.hedgeActive=GlobalVariableCheck(GvKey("hedgeActive")) && GlobalVariableGet(GvKey("hedgeActive"))>0.5;
      restored.hedgeTicket=GlobalVariableCheck(GvKey("hedgeTicket"))?(ulong)(long)GlobalVariableGet(GvKey("hedgeTicket")):0;
      restored.hedgeCloseState=GlobalVariableCheck(GvKey("hedgeCloseState"))?(ENUM_HEDGE_CLOSE_STATE)(int)GlobalVariableGet(GvKey("hedgeCloseState")):HEDGE_CLOSE_NONE;
      restored.hedgeRemainingVolume=GlobalVariableCheck(GvKey("hedgeRemainingVolume"))?GlobalVariableGet(GvKey("hedgeRemainingVolume")):0.0;
      restored.hedgeCloseRetryTime=GlobalVariableCheck(GvKey("hedgeCloseRetryTime"))?(datetime)(long)GlobalVariableGet(GvKey("hedgeCloseRetryTime")):0;

      ulong basketId=GlobalVariableCheck(GvKey("id"))?(ulong)(long)GlobalVariableGet(GvKey("id")):0;

      int ticketCount=(int)GlobalVariableGet(GvKey("ticketCount"));
      ulong recoveredTickets[]; ArrayResize(recoveredTickets,0);
      for(int i=0;i<ticketCount;i++)
        {
         string key=GvKey("ticket_"+IntegerToString(i));
         if(!GlobalVariableCheck(key)) continue;
         ulong t=(ulong)(long)GlobalVariableGet(key);
         if(t==0) continue;
         if(PositionSelectByTicket(t))
           { int n=ArraySize(recoveredTickets); ArrayResize(recoveredTickets,n+1); recoveredTickets[n]=t; }
        }

      bool hedgeStillOpen=restored.hedgeActive && restored.hedgeTicket>0 && PositionSelectByTicket(restored.hedgeTicket);
      if(!hedgeStillOpen)
        {
         restored.hedgeActive=false; restored.hedgeTicket=0;
         restored.hedgeCloseState=HEDGE_CLOSE_NONE; restored.hedgeRemainingVolume=0.0; restored.hedgeCloseRetryTime=0;
        }

      if(ArraySize(recoveredTickets)==0)
        {
         CLogger::Warn("PositionManager","Persisted basket found but no tracked tickets are still open — clearing state.");
         ClearPersistedState();
         return;
        }

      m_basket=restored;
      m_basket.layersOpen=ArraySize(recoveredTickets);
      m_basket.peakFloatingProfit=0.0;
      m_basket.peakFloatingTime=TimeCurrent();
      ArrayResize(m_tickets,ArraySize(recoveredTickets));
      for(int i=0;i<ArraySize(recoveredTickets);i++) m_tickets[i]=recoveredTickets[i];
      m_lastKnownStillOpen=ArraySize(recoveredTickets);
      m_currentBasketId=basketId;

      // v4.0.0 — the rich in-memory SThesis (swing refs, fib refs, MAE/MFE)
      // is intentionally NOT fully persisted (see Config/Inputs.mqh's
      // SThesis comment) — recompute a fresh baseline thesis from what we
      // DO know (direction, last layer price, persisted entry score/regime)
      // so the engines have something sane to work with immediately;
      // EvaluateInvalidation() will re-derive the real state within one
      // management pass regardless.
      SEntryScore approxEntry; ZeroMemory(approxEntry);
      approxEntry.score=m_basket.entryScore; approxEntry.regime=m_basket.entryRegime;
      approxEntry.direction=m_basket.direction;
      m_thesis=m_thesisEngine.BuildThesis(m_basket.direction,m_basket.lastLayerPrice,approxEntry);
      m_thesis.state=m_basket.thesisState;
      m_thesis.timestamp=m_basket.cycleStartTime;
      m_thesis.currentLayer=m_basket.layersOpen;

      CLogger::Info("PositionManager",StringFormat(
         "Recovered basket #%I64u: dir=%s layers=%d (originally %d) cycleStartBalance=%.2f tpTarget=%.2f hedgeActive=%s",
         m_currentBasketId,(m_basket.direction==CYCLE_BUY?"BUY":"SELL"),m_basket.layersOpen,ticketCount,
         m_basket.cycleStartBalance,m_basket.basketTpTarget,(m_basket.hedgeActive?"YES":"NO")));

      PersistState();
     }
  };

#endif // __DTE_POSITIONMANAGER_MQH__
