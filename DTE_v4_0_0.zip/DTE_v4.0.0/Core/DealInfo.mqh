//+------------------------------------------------------------------+
//| DealInfo.mqh — CDealInfo                                          |
//| v4.0.0 SECTION 50 deliverable. Extracted from PositionManager's   |
//| inline commission-lookup helper (v3.3.x BestEffortEntryCommission)|
//| into its own small, reusable module — pure read-only history      |
//| lookups, no trading side-effects.                                  |
//+------------------------------------------------------------------+
#ifndef __DTE_DEALINFO_MQH__
#define __DTE_DEALINFO_MQH__

class CDealInfo
  {
public:
   // Best-effort: sums commission already charged on deals belonging to a
   // still-open position (entry-side only — exit-side commission isn't
   // knowable until the position actually closes, so this remains an
   // approximation while the position is open; see FinalCommission() below
   // for the exact figure once it's closed). Same limitation as v3.3.x,
   // just relocated.
   static double BestEffortEntryCommission(const ulong ticket)
     {
      double total=0.0;
      if(!HistorySelectByPosition(ticket)) return 0.0;
      int totalDeals=HistoryDealsTotal();
      for(int i=0;i<totalDeals;i++)
        {
         ulong dealTicket=HistoryDealGetTicket(i);
         if(dealTicket==0) continue;
         total+=HistoryDealGetDouble(dealTicket,DEAL_COMMISSION);
        }
      return total;
     }

   // Once a position has actually closed, this returns the EXACT net
   // realized result (profit + swap + commission) summed across every deal
   // tied to that position id — entry AND exit sides. Use this in
   // FinalizeBasket() where possible instead of the last-seen floating
   // estimate, so loss-anatomy/expectancy figures are exact, not
   // approximate.
   static bool FinalRealizedResult(const ulong positionId,double &profitOut,double &swapOut,
                                    double &commissionOut)
     {
      profitOut=0.0; swapOut=0.0; commissionOut=0.0;
      if(!HistorySelectByPosition(positionId)) return false;
      int totalDeals=HistoryDealsTotal();
      if(totalDeals<=0) return false;
      for(int i=0;i<totalDeals;i++)
        {
         ulong dealTicket=HistoryDealGetTicket(i);
         if(dealTicket==0) continue;
         profitOut    +=HistoryDealGetDouble(dealTicket,DEAL_PROFIT);
         swapOut      +=HistoryDealGetDouble(dealTicket,DEAL_SWAP);
         commissionOut+=HistoryDealGetDouble(dealTicket,DEAL_COMMISSION);
        }
      return true;
     }

   static double FinalNetResult(const ulong positionId)
     {
      double p,s,c;
      if(!FinalRealizedResult(positionId,p,s,c)) return 0.0;
      return p+s+c;
     }
  };

#endif // __DTE_DEALINFO_MQH__
