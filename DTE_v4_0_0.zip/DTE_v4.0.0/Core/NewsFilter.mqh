//+------------------------------------------------------------------+
//| NewsFilter.mqh — CNewsFilter                                      |
//| v3.1.0: uses the built-in MQL5 Economic Calendar API. Filters by  |
//| the symbol's profit/quote currency (USD for XAUUSD) and the       |
//| configured minimum importance. Blocks NEW entries during the      |
//| lock window; does NOT auto-close existing baskets (section 22).   |
//| After the lock window, an additional "stabilization" window       |
//| keeps new entries blocked so that whatever the confluence engine  |
//| sees afterward reflects settled price action, not the first       |
//| post-news candle — "re-evaluate direction", not "follow the spike"|
//+------------------------------------------------------------------+
#ifndef __DTE_NEWSFILTER_MQH__
#define __DTE_NEWSFILTER_MQH__

#include "..\Config\Inputs.mqh"
#include "Logger.mqh"

class CNewsFilter
  {
private:
   string m_symbol;
   string m_currency;
   bool   m_lastLockState;

public:
   CNewsFilter() : m_lastLockState(false) {}

   void Init(const string symbol)
     {
      m_symbol=symbol;
      m_currency=SymbolInfoString(symbol,SYMBOL_CURRENCY_PROFIT); // e.g. "USD" for XAUUSD
      if(m_currency=="") m_currency="USD";
     }

   // Returns true if new entries should be blocked right now.
   bool IsLockActive(string &eventNameOut,datetime &eventTimeOut) const
     {
      eventNameOut=""; eventTimeOut=0;
      if(!InpNewsFilterEnable) return false;

      datetime now=TimeCurrent();
      datetime from = now-(InpNewsLockMinutesAfter+InpNewsStabilizeMinutes)*60;
      datetime to   = now+InpNewsLockMinutesBefore*60;

      MqlCalendarValue values[];
      int total=CalendarValueHistory(values,from,to,NULL,m_currency);
      if(total<=0) return false;

      bool lockFromUpcoming=false, stabilizing=false;
      string bestName=""; datetime bestTime=0;

      for(int i=0;i<total;i++)
        {
         MqlCalendarEvent ev;
         if(!CalendarEventById(values[i].event_id,ev)) continue;
         if((int)ev.importance<(int)InpNewsMinImportance) continue;

         datetime evTime=values[i].time;

         bool inHardLock = (evTime>=now-InpNewsLockMinutesAfter*60 && evTime<=now+InpNewsLockMinutesBefore*60);
         bool inStabilize = (!inHardLock && evTime>=now-(InpNewsLockMinutesAfter+InpNewsStabilizeMinutes)*60
                              && evTime<now-InpNewsLockMinutesAfter*60);

         if(inHardLock) { lockFromUpcoming=true; bestName=ev.name; bestTime=evTime; }
         else if(inStabilize) { stabilizing=true; if(bestName=="") { bestName=ev.name; bestTime=evTime; } }
        }

      bool active=(lockFromUpcoming||stabilizing);
      eventNameOut=bestName;
      eventTimeOut=bestTime;
      return active;
     }

   // Call once per tick; logs on state transitions only (not every tick).
   // Diagnostic "skipped" counting is done by the caller only at the moment
   // an entry attempt is actually blocked, not on every locked tick.
   bool Evaluate()
     {
      string name; datetime t;
      bool active=IsLockActive(name,t);
      if(active!=m_lastLockState)
        {
         if(active) CLogger::Info("NEWS",StringFormat("lock ACTIVE — \"%s\" at %s",
                                   name,TimeToString(t,TIME_DATE|TIME_MINUTES)));
         else       CLogger::Info("NEWS","lock RELEASED");
         m_lastLockState=active;
        }
      return active;
     }
  };

#endif // __DTE_NEWSFILTER_MQH__
