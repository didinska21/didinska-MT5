//+------------------------------------------------------------------+
//| Inputs.mqh                                                        |
//| Didinska Trading Engine (DTE) v4.0.0                               |
//| CONTROLLED STRATEGY-ENGINE REDESIGN — see Docs/CHANGELOG.md for   |
//| the full "why" behind every change in this file. Short version:   |
//| v3.3.3/v3.3.4 audits found the system was optimizing for win rate |
//| (69%) while expectancy stayed near zero (PF 1.02). v4.0.0 adds an |
//| explicit trade-thesis object + 3-state machine (VALID/WEAKENING/  |
//| INVALID), a 3-way adverse-move classifier (RETRACEMENT/           |
//| CONTINUATION/REVERSAL), a scored (not binary) recovery engine, a  |
//| 6-way market-regime classifier, and per-dimension expectancy/loss |
//| -anatomy reporting — while deliberately keeping the v3.3.x risk   |
//| architecture (layer cap, lot cap, non-martingale lot sizing,      |
//| hedge behavior, close verification) that already worked.          |
//+------------------------------------------------------------------+
#ifndef __DTE_INPUTS_MQH__
#define __DTE_INPUTS_MQH__

#define DTE_VERSION "4.0.0"
#define DTE_BUILD   "001"
// v4.0.0 is a MAJOR version: the basket persistence layout gained several
// new scalar fields (thesis state, entry score, regime, hedge-event count,
// MAE/MFE). Old v3.3.x global-variable state is NOT compatible — a restart
// mid-basket after upgrading from v3.3.x will not correctly restore an
// in-flight basket. This is acceptable for a major version (the owner was
// told to run TEST A — a fresh backtest — not to resume a live v3.3.x
// session). DTE_STATE_VERSION bumped accordingly.
#define DTE_STATE_VERSION 4

//====================================================================
// TIMEFRAMES — always explicit, never PERIOD_CURRENT.
//====================================================================
input group "=== Timeframes ==="
input ENUM_TIMEFRAMES InpTfBias    = PERIOD_H1;  // higher-timeframe directional bias
input ENUM_TIMEFRAMES InpTfStruct  = PERIOD_M15; // structure timeframe
input ENUM_TIMEFRAMES InpTfTrigger = PERIOD_M5;  // execution/trigger timeframe

input group "=== EMA ==="
input int InpEmaFastPeriod = 20;
input int InpEmaSlowPeriod = 50;
input ENUM_MA_METHOD    InpEmaMethod = MODE_EMA;
input ENUM_APPLIED_PRICE InpEmaPrice = PRICE_CLOSE;

input group "=== ATR ==="
input int    InpAtrPeriod     = 14;
input double InpAtrMultiplier = 1.2;    // general regime/recovery-distance ATR multiplier
input double InpAtrMinPoints  = 50.0;   // below this, market is "too quiet" — LOW_VOLATILITY regime
input double InpAtrMaxPoints  = 4000.0; // above this, market is "too wild" — HIGH_VOLATILITY regime
input bool   InpUseAtrFilter  = true;   // block new entries outside [min,max] ATR band

//====================================================================
// ENTRY SCORING (section 5) — transparent, additive, max 12.
// H1 aligned +2, M15 aligned +2, M5 trigger +2, EMA aligned +1,
// BOS +1, CHOCH +1, Fib50 +1, Fib61.8 +1, S/R +1  =  12 max.
// (Momentum and ATR-regime are used as GATES, not extra score points —
// this keeps the max a clean, stated 12, exactly as the spec asked for,
// rather than silently drifting to 14 by tacking on two more +1s.)
//====================================================================
input group "=== Entry Scoring ==="
input int    InpMinEntryScore        = 5;    // default target 5-6/12 — deliberately not over-filtered
input bool   InpRequireM5Trigger     = true; // M5 remains the mandatory execution confirmation
input bool   InpUseFibConfluence     = true;
input bool   InpUseStructureConfluence = true;
input bool   InpUseSrConfluence      = true;
input bool   InpUseEmaConfluence     = true;
input double InpFibProximityAtrMult  = 0.35; // ATR-scaled tolerance for fib/S-R proximity checks

//====================================================================
// THESIS ENGINE (sections 7-10) — multi-factor invalidation score.
// M15 break +3, H1 reversal +3, M5 BOS against +2, EMA regime
// reversal +1, ATR expansion +1, strong momentum against +1 = 11 max.
//====================================================================
input group "=== Thesis Engine ==="
input int InpThesisInvalidScore = 6; // >= this => THESIS_INVALID (out of ~11)
input int InpThesisWeakScore    = 3; // >= this (and < InpThesisInvalidScore) => THESIS_WEAKENING

//====================================================================
// RECOVERY ENGINE (sections 11-14) — scored, expectancy-aware.
//====================================================================
input group "=== Recovery ==="
input bool   InpRecoveryEnable          = true;
input int    InpMaxLayers               = 6;     // HARD MAXIMUM — never exceeded
input double InpLayerAtrMultiplier      = 1.2;   // ATR multiplier for layer distance
input double InpMinLayerDistancePoints  = 150.0; // hard floor under the ATR distance
input int    InpMinRecoveryScore        = 6;     // out of ~13 max positive — see Recovery/RecoveryEngine.mqh
input int    InpRecoveryTimeoutMinutes  = 180;   // after this much time IN RECOVERY (layer>1), no new layers
input int    InpThesisInvalidationGraceMinutes = 15; // grace before a THESIS_INVALID basket is force-exited

// v4.0.0 — basket-relative loss cap carried over from the v3.3.4 hot-fix
// (the equity-% cap almost never fired at these lot sizes — see
// Docs/CHANGELOG.md "v3.3.4" section for the original diagnosis). Still a
// design default to validate, not a value fitted to any specific backtest.
input double InpThesisInvalidLossToTpMultiple = 3.0;

//====================================================================
// LOT MANAGEMENT — UNCHANGED non-martingale, capacity-based model
// (Core/LotSizing.mqh carried over verbatim from v3.3.x — section 15/22).
//====================================================================
input group "=== Lot Management ==="
input double InpBaseLot                 = 0.01;
input double InpMaxLotPerLayer          = 0.03; // HARD MAXIMUM — never exceeded
input double InpAdaptiveLotStep         = 0.01;
input double InpMaxBasketMarginPercent  = 15.0;
input double InpMarginSafetyBufferPct   = 30.0;
input double InpRiskSpreadSlippagePercent = 5.0;

//====================================================================
// RISK LIMITS (section 16/40) — tightened defaults vs v3.3.x. The
// v3.3.x preferred/hard ceiling (15%/20% of EQUITY) was diagnosed as
// unreachable at these lot sizes (v3.3.3 backtest: maxBasketRisk topped
// out at ~2.25%), so it was providing no real protection AND no real
// damage-control trigger. v4.0.0 uses a materially tighter basket-risk
// ceiling as the spec's section 16/40 explicitly asked for, plus a NEW
// account-level equity-drawdown circuit breaker (previously only
// tracked passively in forensic stats, never enforced live).
//====================================================================
input group "=== Risk Limits ==="
input double InpMaxBasketRiskPercent    = 2.5;  // preferred/soft per-basket ceiling (section 16/40)
input double InpHardBasketRiskPercent   = 4.0;  // absolute per-basket ceiling — new layers/hedges refused above this
input double InpMaxEquityDrawdownPercent = 20.0; // HARD account-level DD-from-peak-balance circuit breaker
input double InpPreferredEquityDrawdownPercent = 10.0; // soft warning threshold — logged, does not halt

input group "=== Max Basket Hold ==="
input int InpMaxBasketHoldMinutes = 720; // 12h — TRUE hard limit, see Core/PositionManager.mqh

//====================================================================
// EXIT / PROFIT CAPTURE (sections 18-20)
//====================================================================
input group "=== Basket Exit ==="
input double InpBasketTpPercent          = 0.20; // % of cycle-start balance — small scalping target
input bool   InpUseMicroProfitMode       = true; // section 19 — close early once expected value is small-positive
input double InpMicroProfitMinPercent    = 0.08; // % of cycle-start balance — floor for a "small positive" close
input int    InpMicroProfitMinHoldMinutes = 20;  // don't micro-close a basket that's only seconds old
input bool   InpUseSpikeExit             = true;
input double InpSpikeExitMinPercent      = 0.25;
input double InpSpikeExitTriggerPoints   = 300.0;
input int    InpSpikeExitWindowSeconds   = 60;
input double InpSpikeExitMinAtrMultiple  = 0.75;

//====================================================================
// HEDGE (section 21) — risk-management tool, not a profit engine.
//====================================================================
input group "=== Hedge ==="
input bool   InpHedgeEnable            = true;
input double InpHedgeLot               = 0.01;
input double InpHedgeMaxLot            = 0.01;
input double InpHedgeMinStructureScore = 2.0;
input int    InpHedgeCooldownMinutes   = 60;
input int    InpMaxHedgesPerBasket     = 2; // NEW — bounds hedge-open events per basket, prevents loops

//====================================================================
// PROFIT TARGET LIFECYCLE (section 23) — concept preserved from v3.3.x.
//====================================================================
input group "=== Profit Target ==="
input bool   InpTargetEnable            = true;
input double InpProfitTargetMultiplier  = 10.0; // e.g. 10x initial balance
input int    InpResetConfirmSeconds     = 10;

//====================================================================
// SESSIONS (section 24)
//====================================================================
input group "=== Sessions ==="
input bool InpSessionUseFilter    = true;
input bool InpSessionAsiaEnable   = true;
input int  InpSessionAsiaStart    = 0;
input int  InpSessionAsiaEnd      = 8;
input bool InpSessionLondonEnable = true;
input int  InpSessionLondonStart  = 8;
input int  InpSessionLondonEnd    = 16;
input bool InpSessionNyEnable     = true;
input int  InpSessionNyStart      = 13;
input int  InpSessionNyEnd        = 21;
input bool InpTradeMonday    = true;
input bool InpTradeTuesday   = true;
input bool InpTradeWednesday = true;
input bool InpTradeThursday  = true;
input bool InpTradeFriday    = true;

//====================================================================
// NEWS FILTER (section 25) — optional, no external API required for
// backtesting (uses the built-in MT5 Economic Calendar only).
//====================================================================
input group "=== News Filter ==="
input bool InpNewsFilterEnable      = true;
input int  InpNewsMinImportance     = 3;  // ENUM_CALENDAR_EVENT_IMPORTANCE
input int  InpNewsLockMinutesBefore = 30;
input int  InpNewsLockMinutesAfter  = 15;
input int  InpNewsStabilizeMinutes  = 15;

//====================================================================
// SPREAD (section 26)
//====================================================================
input group "=== Spread Filter ==="
input bool   InpUseSpreadFilter = true;
input double InpMaxSpreadPoints = 150.0;

//====================================================================
// MARGIN SAFETY / EXECUTION
//====================================================================
input group "=== Margin Safety / Execution ==="
input int InpMinFreeMarginPercent          = 50;
input int InpMarketClosedCooldownSeconds   = 300;
input int InpHedgeCloseRetrySeconds        = 5;
input int InpOrphanCloseRetrySeconds       = 10;
input int InpCloseVerifyRetrySeconds       = 3;

input group "=== Misc ==="
input long   InpMagicNumber   = 26080601;
input string InpTradeComment  = "DTE_v400";
input int    InpSlippagePoints = 50;

//====================================================================
// CORE ENUMS
//====================================================================
enum ENUM_CYCLE_DIRECTION
  {
   CYCLE_NONE = 0,
   CYCLE_BUY  = 1,
   CYCLE_SELL = 2
  };

enum ENUM_MARKET_BIAS
  {
   BIAS_STRONG_BEAR = -2,
   BIAS_BEAR        = -1,
   BIAS_NEUTRAL     =  0,
   BIAS_BULL        =  1,
   BIAS_STRONG_BULL =  2
  };

// Carried over from v3.3.x verbatim (Strategy/StructureEngine.mqh — same
// 2-bar fractal swing / BOS / CHOCH heuristic, proven and unchanged).
enum ENUM_STRUCT_STATE
  {
   STRUCT_UNKNOWN    = 0,
   STRUCT_BULLISH    = 1, // HH/HL sequence
   STRUCT_BEARISH    = 2, // LH/LL sequence
   STRUCT_BOS_UP     = 3,
   STRUCT_BOS_DOWN   = 4,
   STRUCT_CHOCH_UP   = 5, // reversal signal turning bullish
   STRUCT_CHOCH_DOWN = 6  // reversal signal turning bearish
  };

// v4.0.0 SECTION 34 — 6-way regime classification (+ UNKNOWN before the
// first full evaluation). Recorded per-basket so ExpectancyEngine can
// report performance by regime (section 33).
enum ENUM_MARKET_REGIME
  {
   REGIME_UNKNOWN         = 0,
   REGIME_TREND_UP        = 1,
   REGIME_TREND_DOWN      = 2,
   REGIME_RANGE           = 3,
   REGIME_HIGH_VOLATILITY = 4,
   REGIME_LOW_VOLATILITY  = 5,
   REGIME_TRANSITION      = 6
  };

// v4.0.0 SECTION 8/9 — explicit trade-thesis lifecycle. A basket does not
// jump straight from VALID to a recovery/exit decision — WEAKENING is a
// distinct, loggable intermediate state driven by the same multi-factor
// score used for full invalidation (InpThesisWeakScore < score <
// InpThesisInvalidScore => WEAKENING).
enum ENUM_THESIS_STATE
  {
   THESIS_VALID     = 0,
   THESIS_WEAKENING = 1,
   THESIS_INVALID   = 2
  };

// v4.0.0 SECTION 10 — THREE MARKET STATES the recovery engine must
// distinguish (ADVERSE_NONE = not evaluated / no basket direction yet).
enum ENUM_ADVERSE_CLASS
  {
   ADVERSE_NONE         = 0,
   ADVERSE_RETRACEMENT  = 1, // thesis still valid — HOLD or controlled layer
   ADVERSE_CONTINUATION = 2, // thesis may still be valid HTF, but only layer on strong confirmation
   ADVERSE_REVERSAL     = 3  // thesis invalid — do NOT blindly average down
  };

// v4.0.0 SECTION 2E — the seven possible basket-lifecycle responses. Every
// tick's management decision is attributed to exactly one of these for
// logging/audit traceability (Core/PositionManager.mqh's dispatcher).
enum ENUM_RESPONSE
  {
   RESPONSE_HOLD             = 0,
   RESPONSE_TAKE_PROFIT      = 1,
   RESPONSE_ADD_LAYER        = 2,
   RESPONSE_RECOVER          = 3, // decision path that LED to a layer — logged distinctly from the mechanical add
   RESPONSE_HEDGE            = 4,
   RESPONSE_REDUCE_EXPOSURE  = 5,
   RESPONSE_EXIT             = 6
  };

// v4.0.0 SECTION 28 — explicit state machine. IDLE/SIGNAL_SCAN/
// ENTRY_PENDING are pre-basket (EA-level) states used for logging before
// a basket object exists; every other value is a real m_basket.state
// value. THESIS_VALID is deliberately NOT a separate basket state (it
// would collide in name with ENUM_THESIS_STATE and adds no information
// beyond "no problem" — POSITION_ACTIVE already means exactly that);
// WEAKENING/INVALID get their own visible basket states because they
// change what the basket is allowed to do.
enum ENUM_BASKET_STATE
  {
   BSTATE_IDLE                 = 0,
   BSTATE_SIGNAL_SCAN          = 1,
   BSTATE_ENTRY_PENDING        = 2,
   BSTATE_POSITION_ACTIVE      = 3,
   BSTATE_THESIS_WEAKENING     = 4,
   BSTATE_THESIS_INVALID       = 5,
   BSTATE_RECOVERY_EVALUATION  = 6,
   BSTATE_RECOVERY_PENDING     = 7,
   BSTATE_HEDGE_EVALUATION     = 8,
   BSTATE_HEDGE_ACTIVE         = 9,
   BSTATE_EXIT_EVALUATION      = 10,
   BSTATE_BASKET_CLOSE_PENDING = 11,
   BSTATE_BASKET_VERIFY        = 12,
   BSTATE_MAX_HOLD_EXIT        = 13,
   BSTATE_FINISHED             = 14,
   BSTATE_ORPHAN_RECOVERY      = 15, // safety state carried over from v3.3.2 — an order
                                      // executed but couldn't be attached to tracking;
                                      // blocks new recovery/hedge/entry until resolved
   BSTATE_HALTED                = 16  // informational only — set while a global halt
                                       // (profit target / equity DD) is active; actual
                                       // gating is done by the riskHalted flag passed
                                       // into TryAddRecoveryLayer()/ManageHedge()
  };

enum ENUM_HALT_CAUSE
  {
   HALT_NONE             = 0,
   HALT_PROFIT_TARGET    = 1,
   HALT_ACCOUNT_TYPE     = 2, // netting account — hard init failure, kept for dashboard reuse
   HALT_EQUITY_DRAWDOWN  = 3  // v4.0.0 NEW — InpMaxEquityDrawdownPercent circuit breaker
  };

// v4.0.0 SECTION 32 — LOSS ANATOMY categories, EXACTLY the 7 the spec
// listed. Also reused as the ExpectancyEngine "by exit reason" dimension
// (section 33) — there ALL trades (win or loss) are bucketed by this same
// reason, not just losses.
enum ENUM_LOSS_EXIT_REASON
  {
   LOSS_EXIT_BASKET_TP      = 0,
   LOSS_EXIT_SPIKE_EXIT     = 1,
   LOSS_EXIT_THESIS_INVALID = 2,
   LOSS_EXIT_MAX_HOLD       = 3,
   LOSS_EXIT_RISK_EXIT      = 4,
   LOSS_EXIT_HEDGE_EXIT     = 5,
   LOSS_EXIT_OTHER          = 6
  };

enum ENUM_BASKET_CLOSE_REASON
  {
   CLOSE_NONE           = 0,
   CLOSE_TP             = 1, // -> LOSS_EXIT_BASKET_TP
   CLOSE_MICRO_TP        = 2, // section 19 micro-profit close -> LOSS_EXIT_BASKET_TP
   CLOSE_SPIKE_EXIT      = 3, // -> LOSS_EXIT_SPIKE_EXIT
   CLOSE_THESIS_INVALID  = 4, // -> LOSS_EXIT_THESIS_INVALID (covers reversal-driven exits too)
   CLOSE_MAX_HOLD        = 5, // -> LOSS_EXIT_MAX_HOLD
   CLOSE_RISK_LIMIT      = 6, // -> LOSS_EXIT_RISK_EXIT (also covers recovery-timeout exits)
   CLOSE_HEDGE_EXIT      = 7, // -> LOSS_EXIT_HEDGE_EXIT
   CLOSE_MARGIN_CALL_EXT = 8, // -> LOSS_EXIT_OTHER
   CLOSE_OTHER           = 9  // -> LOSS_EXIT_OTHER
  };

enum ENUM_SESSION_NAME
  {
   SESSION_NONE=0, SESSION_ASIA=1, SESSION_LONDON=2, SESSION_NY=3, SESSION_OVERLAP=4
  };

enum ENUM_HEDGE_STATE
  {
   HEDGE_NORMAL        = 0,
   HEDGE_RECOVERY      = 1,
   HEDGE_REVERSAL_RISK = 2,
   HEDGE_ACTIVE        = 3,
   HEDGE_BASKET_EXIT   = 4
  };

// v3.3.2 fix carried over verbatim — TRADE_RETCODE_DONE_PARTIAL must never
// be treated as "hedge is gone".
enum ENUM_HEDGE_CLOSE_STATE
  {
   HEDGE_CLOSE_NONE    = 0,
   HEDGE_CLOSE_PARTIAL = 1
  };

//====================================================================
// DTOs
//====================================================================

// v4.0.0 SECTION 5 — entry score, max 12 (see the group comment above
// InpMinEntryScore for the exact breakdown).
struct SEntryScore
  {
   ENUM_CYCLE_DIRECTION direction;
   int                  score;
   bool                 h1Aligned;
   bool                 m15Aligned;
   bool                 m5Trigger;
   bool                 emaAligned;
   bool                 bosHit;
   bool                 chochHit;
   bool                 fib50Hit;
   bool                 fib618Hit;
   bool                 srHit;
   ENUM_MARKET_REGIME   regime;
   bool                 passed;
  };

// v4.0.0 SECTION 12 — recovery score. Positive components sum to ~13;
// negative components can push the total well below zero. See
// Recovery/RecoveryEngine.mqh for the exact weights (mirrors the spec's
// example weights one-for-one).
struct SRecoveryScore
  {
   int    score;
   bool   m15Aligned;                 // +3
   bool   m5Aligned;                  // +2
   bool   emaAligned;                 // +1
   bool   fibHit;                     // +1
   bool   srHit;                      // +1
   bool   momentumOk;                 // +1
   bool   atrAcceptable;              // +1
   bool   thesisValid;                // +3
   bool   strongContinuationAgainst;  // -3
   bool   m15Broken;                  // -4
   bool   h1Reversed;                 // -4
   bool   volAbnormal;                // -2
   ENUM_ADVERSE_CLASS adverseClass;
   bool   passed;
   string reason;
  };

// v4.0.0 SECTION 7 — the explicit trade-thesis object. In-memory only
// (not persisted field-by-field via GlobalVariable — see Core/
// PositionManager.mqh's RestorePersistedState() comment for why: only a
// handful of scalar fields need to survive a restart, and those already
// live in SBasketState below; the rest is cheap to recompute fresh from
// live market data, same tolerance already accepted for v3.3.x's orphan-
// tracking and recovery-throttle state).
struct SThesis
  {
   ENUM_CYCLE_DIRECTION direction;
   double               entryPrice;
   ENUM_STRUCT_STATE    initialStructure;
   ENUM_MARKET_BIAS     initialH1Bias;
   bool                 initialM5Trigger;
   bool                 initialEmaAligned;
   double               initialAtr;
   int                  entryScore;
   double               refSwingHigh;
   double               refSwingLow;
   double               fib50;
   double               fib618;
   bool                 fibValid;
   double               srReference;
   datetime             timestamp;
   double               initialRiskDistance;  // ATR-based, price units
   int                  currentLayer;
   double               maxAdverseExcursionPts;
   double               maxFavorableExcursionPts;
   ENUM_THESIS_STATE    state;
   int                  invalidationScore;
   datetime             weakeningTime;
   datetime             invalidatedTime;
   ENUM_MARKET_REGIME   entryRegime;
  };

struct SBasketState
  {
   bool                 active;
   ENUM_CYCLE_DIRECTION direction;
   int                  layersOpen;
   double               cycleStartBalance;
   double               basketFloatingProfit; // net: profit+swap+commission
   double               basketTpTarget;       // absolute currency value
   datetime             cycleStartTime;       // TRUE lifecycle start — never reset (section 17)
   double               lastLayerPrice;
   ENUM_HEDGE_STATE     hedgeState;
   bool                 hedgeActive;
   ulong                hedgeTicket;
   int                  hedgeEventCount;      // v4.0.0 — bounded by InpMaxHedgesPerBasket
   double               peakFloatingProfit;   // for spike-exit window tracking
   datetime             peakFloatingTime;
   double               selectedBaseLot;
   ENUM_BASKET_STATE    state;
   datetime             recoveryStartTime;
   datetime             lastHedgeCloseTime;
   datetime             thesisInvalidatedTime;
   datetime             thesisWeakeningTime;   // v4.0.0
   ENUM_THESIS_STATE    thesisState;           // v4.0.0
   int                  entryScore;            // v4.0.0 — persisted for restart/dashboard/expectancy
   ENUM_MARKET_REGIME   entryRegime;           // v4.0.0
   double               maxAdverseExcursionPts;   // v4.0.0
   double               maxFavorableExcursionPts; // v4.0.0
   double               maxBasketRiskPct;      // adaptive lot, fixed for this basket's whole lifetime
   ENUM_HEDGE_CLOSE_STATE hedgeCloseState;
   double               hedgeRemainingVolume;
   datetime             hedgeCloseRetryTime;
  };

struct SDiagnosticSnapshot
  {
   ENUM_MARKET_BIAS     h1Bias;
   ENUM_STRUCT_STATE    m15Structure;
   ENUM_CYCLE_DIRECTION m5Signal;
   ENUM_MARKET_REGIME   regime;
   SBasketState         basket;
   bool                 haltActive;
   ENUM_HALT_CAUSE      haltCause;
   double               sessionStartBalance;
   double               currentEquity;
   double               profitTargetProgressPct;
   bool                 sessionOk;
   bool                 spreadOk;
   bool                 atrOk;
   bool                 marginOk;
   bool                 newsLockActive;
   ENUM_SESSION_NAME    currentSession;
   string               lastEntryReason;
   string               lastCloseReason;
   double               currentDrawdownPct;
   ulong                profitCycleId;
   double               profitCycleBaseline;
   double               profitCycleTargetBalance;
   double               currentBalance;
   string               resetStatusMessage;
   double               adaptiveLotLastSelected;
   double               adaptiveMarginCapacityPct;
   double               adaptiveEstSixLayerExposureLots;
   int                  pendingOrphanCount;
  };

// General OPERATIONAL counters — mechanical events, not P/L classification
// (that's Recovery/LossAnatomy.mqh and Recovery/ExpectancyEngine.mqh,
// each a separate deliverable module per section 50).
struct SForensicCounters
  {
   long basketsOpened;
   long basketsClosedByTp;
   long basketsClosedByMicroTp;
   long basketsClosedBySpike;
   long basketsClosedByMarginCall;
   long basketsClosedByHedgeExit;

   long layersPerBasketMin;
   long layersPerBasketMax;
   long layersPerBasketSum;

   long basketHoldSecondsMin;
   long basketHoldSecondsMax;
   long basketHoldSecondsSum;

   long cycleDirectionBuy;
   long cycleDirectionSell;

   long entryScorePassCount;
   long entryScoreRejectCount;

   long layersSkippedMargin;
   long entriesSkippedSpread;
   long entriesSkippedSession;
   long entriesSkippedNews;
   long entriesSkippedDuplicateSignal;
   long entriesSkippedInvalidThesis;

   long recoveryAccepted;
   long recoveryRejected;
   long thesisWeakeningEvents;
   long thesisInvalidations;
   long maxHoldExits;
   long recoveryTimeoutExits;
   long basketRiskRejected;
   long marketClosedEvents;
   long hedgeRejected;
   long hedgeCooldownRejected;
   long hedgeMaxPerBasketRejected;
   long hedgeEventsOpened;
   long hedgeEventsClosed;

   long profitTargetHaltEvents;
   long equityDrawdownHaltEvents;
   long closeVerifyRetries;
   long closeVerifyFailures;

   double maxEquityDrawdownPct;
   double maxBalanceDrawdownPct;
   double maxFloatingLoss;
   double maxBasketLoss;
   double maxBasketRiskPct;
   long   maxLayerCountSeen;
   long   longestRecoverySeconds;
   double maxMarginUsagePct;

   long spikeEvaluationCount;
   long spikeCandidateCount;
   long spikeAcceptedCount;
   long spikeRejectedByProfit;
   long spikeRejectedByMove;
   long spikeRejectedByAtr;
   long spikeRejectedByWindow;

   long thesisExitByGrace;
   long thesisExitByStructural;
   long thesisExitByEquity;

   long adverseRetracementCount;
   long adverseContinuationCount;
   long adverseReversalCount;

   long regimeSeenCount[7]; // indexed by ENUM_MARKET_REGIME
  };

// v4.0.0 SECTION 32 — one bucket per ENUM_LOSS_EXIT_REASON, only
// accumulated for baskets that closed at a net LOSS.
struct SLossAnatomyBucket
  {
   long   count;
   double totalLoss;   // positive magnitude
   double largestLoss; // positive magnitude
   long   holdSum;     // seconds
   long   holdMax;     // seconds
  };

// v4.0.0 SECTION 33 — one bucket per dimension value, accumulated for
// EVERY closed basket (win or loss).
struct SExpectancyBucket
  {
   long   trades;
   long   wins;
   long   losses;
   double grossProfit; // sum of positive results
   double grossLoss;   // sum of loss magnitudes, stored positive
   double largestWin;
   double largestLoss; // positive magnitude
  };

#endif // __DTE_INPUTS_MQH__
