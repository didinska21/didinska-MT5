# DTE v4.0.0 — Strategy Architecture

## Decision flow (section 3)
```
H1 bias (Strategy/TrendEngine.mqh)
        v
M15 structure (Strategy/StructureEngine.mqh)
        v
M5 trigger + 12-pt score (Strategy/SignalEngine.mqh)
        v
ENTRY (Core/PositionManager.mqh::StartBasket)
        v
Trade thesis built (Strategy/ThesisEngine.mqh::BuildThesis)
        v
Every management pass:
  re-evaluate thesis (EvaluateInvalidation) -> VALID/WEAKENING/INVALID
  classify adverse move (ClassifyAdverseMove) -> RETRACEMENT/CONTINUATION/REVERSAL
        v
  RETRACEMENT/CONTINUATION -> recovery scored (Recovery/RecoveryEngine.mqh)
                               -> ADD LAYER if score clears threshold
  REVERSAL (thesis INVALID)  -> NO recovery; grace/structural/equity exit
        v
  hedge evaluated independently (Recovery/HedgeEngine.mqh) — structural
  trigger only, never "basket is losing" alone
        v
EXIT: spike -> ordinary TP -> micro-profit -> thesis-invalid triggers
      -> risk limit -> max hold (true hard limit)
        v
FinalizeBasket -> Recovery/LossAnatomy.mqh (losses only)
               -> Recovery/ExpectancyEngine.mqh (every basket)
```

## The seven responses (section 2E)
Every management pass ultimately resolves to one of: HOLD, TAKE_PROFIT,
ADD_LAYER, RECOVER, HEDGE, REDUCE_EXPOSURE, EXIT (`ENUM_RESPONSE` in
`Config/Inputs.mqh`). The EA never treats every adverse move as a recovery
opportunity — a REVERSAL-classified move (thesis INVALID) is explicitly
routed toward EXIT, never RECOVER.

## Entry scoring (12-point, section 5)
| Component | Points |
|---|---|
| H1 aligned | +2 |
| M15 aligned | +2 |
| M5 trigger | +2 |
| EMA alignment | +1 |
| BOS in direction | +1 |
| CHOCH in direction | +1 |
| Fib 50 proximity | +1 |
| Fib 61.8 proximity | +1 |
| S/R confluence | +1 |
| **Maximum** | **12** |

Direction itself comes from the M5 trigger (gated only by "don't fight a
STRONG opposing H1 trend" — section 6), NOT from requiring M15 to already
agree. M15/EMA/BOS/CHOCH/fib/S-R are all *scored*, not gates — this is the
section-4 fix for the v3.3.x entry filter rejecting 99.9%+ of evaluations.
Default pass threshold `InpMinEntryScore=5` (~42%).

## Thesis invalidation score (11-point, section 9)
| Component | Points |
|---|---|
| H1 bias reversal | +3 |
| M15 structure break against | +3 |
| M5 BOS/CHOCH against | +2 |
| EMA regime reversal | +1 |
| ATR expansion | +1 |
| Strong momentum against | +1 |
| **Maximum** | **11** |

`score >= InpThesisInvalidScore(6)` → INVALID. `score >=
InpThesisWeakScore(3)` (and below invalid) → WEAKENING. Below that → VALID.
Never a single weak signal triggers invalidation (section 9's explicit
requirement) — it always takes at least two moderate factors or one strong
one (e.g. H1 reversal alone at +3 is still below the +6 invalid threshold).

## Recovery score (±13, section 12)
| Component | Points |
|---|---|
| M15 still aligned | +3 |
| M5 trigger aligned | +2 |
| Thesis validity (still VALID) | +3 |
| EMA aligned | +1 |
| Fib 50/61.8 | +1 |
| S/R | +1 |
| Momentum | +1 |
| ATR acceptable | +1 |
| Strong continuation against | −3 |
| M15 structure broken | −4 |
| H1 bias reversed | −4 |
| Volatility abnormal | −2 |

`REVERSAL` classification blocks recovery outright regardless of score.
`CONTINUATION` and `HIGH_VOLATILITY` regime each raise the pass threshold
by +2 above `InpMinRecoveryScore`. `RANGE` regime blocks layers ≥4 outright.
Layer 1 (entry) never goes through this — only layers 2-6.

## Market regime (6-way, section 34)
`REGIME_HIGH_VOLATILITY` / `REGIME_LOW_VOLATILITY` (M5 ATR outside
`[InpAtrMinPoints, InpAtrMaxPoints]`) are checked first — volatility
extremes change *how* to trade regardless of direction. Otherwise:
strong H1 bias with M15 structure agreeing → TREND_UP/TREND_DOWN; strong
H1 bias with M15 structure actively disagreeing → TRANSITION (the higher
timeframe hasn't been confirmed by the structure timeframe yet); H1
neutral with clear M15 structure → still TREND_UP/TREND_DOWN (M15 decides);
otherwise → RANGE.

## Exit priority (section 18)
Checked in this order every management pass, first match wins:
1. All layers closed externally (margin call / stop-out reconciliation)
2. True hard max-hold reached
3. Actual floating loss at the hard basket-risk ceiling
4. Spike exit (favorable impulse — don't wait for a pullback)
5. Ordinary basket TP
6. Micro-profit mode (small positive EV, section 19)
7. Thesis-invalid triggers (grace period / structural loss cap / equity
   risk — whichever fires first)

## Loss anatomy & expectancy (sections 32-33)
Both modules are fed from the same `ENUM_BASKET_CLOSE_REASON ->
ENUM_LOSS_EXIT_REASON` mapping (`CLogger::LossReasonIndex()`, single
source of truth) so the two reports can never disagree about which bucket
a basket landed in. LossAnatomy only records losing baskets (7 buckets);
ExpectancyEngine records every basket, across six independent dimensions
(direction, session, regime, layer count, exit reason, thesis state).

## Explicit non-goals (section 36/47)
No RSI, MACD, machine learning, external APIs, news APIs beyond the
built-in MT5 Economic Calendar, martingale, grid multiplier, or unlimited
recovery. No hardcoded daily profit target. No curve-fitting to the
2024-2025 backtest window — every scoring weight and threshold in this
document is a design choice consistent with the original specification's
own example weights, not a value derived from scanning any backtest for
the best result.
