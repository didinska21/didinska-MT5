# DTE v4.0.0 — Didinska Trading Engine

RESEARCH / TEST BUILD for XAUUSD, M5 execution, on a **hedging** MT5
account. Not claimed profitable. Not claimed live-ready. See
`Docs/CHANGELOG.md` for what changed vs v3.3.3/v3.3.4 and why, and
`Docs/TEST_PLAN.md` for exactly how to test it.

## What this is
A directional scalping/recovery system with an explicit trade-thesis
object and 3-state lifecycle (VALID → WEAKENING → INVALID), scored entry
and recovery decisions, market-regime awareness, and forensic
loss-anatomy/expectancy reporting. See `Docs/STRATEGY.md` for the full
architecture.

## Folder layout
```
GoldHedgeRecovery.mq5      composition root — OnInit/OnTick/OnDeinit wiring
Config/Inputs.mqh          every input, enum, and DTO struct
Core/                      execution plumbing (trades, sessions, risk,
                            persistence, logging, dashboard) — mostly
                            carried over unchanged from v3.3.x
Strategy/                  entry scoring, structure, trend, regime, and
                            the NEW thesis engine
Recovery/                  recovery scoring, hedge, loss anatomy,
                            expectancy reporting
Indicators/                thin EMA/ATR wrappers
Docs/                      this documentation set
```

## Before you run anything
1. Compile in MetaEditor. Required: 0 errors, 0 warnings. (Not verified by
   an actual compiler in this delivery — see CHANGELOG.)
2. Read `Docs/TEST_PLAN.md` and run **TEST A** (same settings as the
   v3.3.3/v3.3.4 baseline, default inputs) before changing anything.
3. Requires a **hedging** account — the EA hard-fails `OnInit` on a
   netting account (unchanged from v3.3.x — layers must exist as
   distinguishable positions).

## Non-negotiables (unchanged from v3.3.x, validated in `OnInit`)
- Maximum 6 layers, maximum 0.03 lot per layer.
- No martingale — lot sizing is capacity/risk-based
  (`Core/LotSizing.mqh`), never a multiplier ladder.
- A basket is never finalized until every position is verified actually
  closed (close-safety state machine).
- Hedge is a risk-management tool only — never opened merely because a
  basket is losing, always gated by genuine opposing structure.

## What to read next
- `Docs/CHANGELOG.md` — the full why/what for this version, section by
  section against the original specification.
- `Docs/STRATEGY.md` — architecture and decision flow.
- `Docs/INPUTS.md` — every input, grouped, with its default and rationale.
- `Docs/TEST_PLAN.md` — exact test settings and success criteria.
