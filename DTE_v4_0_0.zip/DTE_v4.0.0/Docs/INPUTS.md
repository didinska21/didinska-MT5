# DTE v4.0.0 — Inputs Reference

All 105 inputs live in `Config/Inputs.mqh`, grouped exactly as shown in the
MT5 input dialog. Only the ones that changed meaning/value vs v3.3.4, or
are new, are explained in detail below — the rest carry their v3.3.x
defaults and behavior unchanged.

## Timeframes
`InpTfBias` (H1), `InpTfStruct` (M15), `InpTfTrigger` (M5) — unchanged.
`OnInit` refuses to start if any two are equal.

## Entry Scoring (mostly NEW group — section 5)
- **`InpMinEntryScore` (5, out of 12)** — NEW. Replaces v3.3.x's
  `InpMinConfluenceScore` (which operated on a much smaller ~4-point scale
  layered on top of a hard structural pre-filter). See `Docs/STRATEGY.md`
  for the full 12-point breakdown.
- `InpRequireM5Trigger` (true) — unchanged concept, now scored at +2 as
  well as gating direction selection.
- `InpUseFibConfluence` / `InpUseSrConfluence` / `InpUseEmaConfluence` /
  `InpUseStructureConfluence` — toggle individual score components.
- `InpFibProximityAtrMult` (0.35) — unchanged from v3.3.x.

## Thesis Engine (NEW group — sections 7-9)
- **`InpThesisInvalidScore` (6, out of ~11)** and **`InpThesisWeakScore`
  (3)** — NEW. See `Docs/STRATEGY.md` for the weight breakdown.

## Recovery (extends v3.3.x group — sections 11-14)
- `InpRecoveryEnable`, `InpMaxLayers` (6, hard cap), `InpLayerAtrMultiplier`,
  `InpMinLayerDistancePoints` — unchanged.
- **`InpMinRecoveryScore` (6, out of ~13)** — NEW, replaces v3.3.x's
  `InpRecoveryMinConfluenceScore`. See `Docs/STRATEGY.md`.
- `InpRecoveryTimeoutMinutes` (180) — unchanged.
- `InpThesisInvalidationGraceMinutes` — **tightened from 30 to 15**. The
  structural loss cap (next input) is now the primary damage-control
  trigger; the grace period is a fallback, so it no longer needs to be as
  long.
- `InpThesisInvalidLossToTpMultiple` (3.0) — carried from the v3.3.4
  hot-fix unchanged.

## Lot Management (unchanged — sections 15/22)
`InpBaseLot` (0.01), `InpMaxLotPerLayer` (0.03, hard cap),
`InpAdaptiveLotStep` (0.01) — byte-for-byte the same non-martingale,
capacity-based model as v3.3.x (`Core/LotSizing.mqh`).

## Risk Limits (RENAMED + RETIGHTENED — sections 16/40)
- **`InpMaxBasketRiskPercent` (2.5%)** — was `InpMaxBasketEquityRiskPercent`
  (15%). Retightened because the v3.3.3 backtest showed actual basket risk
  never exceeded ~2.25% at these lot sizes — the old 15% ceiling provided
  no real protection.
- **`InpHardBasketRiskPercent` (4.0%)** — was `InpHardBasketEquityRiskPercent`
  (20%). Same reasoning.
- **`InpMaxEquityDrawdownPercent` (20%)** — NEW. Account-level circuit
  breaker, now actually enforced (`Core/RiskEngine.mqh::EvaluateHalts()`),
  not just a passive statistic like in v3.3.x.
- **`InpPreferredEquityDrawdownPercent` (10%)** — NEW. Soft threshold,
  logs a warning only, does not halt.

## Max Basket Hold (unchanged mechanism, stricter enforcement — section 17)
`InpMaxBasketHoldMinutes` (720 / 12h) — same true-hard-limit timer as
v3.3.x (never reset by layer/hedge/restart); v4.0.0 additionally blocks a
NEW hedge (not just new recovery/entry) once reached.

## Basket Exit (extends v3.3.x group — sections 18-20)
- `InpBasketTpPercent` (0.20%) — unchanged.
- **`InpUseMicroProfitMode` (true)`, `InpMicroProfitMinPercent` (0.08%),
  `InpMicroProfitMinHoldMinutes` (20)** — all NEW (section 19).
- `InpUseSpikeExit`, `InpSpikeExitMinPercent`, `InpSpikeExitTriggerPoints`,
  `InpSpikeExitWindowSeconds`, `InpSpikeExitMinAtrMultiple` — unchanged.

## Hedge (extends v3.3.x group — section 21)
`InpHedgeEnable`, `InpHedgeLot`, `InpHedgeMaxLot` (≤0.01, hard, validated),
`InpHedgeMinStructureScore`, `InpHedgeCooldownMinutes` — unchanged.
**`InpMaxHedgesPerBasket` (2)** — NEW, explicit loop-prevention bound.

## Profit Target (unchanged — section 23)
`InpTargetEnable`, `InpProfitTargetMultiplier` (10x), `InpResetConfirmSeconds`
— unchanged lifecycle (persisted baseline/cycle-id, manual-reset-only).

## Sessions / News / Spread / Margin Safety / Misc
All unchanged from v3.3.x — see the group comments in `Config/Inputs.mqh`
directly; nothing in these groups changed for v4.0.0.

## ATR — one latent bug fixed
`InpAtrPeriod`/`InpAtrMultiplier`/`InpAtrMinPoints`/`InpAtrMaxPoints`/
`InpUseAtrFilter` are unchanged in value, but `Indicators/ATRFilter.mqh`
previously always read `PERIOD_CURRENT` regardless of these inputs — see
`Docs/CHANGELOG.md` item 11. Now explicitly reads `InpTfTrigger` (M5).
