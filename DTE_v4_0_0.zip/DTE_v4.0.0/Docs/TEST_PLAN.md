# DTE v4.0.0 — Test Plan

## Step 0 — Compile
Open `GoldHedgeRecovery.mq5` in MetaEditor and compile. Required: **0
errors, 0 warnings**. This was NOT verified by an actual compiler in this
delivery (see CHANGELOG "Compile result") — do this first, before anything
else, and report back any error/warning so it can be fixed.

## TEST A — baseline comparison (section 44) — MANDATORY FIRST TEST
Exactly the same settings as the v3.3.3/v3.3.4 baseline. Do not change any
input from its shipped default for this run.

| Setting | Value |
|---|---|
| Symbol | XAUUSD |
| Timeframe | M5 |
| Period | 2024.01.01 – 2025.12.31 |
| Initial deposit | $3,000 |
| Leverage | 1:500 |
| Model | Every tick based on real ticks |
| Inputs | **Default — do not change anything** |

### What to compare against v3.3.3/v3.3.4
- Net profit, gross profit, gross loss, profit factor, expected payoff
- Win rate, average win, average loss, largest win, largest loss
- Max balance DD, max equity DD
- Total trades / baskets, basket TP count, spike-exit count
- **THESIS_INVALID loss anatomy**: count, total, average, largest — this is
  the single most important number to check, since it's what v4.0.0
  specifically targeted (v3.3.3 baseline: count=25, avg=-$19.89,
  largest=-$41.76)
- Max layers used, average layers, recovery accepted/rejected

### Success criteria (section 45) — NOT "is profit positive"
- Profit factor materially above 1.00 (target ≥1.10, preferred ≥1.20)
- Expected payoff meaningfully positive
- Net profit materially higher than v3.3.3/v3.3.4
- Max equity DD stays controlled (preferred <10%, hard ceiling <20% —
  unchanged from v3.3.x)
- Average loss improves relative to v3.3.3/v3.3.4
- Largest loss decreases if possible
- THESIS_INVALID losses materially decrease
- Recovery becomes more *selective*, not merely more frequent (compare
  the accepted/rejected ratio, not just the raw accepted count)
- **A lower win rate than 69% is an acceptable outcome** if expectancy
  improved — do not treat a win-rate drop alone as a regression (section 46)

### What the new forensic output gives you (not present in v3.3.3/v3.3.4)
At `OnDeinit`, three sections print in order:
1. `================ DTE v4.0.0 FORENSIC SUMMARY ================` — same
   general operational counters as before (baskets, layers, recovery,
   hedge, spike diagnostics), plus a new **regime occurrence** breakdown
   and a **thesis-invalid exit trigger** breakdown (structural vs equity
   vs grace).
2. `---- LOSS ANATOMY (section 32) ----` — 7 categories (BASKET_TP,
   SPIKE_EXIT, THESIS_INVALID, MAX_HOLD, RISK_EXIT, HEDGE_EXIT, OTHER),
   each with count/total/average/largest loss and average/max hold.
3. `================ DTE v4.0.0 EXPECTANCY REPORT (section 33) ================` —
   overall PF/expectancy/win-rate, then broken down by direction, session,
   market regime, layer count, exit reason, and thesis state at close.
   **This is the primary tool for deciding what to adjust next** — e.g. if
   expectancy by regime shows RANGE trades are the drag, that points at a
   different lever than if TREND_DOWN trades are.

## TEST B — out-of-sample / forward (after TEST A only)
Only run this once TEST A results have been reviewed. Do not adjust any
input based on TEST A results and then call the adjusted run "out of
sample" — that is in-sample tuning by another name. A genuine
out-of-sample test uses either:
- A different date range than 2024.01.01–2025.12.31 (e.g. an earlier or
  more recent period not used to design v4.0.0's weights/thresholds), or
- Forward testing (demo or paper) going forward from today.

## Data quality caveat (section 37, carried from the v3.3.3 baseline report)
The v3.3.3 HTML report showed **"History Quality: 0% real ticks"** despite
the tester using a real-tick modeling mode. This has NOT been independently
re-verified for v4.0.0 as part of this coding task. Do not treat TEST A's
results as final validation of data quality — check the tester's own
History Quality/modeling-mode indicator on the new report and flag it if
it still reads 0%.

## What must NOT be changed during baseline testing
- Do not change any `Inp*` default before the first TEST A run.
- Do not change the backtest date range, deposit, leverage, or tick model
  from the table above for TEST A.
- Do not optimize (MT5 Strategy Tester's Optimization mode) before a
  single-pass TEST A has been reviewed — section 36 explicitly prohibits
  curve-fitting to this date range as part of building the strategy.
