# DTE v4.0.0 — Controlled Strategy-Engine Redesign

## Why v3.3.3/v3.3.4 were insufficient

Backtest (XAUUSD, M5, 2024.01.01–2025.12.31, $3,000, 1:500):

| Metric | v3.3.3 | Diagnosis |
|---|---|---|
| Net profit | +$12.45 | Effectively flat over 2 years |
| Profit factor | 1.02 | Barely above breakeven |
| Win rate | 69.44% | High — the system was NOT struggling to find winning trades |
| Avg win / avg loss | $5.80 / -$12.61 | **The actual problem** — losses ran ~2.2x the size of wins |
| Confluence pass/reject | 123 / 139,333 | Entry filter pipeline excessively restrictive |
| THESIS_INVALID losses | count=25, avg=-$19.89, largest=-$41.76 | Dominant loss source |
| Max equity DD / max basket risk | 5.84% / 2.25% | Genuinely well-controlled — **do not break this** |

The conclusion (also independently reached in the v3.3.4 hot-fix): this was
**not** a signal-generation problem. It was a **trade-lifecycle-management**
problem — the system won often but gave back disproportionately more on the
trades that went wrong, because there was no explicit model of *when a trade
thesis actually breaks down* versus *when price is just retracing*.

## What changed

### 1. Entry engine — signal quality vs. filter over-restriction (sections 4-6)
**Old:** `CConfluenceEngine` required M15 structure to *already* be a
confirmed bullish/bearish/BOS/CHOCH state as a hard pre-filter before any
scoring happened at all — this is why 139,333 of 139,456 evaluations were
rejected.
**New:** `Strategy/SignalEngine.mqh` lets the M5 execution trigger pick the
candidate direction (gated only by "don't fight a STRONG opposing H1
trend" — section 6), and moves M15 alignment, EMA, BOS, CHOCH, fib, and S/R
into a transparent, additive **12-point score** (section 5). `InpMinEntryScore`
defaults to 5 (~42%) instead of an undocumented near-impossible bar.

### 2. Trade thesis object + 3-state machine (sections 7-9) — **the core new module**
`Strategy/ThesisEngine.mqh` is entirely new. Every basket now has an
explicit `SThesis` (direction, entry price/structure/H1 bias, fib/S-R
references, MAE/MFE, invalidation score). Thesis state is
`VALID -> WEAKENING -> INVALID`, driven by an 11-point multi-factor score
(M15 break against +3, H1 reversal +3, M5 BOS against +2, EMA regime
reversal +1, ATR expansion +1, momentum against +1) — never a single weak
signal (section 9's explicit requirement).

### 3. Three-way adverse-move classification (section 10)
`ClassifyAdverseMove()` maps thesis state directly onto
RETRACEMENT / CONTINUATION / REVERSAL: REVERSAL (thesis INVALID) blocks
recovery outright; CONTINUATION (WEAKENING) only allows recovery on
materially stronger evidence; RETRACEMENT (still VALID) is the preferred
recovery scenario.

### 4. Recovery — scored, not binary (sections 11-14)
**Old:** recovery was a fresh-M5-trigger yes/no gate, which produced 249,706
rejections in the v3.3.2 baseline (later throttled to 942 in v3.3.3/4 via
event-driven evaluation — that throttling is carried forward unchanged).
**New:** `Recovery/RecoveryEngine.mqh` computes a signed score (+13 max,
-13 min) from M15/M5/EMA/fib/S-R/momentum/ATR/thesis-validity minus
continuation/broken-structure/reversed-bias/abnormal-volatility penalties —
using the spec's own example weights verbatim. `InpMinRecoveryScore=6` is
the base bar; CONTINUATION and HIGH_VOLATILITY regimes raise it further;
RANGE regime blocks layers ≥4 outright ("no aggressive stacking in
sideways conditions").

### 5. Market regime classification (section 34)
`Strategy/RegimeEngine.mqh` is new — 6-way classification (TREND_UP/DOWN,
RANGE, HIGH/LOW_VOLATILITY, TRANSITION) from existing H1 bias + M15
structure + M5 ATR band. Recorded per-basket; feeds both the recovery
threshold adjustment above and the expectancy-by-regime report.

### 6. Loss anatomy + expectancy reporting (sections 32-33, 46)
`Recovery/LossAnatomy.mqh` (losses only, 7 categories) and `Recovery/
ExpectancyEngine.mqh` (every closed basket, broken down by direction,
session, regime, layer count, exit reason, and thesis state) are both new.
The explicit design principle carried through the whole redesign: **optimize
for expectancy, not win rate** (section 46) — a lower win rate with a much
better expectancy is an acceptable, even desirable, outcome.

### 7. Loss magnitude control (section 18-19)
- **Micro-profit mode** (new, section 19): closes a basket early once it
  reaches a small positive expected value (`InpMicroProfitMinPercent`,
  default 0.08% of cycle balance, after a minimum hold), instead of forcing
  every basket to the full TP target.
- **Structural thesis-invalid exit** carried over from the v3.3.4 hot-fix
  (basket-relative loss cap, since the v3.3.3 equity-% trigger almost never
  fired at these lot sizes) — still present alongside the equity trigger.

### 8. Max basket hold — verified true hard limit (section 17)
Investigated the reported "104,700 seconds / ~29.08h vs configured 720min/12h"
discrepancy. **Finding:** `cycleStartTime` was already set exactly once, in
`StartBasket()`, and never reset by a new layer/hedge/restart in the v3.3.x
source — the timer itself was already correct. The ~29h figure in the
original v3.3.2 report almost certainly reflects the **v3.3.2 baseline's
looser thesis-invalidation path** (a basket can run long before its thesis
formally invalidates), not a broken timer. v4.0.0 keeps the same
never-reset timer and additionally logs a structured `[BASKET][MAX_HOLD]`
line with age/configured-max/layers/floating/direction/action on every
enforcement, and — new — blocks a NEW hedge (not just new recovery/entry)
once the limit is reached (`Core/PositionManager.mqh::ManageHedge()`).

### 9. Risk limits tightened (sections 16, 40)
`InpMaxBasketEquityRiskPercent`/`InpHardBasketEquityRiskPercent` (15%/20%)
renamed to `InpMaxBasketRiskPercent`/`InpHardBasketRiskPercent` and
retightened to **2.5%/4.0%** — the v3.3.3 backtest's own
`maxBasketRisk≈2.25%` shows the old 15%/20% ceiling provided no real
protection at these lot sizes. **New:** `InpMaxEquityDrawdownPercent` (20%
hard) is now an *enforced* account-level circuit breaker
(`Core/RiskEngine.mqh::EvaluateHalts()`) — previously only a passive
forensic statistic — plus a softer `InpPreferredEquityDrawdownPercent`
(10%) that logs a warning without halting.

### 10. Hedge — unchanged core logic, bounded (section 21)
`Recovery/HedgeEngine.mqh` is the v3.3.x `CHedgeEngine` moved unchanged
(structural-trigger-only, never "basket is losing" alone). **New:**
`InpMaxHedgesPerBasket` (default 2) bounds hedge-open events per basket —
an explicit loop-prevention guarantee the spec asked for, even though no
loop was observed in the v3.3.x baseline (12 opened / 12 closed).

### 11. Fixed a latent bug found during the audit
`Indicators/ATRFilter.mqh::Init()` always called `iATR(symbol,
PERIOD_CURRENT, period)` — i.e. the ATR regime gate silently read whatever
timeframe the EA's *chart* happened to be on, not necessarily M5 as
intended. Fixed to take an explicit timeframe parameter; the composition
root now passes `InpTfTrigger`.

## What was NOT changed (section 48 — preserve the good parts)
- Max 6 layers, max 0.03 lot/layer (hard, validated in `OnInit`).
- Non-martingale, capacity-based lot sizing (`Core/LotSizing.mqh`, byte-for-byte
  carried over).
- CRITICAL close-safety (never finalize until every position verified
  closed) and orphan-position recovery — carried over unchanged.
- Hedge-close verified state machine (`TRADE_RETCODE_DONE_PARTIAL` never
  treated as "hedge gone").
- Restart-safe GlobalVariable persistence pattern (though the *layout*
  changed — see "Known limitations" below).
- Profit-target lifecycle (persisted baseline/cycle-id, manual-reset-only,
  two-stage confirm button).

## Compile result
**NOT compiled in this environment** — no MetaEditor/MQL5 compiler is
available here. All 25 files were written and then cross-checked
programmatically: brace/parenthesis balance per file, every `#include`
target resolved, every struct field access matched against its declared
type, every `Inp*` input referenced somewhere is declared (and vice versa),
and no duplicate class/struct names or header guards. This is **not** a
substitute for an actual 0-errors/0-warnings MetaEditor compile — please
compile before running TEST A and report back if the compiler finds
anything the manual checks above didn't catch.

## Known limitations
- **Not backtested as part of this coding task**, per explicit instruction —
  nothing in this document is a profitability or performance claim.
- **Persistence layout changed** (new scalar fields: thesis state, entry
  score, entry regime, hedge-event count — see `Config/Inputs.mqh`'s
  `DTE_STATE_VERSION` comment). A v3.3.x persisted basket will NOT restore
  correctly under v4.0.0. Start a fresh backtest/session rather than
  resuming a v3.3.x live session.
- `SThesis`'s richer fields (swing/fib references, MAE/MFE) are
  intentionally **not** persisted field-by-field across a restart — only
  the handful of scalars already in `SBasketState` are. On restart, a
  fresh baseline thesis is rebuilt from what IS known (direction, last
  layer price, persisted entry score/regime); `EvaluateInvalidation()`
  re-derives the real state within one management pass. Same tolerance
  already accepted for v3.3.x's orphan-tracking and recovery-throttle
  state.
- The 12-point entry score, the recovery score weights, and the
  `InpThesisInvalidLossToTpMultiple`/`InpMinRecoveryScore`/
  `InpMinEntryScore` defaults are **design choices consistent with the
  spec's example weights**, not values tuned against this or any backtest
  — per section 36's explicit "do not optimize" instruction. They should be
  treated as a starting architecture to validate, not a finished, proven
  configuration.
- `CDealInfo::FinalRealizedResult()` (used at `FinalizeBasket()` for an
  exact net P/L) falls back to the last live floating-profit snapshot if
  history lookup returns nothing for any basket ticket — this can happen in
  some tester edge cases and is logged nowhere differently, so a very small
  number of closed-basket P/L figures could be the floating estimate rather
  than the exact realized figure.

## What must NOT be changed during baseline testing (section 53.M)
Per section 44 — run **TEST A** with **default inputs**, exact same
backtest settings as the v3.3.3/v3.3.4 baseline (see `Docs/TEST_PLAN.md`),
and compare against v3.3.3/v3.3.4 before touching any input value. Changing
inputs before the first comparison run would make the comparison
meaningless.
