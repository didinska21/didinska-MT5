//+------------------------------------------------------------------+
//| TrendEngine.mqh — CTrendEngine                                    |
//| v4.0.0 — higher-timeframe (H1) directional bias. Logic carried    |
//| over from v3.3.x's CConfluenceEngine::GetH1Bias() (EMA-gap-over-  |
//| ATR strength measure) — proven, unchanged — extracted into its    |
//| own module per the section 41 modular-architecture requirement.   |
//+------------------------------------------------------------------+
#ifndef __DTE_TRENDENGINE_MQH__
#define __DTE_TRENDENGINE_MQH__

#include "..\Config\Inputs.mqh"
#include "..\Indicators\EMAFilter.mqh"

class CTrendEngine
  {
private:
   string     m_symbol;
   CEMAFilter m_fast, m_slow;
   int        m_atrHandle;

public:
   CTrendEngine() : m_atrHandle(INVALID_HANDLE) {}

   bool Init(const string symbol)
     {
      m_symbol=symbol;
      bool ok=true;
      ok = ok && m_fast.Init(symbol,InpTfBias,InpEmaFastPeriod,InpEmaMethod,InpEmaPrice);
      ok = ok && m_slow.Init(symbol,InpTfBias,InpEmaSlowPeriod,InpEmaMethod,InpEmaPrice);
      m_atrHandle=iATR(symbol,InpTfBias,InpAtrPeriod);
      ok = ok && (m_atrHandle!=INVALID_HANDLE);
      return ok;
     }

   void Release()
     {
      m_fast.Release(); m_slow.Release();
      if(m_atrHandle!=INVALID_HANDLE) IndicatorRelease(m_atrHandle);
     }

   double GetAtr(const int shift=1) const
     {
      if(m_atrHandle==INVALID_HANDLE) return 0.0;
      double buf[];
      ArraySetAsSeries(buf,true);
      if(CopyBuffer(m_atrHandle,0,shift,1,buf)<=0) return 0.0;
      return buf[0];
     }

   // EMA-gap-over-ATR strength measure: ratio<0.15 => neutral,
   // 0.15<=ratio<1.0 => bull/bear, ratio>=1.0 => strong bull/bear.
   ENUM_MARKET_BIAS GetBias() const
     {
      double fast,slow;
      if(!m_fast.GetValue(fast,1) || !m_slow.GetValue(slow,1)) return BIAS_NEUTRAL;
      double atr=GetAtr(1);
      if(atr<=0.0) return BIAS_NEUTRAL;

      double gap=fast-slow;
      double ratio=MathAbs(gap)/atr;

      if(ratio<0.15) return BIAS_NEUTRAL;
      if(gap>0) return (ratio>=1.0)?BIAS_STRONG_BULL:BIAS_BULL;
      return (ratio>=1.0)?BIAS_STRONG_BEAR:BIAS_BEAR;
     }

   bool GetEmaValues(double &fastOut,double &slowOut,const int shift=1) const
     {
      return (m_fast.GetValue(fastOut,shift) && m_slow.GetValue(slowOut,shift));
     }
  };

#endif // __DTE_TRENDENGINE_MQH__
