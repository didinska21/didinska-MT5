//+------------------------------------------------------------------+
//| SignalEngine.mqh — CSignalEngine                                  |
//| v4.0.0 SECTIONS 4-6 — entry scoring engine.                       |
//|                                                                     |
//| KEY REDESIGN vs v3.3.x (section 4 finding: Confluence pass=123,    |
//| reject=139,333 — the filter pipeline was excessively restrictive): |
//| v3.3.x required M15 structure to ALREADY be a confirmed bullish/   |
//| bearish/BOS/CHOCH state just to get a candidate direction at all,  |
//| BEFORE any scoring happened — a hard pre-filter, not a score       |
//| component. v4.0.0 instead lets the M5 trigger (the execution       |
//| timeframe) pick the candidate direction, gated only by "don't      |
//| fight a STRONG opposing H1 trend" (section 6) — and moves M15      |
//| alignment, EMA, BOS, CHOCH, fib, and S/R into the transparent      |
//| 12-point SCORE (section 5) instead of a binary pre-filter. This is |
//| the section-4-required distinction between SIGNAL QUALITY (score)  |
//| and TRADE MANAGEMENT QUALITY (thesis/recovery engine, separate).   |
//+------------------------------------------------------------------+
#ifndef __DTE_SIGNALENGINE_MQH__
#define __DTE_SIGNALENGINE_MQH__

#include "..\Config\Inputs.mqh"
#include "..\Indicators\EMAFilter.mqh"
#include "TrendEngine.mqh"
#include "RegimeEngine.mqh"
#include "StructureEngine.mqh"

class CSignalEngine
  {
private:
   string           m_symbol;
   CTrendEngine    *m_trend;   // not owned
   CRegimeEngine   *m_regime;  // not owned

   CEMAFilter m_m5Fast, m_m5Slow;
   int        m_m5AtrHandle;
   datetime   m_lastTriggerBarTime;

   double GetM5Atr(const int shift=1) const
     {
      if(m_m5AtrHandle==INVALID_HANDLE) return 0.0;
      double buf[];
      ArraySetAsSeries(buf,true);
      if(CopyBuffer(m_m5AtrHandle,0,shift,1,buf)<=0) return 0.0;
      return buf[0];
     }

public:
   CSignalEngine() : m_trend(NULL), m_regime(NULL), m_m5AtrHandle(INVALID_HANDLE), m_lastTriggerBarTime(0) {}

   bool Init(const string symbol,CTrendEngine *trend,CRegimeEngine *regime)
     {
      m_symbol=symbol;
      m_trend=trend;
      m_regime=regime;
      bool ok=true;
      ok = ok && m_m5Fast.Init(symbol,InpTfTrigger,InpEmaFastPeriod,InpEmaMethod,InpEmaPrice);
      ok = ok && m_m5Slow.Init(symbol,InpTfTrigger,InpEmaSlowPeriod,InpEmaMethod,InpEmaPrice);
      m_m5AtrHandle=iATR(symbol,InpTfTrigger,InpAtrPeriod);
      ok = ok && (m_m5AtrHandle!=INVALID_HANDLE);
      return ok;
     }

   void Release()
     {
      m_m5Fast.Release(); m_m5Slow.Release();
      if(m_m5AtrHandle!=INVALID_HANDLE) IndicatorRelease(m_m5AtrHandle);
     }

   // Same directional-candle/EMA-order check used since v3.3.x, exposed so
   // it can be evaluated in an EXPLICIT direction — including the
   // direction opposite an open basket (used by Recovery/RecoveryEngine.mqh
   // and Strategy/ThesisEngine.mqh to detect momentum expanding against a
   // basket, section 10's CONTINUATION/REVERSAL detection).
   bool IsM5TriggerValid(const ENUM_CYCLE_DIRECTION candidate) const
     {
      if(candidate==CYCLE_NONE) return false;
      double f,s;
      if(!m_m5Fast.GetValue(f,1) || !m_m5Slow.GetValue(s,1)) return false;
      MqlRates rates[];
      ArraySetAsSeries(rates,true);
      if(CopyRates(m_symbol,InpTfTrigger,1,2,rates)<2) return false;

      double body=MathAbs(rates[0].close-rates[0].open);
      double range=rates[0].high-rates[0].low;
      if(range<=0.0) return false;
      bool directionalCandle=(candidate==CYCLE_BUY)
                             ? (rates[0].close>rates[0].open && rates[0].close>f)
                             : (rates[0].close<rates[0].open && rates[0].close<f);
      return directionalCandle && body>=range*0.10 &&
             ((candidate==CYCLE_BUY && f>s) || (candidate==CYCLE_SELL && f<s));
     }

   bool GetEmaAligned(const ENUM_CYCLE_DIRECTION candidate) const
     {
      double f,s;
      if(!m_m5Fast.GetValue(f,1) || !m_m5Slow.GetValue(s,1)) return false;
      return (candidate==CYCLE_BUY && f>s) || (candidate==CYCLE_SELL && f<s);
     }

   // section 6 — direction comes from the M5 execution trigger, gated only
   // by "do not fight a STRONG opposing H1 trend without a reversal model"
   // (we don't have one, so a strong opposing trend simply blocks that
   // side). This deliberately does NOT require M15 to already agree —
   // that alignment is scored, not gated (see Evaluate() below).
   ENUM_CYCLE_DIRECTION DetermineCandidate(const ENUM_MARKET_BIAS bias) const
     {
      bool m5Bull=IsM5TriggerValid(CYCLE_BUY);
      bool m5Bear=IsM5TriggerValid(CYCLE_SELL);
      if(m5Bull==m5Bear) return CYCLE_NONE; // neither, or (structurally impossible) both

      bool buyBlockedByStrongBias  = (bias==BIAS_STRONG_BEAR);
      bool sellBlockedByStrongBias = (bias==BIAS_STRONG_BULL);

      if(m5Bull && !buyBlockedByStrongBias)  return CYCLE_BUY;
      if(m5Bear && !sellBlockedByStrongBias) return CYCLE_SELL;
      return CYCLE_NONE;
     }

   // Full scored evaluation (section 5) — the entry engine's single
   // source of truth, called once per new M5 bar by CPositionManager.
   SEntryScore Evaluate() const
     {
      SEntryScore r;
      ZeroMemory(r);
      r.direction=CYCLE_NONE;
      r.regime=(m_regime!=NULL)?m_regime.Classify():REGIME_UNKNOWN;
      if(m_trend==NULL) return r;

      ENUM_MARKET_BIAS bias=m_trend.GetBias();
      ENUM_CYCLE_DIRECTION candidate=DetermineCandidate(bias);
      r.direction=candidate;
      if(candidate==CYCLE_NONE) { r.passed=false; return r; }

      SStructureAnalysis m15;
      if(m_regime!=NULL && m_regime.Structure()!=NULL)
         m15=m_regime.Structure().Analyze(InpTfStruct);

      int score=0;

      // H1 aligned: +2
      bool h1Aligned=(candidate==CYCLE_BUY) ? (bias==BIAS_BULL||bias==BIAS_STRONG_BULL)
                                             : (bias==BIAS_BEAR||bias==BIAS_STRONG_BEAR);
      r.h1Aligned=h1Aligned;
      if(h1Aligned) score+=2;

      // M15 aligned: +2 (NOT a gate — see class comment)
      bool m15Aligned=(candidate==CYCLE_BUY)
         ? (m15.valid && (m15.state==STRUCT_BULLISH||m15.state==STRUCT_BOS_UP||m15.state==STRUCT_CHOCH_UP))
         : (m15.valid && (m15.state==STRUCT_BEARISH||m15.state==STRUCT_BOS_DOWN||m15.state==STRUCT_CHOCH_DOWN));
      r.m15Aligned=m15Aligned;
      if(m15Aligned) score+=2;

      // M5 trigger: +2 (already required as the gate above — scored too so
      // the number stays meaningful if InpRequireM5Trigger is ever relaxed)
      r.m5Trigger=true; // DetermineCandidate() already required this to reach here
      score+=2;

      // EMA alignment: +1
      if(InpUseEmaConfluence)
        {
         r.emaAligned=GetEmaAligned(candidate);
         if(r.emaAligned) score++;
        }

      // BOS in candidate direction: +1
      bool bosHit=InpUseStructureConfluence &&
                  ((candidate==CYCLE_BUY) ? (m15.valid && m15.state==STRUCT_BOS_UP)
                                           : (m15.valid && m15.state==STRUCT_BOS_DOWN));
      r.bosHit=bosHit;
      if(bosHit) score++;

      // CHOCH in candidate direction: +1
      bool chochHit=InpUseStructureConfluence &&
                    ((candidate==CYCLE_BUY) ? (m15.valid && m15.state==STRUCT_CHOCH_UP)
                                             : (m15.valid && m15.state==STRUCT_CHOCH_DOWN));
      r.chochHit=chochHit;
      if(chochHit) score++;

      // Fib 50 / 61.8 proximity: +1 each
      double atr=GetM5Atr(1);
      double tolerance=(atr>0.0)?atr*InpFibProximityAtrMult:0.0;
      if(InpUseFibConfluence && tolerance>0.0 && m_regime!=NULL && m_regime.Structure()!=NULL)
        {
         double fib50,fib618;
         if(m_regime.Structure().GetFibLevels(m15,fib50,fib618))
           {
            double price=(candidate==CYCLE_BUY)?SymbolInfoDouble(m_symbol,SYMBOL_ASK)
                                                :SymbolInfoDouble(m_symbol,SYMBOL_BID);
            if(MathAbs(price-fib50)<=tolerance)  { r.fib50Hit=true;  score++; }
            if(MathAbs(price-fib618)<=tolerance) { r.fib618Hit=true; score++; }
           }
        }

      // Support/Resistance confluence: +1 — proximity to the relevant
      // recent swing extreme (reuses the same swing data as the fib leg;
      // StructureEngine's own scope disclosure applies here too).
      if(InpUseSrConfluence && tolerance>0.0 && m15.valid)
        {
         double price=(candidate==CYCLE_BUY)?SymbolInfoDouble(m_symbol,SYMBOL_ASK)
                                             :SymbolInfoDouble(m_symbol,SYMBOL_BID);
         double srLevel=(candidate==CYCLE_BUY)?m15.lastSwingLow:m15.lastSwingHigh;
         if(MathAbs(price-srLevel)<=tolerance) { r.srHit=true; score++; }
        }

      r.score=score;
      r.passed=(score>=InpMinEntryScore);
      return r;
     }

   //=====================================================================
   // New-bar dedup wrapper (section 35 — "avoid entering repeatedly on the
   // same candle/signal"). Returns true ONLY on the tick where a NEW
   // trigger-timeframe bar has formed AND the score passes threshold.
   // Caller (composition root) must also ensure no basket is currently
   // active — one basket at a time.
   //=====================================================================
   bool CheckTrigger(SEntryScore &outResult)
     {
      ZeroMemory(outResult);
      outResult.direction=CYCLE_NONE;

      datetime curBarTime=iTime(m_symbol,InpTfTrigger,0);
      if(curBarTime==0) return false;
      if(curBarTime==m_lastTriggerBarTime) return false; // no new bar yet

      m_lastTriggerBarTime=curBarTime; // mark evaluated regardless of outcome

      SEntryScore r=Evaluate();
      outResult=r;
      return r.passed;
     }

   // Marks the current trigger-timeframe bar as already handled — call the
   // instant a basket closes so a new cycle can't fire mid-bar on the same
   // candle the previous basket just closed on.
   void SuppressCurrentBar()
     {
      datetime curBarTime=iTime(m_symbol,InpTfTrigger,0);
      if(curBarTime>0) m_lastTriggerBarTime=curBarTime;
     }
  };

#endif // __DTE_SIGNALENGINE_MQH__
