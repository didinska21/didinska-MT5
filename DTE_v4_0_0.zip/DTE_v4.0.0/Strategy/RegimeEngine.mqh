//+------------------------------------------------------------------+
//| RegimeEngine.mqh — CRegimeEngine                                  |
//| v4.0.0 SECTION 34 — classifies the current market into one of six |
//| regimes using ONLY existing concepts (H1 bias via CTrendEngine,   |
//| M15 structure via CStructureEngine, M5 ATR band). No new          |
//| indicators. The regime is recorded on every basket (SThesis.      |
//| entryRegime) so ExpectancyEngine can report performance by regime.|
//+------------------------------------------------------------------+
#ifndef __DTE_REGIMEENGINE_MQH__
#define __DTE_REGIMEENGINE_MQH__

#include "..\Config\Inputs.mqh"
#include "TrendEngine.mqh"
#include "StructureEngine.mqh"
#include "..\Indicators\ATRFilter.mqh"

class CRegimeEngine
  {
private:
   string           m_symbol;
   CTrendEngine    *m_trend;   // not owned
   CStructureEngine m_structure;
   CATRFilter       m_atr;

   double GetM5AtrPoints() const
     {
      return m_atr.GetAtrPoints(1);
     }

public:
   CRegimeEngine() : m_trend(NULL) {}

   bool Init(const string symbol,CTrendEngine *trend)
     {
      m_symbol=symbol;
      m_trend=trend;
      m_structure.Init(symbol);
      return m_atr.Init(symbol,InpAtrPeriod,InpTfTrigger);
     }

   void Release()
     {
      m_atr.Release();
     }

   // Classification order deliberately mirrors section 34's response table:
   // volatility extremes are checked first (they change HOW you should
   // trade regardless of direction), then trend, then range/transition as
   // the residual case.
   ENUM_MARKET_REGIME Classify() const
     {
      if(m_trend==NULL) return REGIME_UNKNOWN;

      double atrPts=GetM5AtrPoints();
      if(atrPts>0.0)
        {
         if(atrPts>=InpAtrMaxPoints) return REGIME_HIGH_VOLATILITY;
         if(atrPts<=InpAtrMinPoints) return REGIME_LOW_VOLATILITY;
        }

      ENUM_MARKET_BIAS bias=m_trend.GetBias();
      SStructureAnalysis m15=m_structure.Analyze(InpTfStruct);

      bool m15Bull=(m15.valid && (m15.state==STRUCT_BULLISH || m15.state==STRUCT_BOS_UP || m15.state==STRUCT_CHOCH_UP));
      bool m15Bear=(m15.valid && (m15.state==STRUCT_BEARISH || m15.state==STRUCT_BOS_DOWN || m15.state==STRUCT_CHOCH_DOWN));

      if(bias==BIAS_STRONG_BULL || bias==BIAS_BULL)
        {
         // H1 says up but M15 structure disagrees outright — treat as a
         // TRANSITION (the higher timeframe hasn't been confirmed yet by
         // the structure timeframe), rather than blindly trusting either.
         if(m15Bear) return REGIME_TRANSITION;
         return REGIME_TREND_UP;
        }
      if(bias==BIAS_STRONG_BEAR || bias==BIAS_BEAR)
        {
         if(m15Bull) return REGIME_TRANSITION;
         return REGIME_TREND_DOWN;
        }

      // H1 neutral: let M15 structure decide trend-vs-range.
      if(m15Bull) return REGIME_TREND_UP;
      if(m15Bear) return REGIME_TREND_DOWN;

      return REGIME_RANGE;
     }

   CStructureEngine *Structure() { return GetPointer(m_structure); }
  };

#endif // __DTE_REGIMEENGINE_MQH__
