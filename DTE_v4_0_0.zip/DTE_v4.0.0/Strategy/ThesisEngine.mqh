//+------------------------------------------------------------------+
//| ThesisEngine.mqh — CThesisEngine                                  |
//| v4.0.0 SECTIONS 7-10 — THE core new module of this redesign.      |
//|                                                                     |
//| Owns the explicit trade-thesis object (SThesis, section 7), the    |
//| 3-state machine VALID -> WEAKENING -> INVALID (section 8) driven   |
//| by a multi-factor invalidation SCORE rather than any single signal |
//| (section 9 — "do NOT invalidate based on one weak signal"), and    |
//| the three-way adverse-move classifier RETRACEMENT / CONTINUATION / |
//| REVERSAL (section 10) that Recovery/RecoveryEngine.mqh consults    |
//| before ever adding a layer.                                        |
//|                                                                     |
//| Invalidation score (section 9's example weights, used verbatim):   |
//|   M15 structure break against basket   : +3                       |
//|   H1 bias reversal                     : +3                       |
//|   M5 BOS/CHOCH against basket          : +2                       |
//|   EMA regime reversal (M5 fast/slow)   : +1                       |
//|   ATR expansion (M5 ATR(1) vs ATR(10)) : +1                       |
//|   Strong M5 momentum against basket    : +1                       |
//|   Maximum: 11. THESIS_INVALID when score >= InpThesisInvalidScore  |
//|   (default 6); THESIS_WEAKENING when score >= InpThesisWeakScore   |
//|   (default 3) but below the invalid threshold.                     |
//+------------------------------------------------------------------+
#ifndef __DTE_THESISENGINE_MQH__
#define __DTE_THESISENGINE_MQH__

#include "..\Config\Inputs.mqh"
#include "TrendEngine.mqh"
#include "RegimeEngine.mqh"
#include "SignalEngine.mqh"

class CThesisEngine
  {
private:
   string          m_symbol;
   CTrendEngine   *m_trend;   // not owned
   CRegimeEngine  *m_regime;  // not owned
   CSignalEngine  *m_signal;  // not owned

   int m_m5AtrHandle;

   double GetM5AtrShift(const int shift) const
     {
      if(m_m5AtrHandle==INVALID_HANDLE) return 0.0;
      double buf[];
      ArraySetAsSeries(buf,true);
      if(CopyBuffer(m_m5AtrHandle,0,shift,1,buf)<=0) return 0.0;
      return buf[0];
     }

public:
   CThesisEngine() : m_trend(NULL), m_regime(NULL), m_signal(NULL), m_m5AtrHandle(INVALID_HANDLE) {}

   bool Init(const string symbol,CTrendEngine *trend,CRegimeEngine *regime,CSignalEngine *signal)
     {
      m_symbol=symbol;
      m_trend=trend;
      m_regime=regime;
      m_signal=signal;
      m_m5AtrHandle=iATR(symbol,InpTfTrigger,InpAtrPeriod);
      return (m_m5AtrHandle!=INVALID_HANDLE);
     }

   void Release()
     {
      if(m_m5AtrHandle!=INVALID_HANDLE) IndicatorRelease(m_m5AtrHandle);
     }

   // Called once, when layer 1 opens (section 7 — "every basket MUST have
   // an explicit internal thesis").
   SThesis BuildThesis(const ENUM_CYCLE_DIRECTION direction,const double entryPrice,
                        const SEntryScore &entryScore) const
     {
      SThesis t;
      ZeroMemory(t);
      t.direction=direction;
      t.entryPrice=entryPrice;
      t.initialH1Bias=(m_trend!=NULL)?m_trend.GetBias():BIAS_NEUTRAL;
      t.initialM5Trigger=entryScore.m5Trigger;
      t.initialEmaAligned=entryScore.emaAligned;
      t.initialAtr=GetM5AtrShift(1);
      t.entryScore=entryScore.score;
      t.entryRegime=entryScore.regime;
      t.timestamp=TimeCurrent();
      t.currentLayer=1;
      t.state=THESIS_VALID;
      t.invalidationScore=0;

      SStructureAnalysis m15; ZeroMemory(m15);
      if(m_regime!=NULL && m_regime.Structure()!=NULL)
        {
         m15=m_regime.Structure().Analyze(InpTfStruct);
         t.initialStructure=m15.state;
         if(m15.valid)
           {
            t.refSwingHigh=m15.lastSwingHigh;
            t.refSwingLow=m15.lastSwingLow;
            double f50,f618;
            if(m_regime.Structure().GetFibLevels(m15,f50,f618))
              {
               t.fib50=f50; t.fib618=f618; t.fibValid=true;
              }
            t.srReference=(direction==CYCLE_BUY)?m15.lastSwingLow:m15.lastSwingHigh;
           }
        }

      t.initialRiskDistance=(t.initialAtr>0.0)?t.initialAtr*InpLayerAtrMultiplier:0.0;
      return t;
     }

   // Multi-factor invalidation score (section 9). Updates thesis.state and
   // the relevant transition timestamp; returns the score breakdown so the
   // caller can log it via CLogger::Thesis()/ThesisWeak()/ThesisInvalid().
   int EvaluateInvalidation(SThesis &t,string &reasonOut) const
     {
      reasonOut="";
      if(t.direction==CYCLE_NONE || m_trend==NULL || m_signal==NULL) return 0;

      int score=0;
      string parts="";

      ENUM_MARKET_BIAS bias=m_trend.GetBias();
      bool h1Reversed=(t.direction==CYCLE_BUY) ? (bias==BIAS_STRONG_BEAR)
                                                : (bias==BIAS_STRONG_BULL);
      if(h1Reversed) { score+=3; parts+="h1Reversal(+3) "; }

      SStructureAnalysis m15; ZeroMemory(m15);
      if(m_regime!=NULL && m_regime.Structure()!=NULL) m15=m_regime.Structure().Analyze(InpTfStruct);
      bool m15Break=(t.direction==CYCLE_BUY)
                    ? (m15.valid && (m15.state==STRUCT_BOS_DOWN || m15.state==STRUCT_CHOCH_DOWN))
                    : (m15.valid && (m15.state==STRUCT_BOS_UP   || m15.state==STRUCT_CHOCH_UP));
      if(m15Break) { score+=3; parts+="m15StructureBreak(+3) "; }

      // M5 BOS/CHOCH against basket — same structure heuristic, M5 timeframe.
      SStructureAnalysis m5s; ZeroMemory(m5s);
      if(m_regime!=NULL && m_regime.Structure()!=NULL) m5s=m_regime.Structure().Analyze(InpTfTrigger);
      bool m5Bos=(t.direction==CYCLE_BUY)
                 ? (m5s.valid && (m5s.state==STRUCT_BOS_DOWN || m5s.state==STRUCT_CHOCH_DOWN))
                 : (m5s.valid && (m5s.state==STRUCT_BOS_UP   || m5s.state==STRUCT_CHOCH_UP));
      if(m5Bos) { score+=2; parts+="m5BosAgainst(+2) "; }

      ENUM_CYCLE_DIRECTION oppositeDir=(t.direction==CYCLE_BUY)?CYCLE_SELL:CYCLE_BUY;
      bool emaReversed=m_signal.GetEmaAligned(oppositeDir);
      if(emaReversed) { score+=1; parts+="emaRegimeReversal(+1) "; }

      double atrNow=GetM5AtrShift(1), atrRef=GetM5AtrShift(10);
      bool atrExpansion=(atrRef>0.0 && atrNow>=atrRef*1.4);
      if(atrExpansion) { score+=1; parts+="atrExpansion(+1) "; }

      bool momentumAgainst=m_signal.IsM5TriggerValid(oppositeDir);
      if(momentumAgainst) { score+=1; parts+="strongMomentumAgainst(+1) "; }

      reasonOut=parts;
      t.invalidationScore=score;

      ENUM_THESIS_STATE newState;
      if(score>=InpThesisInvalidScore)     newState=THESIS_INVALID;
      else if(score>=InpThesisWeakScore)   newState=THESIS_WEAKENING;
      else                                 newState=THESIS_VALID;

      if(newState!=t.state)
        {
         if(newState==THESIS_WEAKENING) t.weakeningTime=TimeCurrent();
         if(newState==THESIS_INVALID)   t.invalidatedTime=TimeCurrent();
         t.state=newState;
        }
      return score;
     }

   // section 10 — THREE MARKET STATES. Consulted by Recovery/
   // RecoveryEngine.mqh BEFORE any layer/hedge decision. Deliberately
   // consistent with (not a duplicate re-derivation of) EvaluateInvalidation
   // above: REVERSAL only once the thesis has actually reached INVALID;
   // CONTINUATION covers the WEAKENING band (real adverse evidence present,
   // HTF thesis not yet disproven); RETRACEMENT is the default — thesis
   // still fully valid, ordinary pullback.
   ENUM_ADVERSE_CLASS ClassifyAdverseMove(const SThesis &t) const
     {
      if(t.direction==CYCLE_NONE) return ADVERSE_NONE;
      if(t.state==THESIS_INVALID)   return ADVERSE_REVERSAL;
      if(t.state==THESIS_WEAKENING) return ADVERSE_CONTINUATION;
      return ADVERSE_RETRACEMENT;
     }

   // section 7 — "current adverse excursion / current favorable excursion".
   // Called every management tick; updates the running extremes in place.
   void UpdateExcursion(SThesis &t,const double currentPrice) const
     {
      if(t.direction==CYCLE_NONE || t.entryPrice<=0.0) return;
      double diff=(t.direction==CYCLE_BUY) ? (currentPrice-t.entryPrice) : (t.entryPrice-currentPrice);
      if(diff<0.0) { if(-diff>t.maxAdverseExcursionPts)   t.maxAdverseExcursionPts=-diff; }
      else         { if( diff>t.maxFavorableExcursionPts) t.maxFavorableExcursionPts=diff; }
     }
  };

#endif // __DTE_THESISENGINE_MQH__
