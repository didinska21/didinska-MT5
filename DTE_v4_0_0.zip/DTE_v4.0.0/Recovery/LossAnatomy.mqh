//+------------------------------------------------------------------+
//| LossAnatomy.mqh — CLossAnatomy                                    |
//| v4.0.0 SECTION 32 — forensic loss classification. Exactly the 7    |
//| categories the spec listed: BASKET_TP, SPIKE_EXIT, THESIS_INVALID, |
//| MAX_HOLD, RISK_EXIT, HEDGE_EXIT, MANUAL/OTHER (mapped from         |
//| ENUM_BASKET_CLOSE_REASON via CLogger::LossReasonIndex() — single    |
//| source of truth shared with Recovery/ExpectancyEngine.mqh).        |
//| Only accumulated for baskets that closed at a net LOSS.            |
//+------------------------------------------------------------------+
#ifndef __DTE_LOSSANATOMY_MQH__
#define __DTE_LOSSANATOMY_MQH__

#include "..\Config\Inputs.mqh"
#include "..\Core\Logger.mqh"

class CLossAnatomy
  {
private:
   SLossAnatomyBucket m_buckets[7];

public:
   void Init() { ZeroMemory(m_buckets); }

   // Call once per finalized basket, ONLY when netProfit<0.
   void Record(const ENUM_BASKET_CLOSE_REASON reason,const double netProfit,const long holdSeconds)
     {
      if(netProfit>=0.0) return;
      int idx=CLogger::LossReasonIndex(reason);
      double lossMag=-netProfit;

      m_buckets[idx].count++;
      m_buckets[idx].totalLoss+=lossMag;
      if(lossMag>m_buckets[idx].largestLoss) m_buckets[idx].largestLoss=lossMag;
      m_buckets[idx].holdSum+=holdSeconds;
      if(holdSeconds>m_buckets[idx].holdMax) m_buckets[idx].holdMax=holdSeconds;
     }

   SLossAnatomyBucket GetBucket(const ENUM_LOSS_EXIT_REASON idx) const { return m_buckets[(int)idx]; }

   void Print() const
     {
      string names[7]={"BASKET_TP(!)","SPIKE_EXIT","THESIS_INVALID","MAX_HOLD","RISK_EXIT","HEDGE_EXIT","OTHER"};
      Print("---- LOSS ANATOMY (section 32) ----");
      for(int i=0;i<7;i++)
        {
         long   n=m_buckets[i].count;
         double avgLoss=(n>0)?m_buckets[i].totalLoss/n:0.0;
         double avgHold=(n>0)?(double)m_buckets[i].holdSum/n:0.0;
         PrintFormat("  %-16s count=%-6d totalLoss=%-10.2f avgLoss=%-9.2f largestLoss=%-9.2f "
                     "avgHoldSec=%-8.1f maxHoldSec=%d",
                     names[i],n,m_buckets[i].totalLoss,avgLoss,m_buckets[i].largestLoss,
                     avgHold,m_buckets[i].holdMax);
        }
     }
  };

#endif // __DTE_LOSSANATOMY_MQH__
