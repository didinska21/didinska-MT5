//+------------------------------------------------------------------+
//| ExpectancyEngine.mqh — CExpectancyEngine                          |
//| v4.0.0 SECTION 33/46 — "the system should no longer optimize      |
//| merely for WIN RATE." Tracks gross profit/loss, PF, expected       |
//| payoff, win rate, avg win/loss, largest win/loss, and expectancy   |
//| broken down by direction, session, market regime, layer count,     |
//| exit reason, and thesis state — for EVERY closed basket (win or    |
//| loss), unlike LossAnatomy which only records losses.               |
//+------------------------------------------------------------------+
#ifndef __DTE_EXPECTANCYENGINE_MQH__
#define __DTE_EXPECTANCYENGINE_MQH__

#include "..\Config\Inputs.mqh"
#include "..\Core\Logger.mqh"

class CExpectancyEngine
  {
private:
   SExpectancyBucket m_byDirection[2];    // 0=BUY,1=SELL
   SExpectancyBucket m_bySession[5];      // ENUM_SESSION_NAME
   SExpectancyBucket m_byRegime[7];       // ENUM_MARKET_REGIME
   SExpectancyBucket m_byLayer[6];        // layersOpen 1..6 -> index 0..5
   SExpectancyBucket m_byExitReason[7];   // same mapping as LossAnatomy
   SExpectancyBucket m_byThesisState[3];  // ENUM_THESIS_STATE
   SExpectancyBucket m_overall;

   static void Add(SExpectancyBucket &b,const double netProfit)
     {
      b.trades++;
      if(netProfit>=0.0)
        {
         b.wins++;
         b.grossProfit+=netProfit;
         if(netProfit>b.largestWin) b.largestWin=netProfit;
        }
      else
        {
         b.losses++;
         b.grossLoss+=(-netProfit);
         if((-netProfit)>b.largestLoss) b.largestLoss=(-netProfit);
        }
     }

public:
   void Init()
     {
      ZeroMemory(m_byDirection); ZeroMemory(m_bySession); ZeroMemory(m_byRegime);
      ZeroMemory(m_byLayer); ZeroMemory(m_byExitReason); ZeroMemory(m_byThesisState);
      ZeroMemory(m_overall);
     }

   void Record(const ENUM_CYCLE_DIRECTION dir,const ENUM_SESSION_NAME session,
               const ENUM_MARKET_REGIME regime,const int layersOpen,
               const ENUM_BASKET_CLOSE_REASON reason,const ENUM_THESIS_STATE thesisState,
               const double netProfit)
     {
      Add(m_overall,netProfit);
      if(dir==CYCLE_BUY||dir==CYCLE_SELL) Add(m_byDirection[dir==CYCLE_BUY?0:1],netProfit);
      Add(m_bySession[(int)session],netProfit);
      Add(m_byRegime[(int)regime],netProfit);
      int layerIdx=(int)MathMin(MathMax(layersOpen,1),6)-1;
      Add(m_byLayer[layerIdx],netProfit);
      Add(m_byExitReason[CLogger::LossReasonIndex(reason)],netProfit);
      Add(m_byThesisState[(int)thesisState],netProfit);
     }

   static double PF(const SExpectancyBucket &b)     { return (b.grossLoss>0.0)?b.grossProfit/b.grossLoss:(b.grossProfit>0.0?DBL_MAX:0.0); }
   static double WinRate(const SExpectancyBucket &b) { return (b.trades>0)?100.0*b.wins/b.trades:0.0; }
   static double AvgWin(const SExpectancyBucket &b)  { return (b.wins>0)?b.grossProfit/b.wins:0.0; }
   static double AvgLoss(const SExpectancyBucket &b) { return (b.losses>0)?b.grossLoss/b.losses:0.0; }
   static double Expectancy(const SExpectancyBucket &b) { return (b.trades>0)?(b.grossProfit-b.grossLoss)/b.trades:0.0; }
   static double ExpectedPayoff(const SExpectancyBucket &b) { return Expectancy(b); } // same figure, MT5 terminology

   static void PrintBucket(const string label,const SExpectancyBucket &b)
     {
      if(b.trades<=0) { PrintFormat("  %-16s (no trades)",label); return; }
      double pf=PF(b);
      PrintFormat("  %-16s n=%-5d win%%=%-6.2f avgWin=%-8.2f avgLoss=%-8.2f "
                  "largestWin=%-8.2f largestLoss=%-8.2f PF=%-6.2f expectancy=%-7.3f",
                  label,b.trades,WinRate(b),AvgWin(b),AvgLoss(b),b.largestWin,b.largestLoss,
                  (pf==DBL_MAX?999.99:pf),Expectancy(b));
     }

   void PrintReport() const
     {
      Print("================ DTE v4.0.0 EXPECTANCY REPORT (section 33) ================");
      PrintFormat("Overall: grossProfit=%.2f grossLoss=%.2f PF=%.3f expectedPayoff=%.4f "
                  "winRate=%.2f%% avgWin=%.2f avgLoss=%.2f largestWin=%.2f largestLoss=%.2f",
                  m_overall.grossProfit,m_overall.grossLoss,PF(m_overall),ExpectedPayoff(m_overall),
                  WinRate(m_overall),AvgWin(m_overall),AvgLoss(m_overall),
                  m_overall.largestWin,m_overall.largestLoss);

      Print("-- by direction --");
      PrintBucket("BUY",m_byDirection[0]);
      PrintBucket("SELL",m_byDirection[1]);

      Print("-- by session --");
      string sn[5]={"NONE","ASIA","LONDON","NY","OVERLAP"};
      for(int i=0;i<5;i++) PrintBucket(sn[i],m_bySession[i]);

      Print("-- by market regime --");
      string rn[7]={"UNKNOWN","TREND_UP","TREND_DOWN","RANGE","HIGH_VOL","LOW_VOL","TRANSITION"};
      for(int i=0;i<7;i++) PrintBucket(rn[i],m_byRegime[i]);

      Print("-- by layer count --");
      for(int i=0;i<6;i++) PrintBucket(StringFormat("layer_%d",i+1),m_byLayer[i]);

      Print("-- by exit reason --");
      string en[7]={"BASKET_TP","SPIKE_EXIT","THESIS_INVALID","MAX_HOLD","RISK_EXIT","HEDGE_EXIT","OTHER"};
      for(int i=0;i<7;i++) PrintBucket(en[i],m_byExitReason[i]);

      Print("-- by thesis state at close --");
      string tn[3]={"VALID","WEAKENING","INVALID"};
      for(int i=0;i<3;i++) PrintBucket(tn[i],m_byThesisState[i]);

      Print("=============================================================================");
     }
  };

#endif // __DTE_EXPECTANCYENGINE_MQH__
