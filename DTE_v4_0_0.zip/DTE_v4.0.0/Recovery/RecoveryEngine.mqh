//+------------------------------------------------------------------+
//| RecoveryEngine.mqh — CRecoveryEngine                              |
//| v4.0.0 SECTIONS 11-14 — recovery becomes EXPECTANCY-AWARE and      |
//| SCORED, not a binary "fresh M5 trigger present, yes/no" gate.      |
//|                                                                     |
//| Recovery score (section 12, weights used verbatim):                |
//|   M15 structure still aligned      : +3     M5 trigger aligned : +2|
//|   EMA aligned                      : +1     Fib 50/61.8        : +1|
//|   S/R                              : +1     momentum           : +1|
//|   ATR acceptable                   : +1     thesis validity    : +3|
//|   strong continuation against      : -3     M15 structure broken:-4|
//|   H1 bias reversed                 : -4     volatility abnormal: -2|
//| Max positive ~13. THESIS classification (section 10, via            |
//| CThesisEngine) is consulted FIRST: ADVERSE_REVERSAL blocks recovery |
//| outright regardless of score — "do NOT blindly average down" (13). |
//| ADVERSE_CONTINUATION only proceeds on a materially higher score    |
//| than ADVERSE_RETRACEMENT (section 10's "only layer if recovery     |
//| conditions are strong").                                            |
//+------------------------------------------------------------------+
#ifndef __DTE_RECOVERYENGINE_MQH__
#define __DTE_RECOVERYENGINE_MQH__

#include "..\Config\Inputs.mqh"
#include "..\Strategy\TrendEngine.mqh"
#include "..\Strategy\RegimeEngine.mqh"
#include "..\Strategy\SignalEngine.mqh"
#include "..\Strategy\ThesisEngine.mqh"

class CRecoveryEngine
  {
private:
   string          m_symbol;
   CTrendEngine   *m_trend;
   CRegimeEngine  *m_regime;
   CSignalEngine  *m_signal;
   CThesisEngine  *m_thesis;

   int m_m5AtrHandle;

   double GetM5Atr(const int shift=1) const
     {
      if(m_m5AtrHandle==INVALID_HANDLE) return 0.0;
      double buf[];
      ArraySetAsSeries(buf,true);
      if(CopyBuffer(m_m5AtrHandle,0,shift,1,buf)<=0) return 0.0;
      return buf[0];
     }

public:
   CRecoveryEngine() : m_trend(NULL), m_regime(NULL), m_signal(NULL), m_thesis(NULL),
                        m_m5AtrHandle(INVALID_HANDLE) {}

   bool Init(const string symbol,CTrendEngine *trend,CRegimeEngine *regime,
             CSignalEngine *signal,CThesisEngine *thesis)
     {
      m_symbol=symbol; m_trend=trend; m_regime=regime; m_signal=signal; m_thesis=thesis;
      m_m5AtrHandle=iATR(symbol,InpTfTrigger,InpAtrPeriod);
      return (m_m5AtrHandle!=INVALID_HANDLE);
     }

   void Release()
     {
      if(m_m5AtrHandle!=INVALID_HANDLE) IndicatorRelease(m_m5AtrHandle);
     }

   // Section 14 — ATR-based layer distance with a configurable hard floor.
   double ComputeLayerDistance() const
     {
      double atr=GetM5Atr(1);
      double atrDist=(atr>0.0)?atr*InpLayerAtrMultiplier:0.0;
      double point=SymbolInfoDouble(m_symbol,SYMBOL_POINT);
      double floorDist=InpMinLayerDistancePoints*point;
      return MathMax(atrDist,floorDist);
     }

   // Section 12 — the scored recovery evaluation. thesis MUST already have
   // had EvaluateInvalidation() called this bar (caller's responsibility —
   // CPositionManager calls it once per management pass, before this).
   SRecoveryScore Evaluate(const SThesis &t,const int targetLayer,const ENUM_MARKET_REGIME regime) const
     {
      SRecoveryScore r;
      ZeroMemory(r);
      r.reason="";

      if(t.direction==CYCLE_NONE || m_trend==NULL || m_signal==NULL || m_regime==NULL || m_thesis==NULL)
        {
         r.reason="engine not ready";
         return r;
        }

      r.adverseClass=m_thesis.ClassifyAdverseMove(t);

      // section 10/13 — REVERSAL blocks recovery outright, full stop.
      if(r.adverseClass==ADVERSE_REVERSAL)
        {
         r.reason="thesis REVERSAL — do not average down";
         r.passed=false;
         return r;
        }

      SStructureAnalysis m15; ZeroMemory(m15);
      if(m_regime.Structure()!=NULL) m15=m_regime.Structure().Analyze(InpTfStruct);
      bool m15Aligned=(t.direction==CYCLE_BUY)
         ? (m15.valid && (m15.state==STRUCT_BULLISH||m15.state==STRUCT_BOS_UP||m15.state==STRUCT_CHOCH_UP))
         : (m15.valid && (m15.state==STRUCT_BEARISH||m15.state==STRUCT_BOS_DOWN||m15.state==STRUCT_CHOCH_DOWN));
      bool m15Broken=(t.direction==CYCLE_BUY)
         ? (m15.valid && (m15.state==STRUCT_BOS_DOWN||m15.state==STRUCT_CHOCH_DOWN))
         : (m15.valid && (m15.state==STRUCT_BOS_UP||m15.state==STRUCT_CHOCH_UP));

      ENUM_MARKET_BIAS bias=m_trend.GetBias();
      bool h1Reversed=(t.direction==CYCLE_BUY)?(bias==BIAS_STRONG_BEAR):(bias==BIAS_STRONG_BULL);

      bool m5Aligned=m_signal.IsM5TriggerValid(t.direction);
      bool emaAligned=m_signal.GetEmaAligned(t.direction);

      ENUM_CYCLE_DIRECTION oppositeDir=(t.direction==CYCLE_BUY)?CYCLE_SELL:CYCLE_BUY;
      bool strongContinuationAgainst=m_signal.IsM5TriggerValid(oppositeDir);

      double atr=GetM5Atr(1);
      double point=SymbolInfoDouble(m_symbol,SYMBOL_POINT);
      double atrPts=(point>0.0 && atr>0.0)?atr/point:0.0;
      bool atrAcceptable=(atrPts>0.0 && atrPts<InpAtrMaxPoints);
      bool volAbnormal=(regime==REGIME_HIGH_VOLATILITY);

      double price=(t.direction==CYCLE_BUY)?SymbolInfoDouble(m_symbol,SYMBOL_BID)
                                            :SymbolInfoDouble(m_symbol,SYMBOL_ASK);
      double tolerance=(atr>0.0)?atr*InpFibProximityAtrMult:0.0;
      bool fibHit=false, srHit=false;
      if(tolerance>0.0 && m15.valid)
        {
         if(t.fibValid && (MathAbs(price-t.fib50)<=tolerance || MathAbs(price-t.fib618)<=tolerance))
            fibHit=true;
         double srLevel=(t.direction==CYCLE_BUY)?m15.lastSwingLow:m15.lastSwingHigh;
         if(MathAbs(price-srLevel)<=tolerance) srHit=true;
        }

      bool momentumOk=m5Aligned; // "momentum" component reuses the same M5 momentum check as m5Aligned

      int score=0;
      if(m15Aligned)                  score+=3;
      if(m5Aligned)                   score+=2;
      if(emaAligned)                  score+=1;
      if(fibHit)                      score+=1;
      if(srHit)                       score+=1;
      if(momentumOk)                  score+=1;
      if(atrAcceptable)               score+=1;
      if(t.state==THESIS_VALID)       score+=3; // "thesis validity"
      if(strongContinuationAgainst)   score-=3;
      if(m15Broken)                   score-=4;
      if(h1Reversed)                  score-=4;
      if(volAbnormal)                 score-=2;

      r.score=score;
      r.m15Aligned=m15Aligned; r.m5Aligned=m5Aligned; r.emaAligned=emaAligned;
      r.fibHit=fibHit; r.srHit=srHit; r.momentumOk=momentumOk; r.atrAcceptable=atrAcceptable;
      r.thesisValid=(t.state==THESIS_VALID);
      r.strongContinuationAgainst=strongContinuationAgainst;
      r.m15Broken=m15Broken; r.h1Reversed=h1Reversed; r.volAbnormal=volAbnormal;

      // section 13 — M5 trigger is ONE component of quality, not an
      // absolute gate: a high-quality retracement (thesis valid, H1/M15
      // still aligned, price at a real confluence level) may still recover
      // without a perfect M5 trigger, provided the score clears the bar.
      int threshold=InpMinRecoveryScore;

      // section 12/34 — regime-adaptive: continuation needs materially more
      // evidence than a plain retracement, and abnormal volatility raises
      // the bar further rather than being scored away by one -2.
      if(r.adverseClass==ADVERSE_CONTINUATION) threshold+=2;
      if(volAbnormal)                          threshold+=2;

      // section 12/14 — never aggressively stack layers deep into a range/
      // sideways regime; layers 4+ are "rare/emergency only".
      if(regime==REGIME_RANGE && targetLayer>=4) threshold=999; // effectively blocked

      r.passed=(score>=threshold);
      if(!r.passed)
        {
         r.reason=StringFormat("score %d < threshold %d (class=%s regime=%s)",
                    score,threshold,
                    (r.adverseClass==ADVERSE_CONTINUATION?"CONTINUATION":"RETRACEMENT"),
                    EnumToString(regime));
        }
      else
        {
         r.reason=StringFormat("score %d >= threshold %d",score,threshold);
        }
      return r;
     }
  };

#endif // __DTE_RECOVERYENGINE_MQH__
