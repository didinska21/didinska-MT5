//+------------------------------------------------------------------+
//|                                         GoldHedgeRecovery.mq5     |
//|                    Didinska Trading Engine (DTE) v4.0.0           |
//|                                                                     |
//|   MAJOR VERSION — controlled strategy-engine redesign on top of    |
//|   v3.3.4. v3.3.3/v3.3.4 were audited as insufficiently profitable  |
//|   (PF 1.02 over a 2-year XAUUSD M5 backtest) despite a healthy     |
//|   69% win rate and a genuinely low-risk execution architecture     |
//|   (max equity DD 5.84%, max basket risk 2.25%, zero margin calls). |
//|   The diagnosis was NOT "the EA can't trade" — it was negative     |
//|   expectancy from bad trade-lifecycle management: an excessively   |
//|   restrictive entry filter (Confluence pass=123 / reject=139,333)  |
//|   and, above all, THESIS_INVALID losses averaging ~$19.89 against  |
//|   wins averaging ~$5.80.                                           |
//|                                                                     |
//|   v4.0.0 adds an explicit trade-thesis object with a 3-state        |
//|   machine (VALID/WEAKENING/INVALID, Strategy/ThesisEngine.mqh), a  |
//|   3-way adverse-move classifier (RETRACEMENT/CONTINUATION/         |
//|   REVERSAL), a scored (not binary) recovery engine (Recovery/      |
//|   RecoveryEngine.mqh), a less-restrictive 12-point entry score      |
//|   (Strategy/SignalEngine.mqh) that scores M15/EMA/BOS/CHOCH/fib/SR |
//|   instead of gating on them, a 6-way market-regime classifier      |
//|   (Strategy/RegimeEngine.mqh), and full loss-anatomy +expectancy   |
//|   reporting (Recovery/LossAnatomy.mqh, Recovery/                   |
//|   ExpectancyEngine.mqh) broken down by direction/session/regime/   |
//|   layer/exit-reason/thesis-state — "optimize for expectancy, not   |
//|   win rate" (section 46).                                          |
//|                                                                     |
//|   PRESERVED, UNCHANGED: max 6 layers, max 0.03 lot/layer, non-      |
//|   martingale capacity-based lot sizing (Core/LotSizing.mqh), the    |
//|   verified close-safety and orphan-recovery state machines, and    |
//|   restart-safe GlobalVariable persistence.                          |
//|   TIGHTENED: basket-risk ceiling (was 15%/20% preferred/hard, now   |
//|   2.5%/4.0% — the old ceiling was diagnosed as practically           |
//|   unreachable at these lot sizes). NEW: an enforced account-level   |
//|   equity-drawdown circuit breaker (20% hard, 10% preferred-warn).   |
//|                                                                     |
//|   RESEARCH / TEST BUILD. NOT claimed profitable. Only the           |
//|   controlled backtest (TEST A, Docs/TEST_PLAN.md) can establish     |
//|   that. See Docs/CHANGELOG.md for the full section-by-section       |
//|   mapping against the v4.0.0 specification.                         |
//+------------------------------------------------------------------+
#property copyright "Didinska — private use only"
#property version   "4.00"
#property strict

#include "Config\Inputs.mqh"
#include "Core\Utils.mqh"
#include "Core\Logger.mqh"
#include "Core\AccountValidator.mqh"
#include "Core\SessionManager.mqh"
#include "Core\SpreadFilter.mqh"
#include "Core\NewsFilter.mqh"
#include "Core\RiskEngine.mqh"
#include "Core\LotSizing.mqh"
#include "Core\TradeEngine.mqh"
#include "Core\DealInfo.mqh"
#include "Core\PositionManager.mqh"
#include "Core\Dashboard.mqh"
#include "Strategy\StructureEngine.mqh"
#include "Strategy\TrendEngine.mqh"
#include "Strategy\RegimeEngine.mqh"
#include "Strategy\SignalEngine.mqh"
#include "Strategy\ThesisEngine.mqh"
#include "Recovery\RecoveryEngine.mqh"
#include "Recovery\HedgeEngine.mqh"
#include "Recovery\LossAnatomy.mqh"
#include "Recovery\ExpectancyEngine.mqh"
#include "Indicators\ATRFilter.mqh"

CSessionManager    g_session;
CSpreadFilter      g_spread;
CATRFilter         g_atr;
CNewsFilter        g_news;
CTrendEngine       g_trend;
CRegimeEngine      g_regime;
CSignalEngine      g_signal;
CThesisEngine      g_thesisEngine;
CRecoveryEngine    g_recovery;
CHedgeEngine       g_hedge;
CRiskEngine        g_risk;
CTradeEngine       g_tradeEngine;
CPositionManager   g_posMgr;
CDashboard         g_dashboard;
CLossAnatomy       g_lossAnatomy;
CExpectancyEngine  g_expectancy;
SForensicCounters  g_fc;

string g_symbol;
string g_lastEntryReason="";
string g_lastCloseReason="";
string g_resetStatusMessage="";

#define DTE_RESET_BTN_NAME "DTE_ResetCycleBtn"
bool     g_resetArmed=false;
datetime g_resetArmedUntil=0;

//+------------------------------------------------------------------+
int OnInit()
  {
   g_symbol=_Symbol;

   if(!CAccountValidator::ValidateAccountType())
      return(INIT_FAILED);

   // section 42 — validate, don't optimize.
   if(InpMaxLayers<=0 || InpMaxLayers>6)
     { CLogger::Error("OnInit","InpMaxLayers must be between 1 and hard cap 6"); return(INIT_PARAMETERS_INCORRECT); }
   if(InpMaxLotPerLayer<=0.0 || InpMaxLotPerLayer>0.03)
     { CLogger::Error("OnInit","InpMaxLotPerLayer must be > 0 and <= hard cap 0.03"); return(INIT_PARAMETERS_INCORRECT); }
   if(InpHedgeMaxLot>0.01)
     { CLogger::Error("OnInit","InpHedgeMaxLot must be <= 0.01"); return(INIT_PARAMETERS_INCORRECT); }
   if(InpMaxBasketRiskPercent<=0.0 || InpMaxBasketRiskPercent>InpHardBasketRiskPercent || InpHardBasketRiskPercent>20.0)
     { CLogger::Error("OnInit","Basket risk settings invalid: preferred <= hard <= 20%"); return(INIT_PARAMETERS_INCORRECT); }
   if(InpMaxEquityDrawdownPercent<=0.0 || InpMaxEquityDrawdownPercent>50.0)
     { CLogger::Error("OnInit","InpMaxEquityDrawdownPercent out of sane range 0-50"); return(INIT_PARAMETERS_INCORRECT); }
   if(InpMaxLotPerLayer<InpBaseLot)
     { CLogger::Error("OnInit","InpMaxLotPerLayer must be >= InpBaseLot"); return(INIT_PARAMETERS_INCORRECT); }
   double brokerMinLot=SymbolInfoDouble(g_symbol,SYMBOL_VOLUME_MIN);
   if(InpMaxLotPerLayer<brokerMinLot)
     {
      CLogger::Error("OnInit",StringFormat("InpMaxLotPerLayer=%.2f is below broker minimum %.2f for %s",
         InpMaxLotPerLayer,brokerMinLot,g_symbol));
      return(INIT_PARAMETERS_INCORRECT);
     }
   if(InpBasketTpPercent<=0.0 || InpBasketTpPercent>=5.0)
     { CLogger::Error("OnInit","InpBasketTpPercent must be > 0 and remain scalping-sized (<5%)"); return(INIT_PARAMETERS_INCORRECT); }
   if(InpMaxBasketHoldMinutes<=0)
     { CLogger::Error("OnInit","InpMaxBasketHoldMinutes must be > 0"); return(INIT_PARAMETERS_INCORRECT); }
   if(InpTargetEnable && InpProfitTargetMultiplier<=1.0)
     { CLogger::Error("OnInit","InpProfitTargetMultiplier must be > 1.0"); return(INIT_PARAMETERS_INCORRECT); }
   if(InpTfBias==InpTfStruct || InpTfStruct==InpTfTrigger || InpTfBias==InpTfTrigger)
     { CLogger::Error("OnInit","InpTfBias/InpTfStruct/InpTfTrigger must all be different timeframes"); return(INIT_PARAMETERS_INCORRECT); }
   if(InpMinEntryScore<0 || InpMinEntryScore>12)
     { CLogger::Error("OnInit","InpMinEntryScore must be within [0,12]"); return(INIT_PARAMETERS_INCORRECT); }
   if(InpMaxHedgesPerBasket<0)
     { CLogger::Error("OnInit","InpMaxHedgesPerBasket must be >= 0"); return(INIT_PARAMETERS_INCORRECT); }

   ZeroMemory(g_fc);
   g_lossAnatomy.Init();
   g_expectancy.Init();

   g_spread.Init(g_symbol);
   g_news.Init(g_symbol);

   if(!g_atr.Init(g_symbol,InpAtrPeriod,InpTfTrigger)) // v4.0.0 fix — explicit M5, not PERIOD_CURRENT
     { CLogger::Error("OnInit","ATR filter init failed"); return(INIT_FAILED); }

   if(!g_trend.Init(g_symbol))
     { CLogger::Error("OnInit","TrendEngine init failed — check H1 data availability"); return(INIT_FAILED); }
   if(!g_regime.Init(g_symbol,GetPointer(g_trend)))
     { CLogger::Error("OnInit","RegimeEngine init failed"); return(INIT_FAILED); }
   if(!g_signal.Init(g_symbol,GetPointer(g_trend),GetPointer(g_regime)))
     { CLogger::Error("OnInit","SignalEngine init failed — check M5 data availability"); return(INIT_FAILED); }
   if(!g_thesisEngine.Init(g_symbol,GetPointer(g_trend),GetPointer(g_regime),GetPointer(g_signal)))
     { CLogger::Error("OnInit","ThesisEngine init failed"); return(INIT_FAILED); }
   if(!g_recovery.Init(g_symbol,GetPointer(g_trend),GetPointer(g_regime),GetPointer(g_signal),GetPointer(g_thesisEngine)))
     { CLogger::Error("OnInit","RecoveryEngine init failed"); return(INIT_FAILED); }
   g_hedge.Init(g_regime.Structure());

   g_risk.Init(g_symbol,GetPointer(g_fc));

   if(!g_tradeEngine.Init(g_symbol,InpMagicNumber))
     { CLogger::Error("OnInit","TradeEngine init failed"); return(INIT_FAILED); }

   if(!g_posMgr.Init(g_symbol,InpMagicNumber,GetPointer(g_tradeEngine),GetPointer(g_trend),GetPointer(g_regime),
                     GetPointer(g_signal),GetPointer(g_thesisEngine),GetPointer(g_recovery),GetPointer(g_hedge),
                     GetPointer(g_news),GetPointer(g_lossAnatomy),GetPointer(g_expectancy),GetPointer(g_fc)))
     { CLogger::Error("OnInit","PositionManager init failed (layer ATR handle)"); return(INIT_FAILED); }

   CreateResetButton();

   CLogger::Info("OnInit",StringFormat(
      "DTE v%s Build %s initialized on %s (H1->M15->M5, controlled redesign vs v3.3.4)",
      DTE_VERSION,DTE_BUILD,g_symbol));

   return(INIT_SUCCEEDED);
  }

//+------------------------------------------------------------------+
void CreateResetButton()
  {
   if(ObjectFind(0,DTE_RESET_BTN_NAME)>=0) ObjectDelete(0,DTE_RESET_BTN_NAME);
   ObjectCreate(0,DTE_RESET_BTN_NAME,OBJ_BUTTON,0,0,0);
   ObjectSetInteger(0,DTE_RESET_BTN_NAME,OBJPROP_CORNER,CORNER_LEFT_UPPER);
   ObjectSetInteger(0,DTE_RESET_BTN_NAME,OBJPROP_XDISTANCE,10);
   ObjectSetInteger(0,DTE_RESET_BTN_NAME,OBJPROP_YDISTANCE,10);
   ObjectSetInteger(0,DTE_RESET_BTN_NAME,OBJPROP_XSIZE,190);
   ObjectSetInteger(0,DTE_RESET_BTN_NAME,OBJPROP_YSIZE,26);
   ObjectSetString(0,DTE_RESET_BTN_NAME,OBJPROP_TEXT,"RESET PROFIT/RISK CYCLE");
   ObjectSetInteger(0,DTE_RESET_BTN_NAME,OBJPROP_COLOR,clrWhite);
   ObjectSetInteger(0,DTE_RESET_BTN_NAME,OBJPROP_BGCOLOR,clrDarkSlateGray);
   ObjectSetInteger(0,DTE_RESET_BTN_NAME,OBJPROP_BORDER_COLOR,clrBlack);
   ObjectSetInteger(0,DTE_RESET_BTN_NAME,OBJPROP_STATE,false);
   ObjectSetInteger(0,DTE_RESET_BTN_NAME,OBJPROP_HIDDEN,true);
   ObjectSetInteger(0,DTE_RESET_BTN_NAME,OBJPROP_SELECTABLE,false);
   ChartRedraw(0);
  }

//+------------------------------------------------------------------+
void OnDeinit(const int reason)
  {
   CLogger::BuildForensicSummary(g_fc);
   g_lossAnatomy.Print();
   g_expectancy.Print();
   g_trend.Release();
   g_regime.Release();
   g_signal.Release();
   g_thesisEngine.Release();
   g_recovery.Release();
   g_atr.Release();
   ObjectDelete(0,DTE_RESET_BTN_NAME);
   Comment("");
  }

//+------------------------------------------------------------------+
void OnTick()
  {
   g_risk.EvaluateHalts();

   bool sessionOk = g_session.IsTradingAllowed();
   ENUM_SESSION_NAME session = g_session.CurrentSession();
   bool spreadOk  = g_spread.IsOkForNewEntry();
   bool atrOk     = g_atr.IsWithinRange();
   bool newsLock  = g_news.Evaluate();

   g_posMgr.ManageProtection(); // orphan-recovery retries every tick

   bool halted=g_risk.IsHalted();
   g_posMgr.SyncHaltState(halted);

   bool wasActive=g_posMgr.IsBasketActive();
   if(wasActive)
     {
      g_posMgr.TryAddRecoveryLayer(session,halted);
      g_posMgr.ManageHedge(session,halted);
      g_posMgr.UpdateAndCheckTp(); // never gated by halted — must still reach TP/spike/close-verify
     }
   if(wasActive && !g_posMgr.IsBasketActive())
     {
      g_signal.SuppressCurrentBar();
      g_lastCloseReason="basket closed (see Experts log for reason)";
     }

   SBasketState bs=g_posMgr.GetBasketState();
   g_risk.RecordDrawdownStats(GetPointer(g_fc),bs.basketFloatingProfit,bs.layersOpen,
                               (bs.basketFloatingProfit<0.0?bs.basketFloatingProfit:0.0));

   if(!g_risk.IsHalted() && !g_posMgr.IsBasketActive())
     {
      SEntryScore entry;
      bool triggered=g_signal.CheckTrigger(entry);
      if(triggered)
        {
         if(!sessionOk)             g_fc.entriesSkippedSession++;
         else if(!spreadOk)         g_fc.entriesSkippedSpread++;
         else if(!atrOk)            { /* covered by entry score gate too */ }
         else if(newsLock)          g_fc.entriesSkippedNews++;
         else
           {
            g_posMgr.StartBasket(entry.direction,entry,session);
            g_lastEntryReason=StringFormat(
               "score=%d/12 h1=%s m15=%s ema=%s bos=%s choch=%s fib50=%s fib618=%s sr=%s regime=%s",
               entry.score,(entry.h1Aligned?"Y":"N"),(entry.m15Aligned?"Y":"N"),(entry.emaAligned?"Y":"N"),
               (entry.bosHit?"Y":"N"),(entry.chochHit?"Y":"N"),(entry.fib50Hit?"Y":"N"),
               (entry.fib618Hit?"Y":"N"),(entry.srHit?"Y":"N"),CLogger::RegimeStr(entry.regime));
           }
         if(entry.passed) g_fc.entryScorePassCount++; else g_fc.entryScoreRejectCount++;
        }
     }

   RenderDashboard(sessionOk,spreadOk,atrOk,newsLock,session);
  }

//+------------------------------------------------------------------+
void RenderDashboard(const bool sessionOk,const bool spreadOk,const bool atrOk,
                      const bool newsLock,const ENUM_SESSION_NAME session)
  {
   SDiagnosticSnapshot snap;
   ZeroMemory(snap);

   snap.h1Bias       = g_trend.GetBias();
   snap.m15Structure = (g_regime.Structure()!=NULL)?g_regime.Structure().Analyze(InpTfStruct).state:STRUCT_UNKNOWN;
   snap.m5Signal      = CYCLE_NONE;
   snap.regime        = g_regime.Classify();

   snap.basket = g_posMgr.GetBasketState();

   snap.haltActive = g_risk.IsHalted();
   snap.haltCause  = g_risk.HaltCause();
   snap.sessionStartBalance = g_risk.CycleBaseline();
   snap.currentEquity = AccountInfoDouble(ACCOUNT_EQUITY);
   snap.profitTargetProgressPct = g_risk.ProfitTargetProgressPct();

   snap.sessionOk = sessionOk;
   snap.spreadOk  = spreadOk;
   snap.atrOk     = atrOk;
   snap.marginOk  = (AccountInfoDouble(ACCOUNT_MARGIN_LEVEL)<=0.0 ||
                      AccountInfoDouble(ACCOUNT_MARGIN_LEVEL)>=InpMinFreeMarginPercent);
   snap.newsLockActive = newsLock;
   snap.currentSession = session;
   snap.lastEntryReason = g_lastEntryReason;
   snap.lastCloseReason = g_lastCloseReason;
   snap.currentDrawdownPct = g_risk.CurrentDrawdownPct();

   snap.profitCycleId          = g_risk.CycleId();
   snap.profitCycleBaseline    = g_risk.CycleBaseline();
   snap.profitCycleTargetBalance = g_risk.TargetBalance();
   snap.currentBalance         = AccountInfoDouble(ACCOUNT_BALANCE);
   snap.resetStatusMessage     = g_resetStatusMessage;

   SBasketState curBasket=snap.basket;
   double previewLot=0.0;
   if(curBasket.active) previewLot=curBasket.selectedBaseLot;
   else
     {
      string previewReason;
      CLotSizing::CalculateAdaptiveBaseLot(g_symbol,CYCLE_BUY,InpMaxLayers,previewLot,previewReason);
     }
   snap.adaptiveLotLastSelected = previewLot;
   snap.adaptiveMarginCapacityPct = InpMaxBasketMarginPercent;
   snap.adaptiveEstSixLayerExposureLots = CLotSizing::EstimateFullBasketExposureLots(previewLot,InpMaxLayers);
   snap.pendingOrphanCount = g_posMgr.PendingOrphanCount();

   g_dashboard.Render(snap);
  }

//+------------------------------------------------------------------+
// section 23 — manual reset via dashboard button, two-stage arm/confirm.
//+------------------------------------------------------------------+
void OnChartEvent(const int id,const long &lparam,const double &dparam,const string &sparam)
  {
   if(id!=CHARTEVENT_OBJECT_CLICK) return;
   if(sparam!=DTE_RESET_BTN_NAME) return;

   ObjectSetInteger(0,DTE_RESET_BTN_NAME,OBJPROP_STATE,false);
   datetime now=TimeCurrent();

   if(!g_resetArmed || now>g_resetArmedUntil)
     {
      g_resetArmed=true;
      g_resetArmedUntil=now+InpResetConfirmSeconds;
      ObjectSetString(0,DTE_RESET_BTN_NAME,OBJPROP_TEXT,"CONFIRM RESET?");
      ObjectSetInteger(0,DTE_RESET_BTN_NAME,OBJPROP_BGCOLOR,clrDarkOrange);
      g_resetStatusMessage=StringFormat("Reset armed — click again within %d seconds to confirm.",InpResetConfirmSeconds);
      CLogger::Info("ResetButton",g_resetStatusMessage);
      ChartRedraw(0);
      return;
     }

   g_resetArmed=false;
   string msg;
   bool ok=g_risk.RequestManualReset(g_posMgr.IsBasketActive(),msg);
   g_resetStatusMessage=msg;

   ObjectSetString(0,DTE_RESET_BTN_NAME,OBJPROP_TEXT,"RESET PROFIT/RISK CYCLE");
   ObjectSetInteger(0,DTE_RESET_BTN_NAME,OBJPROP_BGCOLOR,(ok?clrDarkSlateGray:clrFireBrick));
   ChartRedraw(0);
  }

//+------------------------------------------------------------------+
void OnTradeTransaction(const MqlTradeTransaction &trans,
                        const MqlTradeRequest &request,
                        const MqlTradeResult &result)
  {
   // Reserved hook — basket lifecycle is handled by CPositionManager
   // polling ticket state each tick (single-basket-at-a-time model).
  }
//+------------------------------------------------------------------+
