//+------------------------------------------------------------------+
//| DiagnosticEngine.mqh — CDiagnosticEngine                          |
//| v3.3.0: decoupled forensic/diagnostic hub. No engine-class        |
//| includes other than Inputs.mqh (DTOs) and Logger.mqh (print-only).|
//| Adds structured per-basket-event logging (section 27) on top of   |
//| the existing SForensicCounters accumulation pattern.              |
//+------------------------------------------------------------------+
#ifndef __DTE_DIAGNOSTICENGINE_MQH__
#define __DTE_DIAGNOSTICENGINE_MQH__

#include "..\Config\Inputs.mqh"
#include "Logger.mqh"

class CDiagnosticEngine
  {
private:
   SForensicCounters m_counters;

   void UpdateMin(long &minVal,const long v) { if(minVal==0 || v<minVal) minVal=v; }
   void UpdateMax(long &maxVal,const long v) { if(v>maxVal) maxVal=v; }
   void UpdateMaxD(double &maxVal,const double v) { if(v>maxVal) maxVal=v; }

public:
   void Init()
     {
      ZeroMemory(m_counters);
     }

   //--- basket lifecycle -------------------------------------------------
   void OnBasketOpened(const ENUM_CYCLE_DIRECTION dir)
     {
      m_counters.basketsOpened++;
      if(dir==CYCLE_BUY)  m_counters.cycleDirectionBuy++;
      if(dir==CYCLE_SELL) m_counters.cycleDirectionSell++;
     }

   void OnBasketClosed(const ENUM_BASKET_CLOSE_REASON reason,const int layers,const long holdSeconds)
     {
      switch(reason)
        {
         case CLOSE_TP:              m_counters.basketsClosedByTp++; break;
         case CLOSE_SPIKE_EXIT:       m_counters.basketsClosedBySpike++; break;
         case CLOSE_MARGIN_CALL_EXT:  m_counters.basketsClosedByMarginCall++; break;
         case CLOSE_HEDGE_EXIT:       m_counters.basketsClosedByHedgeExit++; break;
         default: break;
        }

      UpdateMin(m_counters.layersPerBasketMin,(long)layers);
      UpdateMax(m_counters.layersPerBasketMax,(long)layers);
      m_counters.layersPerBasketSum += layers;

      UpdateMin(m_counters.basketHoldSecondsMin,holdSeconds);
      UpdateMax(m_counters.basketHoldSecondsMax,holdSeconds);
      m_counters.basketHoldSecondsSum += holdSeconds;

      UpdateMax(m_counters.longestRecoverySeconds,holdSeconds);
     }

   //--- confluence ---------------------------------------------------------
   void OnConfluencePass()   { m_counters.confluencePassCount++; }
   void OnConfluenceReject() { m_counters.confluenceRejectCount++; }

   //--- skip reasons ---------------------------------------------------------
   void OnLayerSkippedMargin()            { m_counters.layersSkippedMargin++; }
   void OnEntrySkippedSpread()            { m_counters.entriesSkippedSpread++; }
   void OnEntrySkippedSession()           { m_counters.entriesSkippedSession++; }
   void OnEntrySkippedNews()              { m_counters.entriesSkippedNews++; }
   void OnEntrySkippedDuplicateSignal()   { m_counters.entriesSkippedDuplicateSignal++; }
   void OnEntrySkippedInvalidThesis()     { m_counters.entriesSkippedInvalidThesis++; }

   //--- hedge ---------------------------------------------------------
   void OnRecoveryAccepted() { m_counters.recoveryAccepted++; }
   void OnRecoveryRejected() { m_counters.recoveryRejected++; }
   void OnThesisInvalidation() { m_counters.thesisInvalidations++; }
   void OnMaxHoldExit() { m_counters.maxHoldExits++; }
   void OnRecoveryTimeoutExit() { m_counters.recoveryTimeoutExits++; }
   void OnBasketRiskRejected() { m_counters.basketRiskRejected++; }
   void RecordBasketRisk(const double riskPct)
     { UpdateMaxD(m_counters.maxBasketRiskPct,riskPct); }
   void OnMarketClosed() { m_counters.marketClosedEvents++; }
   void OnHedgeRejected() { m_counters.hedgeRejected++; }
   void OnHedgeCooldownRejected() { m_counters.hedgeCooldownRejected++; }
   void OnHedgeOpened() { m_counters.hedgeEventsOpened++; }
   void OnHedgeClosed() { m_counters.hedgeEventsClosed++; }

   //--- target / close-safety ---------------------------------------------------------
   void OnProfitTargetHalt()   { m_counters.profitTargetHaltEvents++; }
   void OnCloseVerifyRetry()   { m_counters.closeVerifyRetries++; }
   void OnCloseVerifyFailure() { m_counters.closeVerifyFailures++; }

   //--- statistics (section 25) ---------------------------------------------------------
   void RecordDrawdownSample(const double equityDdPct,const double balanceDdPct,
                              const double floatingLoss,const double basketLoss,
                              const int layerCount,const double marginUsagePct)
     {
      UpdateMaxD(m_counters.maxEquityDrawdownPct,equityDdPct);
      UpdateMaxD(m_counters.maxBalanceDrawdownPct,balanceDdPct);
      if(floatingLoss<0) UpdateMaxD(m_counters.maxFloatingLoss,-floatingLoss);
      if(basketLoss<0)   UpdateMaxD(m_counters.maxBasketLoss,-basketLoss);
      UpdateMax(m_counters.maxLayerCountSeen,(long)layerCount);
      UpdateMaxD(m_counters.maxMarginUsagePct,marginUsagePct);
     }

   const SForensicCounters GetCounters() const { return m_counters; }

   void PrintSummary() const
     {
      CLogger::BuildForensicSummary(m_counters);
     }

   //--- structured per-event logging (section 27) — every basket traceable ----
   static void LogRecoveryDecision(const ulong basketId,const bool accepted,
                                   const int layer,const double movedPoints,
                                   const double distancePoints,const int score,
                                   const string reason)
     {
      PrintFormat("[DTE][BASKET %I64u][RECOVERY]%s layer#=%d moved=%.1f threshold=%.1f score=%d reason=\"%s\"",
                  basketId,(accepted?" ACCEPT":"[REJECT]"),layer,movedPoints,
                  distancePoints,score,reason);
     }

   static void LogThesisInvalid(const ulong basketId,const string reason)
     {
      PrintFormat("[DTE][BASKET %I64u][THESIS_INVALID] reason=\"%s\"",basketId,reason);
     }

   static void LogRiskReject(const ulong basketId,const double projectedRisk,
                             const double preferred,const double hard,const string reason)
     {
      PrintFormat("[DTE][BASKET %I64u][RISK] projected=%.2f%% preferred=%.2f%% hard=%.2f%% reason=\"%s\"",
                  basketId,projectedRisk,preferred,hard,reason);
     }

   static void LogEntry(const ulong basketId,const ENUM_CYCLE_DIRECTION dir,
                         const string reason,const SConfluenceResult &conf,
                         const int layerNumber,const double layerPrice,const double lot,
                         const double atr,const double spreadPoints,const double marginLevel,
                         const ENUM_SESSION_NAME session)
     {
      PrintFormat("[DTE][BASKET %I64u][ENTRY] dir=%s layer#=%d price=%.5f lot=%.2f "
                  "reason=\"%s\" score=%d h1Bias=%d m15Struct=%d fib=%s qm=%s ema=%s "
                  "atr=%.5f spread=%.1f marginLevel=%.1f session=%d m5Trigger=%s regime=%d",
                  basketId,(dir==CYCLE_BUY?"BUY":"SELL"),layerNumber,layerPrice,lot,reason,
                  conf.score,(int)conf.h1Bias,(int)conf.m15Structure,
                  (conf.fibHit?"Y":"N"),(conf.qmHit?"Y":"N"),(conf.emaHit?"Y":"N"),
                  atr,spreadPoints,marginLevel,(int)session,
                  (conf.m5Trigger?"Y":"N"),(int)conf.regime);
     }

   static void LogClose(const ulong basketId,const ENUM_BASKET_CLOSE_REASON reason,
                         const int layers,const double netProfit,const long holdSeconds)
     {
      string reasonStr="UNKNOWN";
      switch(reason)
        {
         case CLOSE_TP:              reasonStr="BASKET_TP"; break;
         case CLOSE_SPIKE_EXIT:       reasonStr="SPIKE_EXIT"; break;
         case CLOSE_MARGIN_CALL_EXT:  reasonStr="MARGIN_CALL_OR_EXTERNAL"; break;
         case CLOSE_HEDGE_EXIT:       reasonStr="HEDGE_EXIT"; break;
         case CLOSE_MAX_HOLD:         reasonStr="MAX_HOLD_EXIT"; break;
         case CLOSE_RECOVERY_TIMEOUT: reasonStr="RECOVERY_TIMEOUT"; break;
         case CLOSE_THESIS_INVALID:   reasonStr="THESIS_INVALID"; break;
         case CLOSE_RISK_LIMIT:        reasonStr="RISK_LIMIT"; break;
         default: break;
        }
      PrintFormat("[DTE][BASKET %I64u][CLOSE] reason=%s layers=%d netProfit=%.2f holdSec=%d",
                  basketId,reasonStr,layers,netProfit,(int)holdSeconds);
     }

   static void LogHedgeEvent(const ulong basketId,const bool opened,const ENUM_HEDGE_STATE state,
                              const string reason)
     {
      PrintFormat("[DTE][BASKET %I64u][HEDGE] %s state=%d reason=\"%s\"",
                  basketId,(opened?"OPENED":"CLOSED"),(int)state,reason);
     }

   static void LogNewsLock(const bool active,const string eventName,const datetime eventTime)
     {
      PrintFormat("[DTE][NEWS] lock=%s event=\"%s\" time=%s",
                  (active?"ACTIVE":"CLEARED"),eventName,TimeToString(eventTime));
     }
  };

#endif // __DTE_DIAGNOSTICENGINE_MQH__
