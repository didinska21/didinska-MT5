//+------------------------------------------------------------------+
//| Logger.mqh — CLogger, named event logging                        |
//+------------------------------------------------------------------+
#ifndef __DTE_LOGGER_MQH__
#define __DTE_LOGGER_MQH__

#include "..\Config\Inputs.mqh"

class CLogger
  {
public:
   static void Info(const string tag,const string msg)
     {
      PrintFormat("[DTE][%s] %s",tag,msg);
     }

   static void Warn(const string tag,const string msg)
     {
      PrintFormat("[DTE][WARN][%s] %s",tag,msg);
     }

   static void Error(const string tag,const string msg)
     {
      PrintFormat("[DTE][ERROR][%s] %s",tag,msg);
     }

   static void Halt(const ENUM_HALT_CAUSE cause,const string reason)
     {
      PrintFormat("[DTE][HALT] cause=%s reason=%s",HaltCauseToString(cause),reason);
     }

   static string HaltCauseToString(const ENUM_HALT_CAUSE cause)
     {
      switch(cause)
        {
         case HALT_PROFIT_TARGET: return "PROFIT_TARGET_900PCT";
         case HALT_ACCOUNT_TYPE:  return "NETTING_ACCOUNT_UNSUPPORTED";
         default: return "NONE";
        }
     }

   // Printed once at OnDeinit, same always-visible style as before.
   static void BuildForensicSummary(const SForensicCounters &c)
     {
      Print("================ DTE v3.3.2 FORENSIC SUMMARY ================");
      PrintFormat("Baskets: opened=%d tp=%d spike=%d marginCall=%d hedgeExit=%d",
                  c.basketsOpened,c.basketsClosedByTp,c.basketsClosedBySpike,
                  c.basketsClosedByMarginCall,c.basketsClosedByHedgeExit);

      double avgLayers = c.basketsOpened>0 ? (double)c.layersPerBasketSum/c.basketsOpened : 0.0;
      PrintFormat("Layers/basket  : min=%d max=%d avg=%.2f",
                  c.layersPerBasketMin,c.layersPerBasketMax,avgLayers);

      double avgHold = c.basketsOpened>0 ? (double)c.basketHoldSecondsSum/c.basketsOpened : 0.0;
      PrintFormat("Hold time(sec) : min=%d max=%d avg=%.1f longestRecovery=%d",
                  c.basketHoldSecondsMin,c.basketHoldSecondsMax,avgHold,c.longestRecoverySeconds);

      PrintFormat("Cycle direction: buy=%d sell=%d",c.cycleDirectionBuy,c.cycleDirectionSell);
      PrintFormat("Confluence     : pass=%d reject=%d",c.confluencePassCount,c.confluenceRejectCount);
      PrintFormat("Entries skipped: margin=%d spread=%d session=%d news=%d dupSignal=%d invalidThesis=%d",
                  c.layersSkippedMargin,c.entriesSkippedSpread,c.entriesSkippedSession,
                  c.entriesSkippedNews,c.entriesSkippedDuplicateSignal,c.entriesSkippedInvalidThesis);
      PrintFormat("Recovery       : accepted=%d rejected=%d thesisInvalid=%d maxHold=%d timeout=%d riskReject=%d",
                  c.recoveryAccepted,c.recoveryRejected,c.thesisInvalidations,
                  c.maxHoldExits,c.recoveryTimeoutExits,c.basketRiskRejected);
      PrintFormat("Hedge events   : opened=%d closed=%d rejected=%d cooldownReject=%d",
                  c.hedgeEventsOpened,c.hedgeEventsClosed,c.hedgeRejected,c.hedgeCooldownRejected);
      PrintFormat("Market closed  : %d",c.marketClosedEvents);
      PrintFormat("Profit-target halts: %d",c.profitTargetHaltEvents);
      PrintFormat("Close-verify   : retries=%d failures=%d",c.closeVerifyRetries,c.closeVerifyFailures);
      PrintFormat("Stats (audit)  : maxEquityDD=%.2f%% maxBalanceDD=%.2f%% maxFloatingLoss=%.2f "
                  "maxBasketLoss=%.2f maxBasketRisk=%.2f%% maxLayers=%d maxMarginUsage=%.2f%%",
                  c.maxEquityDrawdownPct,c.maxBalanceDrawdownPct,c.maxFloatingLoss,
                  c.maxBasketLoss,c.maxBasketRiskPct,c.maxLayerCountSeen,c.maxMarginUsagePct);
      Print("=============================================================");
     }
  };

#endif // __DTE_LOGGER_MQH__
