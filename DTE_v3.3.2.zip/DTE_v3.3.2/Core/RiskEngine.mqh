//+------------------------------------------------------------------+
//| RiskEngine.mqh — CRiskEngine                                      |
//| v3.3.0: no hard drawdown/daily-loss stop (research build); 900%   |
//|         profit-target halt, persisted across restart.             |
//| v3.2.0: profit target is now a full CYCLE lifecycle, not just a    |
//|         one-shot halt:                                             |
//|           ACTIVE -> target reached -> HALTED -> manual reset ->    |
//|           new baseline -> ACTIVE (new cycle ID)                    |
//|         Baseline, halted flag, AND cycle ID all persist across      |
//|         restart. Only RequestManualReset() (an intentional,        |
//|         explicit call from the UI layer) can ever clear HALTED —    |
//|         never a restart/recompile/timeframe/symbol change/         |
//|         reconnect (section 8). Reset is refused while a basket is  |
//|         active, to avoid corrupting basket accounting (section 8). |
//|         Still uses the SAME persistence namespace (account+symbol+ |
//|         magic+state version) — no second persistence architecture.|
//+------------------------------------------------------------------+
#ifndef __DTE_RISKENGINE_MQH__
#define __DTE_RISKENGINE_MQH__

#include "..\Config\Inputs.mqh"
#include "Logger.mqh"
#include "DiagnosticEngine.mqh"

class CRiskEngine
  {
private:
   string   m_symbol;
   string   m_gvPrefix;
   double   m_cycleBaseline;   // persisted, never reset by restart — only by RequestManualReset()
   ulong    m_cycleId;         // persisted, increments on every manual reset
   double   m_peakBalance;     // for balance-drawdown stat (not persisted — informational only)
   double   m_peakEquity;      // for equity-drawdown stat (not persisted — informational only)
   bool     m_halted;
   ENUM_HALT_CAUSE m_haltCause;
   CDiagnosticEngine *m_diag;  // not owned

   string GvKey(const string suffix) const { return m_gvPrefix+"_TARGET_"+suffix; }

public:
   CRiskEngine() : m_cycleBaseline(0.0), m_cycleId(0), m_peakBalance(0.0), m_peakEquity(0.0),
                   m_halted(false), m_haltCause(HALT_NONE), m_diag(NULL) {}

   void Init(const string symbol,CDiagnosticEngine *diag)
     {
      m_symbol=symbol;
      m_diag=diag;

      long login=AccountInfoInteger(ACCOUNT_LOGIN);
      m_gvPrefix=StringFormat("DTE_%I64d_%s_%d_v%d",login,symbol,(int)InpMagicNumber,DTE_STATE_VERSION);

      // Cycle baseline + ID persistence: only set ONCE, on genuine first-ever
      // run for this account+symbol+magic. A restart must NOT touch this —
      // only RequestManualReset() may (section 3/8).
      if(GlobalVariableCheck(GvKey("baseline")))
        {
         m_cycleBaseline=GlobalVariableGet(GvKey("baseline"));
         m_cycleId = GlobalVariableCheck(GvKey("cycleId")) ? (ulong)(long)GlobalVariableGet(GvKey("cycleId")) : 1;
        }
      else
        {
         m_cycleBaseline=AccountInfoDouble(ACCOUNT_BALANCE);
         m_cycleId=1;
         GlobalVariableSet(GvKey("baseline"),m_cycleBaseline);
         GlobalVariableSet(GvKey("cycleId"),(double)m_cycleId);
        }

      m_peakBalance=AccountInfoDouble(ACCOUNT_BALANCE);
      m_peakEquity =AccountInfoDouble(ACCOUNT_EQUITY);

      if(GlobalVariableCheck(GvKey("halted")) && GlobalVariableGet(GvKey("halted"))>0.5)
        {
         m_halted=true;
         m_haltCause=HALT_PROFIT_TARGET;
         CLogger::Warn("RiskEngine",StringFormat(
            "Restored HALTED state from previous session (cycle #%I64u, target reached). "
            "Manual reset required to resume — see dashboard.",m_cycleId));
        }

      CLogger::Info("RiskEngine",StringFormat(
         "Profit cycle #%I64u baseline=%.2f (persisted, survives restart). Target at %.1fx (+%.0f%%).",
         m_cycleId,m_cycleBaseline,InpProfitTargetMultiplier,(InpProfitTargetMultiplier-1.0)*100.0));
     }

   bool IsHalted() const              { return m_halted; }
   ENUM_HALT_CAUSE HaltCause() const  { return m_haltCause; }
   double CycleBaseline() const       { return m_cycleBaseline; }
   ulong  CycleId() const             { return m_cycleId; }

   double TargetBalance() const
     {
      return m_cycleBaseline*InpProfitTargetMultiplier;
     }

   // v3.3.0 PATCH 4: progress is now 0-100% of the CYCLE range
   // (baseline -> target), not equity/target. Previously showed non-zero
   // progress immediately at the baseline (e.g. baseline=$10, target=$100,
   // equity=$10 showed 10% instead of the correct 0%). Displayed value
   // only — the actual halt trigger (equity>=target, in EvaluateHalts())
   // is unchanged.
   double ProfitTargetProgressPct() const
     {
      double target=TargetBalance();
      double range=target-m_cycleBaseline;
      if(range<=0.0) return 0.0;

      double equity=AccountInfoDouble(ACCOUNT_EQUITY);
      double progress=((equity-m_cycleBaseline)/range)*100.0;

      if(progress<0.0)   progress=0.0;
      if(progress>100.0) progress=100.0;
      return progress;
     }

   // Call every tick.
   void EvaluateHalts()
     {
      if(!InpTargetEnable) return;
      if(m_halted) return;

      double equity=AccountInfoDouble(ACCOUNT_EQUITY);
      double target=TargetBalance();
      if(m_cycleBaseline>0.0 && equity>=target)
        {
         m_halted=true;
         m_haltCause=HALT_PROFIT_TARGET;
         GlobalVariableSet(GvKey("halted"),1.0);
         if(m_diag!=NULL) m_diag.OnProfitTargetHalt();

         CLogger::Halt(m_haltCause,StringFormat(
            "cycle #%I64u equity=%.2f reached target=%.2f (%.1fx baseline=%.2f)",
            m_cycleId,equity,target,InpProfitTargetMultiplier,m_cycleBaseline));
         Print("================================================");
         Print("DTE v3.3.2 PROFIT TARGET REACHED");
         PrintFormat("Target: +%.0f%%",(InpProfitTargetMultiplier-1.0)*100.0);
         PrintFormat("Baseline: $%.2f",m_cycleBaseline);
         PrintFormat("Current Balance: $%.2f",AccountInfoDouble(ACCOUNT_BALANCE));
         Print("Status: HALTED");
         Print("Manual reset required.");
         Print("================================================");
        }
     }

   //=====================================================================
   // v3.2.0 — manual reset (section 6-8). Caller (composition root / UI
   // layer) is responsible for actually confirming user intent (e.g. a
   // two-stage dashboard button) BEFORE calling this — this method itself
   // still refuses if a basket is active, as a second line of defense
   // against corrupting basket accounting.
   //=====================================================================
   bool RequestManualReset(const bool basketActive,string &resultMsg)
     {
      if(basketActive)
        {
         resultMsg="RESET DENIED — ACTIVE BASKET EXISTS";
         CLogger::Warn("RiskEngine",resultMsg);
         return false;
        }

      ulong previousCycle=m_cycleId;
      double previousBaseline=m_cycleBaseline;
      double currentBalance=AccountInfoDouble(ACCOUNT_BALANCE);

      m_cycleId=previousCycle+1;
      m_cycleBaseline=currentBalance;
      m_halted=false;
      m_haltCause=HALT_NONE;

      GlobalVariableSet(GvKey("baseline"),m_cycleBaseline);
      GlobalVariableSet(GvKey("cycleId"),(double)m_cycleId);
      GlobalVariableSet(GvKey("halted"),0.0);

      resultMsg=StringFormat("Cycle #%I64u -> #%I64u, new baseline $%.2f",
                              previousCycle,m_cycleId,m_cycleBaseline);

      Print("================================================");
      Print("DTE v3.3.2 PROFIT TARGET RESET");
      PrintFormat("Previous cycle: #%I64u",previousCycle);
      PrintFormat("Previous baseline: $%.2f",previousBaseline);
      PrintFormat("Current balance: $%.2f",currentBalance);
      PrintFormat("New cycle: #%I64u",m_cycleId);
      PrintFormat("New baseline: $%.2f",m_cycleBaseline);
      Print("Status: ACTIVE");
      Print("================================================");

      return true;
     }

   // Statistics only (section 25 of v3.3.0) — no forced action taken from this.
   void RecordDrawdownStats(CDiagnosticEngine *diag,const double basketFloating,
                             const int layerCount,const double basketLossIfNegative)
     {
      if(!InpRecordDrawdownStats || diag==NULL) return;

      double balance=AccountInfoDouble(ACCOUNT_BALANCE);
      double equity =AccountInfoDouble(ACCOUNT_EQUITY);
      if(balance>m_peakBalance) m_peakBalance=balance;
      if(equity>m_peakEquity)   m_peakEquity=equity;

      double balanceDdPct = m_peakBalance>0.0 ? ((m_peakBalance-balance)/m_peakBalance)*100.0 : 0.0;
      double equityDdPct  = m_peakEquity>0.0  ? ((m_peakEquity-equity)/m_peakEquity)*100.0 : 0.0;

      double marginUsed=AccountInfoDouble(ACCOUNT_MARGIN);
      double marginUsagePct = (equity>0.0) ? (marginUsed/equity)*100.0 : 0.0;

      diag.RecordDrawdownSample(equityDdPct,balanceDdPct,basketFloating,
                                  basketLossIfNegative,layerCount,marginUsagePct);
     }
  };

#endif // __DTE_RISKENGINE_MQH__
