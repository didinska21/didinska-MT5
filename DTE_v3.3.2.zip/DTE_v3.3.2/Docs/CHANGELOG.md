# DTE v3.3.2

## Execution-safety patch (no strategy redesign)
Final execution-safety patch before baseline backtesting. Fixes the two
remaining defects from the v3.3.1 source audit: hedge partial-close
tracking and orphan-position protection. No new indicators, no strategy-
philosophy changes. All strategy defaults (max layers, max lot, risk
ceilings, hold/timeout minutes, hedge limits, market-closed cooldown, 900%
target) are unchanged from v3.3.1.

### Files changed
| File | Change |
|---|---|
| `Config/Inputs.mqh` | `DTE_VERSION`→`3.3.2`, `DTE_BUILD`→`003`. Added `ENUM_HEDGE_CLOSE_STATE` (`HEDGE_CLOSE_NONE`/`HEDGE_CLOSE_PARTIAL`) and three new `SBasketState` fields (`hedgeCloseState`, `hedgeRemainingVolume`, `hedgeCloseRetryTime`) for issue #1. Added `BSTATE_ORPHAN_RECOVERY` to `ENUM_BASKET_STATE` (appended at the end — no collision with persisted older values) for issue #2. Added input group "Execution Safety (v3.3.2)": `InpHedgeCloseRetrySeconds` (default 5s), `InpOrphanCloseRetrySeconds` (default 10s). Added `pendingOrphanCount` to `SDiagnosticSnapshot` (dashboard visibility only). |
| `Core/PositionManager.mqh` | Issue #1: replaced the inline close-and-clear hedge logic with `AttemptHedgeClose()`/`FinalizeHedgeClosed()` — never clears `hedgeActive`/`hedgeTicket` from `ClosePositionByTicket()`'s return value alone; always re-selects the position and checks real remaining volume, retrying on a cooldown until confirmed zero. `ManageHedge()` checks for an in-progress `HEDGE_CLOSE_PARTIAL` before evaluating open/close at all. Issue #2: replaced the one-shot `AttemptOrphanClose()` with `SOrphanRecord`/`RegisterOrphan()`/`ProcessOrphanRecovery()` — a tracked, cooldown-retried orphan-recovery list, driven every tick from the existing `ManageProtection()` hook, that is never dropped until the position is attached or verified closed. `HasPendingOrphans()` blocks new basket/recovery/hedge risk at all three call sites. `IsTicketTracked()` extended to also exclude orphan-claimed tickets. Persistence for the three new hedge-close fields uses the same `GlobalVariableCheck(...)`-guarded-default pattern as existing backward-compatible fields — `DTE_STATE_VERSION` unchanged. |
| `Core/TradeEngine.mqh` | Added `m_lastCloseRetcode` + `LastCloseRetcode()` getter so callers can log the real MT5 retcode on a partial/failed close without re-deriving it. |
| `Core/Logger.mqh` | Forensic summary header → `DTE v3.3.2 FORENSIC SUMMARY`. |
| `Core/RiskEngine.mqh` | Runtime print labels (`PROFIT TARGET REACHED` / `PROFIT TARGET RESET`) updated to `DTE v3.3.2` — no logic change. |
| `Core/Dashboard.mqh` | Added a `Hedge close: PARTIAL — remaining X.XX lots, retrying` line and an `>>> ORPHAN RECOVERY IN PROGRESS (N) <<<` banner — visibility only, no strategy logic. |
| `GoldHedgeRecovery.mq5` | Header comment, `#property version` (`3.32`), and `OnInit` log line updated to v3.3.2. Wired `snap.pendingOrphanCount` into the dashboard snapshot. |
| `Docs/README.md`, `Docs/CHANGELOG.md`, `Docs/V3.3.2_IMPLEMENTATION_NOTES.md` (new) | Documentation for this release. |

### Issue #1 — partial hedge close tracking (fixed)
`ManageHedge()`'s close branch treated `TRADE_RETCODE_DONE_PARTIAL` (or any
non-exception return from `ClosePositionByTicket()`) as "hedge fully
closed" and immediately cleared `hedgeActive`/`hedgeTicket`. DONE_PARTIAL
means only part of the requested volume closed — the hedge could still
have open volume, now completely untracked. Fixed via a verified
close-state machine (`HEDGE_CLOSE_NONE` → `HEDGE_CLOSE_PARTIAL` →
finalized only on a re-selected, confirmed-zero-volume position). See
`Docs/V3.3.2_IMPLEMENTATION_NOTES.md` for full detail.

### Issue #2 — orphan position protection (fixed)
The v3.3.1 `AttemptOrphanClose()` was a single best-effort close attempt
with no result tracked afterward — a failed close meant the position (if
it existed) was silently abandoned and normal operation, including
opening a brand-new basket, resumed as if nothing had happened. Fixed via
a tracked, cooldown-retried orphan-recovery list (`m_orphans[]`) that
blocks new basket/recovery/hedge risk until every entry is either attached
to normal tracking or verified fully closed. See
`Docs/V3.3.2_IMPLEMENTATION_NOTES.md` for full detail, including the
disclosed in-memory-only (non-restart-persisted) scope limitation.

---

# DTE v3.3.1

## Defect-fix patch (no strategy redesign)
Fixes six verified defects found in the v3.3.0 audit. No new indicators, no
new trading concepts, no strategy-philosophy changes. Defaults (max layers,
max lot, risk ceilings, hold/timeout minutes, hedge limits, market-closed
cooldown, 900% target) are unchanged from v3.3.0.

### Files changed
| File | Change |
|---|---|
| `Config/Inputs.mqh` | `DTE_VERSION`→`3.3.1`, `DTE_BUILD`→`002`. Added the missing `m5Trigger` (bool) and `regime` (`ENUM_MARKET_REGIME`) members to `SConfluenceResult` — referenced by `ConfluenceEngine`/`PositionManager`/`DiagnosticEngine` in v3.3.0 but never declared (compile blocker). |
| `Core/PositionManager.mqh` | P1: fixed undefined identifier `dir` in `TryAddRecoveryLayer()`'s risk projection call → `m_basket.direction`. P3: added `ProjectedNetRiskPct()` (single coherent adverse-price scenario across basket+hedge, signed net P/L) and switched `ManageHedge()`'s accept/reject check to it. P4: reordered `UpdateAndCheckTp()` so `CheckSpikeExit()` is evaluated before the ordinary basket-TP check. P5: added `ResolveExecutedTicket()` (bounded retry rescan) and `AttemptOrphanClose()` (symbol+magic+comment-scoped safe close), wired into the three post-order ticket-resolution sites (layer 1, recovery layer, hedge open). |
| `Core/ConfluenceEngine.mqh` | P2: `ValidateRecoveryThesis()` no longer accepts `m15Directional \|\| freshM5`. When `InpRequireM5Trigger` is enabled (default), a fresh M5 trigger in the exact basket direction is now a hard requirement for every recovery layer; rejection is logged as `[DTE][RECOVERY][REJECT]`. |
| `Core/TradeEngine.mqh` | P6: `OpenMarket()`/`ClosePositionByTicket()` now explicitly check `ResultRetcode()` against `TRADE_RETCODE_DONE`/`TRADE_RETCODE_DONE_PARTIAL` (not just the boolean return), log `[DTE][EXECUTION][FAIL]` with the actual retcode on failure, and warn on partial fills via `ResultVolume()`. Existing `TRADE_RETCODE_MARKET_CLOSED` cooldown behavior (P7) is unchanged. |
| `Core/Logger.mqh` | Forensic summary header → `DTE v3.3.1 FORENSIC SUMMARY`. |
| `Core/RiskEngine.mqh` | Runtime print labels (`PROFIT TARGET REACHED` / `PROFIT TARGET RESET`) updated to `DTE v3.3.1` for consistency — no logic change. |
| `GoldHedgeRecovery.mq5` | Header comment, `#property version`, and `OnInit` log line updated to v3.3.1. |

### P1 — Compile blocker (fixed)
`TryAddRecoveryLayer()` referenced an identifier `dir` that does not exist
in that function's scope (its parameters are `session` and `riskHalted`).
Replaced with `m_basket.direction`, the basket's own locked-in direction —
consistent with every other use of direction inside this function. Also
found and fixed during the required project-wide undefined-reference sweep:
`SConfluenceResult` was missing the `m5Trigger` and `regime` members that
`CConfluenceEngine::Evaluate()` assigns and that `PositionManager`/
`DiagnosticEngine` read — also a compile blocker, now resolved by adding
both fields to the struct.

### P2 — Recovery M5 gate (fixed)
`ValidateRecoveryThesis()`'s final acceptance test is now
`h1Support && m15Directional && m5Ok && scoreOk`, where `m5Ok` requires a
fresh M5 trigger in the basket's exact direction whenever
`InpRequireM5Trigger` is true (the default) — M15 structural alignment can
no longer substitute for a missing M5 confirmation. Rejections log
`[DTE][RECOVERY][REJECT]` with the specific reason.

### P3 — Hedge net-exposure risk model (fixed)
Hedge accept/reject now uses `ProjectedNetRiskPct()`, which applies ONE
coherent adverse price scenario (against the basket's own direction) to
every basket layer, any already-open hedge, and the candidate new hedge,
and sums their SIGNED P/L. An opposing-direction hedge position now
correctly offsets basket loss in that single scenario instead of being
added as independent risk (the v3.3.0 bug: basket and candidate hedge were
each evaluated against their OWN, mutually contradictory, adverse
direction, so a hedge could never appear to reduce risk). Hedge is
accepted only when `riskAfter < riskBefore`; rejection logs
`[DTE][HEDGE][REJECT] reason="hedge does not reduce net risk"`. Hedge
stacking rules (max 1 active, lot capped at `InpHedgeMaxLot`=0.01, 60-minute
cooldown) are unchanged.

### P4 — Spike-exit priority (fixed)
`UpdateAndCheckTp()` now checks `CheckSpikeExit()` before the ordinary
`floating>=basketTpTarget` check. In v3.3.0, TP defaulted to 0.20% of
cycle-start balance while spike-exit's profitability floor
(`InpSpikeExitMinPercent`) defaulted to 0.25% — a HIGHER bar — and ran
second, so ordinary TP almost always closed the basket first, making
`CLOSE_SPIKE_EXIT` effectively unreachable. Spike-detection logic itself
(`CheckSpikeExit()`) is unchanged — a genuine fast favorable move is still
required, so trivial small-profit ticks still cannot trigger it.

### P5 — Orphan-position protection (fixed)
Added `ResolveExecutedTicket()` — retries the existing symbol+magic+comment
rescan (`FallbackFindUntrackedTicket()`) up to 3 additional times with a
short delay when the ticket wasn't immediately resolvable via
`ResultDeal()`. If still unresolved after retries, `AttemptOrphanClose()`
scans open positions restricted to this EA's own symbol+magic+comment
identity and attempts a safe close, logging
`[DTE][EXECUTION][ORPHAN_PROTECTION]` with symbol/direction/volume/magic/
reason either way. Wired into all three post-order sites: initial layer,
recovery layer, and hedge open. Never touches a position outside this
exact identity match.

### P6 — Trade execution verification (fixed)
`CTrade::Buy()`/`Sell()`/`PositionClose()` returning `true` is no longer
treated as sufficient confirmation on its own. Both `OpenMarket()` and
`ClosePositionByTicket()` now check `ResultRetcode()` against
`TRADE_RETCODE_DONE`/`TRADE_RETCODE_DONE_PARTIAL` explicitly, log
`[DTE][EXECUTION][FAIL]` with the real retcode/description on any failure
path, and warn (via `ResultVolume()`) on partial fills/closes. The existing
`TRADE_RETCODE_MARKET_CLOSED` cooldown handling (P7 requirement) is fully
preserved and checked first.

### P11 — State-machine safety (verified, unchanged)
Reviewed all `THESIS_INVALIDATED` / `HALTED` / `CLOSING` transition guards
per the audit checklist — all were already correctly enforced in v3.3.0
(`TryAddRecoveryLayer()` and `ManageHedge()` both bail out on
`m_closePending`/`riskHalted`/thesis-invalidated state before any new
order; new-basket entry is gated by `!g_risk.IsHalted() &&
!g_posMgr.IsBasketActive()` in `OnTick()`). No changes required.

### Known limitations carried forward
Same scope disclosures as v3.3.0: `CStructureEngine` is a simplified
fractal-swing heuristic, not a full SMC implementation; commission
accounting is best-effort (entry-side only pre-close); the news filter
depends on the broker/terminal's Economic Calendar population. This
remains a research/test build — not claimed profitable, not claimed
live-ready, no backtest results are claimed by this patch.

---

# DTE v3.3.0

## Architecture redesign
- Recovery requires fresh directional confirmation; price distance only arms evaluation.
- Added explicit basket state and thesis-invalidation handling.
- Added equity-damage risk projection for new layers and a hard 20% basket risk ceiling.
- Added 12-hour default maximum basket hold and independent recovery timeout.
- Basket TP default changed to 0.20% of basket-start balance.
- Hedge limited to one active 0.01-lot hedge, with 60-minute cooldown and projected-risk-reduction check.
- Added market-closed cooldown handling for retcode 10018.
- Added recovery/risk/hold/thesis/hedge/market-closed forensic counters.
- Corrected forensic label to DTE v3.3.0.

## Validation note
This package was source-reviewed and statically sanity-checked. MetaEditor is not available in the build environment, so compile success is not claimed until compiled in MT5/MetaEditor.

# Changelog — Didinska Trading Engine (DTE)

## v3.2.1 — Critical Audit Patch: Halt Gate, Flat Lot Integrity, Dashboard Accuracy

**Strict patch release.** No strategy redesign, no new indicators, no changes
to H1→M15→M5 architecture, confluence system, BOS/CHOCH, Fibonacci, QM
heuristic, ATR layer distance, hedge strategy, news filter, spread filter,
session logic, basket TP, spike exit, persistence architecture, account
validation, or close-verification. Only the four issues below were fixed.

### Files changed

| File | Change |
|---|---|
| `Core/PositionManager.mqh` | `TryAddRecoveryLayer()` and `ManageHedge()` now take a `riskHalted` parameter (defensive second gate). `TryAddRecoveryLayer()` returns immediately if halted — no new recovery layer, ever, once the profit target is reached. `ManageHedge()` blocks only the **open-new-hedge** branch when halted; the **close-existing-hedge** branch is unconditional, so an already-open hedge can still be closed while halted. Recovery-layer lot check now calls `CLotSizing::GetAffordableLot(..., exact=true)` — the flat `selectedBaseLot` is validated exactly, never downgraded; if it doesn't fit, the layer is skipped and the basket stays alive. |
| `Core/LotSizing.mqh` | `GetAffordableLot()` gains an `exact` parameter, default `false` (zero behavior change for every existing caller, including the hedge lot). When `exact=true`, only the normalized desired lot itself is margin-checked — no downward search to a smaller lot. |
| `Core/Dashboard.mqh` | Basket "Volume" line now computed as `layersOpen * selectedBaseLot` (the basket's actual flat lot) instead of `layersOpen * InpBaseLot` (a fixed input that ignores which adaptive tier — 0.01/0.02/0.03 — was actually selected). Now also prints the per-layer lot alongside total volume so it can't silently contradict the "Adaptive Lot" block. |
| `Core/RiskEngine.mqh` | `ProfitTargetProgressPct()` rewritten from `equity/target*100` to `(equity-baseline)/(target-baseline)*100`, clamped to 0–100%. Previously showed non-zero progress immediately at the baseline (e.g. baseline=$10, target=$100, equity=$10 showed 10% instead of the correct 0%). **Display only** — the actual halt trigger in `EvaluateHalts()` (`equity >= targetBalance`) is unchanged. |
| `GoldHedgeRecovery.mq5` | `OnTick()` now computes `halted=g_risk.IsHalted()` once per tick and passes it into `TryAddRecoveryLayer()`/`ManageHedge()`. The new-basket gate (`!g_risk.IsHalted() && !g_posMgr.IsBasketActive()`) was already correct in v3.2.0 and required no change. `UpdateAndCheckTp()` remains unconditional — an active basket must still be able to reach TP, trigger spike-exit, and go through close-verification regardless of halt state. |
| `Config/Inputs.mqh` | `DTE_VERSION` → `3.2.1`, `DTE_BUILD` → `007`. `DTE_STATE_VERSION` unchanged (2) — no persisted-layout change in this patch. |

### Patch 1 — Halt gate (explicit)
Once `CRiskEngine::IsHalted()` is true (the +900% profit-cycle target has
been reached), the EA now guarantees:
- No new basket (`StartBasket()` — already gated correctly in v3.2.0).
- No new recovery layer (`TryAddRecoveryLayer()` — new hard return added).
- No new hedge (`ManageHedge()`'s open-branch — new guard added).

What still runs while halted, unchanged:
- `UpdateAndCheckTp()` — basket TP, spike-exit, margin-call reconciliation,
  close-verification retries.
- `ManageHedge()`'s close-branch — an already-open hedge can still be closed
  when the opposing structure that justified it fades, even while halted.
  Blocking this too would have meant "halted" silently stopped protecting
  an open hedge position, which contradicts "existing positions may still
  be safely managed."

### Patch 2 — Flat lot integrity (explicit)
`m_basket.selectedBaseLot` (chosen once by `CalculateAdaptiveBaseLot()` at
`StartBasket()`) is now genuinely locked for the basket's lifetime. Every
recovery layer requests that **exact** lot via `GetAffordableLot(...,
exact=true)`; if the account can no longer safely support that exact size,
the layer is skipped (`layersSkippedMargin` counter, logged) rather than
opened at a smaller size. A basket's lots are now always
`0.01×N` or `0.02×N` or `0.03×N` — never a mix within one basket. The hedge
lot (`InpHedgeLot`) is unaffected — it was not part of the flat-lot
requirement and continues to use the existing downward-search behavior.

### Patch 3 — Dashboard volume accuracy (explicit)
The dashboard's "Volume" figure now matches the "Adaptive Lot" figure by
construction (both read from `selectedBaseLot`), instead of the two being
computed from different, sometimes-contradictory sources.

### Patch 4 — Profit-cycle progress (explicit)
Progress is now a true 0–100% read of "how far through this cycle's
baseline→target range are we", not "what fraction of the target does
current equity represent" (which was never 0% at the start of a cycle).

### Regression confirmation
No changes were made to: H1→M15→M5 signal architecture, confluence scoring
(structure/Fib/QM/EMA), BOS/CHOCH detection, ATR-based layer spacing,
hedge decision logic (only *when it may open* is gated by halt — the
decision logic itself, `CHedgeEngine::Evaluate()`, is untouched), news
filter, spread filter, session logic, basket TP trigger condition, spike
exit, persistence architecture/versioning, account validation, or the
close-safety/verification mechanism.

---

## v3.2.0 — Profit Target Lifecycle + Adaptive Lot Sizing

**Targeted update only.** No strategy redesign — H1→M15→M5, confluence
scoring, sequential ATR-spaced layering, hedge state machine, sessions,
news filter, spread filter, position tracking, and diagnostics from v3.1.0
are all unchanged. Only the profit-target lifecycle and the base lot
selection changed.

### Files changed

| File | Change |
|---|---|
| `Config/Inputs.mqh` | `DTE_STATE_VERSION` bumped 1→2 (persisted layout now includes a cycle ID). New inputs: `InpAdaptiveLotStep`, `InpMaxBasketMarginPercent`, `InpResetConfirmSeconds`. `SBasketState.selectedBaseLot` added (flat lot locked in per basket). `SDiagnosticSnapshot` extended with profit-cycle and adaptive-lot dashboard fields. |
| `Core/RiskEngine.mqh` | Rewritten around a **profit cycle** instead of a one-shot halt: `m_cycleBaseline` + `m_cycleId`, both persisted; `RequestManualReset()` is the only way to clear `HALTED` — refuses if a basket is active. Renamed `SessionStartBalance()`→`CycleBaseline()`; added `CycleId()`, `TargetBalance()`. |
| `Core/LotSizing.mqh` | `GetAffordableLot()` now takes an explicit `desiredLot` parameter (was hardcoded to `InpBaseLot`) so the same lot can be reused flat across layers. New `CalculateAdaptiveBaseLot()` — the centralized, non-martingale capacity model (section 10-19). New `EstimateFullBasketExposureLots()` helper for dashboard/audit display. |
| `Core/PositionManager.mqh` | `StartBasket()` now calls `CalculateAdaptiveBaseLot()` instead of using `InpBaseLot` directly, stores the result in `m_basket.selectedBaseLot`, and logs the `DTE ADAPTIVE LOT` audit block. `TryAddRecoveryLayer()` reuses `m_basket.selectedBaseLot` (flat across all layers, section 20 — unchanged progression logic otherwise). Hedge lot call adapted to the new `GetAffordableLot()` signature (passes `InpHedgeLot` as the desired lot directly). |
| `Core/Dashboard.mqh` | Added a `PROFIT CYCLE` block (baseline, target %, target balance, current balance, progress, status, cycle ID, reset status message) and an `Adaptive Lot` block (selected lot, max lot, margin capacity %, estimated 6-layer exposure). |
| `GoldHedgeRecovery.mq5` | Adds a chart button `RESET PROFIT TARGET` (`OBJ_BUTTON`) with two-stage arm/confirm handling in `OnChartEvent()` — first click arms (button relabels `CONFIRM RESET?`), second click within `InpResetConfirmSeconds` calls `CRiskEngine::RequestManualReset()`. Dashboard snapshot wiring updated for the new fields. |

### Profit target — where things live
- **Baseline**: `CRiskEngine::m_cycleBaseline`, persisted at
  `GlobalVariable` key `..._TARGET_baseline`. Set once on first-ever run;
  changed ONLY by `RequestManualReset()`.
- **Halted state**: `..._TARGET_halted` (0/1). Set the instant equity
  reaches the target; cleared ONLY by `RequestManualReset()`.
- **Cycle ID**: `..._TARGET_cycleId`. Increments by 1 on every successful
  manual reset; starts at 1 on first-ever run.
- **Reset**: UI layer (chart button, two-stage arm/confirm) → 
  `CRiskEngine::RequestManualReset(basketActive, msg)` → refuses with
  `"RESET DENIED — ACTIVE BASKET EXISTS"` if a basket is open; otherwise
  increments cycle ID, sets new baseline = current balance, clears halted,
  persists all three, logs the before/after summary, returns success.
- **Restart persistence**: unchanged mechanism from v3.1.0 — `CRiskEngine
  ::Init()` reads the existing GlobalVariables if present rather than
  reinitializing them, so EA/MT5/VPS restart, chart/timeframe change, and
  reconnection never touch cycle state. Only `RequestManualReset()` does.

### Adaptive lot — formula and parameters
For each candidate lot in `{InpMaxLotPerLayer, InpMaxLotPerLayer-
InpAdaptiveLotStep, ..., InpBaseLot}` (largest first, e.g. 0.03/0.02/0.01):
1. `marginPerLayer = OrderCalcMargin(candidate lot)` at current price.
2. `projectedFullBasketMargin = marginPerLayer * InpMaxLayers`.
3. `allowedBasketMargin = AccountEquity * InpMaxBasketMarginPercent / 100`.
4. Select the first (largest) candidate where
   `projectedFullBasketMargin <= allowedBasketMargin` **and** the
   immediate free-margin buffer check for a single layer also passes.
5. If no candidate qualifies, fall back to the broker-minimum lot
   (still single-layer-margin-checked) — never refuses the whole basket
   purely on the 6-layer projection; real-time per-layer checks remain the
   actual layer-count safety net (unchanged from v3.1.0).

Determined **only** from account capacity (equity, free margin, margin
level, broker volume constraints) — never from whether the previous layer
won or lost. Computed once per basket at `StartBasket()`, stored in
`SBasketState.selectedBaseLot`, and reused unchanged for every subsequent
layer — lots stay flat across a basket, no martingale-style progression.

### Section 25 disclosure
DTE v3.2.0 remains a **research/backtest build**. Not claimed profitable,
not claimed safe for live trading, not claimed proven, not claimed
guaranteed consistent, not claimed ready for the $10 live account.

---



**Major rewrite.** Replaces the v3.0.x "open up to 6 layers immediately"
basket-grid with a trend/structure-confluence system that layers
sequentially, adds a state-driven hedge, and adds several mandatory safety
mechanisms (netting-account guard, versioned persistence, safe-close
verification). This is a **research/test build** — not claimed profitable,
not claimed live-ready, strategy not claimed proven.

### Files changed

| File | Change |
|---|---|
| `Config/Inputs.mqh` | Full rewrite, grouped per section 29. New enums (`ENUM_MARKET_BIAS`, `ENUM_STRUCT_STATE`, `ENUM_HEDGE_STATE`, `ENUM_BASKET_CLOSE_REASON`, `ENUM_SESSION_NAME`) and DTOs (`SConfluenceResult`, extended `SBasketState`/`SDiagnosticSnapshot`/`SForensicCounters`). Legacy daily-loss/drawdown-halt inputs removed entirely (superseded by section 25/26 — no hard DD stop this version). |
| `Core/AccountValidator.mqh` | **New.** Hard-fails `OnInit()` on a NETTING account (section 3). |
| `Core/StructureEngine.mqh` | **New.** Simplified fractal-based swing/BOS/CHOCH detection + Fib 50/61.8 + a light Quasimodo-retest heuristic. **Scope-disclosed as simplified, not a full SMC library** — see the header comment in the file itself. |
| `Core/ConfluenceEngine.mqh` | **New.** H1 bias with strength (EMA-gap/ATR ratio), M15 structure via `CStructureEngine`, M5 confluence scoring (Fib/QM/EMA), configurable `InpMinConfluenceScore` threshold (section 5-8). |
| `Core/HedgeEngine.mqh` | **New.** State machine (`NORMAL/RECOVERY/REVERSAL_RISK/HEDGE/BASKET_EXIT`). Hedge is only recommended on a genuine opposing CHOCH/BOS, never merely because the basket is losing (section 13). |
| `Core/NewsFilter.mqh` | **New.** Uses the built-in MQL5 Economic Calendar API, filtered by the symbol's quote currency and configurable minimum importance. Blocks new entries during the lock window + a post-event stabilization window; never auto-closes existing baskets (section 22). |
| `Core/SpreadFilter.mqh` | **New** (was inline). Blocks new entries only; never closes an existing basket for spread (section 23). |
| `Core/SessionManager.mqh` | Rewritten: named Asia/London/NY sessions, independently configurable hours/enable (section 21). |
| `Core/LotSizing.mqh` | **New.** Dynamic lot affordability — searches from `InpBaseLot` down to broker minimum in step increments for the largest lot the account can safely support right now. Never assumes a fixed layer count is affordable (section 1/14). |
| `Core/SignalEngine.mqh` | Rewritten: chart-timeframe-independent H1→M15→M5 trigger, delegates scoring to `CConfluenceEngine`, `SuppressCurrentBar()` prevents same-bar re-trigger after a basket closes. |
| `Core/RiskEngine.mqh` | Rewritten: **no hard drawdown/daily-loss stop** in this version (sections 25/26 — stats only). The 900% profit-target halt is now **persisted** (baseline + halted flag survive terminal/EA/VPS restart) (section 20). Drawdown/margin-usage statistics recorded for audit. |
| `Core/PositionManager.mqh` | Major rewrite — see "Key behavioral changes" below. |
| `Core/TradeEngine.mqh` | `OpenMarket()` now takes an explicit comment (basket ID encoded) and still resolves the ticket via `ResultDeal()`. |
| `Core/DiagnosticEngine.mqh` | Extended counters (confluence pass/reject, skip reasons, hedge events, close-verify retries/failures, audit statistics). Added structured per-event logging: `LogEntry()`, `LogClose()`, `LogHedgeEvent()`, `LogNewsLock()` (section 27). |
| `Core/Dashboard.mqh` | Rewritten to show H1/M15/M5 state, session, all gates, basket detail incl. hedge state, drawdown, and target-halt progress (section 28). |
| `GoldHedgeRecovery.mq5` | Composition root rewired for all of the above. |
| `Indicators/TrendFilter.mqh` | **Removed** — superseded by `CConfluenceEngine`/`CStructureEngine`. |

### Key behavioral changes in `PositionManager.mqh` (the biggest change)

1. **Sequential layering (section 10/11):** `StartBasket()` now opens
   **layer 1 only**. `TryAddRecoveryLayer()`, called every tick, adds layer
   N+1 only once price has moved against the basket by
   `ATR(M5, InpAtrPeriodLayer) * InpLayerAtrMultiplier`, floored by
   `InpMinLayerDistancePoints` and by the broker's stop/freeze level and
   2x current spread. Layers are never opened at nearly the same price.
2. **Thesis invalidation (section 12):** before adding a layer, the
   original H1 bias / M15 structure is re-checked via
   `CConfluenceEngine::IsThesisValid()`. If the thesis has flipped
   (opposite strong bias or a CHOCH against the basket), the layer is
   skipped — logged as `entriesSkippedInvalidThesis` — instead of blindly
   averaging in.
3. **Hedge (section 13):** `ManageHedge()` opens a hedge only when
   `CHedgeEngine` reports `HEDGE_ACTIVE` (a genuine opposing CHOCH) with a
   structure score at/above `InpHedgeMinStructureScore`, and closes it once
   that opposing structure fades. No random alternation.
4. **Dynamic lot (section 14):** every layer/hedge lot goes through
   `CLotSizing::GetAffordableLot()` — if only one 0.01 lot is safely
   affordable, only one layer opens; `InpMaxLayers` is a **cap**, never a
   forced target.
5. **Net basket P/L + spike exit (section 15/16):** floating P/L now
   includes swap and a best-effort entry-side commission sum (exit
   commission isn't knowable pre-close — documented limitation). An
   optional spike-exit closes early on a fast favorable price move once the
   basket is already meaningfully profitable.
6. **CRITICAL close-safety (section 17):** `InitiateClose()` /
   `AttemptCloseRetry()` never finalize (never clear persisted state) until
   every tracked position (and the hedge, if any) is verified actually
   closed via `PositionSelectByTicket()`. If any remain, the basket state
   stays alive and closing retries next tick — logged via
   `closeVerifyRetries` / `closeVerifyFailures`.
7. **Robust tracking (section 18):** the order comment now encodes the
   basket ID (`InpTradeComment_<basketId>`); the fallback ticket lookup
   (used only if `ResultDeal()` doesn't resolve immediately) matches on
   symbol+magic+**exact comment**, so it can never pick up another EA's or
   another basket's position.
8. **Versioned persistence (section 19):** the GlobalVariable namespace is
   now `DTE_<accountLogin>_<symbol>_<magic>_v<DTE_STATE_VERSION>_...`, so
   two DTE instances (different accounts, symbols, or magic numbers) never
   collide. `DTE_STATE_VERSION` (in `Inputs.mqh`) should be bumped if the
   persisted-state layout ever changes incompatibly.

### Section 3 — netting account (explicit)
`CAccountValidator::ValidateAccountType()` runs first in `OnInit()`. On a
netting account it prints a clear log message, shows a clear `Comment()`
message on the chart, and returns `INIT_FAILED` — the EA does not attempt
to run in any degraded mode.

### Section 20 — 900% target persistence (explicit)
The target baseline balance is written to a `GlobalVariable` **once**, on
the very first run for that account+symbol+magic+version combination, and
is never rewritten by a restart. The halted flag is likewise persisted the
moment the target is hit, and restored on `OnInit()` — a restart while
halted stays halted, exactly as required (acceptance test 5).

### Known simplifications / scope disclosures (see final report for full list)
- `StructureEngine`'s BOS/CHOCH/QM detection is a practical fractal-swing
  heuristic, not a rigorous Smart-Money-Concepts implementation.
- Best-effort commission accounting only covers entry-side deals already
  in history; exit-side commission is unknown until a position actually
  closes.
- The news filter depends on the MQL5 Economic Calendar API being
  populated by the terminal/broker; behavior in the Strategy Tester depends
  on the tester's calendar emulation for the build in use.

---

## v3.0.1 — Bug-fix pass (self-audit findings)
See prior revision of this file (superseded scope). Ticket resolution via
`ResultDeal`, GlobalVariable basket persistence, partial stop-out tracking,
M5 re-trigger guard, slippage input, input validation.

## v3.0.0 — Basket/Layer Grid Rewrite
Replaced the v2.x single-position trend-follower with a fixed-size
(up to 6 layers, opened immediately) no-SL basket grid. Superseded by
v3.1.0's sequential/ATR-spaced layering — the "open all layers at once"
behavior was an explicit correction requested for v3.1 (section 10).

## v2.2 Alpha Build 002b (inherited baseline)
Diagnostic Engine + decoupled DTO architecture. Single-timeframe M15
EMA20/50 + 2-candle confirmation, graded 0–100 score, single position with
ATR-based SL/TP, break-even + trailing management, RiskEngine halts on 2%
daily loss / 10% drawdown.
