/**
 * Wrapper lengkap untuk Telegram Bot API — dipakai oleh bot interaktif (webhook).
 */

const API_BASE = (token) => `https://api.telegram.org/bot${token}`;

async function call(env, method, payload) {
  const res = await fetch(`${API_BASE(env.TELEGRAM_BOT_TOKEN)}/${method}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload),
  });

  if (!res.ok) {
    const errText = await res.text();
    throw new Error(`Telegram API error (${method}): ${res.status} - ${errText}`);
  }

  return res.json();
}

/** Kirim pesan teks biasa, bisa dengan inline keyboard opsional */
export async function sendMessage(env, chatId, text, replyMarkup = null) {
  const payload = {
    chat_id: chatId,
    text,
    parse_mode: "HTML",
    disable_web_page_preview: true,
  };
  if (replyMarkup) payload.reply_markup = replyMarkup;
  return call(env, "sendMessage", payload);
}

/**
 * Kirim foto. `photo` bisa berupa:
 * - string URL (Telegram yang fetch sendiri, paling simpel)
 * - bytes (ArrayBuffer/Uint8Array/Blob), di-upload manual lewat multipart —
 *   dipakai buat gambar chart yang kita generate sendiri (bukan dari URL publik).
 */
export async function sendPhoto(env, chatId, photo, caption = null) {
  if (typeof photo === "string") {
    const payload = { chat_id: chatId, photo };
    if (caption) {
      payload.caption = caption;
      payload.parse_mode = "HTML";
    }
    return call(env, "sendPhoto", payload);
  }

  const form = new FormData();
  form.append("chat_id", String(chatId));
  if (caption) {
    form.append("caption", caption);
    form.append("parse_mode", "HTML");
  }
  const blob = photo instanceof Blob ? photo : new Blob([photo], { type: "image/png" });
  form.append("photo", blob, "chart.png");

  const res = await fetch(`${API_BASE(env.TELEGRAM_BOT_TOKEN)}/sendPhoto`, {
    method: "POST",
    body: form,
  });

  if (!res.ok) {
    const errText = await res.text();
    throw new Error(`Telegram API error (sendPhoto): ${res.status} - ${errText}`);
  }

  return res.json();
}

/** Edit pesan yang sudah ada (dipakai saat user klik tombol menu) */
export async function editMessageText(env, chatId, messageId, text, replyMarkup = null) {
  const payload = {
    chat_id: chatId,
    message_id: messageId,
    text,
    parse_mode: "HTML",
    disable_web_page_preview: true,
  };
  if (replyMarkup) payload.reply_markup = replyMarkup;
  return call(env, "editMessageText", payload);
}

/**
 * Lumpuhkan (hapus) inline keyboard pada pesan lama TANPA perlu tahu/ubah
 * teksnya — dipakai saat sesi direset supaya tombol dari sesi sebelumnya
 * (misal "Analisa Sekarang (2 foto)" yang ditinggal begitu saja) tidak bisa
 * diklik lagi dan membingungkan user. Diam-diam abaikan kalau gagal (misal
 * pesannya sudah dihapus / terlalu lama) — bukan hal kritis.
 */
export async function editMessageReplyMarkup(env, chatId, messageId, replyMarkup = null) {
  try {
    return await call(env, "editMessageReplyMarkup", {
      chat_id: chatId,
      message_id: messageId,
      reply_markup: replyMarkup || { inline_keyboard: [] },
    });
  } catch (err) {
    return null;
  }
}

/** Wajib dipanggil setelah callback_query supaya tombol tidak "loading" terus di UI Telegram */
export async function answerCallbackQuery(env, callbackQueryId, text = "") {
  return call(env, "answerCallbackQuery", {
    callback_query_id: callbackQueryId,
    text,
  });
}

/** Daftarkan URL webhook Worker ke Telegram (dipanggil manual sekali via browser, bukan dari kode) */
export async function setWebhook(env, url) {
  return call(env, "setWebhook", { url });
}

/** Hapus pesan (dipakai untuk membersihkan pesan sementara) */
export async function deleteMessage(env, chatId, messageId) {
  try {
    return await call(env, "deleteMessage", { chat_id: chatId, message_id: messageId });
  } catch {
    // Kalau gagal hapus (misal pesan sudah terlalu lama), abaikan saja — tidak kritis.
    return null;
  }
}

/**
 * Hapus custom keyboard (ReplyKeyboardMarkup) lama yang mungkin masih nempel
 * di chat dari sesi/bot sebelumnya. Telegram mewajibkan ada teks saat mengirim
 * remove_keyboard, jadi kita kirim pesan singkat lalu langsung hapus lagi
 * supaya tidak mengotori riwayat chat.
 */
export async function clearOldReplyKeyboard(env, chatId) {
  const result = await sendMessage(env, chatId, "🔄", { remove_keyboard: true });
  const messageId = result?.result?.message_id;
  if (messageId) {
    await deleteMessage(env, chatId, messageId);
  }
}

/** Download 1 file (misal foto chart) dari Telegram, kembalikan sebagai ArrayBuffer */
export async function getFile(env, fileId) {
  const info = await call(env, "getFile", { file_id: fileId });
  const filePath = info.result.file_path;
  const fileUrl = `https://api.telegram.org/file/bot${env.TELEGRAM_BOT_TOKEN}/${filePath}`;

  const res = await fetch(fileUrl);
  if (!res.ok) {
    throw new Error(`Gagal download file dari Telegram: ${res.status}`);
  }
  return res.arrayBuffer();
}
