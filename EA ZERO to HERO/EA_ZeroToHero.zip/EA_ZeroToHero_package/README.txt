EA Zero to Hero — Paket File
=============================

Isi:
1. EA_ZeroToHero.mq5        -> source code Expert Advisor (MQL5, MetaTrader 5)
2. EA_Zero_to_Hero_Spec.md  -> dokumen spec teknis lengkap (hasil Q&A logika)

Cara pakai:
1. Copy EA_ZeroToHero.mq5 ke folder MQL5/Experts/ di data folder MetaTrader 5 kamu
   (File > Open Data Folder > MQL5 > Experts)
2. Buka MetaEditor, compile file ini (F7). Belum pernah dicompile di environment ini
   karena tidak ada compiler MetaEditor tersedia di sini — WAJIB dicompile & dicek
   error/warning dulu sebelum dipakai live atau demo.
3. Attach ke chart XAUUSD, pastikan:
   - Akun hedging type
   - InpMagicNumber unik, beda dari EA lain yang jalan di akun sama (misal DTE)
   - InpBrokerGMTOffset disesuaikan dengan offset broker kamu vs GMT
   - InpSessionStartHour/EndHour disesuaikan setelah tahu offset broker
4. WAJIB backtest & forward-test di akun demo dulu sebelum live, terutama untuk:
   - Validasi frekuensi entry per hari sesuai ekspektasi
   - Validasi margin cukup di modal $12 (0.01 lot XAUUSD, leverage 1:500)
   - Validasi filter sesi & fractal SNR sesuai candle broker kamu

Catatan penting:
- Equity floor (circuit breaker) begitu kena akan HALT TOTAL EA, cuma bisa direset
  manual lewat tombol "RESET HALT (Zero2Hero)" di pojok kiri atas chart, atau restart EA.
- Reset harian (profit lock $15) ditunda otomatis kalau masih ada posisi nyantol
  lewat tengah malam — EA baru reset counter setelah posisi itu closed (sesuai spec 6a).
- Fase balance: <$50 = single posisi, >=$50 = multi-layer independen (lihat spec bagian 3a).

Semua keputusan logika ada di EA_Zero_to_Hero_Spec.md — baca itu kalau lupa alasan
di balik satu parameter atau rule tertentu.
