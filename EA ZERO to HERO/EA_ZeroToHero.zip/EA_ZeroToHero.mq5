//+------------------------------------------------------------------+
//|                                            EA_ZeroToHero.mq5     |
//|  Strategi: H1 SNR (fractal) + M15 EMA20/50 arah + M5 trigger     |
//|  Tujuan: profit harian fix $15 lalu lock, equity floor 50%.      |
//|  Lihat EA_Zero_to_Hero_Spec.md untuk penjelasan lengkap logika.  |
//+------------------------------------------------------------------+
#property copyright "Didinska"
#property version   "1.00"
#property strict

//================== INPUTS ==================
input group "=== Strategi / Timeframe ==="
input int    InpFractalBars        = 5;      // periode fractal H1 SNR (5 = standar 2 kiri/2 kanan)
input int    InpEMA_Fast           = 20;     // EMA cepat M15
input int    InpEMA_Slow           = 50;     // EMA lambat M15
input int    InpATR_Period         = 14;     // ATR period (dihitung di H1)
input double InpZoneATRMult        = 1.0;    // toleransi "sentuh zona SNR" = ATR * mult (naik dari 0.5 -> 1.0 biar sinyal lebih sering)
input int    InpSNRLookbackBars    = 300;    // berapa bar H1 ke belakang dicari fractal

input group "=== Risk Management ==="
input double InpSL_ATR_Buffer      = 0.3;    // buffer SL tambahan = ATR * mult
input double InpRR_Ratio           = 2.0;    // TP = jarak SL * RR
input double InpMaxRiskUSD         = 2.0;    // batas rugi maksimal per trade (USD). Kalau jarak SL x lot > ini, entry di-skip
input double InpDailyProfitTarget  = 15.0;   // USD, target profit harian (gabungan semua layer)
input double InpEquityFloorPercent = 50.0;   // % dari balance awal hari, circuit breaker total

input group "=== Sesi Trading ==="
input int    InpSessionStartHour   = 7;      // GMT (broker time), full London open
input int    InpSessionEndHour     = 21;     // GMT (broker time), akhir sesi NY
input int    InpBrokerGMTOffset    = 0;      // offset jam server broker vs GMT, sesuaikan saat live

input group "=== Lot & Fase Balance ==="
input double InpMultiLayerBalance  = 50.0;   // >= ini baru boleh multi-layer independen
input double InpMarginBufferPct    = 20.0;   // % free margin ekstra wajib tersisa sebelum entry baru

input group "=== Lain-lain ==="
input ulong  InpMagicNumber        = 260820261; // WAJIB unik, beda dari EA lain (DTE dsb)
input string InpTradeComment       = "ZeroToHero";

//================== GLOBAL STATE ==================
double   g_dayStartBalance = 0.0;
datetime g_trackedDay      = 0;       // tanggal (dibulatkan ke hari) yang sedang di-track
bool     g_dailyLocked     = false;   // true = target $15 tercapai, entry dikunci sampai reset
string   g_haltGlobalVarName;         // nama global variable buat persist equity-floor halt
string   g_resetBtnName = "ZTH_ResetHaltBtn";

int      g_emaFastHandle, g_emaSlowHandle, g_atrHandle;

//+------------------------------------------------------------------+
int OnInit()
{
   g_haltGlobalVarName = StringFormat("ZTH_HALT_%I64u", InpMagicNumber);

   g_emaFastHandle = iMA(_Symbol, PERIOD_M15, InpEMA_Fast, 0, MODE_EMA, PRICE_CLOSE);
   g_emaSlowHandle = iMA(_Symbol, PERIOD_M15, InpEMA_Slow, 0, MODE_EMA, PRICE_CLOSE);
   g_atrHandle     = iATR(_Symbol, PERIOD_H1, InpATR_Period);

   if(g_emaFastHandle==INVALID_HANDLE || g_emaSlowHandle==INVALID_HANDLE || g_atrHandle==INVALID_HANDLE)
   {
      Print("EA_ZeroToHero: gagal buat indicator handle");
      return(INIT_FAILED);
   }

   // Inisialisasi day tracking dari state sekarang
   g_dayStartBalance = AccountInfoDouble(ACCOUNT_BALANCE);
   g_trackedDay = DateFloor(TimeCurrent());
   g_dailyLocked = false;

   CreateResetButton();

   Print("EA_ZeroToHero init OK. Magic=", InpMagicNumber,
         " HaltFlag=", (GlobalVariableCheck(g_haltGlobalVarName) ? "ADA (halted)" : "tidak ada"));
   return(INIT_SUCCEEDED);
}

//+------------------------------------------------------------------+
void OnDeinit(const int reason)
{
   IndicatorRelease(g_emaFastHandle);
   IndicatorRelease(g_emaSlowHandle);
   IndicatorRelease(g_atrHandle);
   ObjectDelete(0, g_resetBtnName);
}

//+------------------------------------------------------------------+
//| Helper: bulatkan waktu ke awal hari (00:00) untuk perbandingan   |
//+------------------------------------------------------------------+
datetime DateFloor(datetime t)
{
   return t - (t % 86400);
}

//+------------------------------------------------------------------+
//| Tombol manual reset equity-floor halt (klik di chart)            |
//+------------------------------------------------------------------+
void CreateResetButton()
{
   ObjectCreate(0, g_resetBtnName, OBJ_BUTTON, 0, 0, 0);
   ObjectSetInteger(0, g_resetBtnName, OBJPROP_XDISTANCE, 20);
   ObjectSetInteger(0, g_resetBtnName, OBJPROP_YDISTANCE, 20);
   ObjectSetInteger(0, g_resetBtnName, OBJPROP_XSIZE, 160);
   ObjectSetInteger(0, g_resetBtnName, OBJPROP_YSIZE, 30);
   ObjectSetString(0, g_resetBtnName, OBJPROP_TEXT, "RESET HALT (Zero2Hero)");
   ObjectSetInteger(0, g_resetBtnName, OBJPROP_COLOR, clrWhite);
   ObjectSetInteger(0, g_resetBtnName, OBJPROP_BGCOLOR, clrFireBrick);
   ObjectSetInteger(0, g_resetBtnName, OBJPROP_CORNER, CORNER_LEFT_UPPER);
}

void OnChartEvent(const int id, const long &lparam, const double &dparam, const string &sparam)
{
   if(id==CHARTEVENT_OBJECT_CLICK && sparam==g_resetBtnName)
   {
      if(GlobalVariableCheck(g_haltGlobalVarName))
      {
         GlobalVariableDel(g_haltGlobalVarName);
         Print("EA_ZeroToHero: equity-floor halt di-reset manual oleh user.");
      }
      ObjectSetInteger(0, g_resetBtnName, OBJPROP_STATE, false);
   }
}

//+------------------------------------------------------------------+
//| Hitung floating P/L dari posisi kita saat ini (magic number ini) |
//+------------------------------------------------------------------+
double GetFloatingPL()
{
   double total = 0.0;
   for(int i=0; i<PositionsTotal(); i++)
   {
      ulong ticket = PositionGetTicket(i);
      if(ticket==0) continue;
      if(PositionGetString(POSITION_SYMBOL)!=_Symbol) continue;
      if((ulong)PositionGetInteger(POSITION_MAGIC)!=InpMagicNumber) continue;
      total += PositionGetDouble(POSITION_PROFIT) + PositionGetDouble(POSITION_SWAP);
   }
   return total;
}

int CountOurPositions()
{
   int c=0;
   for(int i=0; i<PositionsTotal(); i++)
   {
      ulong ticket = PositionGetTicket(i);
      if(ticket==0) continue;
      if(PositionGetString(POSITION_SYMBOL)!=_Symbol) continue;
      if((ulong)PositionGetInteger(POSITION_MAGIC)!=InpMagicNumber) continue;
      c++;
   }
   return c;
}

void CloseAllOurPositions()
{
   for(int i=PositionsTotal()-1; i>=0; i--)
   {
      ulong ticket = PositionGetTicket(i);
      if(ticket==0) continue;
      if(PositionGetString(POSITION_SYMBOL)!=_Symbol) continue;
      if((ulong)PositionGetInteger(POSITION_MAGIC)!=InpMagicNumber) continue;

      MqlTradeRequest req; MqlTradeResult res;
      ZeroMemory(req); ZeroMemory(res);
      req.action   = TRADE_ACTION_DEAL;
      req.position = ticket;
      req.symbol   = _Symbol;
      long ptype = PositionGetInteger(POSITION_TYPE);
      double volume = PositionGetDouble(POSITION_VOLUME);
      req.volume = volume;
      req.deviation = 20;
      req.magic = InpMagicNumber;
      if(ptype==POSITION_TYPE_BUY)
      {
         req.type  = ORDER_TYPE_SELL;
         req.price = SymbolInfoDouble(_Symbol, SYMBOL_BID);
      }
      else
      {
         req.type  = ORDER_TYPE_BUY;
         req.price = SymbolInfoDouble(_Symbol, SYMBOL_ASK);
      }
      if(!OrderSend(req, res))
         Print("EA_ZeroToHero: gagal force-close ticket ", ticket, " err=", GetLastError());
   }
}

//+------------------------------------------------------------------+
//| Reset harian: HANYA kalau tanggal berganti DAN tidak ada posisi  |
//| terbuka (lihat spec 6a). Kalau masih ada posisi nyantol, reset   |
//| ditunda walau tanggal sudah ganti.                               |
//+------------------------------------------------------------------+
void CheckDailyReset()
{
   datetime today = DateFloor(TimeCurrent());
   if(today > g_trackedDay)
   {
      if(CountOurPositions()==0)
      {
         g_trackedDay = today;
         g_dayStartBalance = AccountInfoDouble(ACCOUNT_BALANCE);
         g_dailyLocked = false;
         Print("EA_ZeroToHero: reset harian. Balance awal hari baru = ", g_dayStartBalance);
      }
      // kalau masih ada posisi terbuka, g_trackedDay TIDAK diupdate -> reset ditunda
      // sampai posisi flat, sesuai spec 6a. dayStartBalance & lock state tetap punya
      // hari sebelumnya sampai posisi itu closed.
   }
}

//+------------------------------------------------------------------+
//| Cek & terapkan daily profit lock + equity floor (circuit breaker)|
//+------------------------------------------------------------------+
bool CheckRiskGates()
{
   // 1) Equity floor -> halt total, persist via GlobalVariable, hanya reset manual
   if(GlobalVariableCheck(g_haltGlobalVarName))
      return false; // sudah halted sebelumnya

   double floating = GetFloatingPL();
   double currentEquityBasis = AccountInfoDouble(ACCOUNT_BALANCE) + floating;
   double floorLevel = g_dayStartBalance * (1.0 - InpEquityFloorPercent/100.0);

   if(currentEquityBasis <= floorLevel)
   {
      Print("EA_ZeroToHero: EQUITY FLOOR TERSENTUH (", currentEquityBasis,
            " <= ", floorLevel, "). EA HALT TOTAL. Reset manual via tombol chart / top-up.");
      CloseAllOurPositions();
      GlobalVariableSet(g_haltGlobalVarName, 1.0);
      return false;
   }

   // 2) Daily profit lock
   double dailyPL = (AccountInfoDouble(ACCOUNT_BALANCE) - g_dayStartBalance) + floating;
   if(dailyPL >= InpDailyProfitTarget)
   {
      if(!g_dailyLocked)
      {
         Print("EA_ZeroToHero: target profit harian $", InpDailyProfitTarget,
               " tercapai (", dailyPL, "). Force-close semua & lock entry.");
         CloseAllOurPositions();
      }
      g_dailyLocked = true;
      return false;
   }

   return true; // aman, boleh cari entry
}

//+------------------------------------------------------------------+
//| Filter sesi trading (broker time -> dikonversi ke GMT pakai      |
//| InpBrokerGMTOffset)                                               |
//+------------------------------------------------------------------+
bool InSession()
{
   datetime now = TimeCurrent();
   MqlDateTime dt; TimeToStruct(now, dt);
   int gmtHour = (dt.hour - InpBrokerGMTOffset + 24) % 24;
   if(InpSessionStartHour <= InpSessionEndHour)
      return (gmtHour >= InpSessionStartHour && gmtHour < InpSessionEndHour);
   else // sesi lintas tengah malam (jaga-jaga)
      return (gmtHour >= InpSessionStartHour || gmtHour < InpSessionEndHour);
}

//+------------------------------------------------------------------+
//| Lot tiering berdasarkan balance SAAT INI (tabel manual, max 0.10) |
//+------------------------------------------------------------------+
double GetTierLot()
{
   double bal = AccountInfoDouble(ACCOUNT_BALANCE);
   double lot;

   if(bal <= 15)        lot = 0.01;
   else if(bal <= 30)   lot = 0.02;
   else if(bal <= 50)   lot = 0.03;
   else if(bal <= 70)   lot = 0.04;
   else if(bal <= 100)  lot = 0.05;
   else if(bal <= 200)  lot = 0.06;
   else if(bal <= 400)  lot = 0.07;
   else if(bal <= 700)  lot = 0.08;
   else if(bal <= 999)  lot = 0.09;
   else                 lot = 0.10; // batas maksimal, gak naik lagi di atas ini

   double minLot  = SymbolInfoDouble(_Symbol, SYMBOL_VOLUME_MIN);
   double maxLot  = SymbolInfoDouble(_Symbol, SYMBOL_VOLUME_MAX);
   double lotStep = SymbolInfoDouble(_Symbol, SYMBOL_VOLUME_STEP);
   lot = MathMax(minLot, MathMin(MathMin(maxLot, 0.10), lot));
   lot = MathRound(lot/lotStep) * lotStep;
   return lot;
}

//+------------------------------------------------------------------+
//| Cek apakah boleh entry baru berdasarkan fase balance             |
//| (single posisi < $50, multi-layer independen >= $50)             |
//+------------------------------------------------------------------+
bool PhaseAllowsNewEntry()
{
   double bal = AccountInfoDouble(ACCOUNT_BALANCE);
   int openCount = CountOurPositions();
   if(bal < InpMultiLayerBalance)
      return (openCount==0); // fase 1: harus flat dulu
   return true; // fase 2: multi-layer, dibatasi margin check terpisah
}

//+------------------------------------------------------------------+
//| Cek free margin cukup buat buka posisi baru + buffer aman        |
//+------------------------------------------------------------------+
bool MarginOK(double lot, ENUM_ORDER_TYPE type, double price)
{
   double marginNeeded=0.0;
   if(!OrderCalcMargin(type, _Symbol, lot, price, marginNeeded))
      return false;
   double freeMargin = AccountInfoDouble(ACCOUNT_MARGIN_FREE);
   double required = marginNeeded * (1.0 + InpMarginBufferPct/100.0);
   return (freeMargin >= required);
}

//+------------------------------------------------------------------+
//| ==================== SIGNAL: H1 SNR (fractal) ================= |
//+------------------------------------------------------------------+
bool FindNearestSNR(double &supportLevel, double &resistanceLevel)
{
   int half = InpFractalBars/2; // 2 utk periode 5
   double price = SymbolInfoDouble(_Symbol, SYMBOL_BID);

   double bestSupport = -1;
   double bestResistance = -1;

   int bars = MathMin(InpSNRLookbackBars, iBars(_Symbol, PERIOD_H1) - InpFractalBars - 1);
   for(int shift = half+1; shift < bars; shift++)
   {
      double high = iHigh(_Symbol, PERIOD_H1, shift);
      double low  = iLow(_Symbol, PERIOD_H1, shift);
      bool isFractalHigh = true, isFractalLow = true;

      for(int k=1; k<=half; k++)
      {
         if(iHigh(_Symbol, PERIOD_H1, shift-k) >= high) isFractalHigh=false;
         if(iHigh(_Symbol, PERIOD_H1, shift+k) >= high) isFractalHigh=false;
         if(iLow(_Symbol, PERIOD_H1, shift-k) <= low) isFractalLow=false;
         if(iLow(_Symbol, PERIOD_H1, shift+k) <= low) isFractalLow=false;
      }

      if(isFractalHigh && high > price)
      {
         if(bestResistance < 0 || high < bestResistance) bestResistance = high;
      }
      if(isFractalLow && low < price)
      {
         if(bestSupport < 0 || low > bestSupport) bestSupport = low;
      }
   }

   supportLevel = bestSupport;
   resistanceLevel = bestResistance;
   return (bestSupport > 0 || bestResistance > 0);
}

//+------------------------------------------------------------------+
//| ==================== SIGNAL: M15 arah (EMA) ===================  |
//+------------------------------------------------------------------+
// return: 1 = bias BUY, -1 = bias SELL, 0 = tidak jelas
int GetM15Bias()
{
   double emaFast[2], emaSlow[2];
   if(CopyBuffer(g_emaFastHandle, 0, 0, 2, emaFast) < 2) return 0;
   if(CopyBuffer(g_emaSlowHandle, 0, 0, 2, emaSlow) < 2) return 0;

   if(emaFast[0] > emaSlow[0]) return 1;
   if(emaFast[0] < emaSlow[0]) return -1;
   return 0;
}

//+------------------------------------------------------------------+
//| ==================== SIGNAL: M5 trigger ========================  |
//+------------------------------------------------------------------+
// Cek candle M5 terakhir yg closed (shift 1): apakah menyentuh zona
// SNR dan menunjukkan candle reversal/rejection searah bias.
bool CheckM5Trigger(int bias, double supportLevel, double resistanceLevel, double atrH1, double &entrySwingLevel)
{
   double open  = iOpen(_Symbol, PERIOD_M5, 1);
   double close = iClose(_Symbol, PERIOD_M5, 1);
   double high  = iHigh(_Symbol, PERIOD_M5, 1);
   double low   = iLow(_Symbol, PERIOD_M5, 1);
   double zoneTolerance = atrH1 * InpZoneATRMult;

   // Catatan revisi: syarat awal (harus close di upper/lower half candle) terlalu ketat
   // dan bikin sinyal sangat jarang (backtest awal cuma 3 trade dalam 2 tahun). Sekarang
   // cukup: harga menyentuh zona SNR (dengan toleransi ATR yang sudah dinaikkan ke 1.0x)
   // DAN candle close searah bias -- tidak wajib close di setengah candle atas/bawah lagi.
   if(bias==1 && supportLevel>0)
   {
      bool touchedZone  = (low <= supportLevel + zoneTolerance);
      bool bullishClose = (close > open);
      if(touchedZone && bullishClose)
      {
         entrySwingLevel = MathMin(low, supportLevel);
         return true;
      }
   }
   else if(bias==-1 && resistanceLevel>0)
   {
      bool touchedZone  = (high >= resistanceLevel - zoneTolerance);
      bool bearishClose = (close < open);
      if(touchedZone && bearishClose)
      {
         entrySwingLevel = MathMax(high, resistanceLevel);
         return true;
      }
   }
   return false;
}

//+------------------------------------------------------------------+
//| Eksekusi entry                                                    |
//+------------------------------------------------------------------+
void TryOpenPosition(int bias, double swingLevel, double atrH1)
{
   double lot = GetTierLot();
   double buffer = atrH1 * InpSL_ATR_Buffer;
   double price, sl, tp;

   ENUM_ORDER_TYPE otype = (bias==1) ? ORDER_TYPE_BUY : ORDER_TYPE_SELL;
   price = (bias==1) ? SymbolInfoDouble(_Symbol, SYMBOL_ASK) : SymbolInfoDouble(_Symbol, SYMBOL_BID);

   if(bias==1)
   {
      sl = swingLevel - buffer;
      double dist = price - sl;
      if(dist <= 0) return;
      tp = price + dist*InpRR_Ratio;
   }
   else
   {
      sl = swingLevel + buffer;
      double dist = sl - price;
      if(dist <= 0) return;
      tp = price - dist*InpRR_Ratio;
   }

   // Cek risiko dollar sebelum entry: kalau jarak SL x lot melebihi InpMaxRiskUSD,
   // skip entry ini sama sekali -- jangan dipaksakan / jangan diclamp SL-nya, karena
   // clamp SL berarti mengubah level stop dari struktur (jadi gak valid lagi secara teknikal).
   // Lebih aman skip dan tunggu setup lain yang SL-nya lebih dekat ke harga.
   double slDistPrice = MathAbs(price - sl);
   double tickSize  = SymbolInfoDouble(_Symbol, SYMBOL_TRADE_TICK_SIZE);
   double tickValue = SymbolInfoDouble(_Symbol, SYMBOL_TRADE_TICK_VALUE);
   double potentialLossUSD = 0.0;
   if(tickSize > 0)
      potentialLossUSD = (slDistPrice / tickSize) * tickValue * lot;

   if(potentialLossUSD > InpMaxRiskUSD)
   {
      Print("EA_ZeroToHero: skip entry, potensi rugi $", DoubleToString(potentialLossUSD,2),
            " melebihi batas InpMaxRiskUSD=$", InpMaxRiskUSD, " (SL terlalu jauh dari harga).");
      return;
   }

   if(!MarginOK(lot, otype, price))
   {
      Print("EA_ZeroToHero: skip entry, free margin tidak cukup (+buffer ", InpMarginBufferPct, "%).");
      return;
   }

   MqlTradeRequest req; MqlTradeResult res;
   ZeroMemory(req); ZeroMemory(res);
   req.action    = TRADE_ACTION_DEAL;
   req.symbol    = _Symbol;
   req.volume    = lot;
   req.type      = otype;
   req.price     = price;
   req.sl        = NormalizeDouble(sl, _Digits);
   req.tp        = NormalizeDouble(tp, _Digits);
   req.deviation = 20;
   req.magic     = InpMagicNumber;
   req.comment   = InpTradeComment;
   req.type_filling = ORDER_FILLING_FOK;

   if(!OrderSend(req, res))
      Print("EA_ZeroToHero: OrderSend gagal, err=", GetLastError());
   else
      Print("EA_ZeroToHero: entry ", (bias==1?"BUY":"SELL"), " lot=", lot,
            " price=", price, " sl=", sl, " tp=", tp);
}

//+------------------------------------------------------------------+
//| OnTick                                                            |
//+------------------------------------------------------------------+
datetime g_lastM5BarTime = 0;

void OnTick()
{
   CheckDailyReset();

   if(!CheckRiskGates())
      return; // halted / locked hari ini

   if(!InSession())
      return;

   if(g_dailyLocked)
      return;

   if(!PhaseAllowsNewEntry())
      return;

   // Evaluasi cuma sekali per candle M5 baru biar gak spam & konsisten dgn "candle close"
   datetime curM5Bar = iTime(_Symbol, PERIOD_M5, 0);
   if(curM5Bar == g_lastM5BarTime)
      return;
   g_lastM5BarTime = curM5Bar;

   double atrBuf[1];
   if(CopyBuffer(g_atrHandle, 0, 1, 1, atrBuf) < 1) return;
   double atrH1 = atrBuf[0];
   if(atrH1<=0) return;

   double support, resistance;
   if(!FindNearestSNR(support, resistance)) return;

   int bias = GetM15Bias();
   if(bias==0) return;

   double swingLevel;
   if(CheckM5Trigger(bias, support, resistance, atrH1, swingLevel))
   {
      TryOpenPosition(bias, swingLevel, atrH1);
   }
}
//+------------------------------------------------------------------+
