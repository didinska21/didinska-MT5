# EA Zero to Hero — Spec Teknis (MT5 / MQL5)

## 1. Ringkasan Proyek
EA baru, terpisah dari proyek DTE (Didinska Trading Engine). Tujuan bukan profit maksimal, tapi **profit kecil konsisten**: $15/hari, lalu stop. Modal awal kecil ($12), jadi manajemen risiko lebih penting daripada agresivitas strategi.

- **Instrumen:** XAUUSD (Gold) — pair lain menyusul setelah versi ini terbukti profitable
- **Akun:** Hedging type, leverage 1:500
- **Modal awal:** $12

---

## 2. Strategi Entry (3-Lapis)

> Revisi dari rencana awal 4-lapis (H1 SNR + M30 trendline + M15 EMA + M5 eksekusi). M30 trendline dibuang karena redundant dengan filter arah M15 dan terlalu mempersempit frekuensi sinyal untuk tujuan profit-harian-kecil ini.

### Layer 1 — H1: Zona SNR (Support & Resistance)
- Deteksi swing high/low pakai **fractal 5-bar standar** (2 candle kiri & 2 candle kanan lebih rendah/tinggi dari titik tengah)
- Track hanya **2 level aktif**: resistance terdekat di atas harga saat ini, support terdekat di bawah harga saat ini
- Level lama di-invalidate/diganti begitu ada fractal baru yang lebih dekat ke harga

### Layer 2 — M15: Filter Arah
- EMA20 vs EMA50 pada M15
- EMA20 > EMA50 → bias **BUY**
- EMA20 < EMA50 → bias **SELL**
- Ini satu-satunya filter arah (menggantikan fungsi M30 trendline yang dihapus)

### Layer 3 — M5: Trigger Eksekusi
- Harga M5 harus berada **di dalam/menyentuh zona SNR H1** yang relevan dengan bias (support untuk BUY, resistance untuk SELL)
- Konfirmasi: candle M5 **close** menunjukkan reversal/rejection dari zona tersebut (searah bias M15), bukan breakout
- Entry di candle close berikutnya setelah konfirmasi

---

## 3. Manajemen Posisi

| Item | Rule |
|---|---|
| Stop Loss | Di belakang swing point terakhir (yang membentuk zona SNR) + buffer 0.3 × ATR(14, H1 atau M5 — pilih di implementasi) |
| Take Profit | Risk:Reward tetap 1:2 dari jarak SL |
| Re-entry | Diizinkan setelah SL kena, **selama** bias M15 masih sama arah dan harga kembali membentuk setup valid (zona SNR + konfirmasi M5) |
| Posisi bersamaan | Lihat 3a — tergantung fase balance |

### 3a. Fase Balance: Single Posisi vs Multi-Layer

**Fase 1 — Balance < $50:**
- Satu posisi aktif per waktu (constraint margin, modal kecil cuma cukup 1 posisi 0.01 lot)
- **Tidak ada timeout.** Kalau posisi nyantol lama (bahkan lewat beberapa hari), dibiarkan jalan sampai kena SL atau TP sendiri — tidak di-force-close karena lama nyantol
- Konsekuensi yang disadari & diterima: selama posisi ini nyantol, EA tidak bisa entry baru meski ada setup lain lewat
- **"Satu posisi aktif per waktu" ≠ "satu entry per hari".** Begitu posisi closed — baik kena TP maupun SL — dan profit harian belum mencapai $15 serta equity floor belum tersentuh, EA lanjut mencari setup baru di hari yang sama, bisa entry berkali-kali sampai salah satu dari 2 kondisi stop (target $15 atau equity floor) tercapai

**Fase 2 — Balance ≥ $50:**
- **Multi-layer independen** (bukan basket/averaging style DTE): begitu ada setup valid baru (H1 SNR + M15 EMA + M5 trigger), EA boleh buka posisi baru meski posisi lain masih terbuka
- Tiap posisi/layer punya SL & TP sendiri-sendiri, sepenuhnya independen, tidak saling terkait atau saling mempengaruhi exit-nya
- Jumlah layer bersamaan dibatasi oleh free margin — sebelum buka layer baru, EA wajib cek free margin cukup untuk margin posisi baru + buffer aman (jangan sampai margin call)
- **Daily profit lock ($15) dihitung dari total P/L gabungan semua layer**, bukan per layer — begitu total (closed + floating semua layer) mencapai $15, semua layer di-force-close sekaligus dan entry dikunci sampai hari berikutnya
- Equity floor (50%) juga dihitung dari balance gabungan, bukan per layer

---

## 4. Lot Sizing (Tier Berdasar Balance)

Lot ditentukan dari tabel manual berikut, dicek ulang setiap kali mau entry berdasarkan **balance saat itu juga** (bukan histori kemarin), dibatasi maksimal **0.10 lot**:

| Balance | Lot |
|---|---|
| $1 – $15 | 0.01 |
| $16 – $30 | 0.02 |
| $31 – $50 | 0.03 |
| $51 – $70 | 0.04 |
| $71 – $100 | 0.05 |
| $101 – $200 | 0.06 |
| $201 – $400 | 0.07 |
| $401 – $700 | 0.08 |
| $701 – $999 | 0.09 |
| $1000+ | 0.10 (maksimal, tidak naik lagi di atas ini) |

---

## 5. Filter Sesi
- Trading dibatasi ke **full London + New York session**, sekitar **07:00–21:00 GMT** (~14 jam) — sesuaikan persis dengan offset server time broker saat implementasi
- Sengaja bukan cuma overlap sempit (~4 jam, 12:00-16:00 GMT): overlap terlalu sempit buat frekuensi entry yang dibutuhkan tujuan profit-harian-kecil ini, sementara London open sendiri (07:00-10:00 GMT) sering kasih reaksi kuat di level SNR yang sayang dilewatkan
- Sesi Asia tetap di-exclude: volatilitas rendah, spread XAUUSD relatif lebih lebar terhadap pergerakan harga, kurang efisien buat SL/TP ketat
- Di luar jam ini: no new entry (posisi yang sudah terbuka tetap dikelola SL/TP normal)

---

## 6. Daily Profit Lock
- Hitung **profit harian** = closed P/L + floating P/L sejak reset harian (server time, awal hari trading)
- Begitu total mencapai **$15**:
  1. **Force-close semua posisi terbuka** (tidak dibiarkan jalan sampai SL/TP sendiri)
  2. **Lock entry baru** sampai reset hari berikutnya
- Reset otomatis di pergantian hari (server time) — **dengan syarat tambahan**, lihat 6a

### 6a. Posisi yang Nyambung Lewat Tengah Malam
Kalau ada posisi masih terbuka pas tanggal server berganti (belum sempat kena SL/TP sebelum sesi berakhir):
- **Reset harian DITUNDA** — bukan murni berdasar jam ganti tanggal, tapi baru terjadi setelah: (tanggal sudah berganti) **DAN** (tidak ada posisi terbuka)
- Posisi yang nyambung dibiarkan jalan normal sampai kena SL atau TP sendiri (risiko sudah dibatasi RR 1:2, jadi tidak liar) — **tidak** di-force-close hanya karena ganti hari
- P/L dari posisi itu tetap dihitung sebagai milik **hari saat posisi dibuka** (hari sebelumnya), bukan hari baru
- Begitu posisi tersebut closed, baru hari trading baru resmi dimulai dan counter profit target / equity floor reset bersih dari nol
- Alasan: mencegah floating P/L posisi kemarin "mengotori" perhitungan target/floor hari baru (bisa salah trigger equity floor padahal itu sisa kerugian kemarin, atau salah trigger profit lock karena kebantu floating profit semalam)

---

## 7. Equity Floor Harian (Circuit Breaker)
- Floor = **50% dari balance awal hari itu** (dihitung ulang tiap reset harian, bukan dari modal awal proyek)
- Begitu balance harian turun ke floor ini:
  - EA **stop total** (bukan cuma stop hari itu) — tidak entry lagi sampai user restart manual/top-up
  - Ini disengaja: pada modal sekecil ini, EA tidak boleh mencoba "balikin modal" otomatis, itu keputusan manual user

---

## 8. Parameter yang Harus Jadi Input (bukan hardcode)
```
InpFractalBars        = 5        // periode fractal H1 SNR
InpEMA_Fast           = 20       // EMA cepat M15
InpEMA_Slow           = 50       // EMA lambat M15
InpATR_Period         = 14
InpSL_ATR_Buffer      = 0.3      // multiplier buffer SL
InpRR_Ratio           = 2.0      // TP = SL_distance * RR
InpMaxRiskUSD         = 2.0      // batas rugi maksimal per trade (USD), entry di-skip kalau lebih
InpDailyProfitTarget  = 15.0     // USD
InpEquityFloorPercent = 50.0     // % dari balance awal hari
InpSessionStartHour   = 7        // GMT, full London open — sesuaikan ke server time broker
InpSessionEndHour     = 21       // GMT, akhir sesi NY — sesuaikan ke server time broker
InpMultiLayerBalance  = 50.0     // >= ini baru boleh multi-layer independen (lot tetap ikut tabel manual)
InpMagicNumber        = <unik, beda dari DTE>
```

---

## 9. Hal yang Perlu Diputuskan/Divalidasi Saat Implementasi
- Simbol broker: pastikan suffix XAUUSD sesuai broker (mis. `XAUUSD.` atau `GOLD`)
- Server time offset vs broker time untuk filter sesi & reset harian — jangan asumsikan sama dengan GMT
- ATR dihitung di timeframe mana persis untuk buffer SL (disarankan H1, selaras dengan swing point SNR)
- Perilaku saat spread melebar ekstrem (belum ada spread filter di spec ini — pertimbangkan tambah kalau backtest menunjukkan banyak entry di spread buruk)

---

## 10. Yang Sengaja TIDAK Dipakai (dari diskusi awal)
- M30 trendline sebagai filter wajib — dibuang, redundant dengan EMA M15, terlalu mempersempit frekuensi sinyal
- Basket/grid multi-layer seperti DTE — modal $12 hanya cukup untuk 1 posisi per waktu
