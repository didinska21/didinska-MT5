# FINAL ACCEPTANCE CHECKLIST

## Build
[ ] 0 errors
[ ] 0 warnings

## Functional
[ ] setup candidates observed
[ ] Phase 5 PASS observed
[ ] Phase 6 PASS observed
[ ] Phase 7 PASS observed
[ ] Phase 8 PASS observed
[ ] execution preflight PASS observed
[ ] broker retcode recorded

## Risk
[ ] $10 tested
[ ] $20 tested
[ ] $30 tested
[ ] no minimum-lot over-risk
[ ] actual risk verified

## AI
[ ] AI OFF baseline
[ ] AI REPLAY deterministic
[ ] BUY fixture
[ ] SELL fixture
[ ] WAIT fixture
[ ] low confidence rejection
[ ] HIGH risk rejection
[ ] malformed response rejection

## Stress
[ ] Gateway down
[ ] timeout
[ ] 429
[ ] auth failure
[ ] 5xx
[ ] all keys unavailable
[ ] invalid stops
[ ] insufficient margin
[ ] invalid volume

## Security
[ ] Gateway token rotated before live
[ ] no Groq keys in EA
[ ] no secrets in logs/reports
[ ] live execution gate verified

## Release
[ ] Demo validation complete
[ ] Final audit approved
