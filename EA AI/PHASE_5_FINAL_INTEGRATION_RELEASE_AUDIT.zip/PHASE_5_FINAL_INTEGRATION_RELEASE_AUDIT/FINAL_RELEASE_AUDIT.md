# EA + AI = MONEY
# PHASE 5 — FINAL INTEGRATION & RELEASE AUDIT
## XAUUSD_AI_EA

## Purpose

This is the final gate after the five remediation phases. It does not claim that MT5 compilation, Strategy Tester execution, broker execution, or live trading has been performed inside this environment.

## Final architecture to validate

Market data
 -> Structure / Candidate
 -> Technical score
 -> SL/TP + RR
 -> Risk / Position sizing
 -> Environment / broker preflight
 -> AI validation (when enabled)
 -> Final local gate
 -> Execution
 -> Retcode validation
 -> Position management

## Locked safety principles

1. AI cannot override local risk.
2. AI cannot set or increase lot size.
3. AI cannot override SL/TP validation.
4. AI cannot bypass broker constraints.
5. Minimum-lot normalization must never silently over-risk the account.
6. A rejected broker order must never be recorded as an entry.
7. Unowned/manual positions must not be managed when ownership filtering is enabled.
8. Tester results must identify the AI mode used.
9. Secrets must not be exposed in reports/logs.
10. No optimization is allowed until functional validation passes.

## Final validation gates

### Gate A — Compile
Required in the user's MetaEditor:
- Errors = 0
- Warnings = 0

### Gate B — Functional baseline
Use:
- XAUUSD
- M5
- Every tick based on real ticks
- Optimization OFF
- Deposit = $30
- AI mode = OFF

The objective is NOT profit. The objective is proving that a valid deterministic setup can progress through risk and execution.

### Gate C — Risk validation
Repeat at:
- $10
- $20
- $30

Record:
- raw lot
- normalized lot
- minimum/step/max volume
- loss per lot
- target risk
- actual risk
- rejection reason when the minimum lot would exceed policy

### Gate D — AI replay
Use deterministic recorded AI responses:
- BUY
- SELL
- WAIT
- confidence below threshold
- confidence above threshold
- HIGH risk assessment
- malformed/invalid response

The same request fingerprint must produce the same replay decision.

### Gate E — Failure injection
Validate safe behavior for:
- Gateway unavailable
- timeout
- 429
- 401/403
- 5xx
- all keys unavailable
- malformed AI response
- invalid stops
- insufficient margin
- invalid volume
- trading disabled

Expected result: no unvalidated order.

### Gate F — Final audit
Confirm:
- order retcodes are logged;
- successful fills only update trade state;
- risk accounting is updated only after accepted execution;
- position management respects ownership;
- no duplicate entry path exists;
- no hard-coded secret exists;
- no test-only bypass remains enabled for live execution.

## Release decision

**Current status: RELEASE CANDIDATE — PENDING USER-SIDE MT5 VALIDATION**

This package must not be described as live-ready until Gates A–F have actual evidence from MetaEditor/Strategy Tester/demo.

## Important

The supplied tester result with zero trades is not a profitability result. Earlier source-level evidence showed candidates reaching technical and SL/TP phases but being rejected by risk sizing. The remediation phases therefore must be validated empirically after compilation.

## Recommended first run

Do not optimize.

Run the $30 / XAUUSD / M5 / real-ticks / AI-OFF baseline and inspect:
- Overview
- Journal
- Report

Then compare the rejection counters and any execution retcodes against the acceptance criteria.
