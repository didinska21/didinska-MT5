# EA + AI = MONEY — XAUUSD_AI_EA
## Phase 5 Release Candidate

This package contains the remediated XAUUSD AI EA and Gateway.

### Runtime
- XAUUSD-only
- M5 signal pipeline
- Groq Gateway with 10-key pool
- AI validation layer
- local risk authority
- broker-aware execution

### IMPORTANT
This is a RELEASE CANDIDATE, not a compile-certified final live build.
Compile in MetaEditor first and require 0 errors / 0 warnings.

Strategy Tester does not call live Groq HTTP. Use the deterministic baseline for engine validation; AI Replay certification is a separate controlled test mode.

Before live deployment rotate the Gateway token that was previously exposed in tester output.
