#ifndef XAUUSD_AI_SLTP_CALCULATOR_MQH
#define XAUUSD_AI_SLTP_CALCULATOR_MQH

#include <XAUUSD_AI/Core/Types.mqh>

// Phase 6: deterministic SL/TP/RR construction.
// No broker order is sent here. The engine only calculates and validates a
// candidate using closed-candle structure, ATR and the supplied liquidity map.
class CXAISLTPService {
private:
   double m_sl_buffer_atr;
   double m_min_rr;
   int    m_stops_level_points;
   double m_point;

   double ClampNonNegative(const double value) const {
      return (value < 0.0 ? 0.0 : value);
   }

   bool FindNearestTarget(const XAISetupCandidate &candidate,
                          const SXAILiquidityLevel &levels[],
                          double &target) const {
      bool found=false;
      double best=0.0;

      for(int i=0;i<ArraySize(levels);i++) {
         if(!levels[i].active) continue;
         const double p=levels[i].price;

         if(candidate.direction==XAI_DIR_BUY && p>candidate.proposed_entry) {
            if(!found || p<best) { best=p; found=true; }
         }
         else if(candidate.direction==XAI_DIR_SELL && p<candidate.proposed_entry) {
            if(!found || p>best) { best=p; found=true; }
         }
      }

      if(found) target=best;
      return found;
   }

   double NormalizePrice(const double price) const {
      if(price<=0.0) return 0.0;
      const double tick_size=SymbolInfoDouble(_Symbol,SYMBOL_TRADE_TICK_SIZE);
      if(tick_size>0.0) {
         const double steps=MathRound(price/tick_size);
         return NormalizeDouble(steps*tick_size,(int)SymbolInfoInteger(_Symbol,SYMBOL_DIGITS));
      }
      return NormalizeDouble(price,(int)SymbolInfoInteger(_Symbol,SYMBOL_DIGITS));
   }

public:
   CXAISLTPService() : m_sl_buffer_atr(0.10),m_min_rr(1.50),m_stops_level_points(0),m_point(0.0) {}

   void Configure(const double sl_buffer_atr,
                  const double minimum_rr,
                  const int stops_level_points=0,
                  const double point=0.0) {
      m_sl_buffer_atr=ClampNonNegative(sl_buffer_atr);
      m_min_rr=(minimum_rr<0.0 ? 0.0 : minimum_rr);
      m_stops_level_points=(stops_level_points<0 ? 0 : stops_level_points);
      m_point=point;
   }

   double CalculateSL(const XAISetupCandidate &candidate,const double atr) const {
      if(!candidate.valid || atr<=0.0) return 0.0;

      const double buffer=atr*m_sl_buffer_atr;
      double sl=0.0;

      if(candidate.direction==XAI_DIR_BUY)
         sl=candidate.invalidation_price-buffer;
      else if(candidate.direction==XAI_DIR_SELL)
         sl=candidate.invalidation_price+buffer;
      else
         return 0.0;

      return NormalizePrice(sl);
   }

   bool ValidateSL(const XAISetupCandidate &candidate,
                   const double entry,
                   const double sl) const {
      if(entry<=0.0 || sl<=0.0) return false;

      if(candidate.direction==XAI_DIR_BUY && sl>=entry) return false;
      if(candidate.direction==XAI_DIR_SELL && sl<=entry) return false;

      if(m_stops_level_points>0 && m_point>0.0) {
         const double minimum_distance=m_stops_level_points*m_point;
         if(MathAbs(entry-sl)<minimum_distance) return false;
      }
      return true;
   }

   bool ValidateTP(const XAISetupCandidate &candidate,
                   const double entry,
                   const double tp) const {
      if(entry<=0.0 || tp<=0.0) return false;
      if(candidate.direction==XAI_DIR_BUY && tp<=entry) return false;
      if(candidate.direction==XAI_DIR_SELL && tp>=entry) return false;
      if(m_stops_level_points>0 && m_point>0.0) {
         const double minimum_distance=m_stops_level_points*m_point;
         if(MathAbs(tp-entry)<minimum_distance) return false;
      }
      return true;
   }

   double CalculateTP(const XAISetupCandidate &candidate,
                      const SXAILiquidityLevel &levels[]) const {
      double target=0.0;
      if(!FindNearestTarget(candidate,levels,target)) return 0.0;
      return NormalizePrice(target);
   }

   double CalculateRR(const XAISetupCandidate &candidate,
                      const double entry,
                      const double sl,
                      const double tp) const {
      if(entry<=0.0 || sl<=0.0 || tp<=0.0) return 0.0;

      const double risk=MathAbs(entry-sl);
      if(risk<=0.0) return 0.0;

      double reward=0.0;
      if(candidate.direction==XAI_DIR_BUY) {
         if(tp<=entry) return 0.0;
         reward=tp-entry;
      }
      else if(candidate.direction==XAI_DIR_SELL) {
         if(tp>=entry) return 0.0;
         reward=entry-tp;
      }
      else return 0.0;

      return reward/risk;
   }

   bool Build(XAISetupCandidate &candidate,
              const SXAILiquidityLevel &levels[],
              const double atr,
              const double entry) const {
      candidate.proposed_entry=entry;
      candidate.proposed_sl=0.0;
      candidate.proposed_tp=0.0;
      candidate.rr_score=0.0;

      if(!candidate.valid || entry<=0.0 || atr<=0.0) {
         candidate.valid=false;
         return false;
      }

      const double sl=CalculateSL(candidate,atr);
      if(!ValidateSL(candidate,entry,sl)) {
         candidate.valid=false;
         return false;
      }

      const double tp=CalculateTP(candidate,levels);
      if(!ValidateTP(candidate,entry,tp)) {
         candidate.valid=false;
         return false;
      }

      const double rr=CalculateRR(candidate,entry,sl,tp);
      if(rr<m_min_rr) {
         candidate.valid=false;
         return false;
      }

      candidate.proposed_sl=sl;
      candidate.proposed_tp=tp;
      candidate.rr_score=rr;
      candidate.valid=true;
      return true;
   }

   double MinimumRR() const { return m_min_rr; }
   double SLBufferATR() const { return m_sl_buffer_atr; }
};

#endif
