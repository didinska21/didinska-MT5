#ifndef __XAI_AI_CLIENT_MQH__
#define __XAI_AI_CLIENT_MQH__

#include <XAUUSD_AI/AI/AIResponse.mqh>

class CAIClient
{
private:
   string m_url;
   string m_token;
   int    m_timeout_ms;

   bool ParseStringField(const string body,const string field,string &out)
   {
      string marker="\"" + field + "\":\"";
      int p=StringFind(body,marker);
      if(p<0) return false;
      p+=StringLen(marker);
      int e=StringFind(body,"\"",p);
      if(e<=p) return false;
      out=StringSubstr(body,p,e-p);
      return true;
   }

   bool ParseDoubleField(const string body,const string field,double &out)
   {
      string marker="\"" + field + "\":";
      int p=StringFind(body,marker);
      if(p<0) return false;
      p+=StringLen(marker);
      int e=p;
      while(e<StringLen(body))
      {
         ushort c=StringGetCharacter(body,e);
         if((c>='0' && c<='9') || c=='.' || c=='-' || c=='+' || c=='e' || c=='E') e++;
         else break;
      }
      if(e<=p) return false;
      out=StringToDouble(StringSubstr(body,p,e-p));
      return true;
   }

   bool ParseResponse(const string body,const string expected_request_id,AIResponse &out)
   {
      ZeroMemory(out);
      out.valid=false;
      string status,request_id,decision,market_regime,risk_assessment,reason_code;
      double confidence=0.0,setup_quality=0.0;

      if(!ParseStringField(body,"status",status) || status!="OK") return false;
      if(!ParseStringField(body,"request_id",request_id)) return false;
      if(request_id!=expected_request_id) return false;
      if(!ParseStringField(body,"decision",decision)) return false;
      if(!ParseDoubleField(body,"confidence",confidence)) return false;
      if(!ParseStringField(body,"market_regime",market_regime)) return false;
      if(!ParseDoubleField(body,"setup_quality",setup_quality)) return false;
      if(!ParseStringField(body,"risk_assessment",risk_assessment)) return false;
      if(!ParseStringField(body,"reason_code",reason_code)) return false;

      if(decision!="BUY" && decision!="SELL" && decision!="WAIT") return false;
      if(confidence<0.0 || confidence>1.0) return false;
      if(setup_quality<0.0 || setup_quality>1.0) return false;
      if(risk_assessment!="LOW" && risk_assessment!="NORMAL" &&
         risk_assessment!="ELEVATED" && risk_assessment!="HIGH") return false;

      out.request_id=request_id;
      out.decision=decision;
      out.confidence=confidence;
      out.market_regime=market_regime;
      out.setup_quality=setup_quality;
      out.risk_assessment=risk_assessment;
      out.reason_code=reason_code;
      out.valid=true;
      return true;
   }

public:
   bool Initialize(const string url,const string token,const int timeout_ms=5000)
   {
      m_url=url; m_token=token; m_timeout_ms=timeout_ms;
      return StringLen(m_url)>0 && StringLen(m_token)>0;
   }

   bool RequestDecision(const string request_id,const string json_body,AIResponse &response)
   {
      char data[];
      char result[];
      string result_headers;
      string headers="Content-Type: application/json\r\nX-Gateway-Token: "+m_token+"\r\n";
      StringToCharArray(json_body,data,0,StringLen(json_body),CP_UTF8);

      ResetLastError();
      int code=WebRequest("POST",m_url+"/v1/decision",headers,m_timeout_ms,
                          data,result,result_headers);
      if(code!=200) return false;

      string body=CharArrayToString(result,0,-1,CP_UTF8);
      return ParseResponse(body,request_id,response);
   }
};

#endif
