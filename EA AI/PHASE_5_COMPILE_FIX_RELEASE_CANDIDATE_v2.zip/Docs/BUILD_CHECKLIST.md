# BUILD CHECKLIST

## MetaEditor
- [ ] Open `EA_MT5/Experts/XAUUSD_AI_EA.mq5`
- [ ] Compile
- [ ] Errors = 0
- [ ] Warnings = 0

## Tester baseline
- [ ] XAUUSD
- [ ] M5
- [ ] Every tick based on real ticks
- [ ] Deposit $30
- [ ] Optimization disabled
- [ ] `InpAIMode=LIVE` is automatically bypassed in tester
- [ ] Verify trades can now reach execution

## Live/demo integration
- [ ] Gateway running
- [ ] WebRequest allowed
- [ ] `InpAIMode=LIVE`
- [ ] `InpAllowLiveTrading=false` for first demo observation
- [ ] Then explicit demo execution validation

## Security
- [ ] Rotate previously exposed Gateway token before live
- [ ] Never expose Groq keys
- [ ] Never commit `.env`
