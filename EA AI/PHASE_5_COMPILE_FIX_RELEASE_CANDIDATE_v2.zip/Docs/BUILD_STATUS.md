# BUILD STATUS — PATCHED RELEASE CANDIDATE

This package contains a compile-fix pass after the MT5 screenshot reported:
- InpAIMode undeclared
- XAI_AI_LIVE undeclared
- InpBreakEvenTriggerR undeclared
- NewsFilter `event.currency` undeclared
- related implicit conversion warning

Important: `InpAIMode`, `XAI_AI_LIVE`, and `InpBreakEvenTriggerR` are defined in the canonical
`EA_MT5/Include/XAUUSD_AI/Core/Config.mqh`. Copy the complete `EA_MT5/Experts` AND
`EA_MT5/Include` trees from this package, not only the .mq5 file.

NewsFilter was corrected to use `CalendarValueHistory(..., "USD")`, because the official
MQL5 `MqlCalendarEvent` structure exposes `country_id` but not a `currency` member.

The package has been statically inspected for missing `Inp*` declarations.
Actual MetaEditor compilation must still be performed on the user's MT5 installation.
