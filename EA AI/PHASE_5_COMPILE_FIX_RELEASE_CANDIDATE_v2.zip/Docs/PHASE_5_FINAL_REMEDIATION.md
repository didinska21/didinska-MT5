# PHASE 5 — FINAL REMEDIATION & RELEASE CANDIDATE

## Implemented

### MT5 EA
- Wired `CAITradeCoordinator` into the main signal pipeline for live/demo runtime.
- Added final execution boundary.
- Added BUY/SELL execution after local risk approval and AI approval.
- Enforced `InpAllowLiveTrading` outside Strategy Tester.
- Strategy Tester automatically avoids live HTTP AI calls.
- Recorded daily trade count only after accepted broker retcodes.
- Expanded AI response parsing to include all required response fields.
- Fixed swing pivot ordering so index 0 is the latest confirmed pivot.
- Added tick-size-aware price normalization.
- Added TP broker stop-distance validation.
- Added UTC session gate.
- Added fail-closed live news gate.
- Preserved AI as validation-only; local risk/execution remains authoritative.

### Gateway
- Added actual cache lookup/store to the AI service.
- Added global circuit-breaker enforcement.
- Added per-key consecutive-failure tracking.
- Added per-key cooldown after repeated failures.
- Added exponential retry delay for 429/5xx/network failures.
- Preserved authentication-disable behavior for 401/403.
- Removed Python bytecode/cache artifacts from release package.

## Important tester behavior

The Strategy Tester does NOT make uncontrolled live Groq calls. When `MQL_TESTER` is true, the EA does not invoke live AI HTTP.

Therefore:
- Tester baseline = deterministic local strategy/risk/execution path.
- AI Replay is still a separate certification task if AI-influenced historical performance is required.
- Live/demo = `InpAIMode=LIVE` and `InpAllowLiveTrading=true` only after demo validation.

## Not claimed

This package is NOT claimed as MetaEditor-compiled in this environment. The user must compile it in MT5 MetaEditor and report the exact error/warning count.

No profitability claim is made.

## Release gate

RELEASE CANDIDATE — PENDING:
1. MetaEditor compile = 0 errors / 0 warnings.
2. Strategy Tester functional test.
3. $30 baseline.
4. $20/$10 eligibility tests.
5. Gateway live integration test.
6. Demo forward test.
7. Final security/token rotation.
