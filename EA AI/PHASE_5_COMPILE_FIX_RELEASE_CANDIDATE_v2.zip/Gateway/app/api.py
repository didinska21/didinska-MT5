# Legacy compatibility module. Active routes live in app.api.routes.
from .api.routes import router
