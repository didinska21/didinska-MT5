from .api.schemas import DecisionRequest, DecisionData
AIResult = DecisionData
from enum import Enum
class Decision(str,Enum):
    BUY="BUY"; SELL="SELL"; WAIT="WAIT"
class MarketRegime(str,Enum):
    TRENDING="TRENDING"; RANGING="RANGING"; REVERSAL="REVERSAL"; TRANSITION="TRANSITION"
class RiskAssessment(str,Enum):
    LOW="LOW"; NORMAL="NORMAL"; ELEVATED="ELEVATED"; HIGH="HIGH"
