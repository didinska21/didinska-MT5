from typing import Any, Dict, Literal
from pydantic import BaseModel, ConfigDict, Field

class DecisionRequest(BaseModel):
    model_config=ConfigDict(extra="forbid")
    request_id:str=Field(min_length=1,max_length=128)
    setup_id:str=Field(min_length=1,max_length=128)
    timestamp_utc:str
    symbol:Literal["XAUUSD"]
    signal:Literal["BUY","SELL"]
    technical_score:float=Field(ge=0.0,le=1.0)
    market:Dict[str,Any]=Field(default_factory=dict)
    structure:Dict[str,Any]=Field(default_factory=dict)
    liquidity:Dict[str,Any]=Field(default_factory=dict)
    momentum:Dict[str,Any]=Field(default_factory=dict)
    volatility:Dict[str,Any]=Field(default_factory=dict)
    session:Dict[str,Any]=Field(default_factory=dict)
    news:Dict[str,Any]=Field(default_factory=dict)
    risk_context:Dict[str,Any]=Field(default_factory=dict)

class DecisionData(BaseModel):
    model_config=ConfigDict(extra="forbid")
    request_id:str
    decision:Literal["BUY","SELL","WAIT"]
    confidence:float=Field(ge=0.0,le=1.0)
    market_regime:Literal["TRENDING","RANGING","REVERSAL","TRANSITION"]
    setup_quality:float=Field(ge=0.0,le=1.0)
    risk_assessment:Literal["LOW","NORMAL","ELEVATED","HIGH"]
    reason_code:str=Field(min_length=1,max_length=128)

class DecisionResponse(BaseModel):
    model_config=ConfigDict(extra="forbid")
    status:Literal["OK"]
    data:DecisionData
