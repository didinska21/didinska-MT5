from __future__ import annotations
import time
from app.ai.groq_client import GroqClient
from app.audit.store import AuditStore
from app.api.schemas import DecisionData
from app.keys.key_manager import KeyManager
from app.circuit import circuit
from app.cache import make_cache_key, get, set_value

class AIService:
    def __init__(self):
        self.keys=KeyManager()
        self.groq=GroqClient(self.keys)
        self.audit=AuditStore()

    def decide(self,payload:dict)->DecisionData:
        if circuit.is_open:
            raise RuntimeError("CIRCUIT_OPEN")

        cache_key=make_cache_key(payload)
        cached=get(cache_key)
        if cached:
            result=DecisionData.model_validate(cached)
            return result

        started=time.perf_counter()
        try:
            result,_,latency=self.groq.decide(payload)
            circuit.success()
            set_value(cache_key,result.model_dump())
            self.audit.record(
                request_id=payload["request_id"],setup_id=payload["setup_id"],
                symbol=payload["symbol"],signal=payload["signal"],
                technical_score=payload["technical_score"],
                decision=result.decision,confidence=result.confidence,
                market_regime=result.market_regime,setup_quality=result.setup_quality,
                risk_assessment=result.risk_assessment,reason_code=result.reason_code,
                latency_ms=int(latency),status="OK")
            return result
        except RuntimeError as exc:
            circuit.failure()
            code=str(exc)
            try:
                self.audit.record(
                    request_id=payload["request_id"],setup_id=payload["setup_id"],
                    symbol=payload["symbol"],signal=payload["signal"],
                    technical_score=payload["technical_score"],
                    latency_ms=int((time.perf_counter()-started)*1000),
                    status="ERROR",error_code=code)
            except Exception:
                pass
            raise
