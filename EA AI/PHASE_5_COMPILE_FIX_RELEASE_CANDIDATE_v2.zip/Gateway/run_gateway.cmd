@echo off
setlocal
cd /d "%~dp0"
if not exist "..\xai-gateway-env\Scripts\python.exe" (
 echo [ERROR] Create the venv first: python -m venv xai-gateway-env
 exit /b 1
)
if not exist ".env" (
 echo [ERROR] Copy .env.example to .env and configure it first.
 exit /b 1
)
"..\xai-gateway-env\Scripts\python.exe" -m uvicorn main:app --host 127.0.0.1 --port 8787
