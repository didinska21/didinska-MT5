# Windows Gateway setup

From the project root:

```cmd
python -m venv xai-gateway-env
xai-gateway-env\Scripts\activate
python -m pip install --upgrade pip
python -m pip install -r Gateway\requirements.txt
copy Gateway\.env.example Gateway\.env
```

Edit `Gateway\.env` and set one gateway token plus `GROQ_API_KEY_01` ... `GROQ_API_KEY_10`.

Run:
```cmd
cd Gateway
..\xai-gateway-env\Scripts\python.exe -m uvicorn main:app --host 127.0.0.1 --port 8787
```

Health:
```cmd
curl http://127.0.0.1:8787/health
```

MT5 EA settings must use the same:
`InpGatewayURL = http://127.0.0.1:8787`
`InpGatewayToken = <same GATEWAY_TOKEN>`

MT5 must allow WebRequest to `http://127.0.0.1:8787`.
