# XAUUSD AI-GROQ Gateway

Active path:
MT5 EA -> FastAPI -> 10-key Groq pool -> Groq API

Groq secrets exist only in `.env` on the Gateway machine.

Key policy:
- least-recently-used available key
- 429 cooldown
- 401/403 disable
- network/timeout failover
- all keys unavailable => 503 / no AI decision
- strict response validation
- gateway token authentication
